import { FormGroup, AbstractControl } from '@angular/forms';
import { isNullOrUndefined } from 'util';
import * as $ from "jquery";

export class BaseValidator {
  static ValidateErrorMessage(c: AbstractControl, controlName: string): string {
    if (!isNullOrUndefined(c.errors)) {
      if (c.errors.required) {
        //return "Please specify the " + controlName + '.';
        return "Please specify this required field.";
      }
      else if (c.errors.email) {
        return "Please enter the valid email address.";
      }
      else if (c.errors.minlength) {
        return (controlName + ' is too short(minimum ' + c.errors['minlength']['requiredLength'] + ' characters.');
      }
      else if (c.errors.pattern) {
        return controlName + ' is not following correct pattern.';
      }
      else if (c.errors.maxlength) {
        return (controlName + ' is too long( maximum length is ' + c.errors['maxlength']['requiredLength'] + ' characters.');
      }
    }
    return "";
  }

  static ValidateFormControl(form: FormGroup) {
    for (let key in form.controls) {
      let control = form.controls[key];
      let r = this.ValidateErrorMessage(control, key);
      var currentInput = $("[formControlName=" + key + "]");
      if ($("#" + key + "spn").length == 0) {
        currentInput.parent().append($("<span class='ngvalidationmsg' id=" + key + "spn />"));
      }
      $("#" + key + "spn").text(r);
    }
  }
}