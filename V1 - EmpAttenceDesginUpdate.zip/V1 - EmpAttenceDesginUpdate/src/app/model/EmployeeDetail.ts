import { Component } from '@angular/core';

export class EmployeeDetail{
    name: string;
    address: string;
    city: string;
    role: any[];
    type: any[];
    phonenumber: string;
    remarks: string;
    status: boolean=true;
    referencename: string;
    referencephonenumber: string;
}

export class EmployeeDetailFireBase extends EmployeeDetail{
    key: string;
}