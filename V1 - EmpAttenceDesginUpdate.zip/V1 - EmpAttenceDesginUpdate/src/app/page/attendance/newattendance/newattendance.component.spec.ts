import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewattendanceComponent } from './newattendance.component';

describe('NewattendanceComponent', () => {
  let component: NewattendanceComponent;
  let fixture: ComponentFixture<NewattendanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewattendanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewattendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
