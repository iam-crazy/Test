import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule,NgZone } from '@angular/core';
import { ButtonsModule } from 'ngx-bootstrap';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from "@angular/common";

import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { LoginComponent } from './page/login/login.component';

import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireDatabaseModule } from 'angularfire2/database';

import { routing } from './app.routing'

///Enviornment///
import { environment } from '../environments/environment';

///Provider///
import { AuthService } from './services/auth.service'
import { SessionBehaviour } from './framework/SessionBehaviour'
import { FirebaseService } from './services/firebase.service'
import { StatusToStringPipe } from './pipes/status/status-to-string.pipe';
import { FirebasecloudstoreService } from './services/firebasecloudstore.service'


///Component///
import { PageNotFoundComponent } from './page/page-not-found/page-not-found.component';
import { LayoutComponent } from './layout/layout/layout.component';
import { EmployeeComponent } from './page/employee/employee.component';
import { NewEmployeeComponent } from './page/employee/new-employee/new-employee.component';

///Prime NG///
import { InputTextModule } from 'primeng/inputtext';
import { DataTableModule } from 'primeng/datatable';
import { ButtonModule } from 'primeng/button';
import { MenubarModule } from 'primeng/menubar';
import { DropdownModule } from 'primeng/dropdown';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { CalendarModule } from 'primeng/calendar';

/// Prime NG Service///
import { ConfirmationService } from 'primeng/api';
import { AttendanceComponent } from './page/attendance/attendance.component';
import { NewattendanceComponent } from './page/attendance/newattendance/newattendance.component';
import { CustomDatePipePipe } from './pipes/custom-date-pipe/custom-date-pipe.pipe';

///Class

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    PageNotFoundComponent,
    LayoutComponent,
    EmployeeComponent,
    NewEmployeeComponent,
    StatusToStringPipe,
    AttendanceComponent,
    NewattendanceComponent,
    CustomDatePipePipe,
  ],
  imports: [
    routing,
    BrowserModule,
    NoopAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ButtonsModule.forRoot(),
    AngularFireModule.initializeApp(environment.firebase, 'mositen'),
    AngularFirestoreModule,
    AngularFireAuthModule,
    AngularFireDatabaseModule,

    ///Prime NG//
    ButtonModule,
    MenubarModule,
    InputTextModule,
    DataTableModule,
    DropdownModule,
    ToggleButtonModule,
    ConfirmDialogModule,
    CalendarModule
  ],
  providers: [AuthService, SessionBehaviour, FirebaseService, ConfirmationService, FirebasecloudstoreService],
  bootstrap: [AppComponent]
})
export class AppModule { }
