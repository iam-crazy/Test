export class SessionBehaviour {
    setSessionStorage(key: string, value: string) {
      sessionStorage.setItem(key, value);
    }
  
    getSessionStorage(key: string): string {
      return sessionStorage.getItem(key);
    }

    removeSession(key: string){
      sessionStorage.removeItem(key);
    }

    clearAll(){
      sessionStorage.clear();
    }
  }