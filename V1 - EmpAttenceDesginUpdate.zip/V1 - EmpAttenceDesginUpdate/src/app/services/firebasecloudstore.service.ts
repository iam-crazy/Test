import { Injectable } from '@angular/core';
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class FirebasecloudstoreService {

  ngInit(){
    console.log("inject issue");
  }
  constructor(private db: AngularFirestore) {
  console.log("inject issue");
  }

  get(path: string): Observable<any[]> {
    return this.db.collection(path).snapshotChanges().map(changes => 
      {
      return changes.map(c => { return { key: c.payload.doc.id, ...c.payload.doc.data() }; });
    });
  }

  getSingle(path: string, id: string): any {
    return this.db.collection(path).doc(id).valueChanges();
  }

  add(path: string, item: any): void {
    this.db.collection(path).add(item);
  }

  update(path: string, item: any, id: string): void {
    this.db.collection(path).doc(id).update(item);
  }

  delete(path: string, id: string): void {
    this.db.doc(path).delete();
  }

  // deleteEntire(path: string): void  {
  //   this.db.doc(path).remove();
  // }

}
