import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { AttendanceDetailFireBase, AttendanceDetailFireBaseWithKey } from "../model/Attendance";

@Injectable()
export class FirebaseService {

  
 constructor(private db: AngularFireDatabase) {}

 get(path: string): Observable<any[]> {
   return this.db.list(path).snapshotChanges().map(changes => {
    changes.forEach(function(c){
      console.log("Tabel");
      console.log(c.payload.key);
      console.table(c.payload.val() as AttendanceDetailFireBase);
      console.log("Tabel Over");
    }) 

     return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
   });
 }

 getSingle(path: string, key: string): any {
   return this.db.object(path + '/' + key).valueChanges();
 }

 add(path: string, item: any): void {
    this.db.list(path).push(item);
 }

 update(path: string, item: any, key: string): void {
    this.db.list(path).update(key, item);
 }

 delete(path: string, key: string): void {
     this.db.list(path).remove(key);
 }

 deleteEntire(path: string): void  {
   this.db.list(path).remove();
 }


}
