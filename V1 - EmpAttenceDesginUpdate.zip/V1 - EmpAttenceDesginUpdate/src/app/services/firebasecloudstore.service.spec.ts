import { TestBed, inject } from '@angular/core/testing';

import { FirebasecloudstoreService } from './firebasecloudstore.service';

describe('FirebasecloudstoreService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FirebasecloudstoreService]
    });
  });

  it('should be created', inject([FirebasecloudstoreService], (service: FirebasecloudstoreService) => {
    expect(service).toBeTruthy();
  }));
});
