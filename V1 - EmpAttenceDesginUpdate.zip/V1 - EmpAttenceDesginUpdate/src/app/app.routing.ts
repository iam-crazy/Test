import { AppComponent } from './app.component';
import { LoginComponent } from './page/login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout/layout.component';
import { PageNotFoundComponent } from './page/page-not-found/page-not-found.component';
import { EmployeeComponent } from './page/employee/employee.component';
import { AttendanceComponent } from './page/attendance/attendance.component';
import { NewattendanceComponent } from './page/attendance/newattendance/newattendance.component';
import { NewEmployeeComponent } from './page/employee/new-employee/new-employee.component';
import { HeaderComponent } from './shared/header/header.component';

const appRoutes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: '',
                component: HeaderComponent
            },
            {
                path: 'header',
                component: HeaderComponent
            },
            {
                path: 'employee',
                component: EmployeeComponent
            },
            {
                path: 'attendance',
                component: AttendanceComponent
            },
            {
                path: 'newattendance',
                component: NewattendanceComponent
            },
            {
                path: 'newattendance/:key',
                component: NewattendanceComponent
            },
            
            {
                path: 'newemployee',
                component: NewEmployeeComponent
            },
            {
                path: 'newemployee/:key',
                component: NewEmployeeComponent
            },

        ]
    },

    {
        path: '**',
        component: PageNotFoundComponent
    }
];

export const routing = RouterModule.forRoot(appRoutes);