﻿// ------------------------------------------------------------------------------//
// <copyright file="Utility.cs" company="anantH Enterprises">
//   Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//

namespace Ah.Framwork.SqlClient.Helper
{
    using System.Data.SqlClient;
    using System.Reflection;

    /// <summary>
    /// Defines the <see cref="Common" />
    /// </summary>
    class Common
    {
        #region Methods

        /// <summary>
        /// The ConvertToType
        /// </summary>
        /// <param name="prop">The <see cref="PropertyInfo"/></param>
        /// <param name="obj">The <see cref="object"/></param>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        internal static void ConvertToType(PropertyInfo prop, object obj, SqlDataReader reader)
        {
            switch (prop.PropertyType.Name.ToUpper())
            {
                case "INT16":
                    prop.SetValue(obj, Utility.ConvertInt16(reader[prop.Name]), null);
                    break;
                case "INT32":
                    prop.SetValue(obj, Utility.ConvertInt32(reader[prop.Name]), null);
                    break;
                case "INT64":
                    prop.SetValue(obj, Utility.ConvertInt64(reader[prop.Name]), null);
                    break;
                case "SHORT":
                    prop.SetValue(obj, Utility.ConvertInt16(reader[prop.Name]), null);
                    break;
                case "INT":
                    prop.SetValue(obj, Utility.ConvertInt32(reader[prop.Name]), null);
                    break;
                case "LONG":
                    prop.SetValue(obj, Utility.ConvertInt64(reader[prop.Name]), null);
                    break;
                case "BOOL":
                    prop.SetValue(obj, Utility.ToBoolean(reader[prop.Name]), null);
                    break;
                case "CHAR":
                    prop.SetValue(obj, Utility.ToChar(reader[prop.Name]), null);
                    break;
                case "DATETIME":
                    prop.SetValue(obj, Utility.ToDate(reader[prop.Name]), null);
                    break;
                case "DateTimeOffset":
                    prop.SetValue(obj, Utility.ToDateTimeOffset(reader[prop.Name]), null);
                    break;
                case "DECIMAL":
                    prop.SetValue(obj, Utility.ToDecimal(reader[prop.Name]), null);
                    break;
                case "DOUBLE":
                    prop.SetValue(obj, Utility.ToDouble(reader[prop.Name]), null);
                    break;
                case "STRING":
                    prop.SetValue(obj, Utility.ToString(reader[prop.Name]), null);
                    break;
            }
        }

        #endregion
    }
}

