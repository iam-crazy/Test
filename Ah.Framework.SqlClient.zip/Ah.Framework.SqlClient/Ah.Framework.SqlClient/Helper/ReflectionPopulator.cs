﻿//-----------------------------------------------------------------------
// <copyright file = "ReflectionPopulator.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ReflectionPopulator.cs. </summary>
//-----------------------------------------------------------------------

namespace Ah.Framwork.SqlClient.Helper
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;

    /// <summary>
    /// Defines the <see cref="ReflectionPopulator{T}" />
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public static class ReflectionPopulator<T>
    {
        #region Methods

        /// <summary>
        /// The CreateList
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="List{T}"/></returns>
        public static List<T> CreateList(SqlDataReader reader)
        {
            var results = new List<T>();
            var properties = typeof(T).GetProperties();

            while (reader.Read())
            {
                var item = Activator.CreateInstance<T>();
                foreach (var property in typeof(T).GetProperties())
                {
                    if (!reader.IsDBNull(reader.GetOrdinal(property.Name)))
                    {
                        Type convertTo = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                        property.SetValue(item, Convert.ChangeType(reader[property.Name], convertTo), null);
                    }
                }
                results.Add(item);
            }
            return results;
        }

        #endregion
    }
}
