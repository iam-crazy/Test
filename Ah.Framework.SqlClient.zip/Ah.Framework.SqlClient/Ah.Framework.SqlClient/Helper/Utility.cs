﻿// ------------------------------------------------------------------------------//
// <copyright file="Utility.cs" company="anantH Enterprises">
//   Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//

namespace Ah.Framwork.SqlClient.Helper
{
    using System;

    /// <summary>
    /// Initialize Utility class
    /// </summary>
    internal static class Utility
    {
        #region Methods

        /// <summary>
        /// This is method is used for short Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Short value.</param>
        /// <returns>Returns The Short Value.</returns>
        internal static short ConvertInt16<T>(T value)
        {
            if (value == null)
            {
                return default(short);
            }

            var input = value.ToString();
            short resout;
            return short.TryParse(input, out resout) ? resout : default(short);
        }

        /// <summary>
        /// This is method is used for Integer Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="parameterName">Integer value.</param>
        /// <returns>Returns The Integer Value.</returns>
        internal static int ConvertInt32<T>(T parameterName)
        {
            if (parameterName == null)
            {
                return default(int);
            }

            var input = parameterName.ToString();
            int resout;
            return int.TryParse(input, out resout) ? resout : default(int);
        }

        /// <summary>
        /// This method is used for Long conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Long value.</param>
        /// <returns>Returns The Long Value.</returns>
        internal static long ConvertInt64<T>(T value)
        {
            if (value == null)
            {
                return default(long);
            }

            var input = value.ToString();
            long resout;
            return long.TryParse(input, out resout) ? resout : default(long);
        }

        /// <summary>
        /// This method is used for boolean conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Boolean value.</param>
        /// <returns>Returns The Boolean Value.</returns>
        internal static bool ToBoolean<T>(T value)
        {
            if (value == null)
            {
                return default(bool);
            }

            var input = value.ToString();
            bool resout;
            return bool.TryParse(input, out resout) ? resout : default(bool);
        }

        /// <summary>
        /// This method is used for Character Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Character value.</param>
        /// <returns>Returns The Character Value.</returns>
        internal static char ToChar<T>(T value)
        {
            if (value == null)
            {
                return default(char);
            }

            var input = value.ToString();
            char resout;
            return char.TryParse(input, out resout) ? resout : default(char);
        }

        /// <summary>
        /// This method is used for Date Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Date value.</param>
        /// <returns>Returns The DateTime Value.</returns>
        internal static DateTime ToDate<T>(T value)
        {
            if (value == null)
            {
                return default(DateTime);
            }

            var input = value.ToString();
            DateTime resout;
            return DateTime.TryParse(input, out resout) ? resout : default(DateTime);
        }

        /// <summary>
        /// This method is used for DateTime Offset Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Date value.</param>
        /// <returns>Returns The DateTime offset Value.</returns>
        internal static DateTimeOffset ToDateTimeOffset<T>(T value)
        {
            if (value == null)
            {
                return default(DateTimeOffset);
            }

            var input = value.ToString();
            DateTimeOffset resout;
            return DateTimeOffset.TryParse(input, out resout) ? resout : default(DateTimeOffset);
        }

        /// <summary>
        /// This method is used for Decimal Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Decimal value.</param>
        /// <returns>Returns The Value.</returns>
        internal static decimal ToDecimal<T>(T value)
        {
            if (value == null)
            {
                return default(decimal);
            }

            var input = value.ToString();
            decimal resout;
            return decimal.TryParse(input, out resout) ? resout : default(decimal);
        }

        /// <summary>
        /// This method is used for Double Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Double value.</param>
        /// <returns>Returns The Value.</returns>
        internal static double ToDouble<T>(T value)
        {
            if (value == null)
            {
                return default(double);
            }

            var input = value.ToString();
            double resout;
            return double.TryParse(input, out resout) ? resout : default(double);
        }

        /// <summary>
        /// This method is used for string conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">String value.</param>
        /// <returns>Returns The String Value.</returns>
        internal static string ToString<T>(T value)
        {
            if (value == null)
            {
                return string.Empty;
            }
            else
            {
                return value.ToString();
            }
        }

        /// <summary>
        /// This method is used to split a string to an string array by splitting the "\r\n".
        /// </summary>
        /// <param name="value">Multi-line String.</param>
        /// <returns>Returns String Array based on "\r\n".</returns>
        internal static string[] ToStringArray(this string value)
        {
            return value.ToStringArray(separator: "\r\n");
        }

        /// <summary>
        /// This method is used to split a string to an string array.
        /// </summary>
        /// <param name="value">    Multi-line String.</param>
        /// <param name="separator">String separator.</param>
        /// <returns>Returns String Array based on separator.</returns>
        internal static string[] ToStringArray(this string value, string separator)
        {
            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            if (string.IsNullOrEmpty(separator))
            {
                var arrayvalue = new string[1];
                arrayvalue[0] = value;
                return arrayvalue;
            }

            return value.Split(separator.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
        }

        #endregion
    }
}
