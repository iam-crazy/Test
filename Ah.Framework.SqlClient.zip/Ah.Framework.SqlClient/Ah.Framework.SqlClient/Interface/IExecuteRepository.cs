﻿//-----------------------------------------------------------------------
// <copyright file = "IExecuteRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IExecuteRepository.cs. </summary>
//-----------------------------------------------------------------------

namespace Ah.Framwork.SqlClient.Interface
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Initialize IExecuteDataRepository interface Api key 48c04ecd-46ae-4649-bfb9-1307f9b7721c
    /// </summary>
    public interface IExecuteRepository
    {
        #region Methods

        /// <summary>
        /// The ExecuteDataReaderMapToList
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="List{T}"/></returns>
        List<T> ExecuteDataReaderMapToList<T>(string connectionString, string procName, SqlParameter[] parameters);

        /// <summary>
        /// The ExecuteDataReaderMapToList
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="parameter1">The <see cref="string"/></param>
        /// <param name="parameter2">The <see cref="string"/></param>
        /// <returns>The <see cref="Tuple{IList{T}, string, string}"/></returns>
        Tuple<IList<T>, string, string> ExecuteDataReaderMapToList<T>(string connectionString, string procName, SqlParameter[] parameters, string parameter1, string parameter2);

        /// <summary>
        /// The ExecuteDataReaderMapToListAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task{List{T}}"/></returns>
        Task<List<T>> ExecuteDataReaderMapToListAsync<T>(string connectionString, string procName, SqlParameter[] parameters);

        /// <summary>
        /// The ExecuteDataReaderMapToListAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="parameter1">The <see cref="string"/></param>
        /// <param name="parameter2">The <see cref="string"/></param>
        /// <returns>The <see cref="Task{Tuple{IList{T}, string, string}}"/></returns>
        Task<Tuple<IList<T>, string, string>> ExecuteDataReaderMapToListAsync<T>(string connectionString, string procName, SqlParameter[] parameters, string parameter1 = null, string parameter2 = null);

        /// <summary>
        /// The ExecuteNonQuery
        /// </summary>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task{object}"/></returns>
        Task<object> ExecuteNonQuery(string connectionString, string procName, SqlParameter[] parameters);

        #endregion
    }

    #endregion
}
