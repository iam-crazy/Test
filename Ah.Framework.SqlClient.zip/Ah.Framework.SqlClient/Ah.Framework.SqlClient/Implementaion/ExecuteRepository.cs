﻿//-----------------------------------------------------------------------
// <copyright file = "ExecuteRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ExecuteRepository.cs. </summary>
//-----------------------------------------------------------------------

namespace Ah.Framwork.SqlClient.Implementaion
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Threading.Tasks;
    using Helper;
    using Interface;

    /// <summary>
    /// Defines the <see cref="ExecuteRepository" />Api key 48c04ecd-46ae-4649-bfb9-1307f9b7721c
    /// </summary>
    public class ExecuteRepository : IExecuteRepository
    {
        #region Methods

        /// <summary>
        /// The ExecuteDataReaderMapToListNotAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="List{T}"/></returns>
        public List<T> ExecuteDataReaderMapToList<T>(string connectionString, string procName, SqlParameter[] parameters)
        {
            var output = new List<T>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            output = ReflectionPopulator<T>.CreateList(reader);
                        }
                    }
                }
            }
            return output;
        }

        /// <summary>
        /// The ExecuteDataReaderMapToListNotAsync
        /// </summary>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="parameter1">todo: describe parameter1 parameter on ExecuteDataReaderMapToList</param>
        /// <param name="parameter2">todo: describe parameter2 parameter on ExecuteDataReaderMapToList</param>
        /// <typeparam name="T"></typeparam>
        /// <returns>The <see cref="List{T}"/></returns>
        public Tuple<IList<T>, string, string> ExecuteDataReaderMapToList<T>(string connectionString, string procName, SqlParameter[] parameters, string parameter1, string parameter2)
        {
            var output = new List<T>();
            var tempParameter1 = string.Empty;
            var tempParameter2 = string.Empty;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            output = ReflectionPopulator<T>.CreateList(reader);
                        }
                    }

                    if (!string.IsNullOrEmpty(parameter1))
                    {
                        tempParameter1 = Convert.ToString(command.Parameters[parameter1].Value);
                    }

                    if (!string.IsNullOrEmpty(parameter2))
                    {
                        tempParameter2 = Convert.ToString(command.Parameters[parameter2].Value);
                    }
                }
            }
            return new Tuple<IList<T>, string, string>(output, tempParameter1, tempParameter2);
        }

        /// <summary>
        /// The ExecuteDataReaderMapToList
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task{List{T}}"/></returns>
        public async Task<List<T>> ExecuteDataReaderMapToListAsync<T>(string connectionString, string procName, SqlParameter[] parameters)
        {
            var output = new List<T>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            output = ReflectionPopulator<T>.CreateList(reader);
                        }
                    }
                }
            }
            return output;
        }

        /// <summary>
        /// The ExecuteDataReaderMapToList
        /// </summary>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="parameter1">todo: describe parameter1 parameter on ExecuteDataReaderMapToListAsync</param>
        /// <param name="parameter2">todo: describe parameter2 parameter on ExecuteDataReaderMapToListAsync</param>
        /// <typeparam name="T"></typeparam>
        /// <returns>The <see cref="Task{List{T}}"/></returns>
        public async Task<Tuple<IList<T>, string, string>> ExecuteDataReaderMapToListAsync<T>(string connectionString, string procName, SqlParameter[] parameters, string parameter1 = null, string parameter2 = null)
        {
            var output = new List<T>();
            var tempParameter1 = string.Empty;
            var tempParameter2 = string.Empty;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            output = ReflectionPopulator<T>.CreateList(reader);
                        }
                    }

                    if (!string.IsNullOrEmpty(parameter1))
                    {
                        tempParameter1 = Convert.ToString(command.Parameters[parameter1].Value);
                    }

                    if (!string.IsNullOrEmpty(parameter2))
                    {
                        tempParameter2 = Convert.ToString(command.Parameters[parameter2].Value);
                    }
                }
            }
            return new Tuple<IList<T>, string, string>(output, tempParameter1, tempParameter2);
        }

        /// <summary>
        /// The ExecuteNonQuery
        /// </summary>
        /// <param name="connectionString">The <see cref="string"/></param>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task{object}"/></returns>
        public async Task<object> ExecuteNonQuery(string connectionString, string procName, SqlParameter[] parameters)
        {
            object output = string.Empty;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    await command.ExecuteNonQueryAsync();
                    output = command.Parameters["OUTPUT"].Value;
                    connection.Close();
                }
            }
            return output;
        }

        #endregion
    }
}
