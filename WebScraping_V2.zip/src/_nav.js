export default {
  items: [
    {
      name: 'Dashboard',
      url: '/dashboard',
      icon: 'fa fa-tachometer'
    },
    {
      name: 'configuration',
      url: '/configuration',
      icon: 'fa fa-puzzle-piece',
      children: [
        {
          name: 'Document Setup',
          url: '/configuration/documentsetup',
          icon: 'fa fa-file-text'
        }
      ]
    },
    {
      name: 'Operation',
      url: '/operation',
      icon: 'fa fa-clock-o',
      children: [
        {
          name: 'Preprocessed Image',
          url: '/operation/preprocessedimage',
          icon: 'fa fa-image'
        },
        {
          name: 'Classification',
          url: '/operation/classification',
          icon: 'fa fa-star'
        },
        {
          name: 'MetaData Extraction',
          url: '/operation/metadataextraction',
          icon: 'fa fa-cloud-upload'
        },
        {
          name: 'MetaData(3JS)',
          url: '/operation/metadataextractionthree',
          icon: 'fa fa-cloud-upload'
        }
      ]
    }
  ]
}
