<template lang="html">

  <section class="document-setup">
    <h1>document-setup Component</h1>
  </section>

</template>

<script lang="js">
  export default  {
    name: 'document-setup',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style>
</style>
