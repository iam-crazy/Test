<template lang="html">

  <section class="classification">
    <h1>classification Component</h1>
  </section>

</template>

<script lang="js">
  export default  {
    name: 'classification',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style>
</style>
