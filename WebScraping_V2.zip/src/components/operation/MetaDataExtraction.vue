<template lang="html">

  <section class="meta-data-extraction">
    <h1>meta-data-extraction Component</h1>
  </section>

</template>

<script lang="js">
  export default  {
    name: 'meta-data-extraction',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style>
</style>
