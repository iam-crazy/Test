<template lang="html">
<div>
  <section class="dashboard">
    <h1>dashboard Component</h1>
  </section>
</div>
</template>

<script lang="js">
  export default  {
    name: 'dashboard',
    props: [],
    mounted() {

    },
    data() {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}
</script>

<style>
</style>
