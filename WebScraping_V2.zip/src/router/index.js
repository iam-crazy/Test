import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

export default new Router({
  mode: 'hash', // https://router.vuejs.org/api/#mode
  linkActiveClass: 'open active',
  scrollBehavior: () => ({
    y: 0
  }),
  routes: [
    {
      path: '/',
      redirect: '/dashboard',
      name: 'Home',
      component: () => import('../components/shared/TheLayout.vue'),
      children: [
        {
          path: 'dashboard',
          name: 'Dashboard',
          component: () => import('@/components/Dashboard')
        },
        {
          path: 'configuration',
          name: 'Configuration',
          component: {
            render(c) {
              return c('router-view')
            }
          },
          children: [
            {
              path: 'documentsetup',
              name: 'Document Setup',
              component: () =>
                import('@/components/configuration/DocumentSetup')
            }
          ]
        },
        {
          path: 'operation',
          name: 'Operation',
          component: {
            render(c) {
              return c('router-view')
            }
          },
          children: [
            {
              path: 'preprocessedimage',
              name: 'Preprocessed Image',
              component: () =>
                import('@/components/operation/PreprocessedImage')
            },
            {
              path: 'classification',
              name: 'Classification',
              component: () => import('@/components/operation/Classification')
            },
            {
              path: 'metadataextraction',
              name: 'MetaData Extraction',
              component: () =>
                import('@/components/operation/MetaDataExtraction')
            },
            {
              path: 'metadataextractionthree',
              name: 'MetaData(3JS)',
              component: () =>
                import('@/components/operation/MetaDataExtractionThree')
            }
          ]
        }
      ]
    }
  ]
})
