﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;




namespace UniforPayroll
{
    public partial class salarystructure : Form
    {

        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");


        public salarystructure()
        {
            InitializeComponent();
        }

        
       

        private void button1_Click(object sender, EventArgs e)
        {
            txtearnmonbasic.Text = (Convert.ToInt32(txtearnyrbasic.Text) / 12).ToString();
            txtearnmonhra.Text = (Convert.ToInt32(txtearnyrhra.Text) / 12).ToString();
            txtearnmonlta.Text = (Convert.ToInt32(txtearnyrlta.Text) / 12).ToString();
            txtearnmonconvey.Text = (Convert.ToInt32(txtearnyrconvey.Text) / 12).ToString();
            txtearnmonsplallow.Text = (Convert.ToInt32(txtearnyrsplallow.Text) / 12).ToString();
            txtearnmonattrallow.Text = (Convert.ToInt32(txtearnyrattrallow.Text) / 12).ToString();
            txtearnmonmedallow.Text = (Convert.ToInt32(txtearnyrmedallow.Text) / 12).ToString();

            //Gross take home calc
            float grosstakhomeyr;
            
            txtgrossyrtakhome.Text = ((Convert.ToInt32(txtearnyrbasic.Text)) + (Convert.ToInt32(txtearnyrhra.Text)) + (Convert.ToInt32(txtearnyrlta.Text)) + (Convert.ToInt32(txtearnyrconvey.Text)) + (Convert.ToInt32(txtearnyrsplallow.Text)) + (Convert.ToInt32(txtearnyrattrallow.Text)) + (Convert.ToInt32(txtearnyrmedallow.Text))).ToString();
            txtgrossmontakhome.Text = (Convert.ToInt32(txtgrossyrtakhome.Text) / 12).ToString();

            grosstakhomeyr=Convert.ToInt32(txtgrossyrtakhome.Text);


            txtreimbmondriverallow.Text = (Convert.ToInt32(txtreimbyrdriverallow.Text) / 12).ToString();
            txtreimbmonvehicmaintnce.Text = (Convert.ToInt32(txtreimbyrvehicmaintnce.Text) / 12).ToString();
            txtreimbmonrelocallow.Text = (Convert.ToInt32(txtreimbyrrelocallow.Text) / 12).ToString();

            //Monthly take home calc

            txtyrtotmontakhome.Text = ((Convert.ToInt32(txtgrossyrtakhome.Text)) + (Convert.ToInt32(txtreimbyrdriverallow.Text)) + (Convert.ToInt32(txtreimbyrvehicmaintnce.Text)) + (Convert.ToInt32(txtreimbyrrelocallow.Text))).ToString();
            txtmontotmontakhome.Text = (Convert.ToInt32(txtyrtotmontakhome.Text) / 12).ToString();

            float totmontakehomeyr;
            totmontakehomeyr = Convert.ToInt32(txtyrtotmontakhome.Text);

            //deduction calc

            txtdeducmonpfdeduc.Text = (Convert.ToInt32(txtdeducyrpfdeduc.Text) / 12).ToString();
            txtdeducmonesic.Text = (Convert.ToInt32(txtdeducyresic.Text) / 12).ToString();

            float totdeductionyearly;
            float totdeductionmonthly;
            float pfdeducyr;
            float esicdeducyr;
            pfdeducyr = Convert.ToInt32(txtdeducyrpfdeduc.Text);
            esicdeducyr = Convert.ToInt32(txtdeducyresic.Text);
            totdeductionyearly = pfdeducyr + esicdeducyr;
            totdeductionmonthly = totdeductionyearly / 12;

            //Nettake home calc
            float nettakehomeyr;
            nettakehomeyr = totmontakehomeyr - totdeductionyearly;
            txtyrnettakhome.Text = nettakehomeyr.ToString();
            txtmontotmontakhome.Text = (Convert.ToInt32(txtyrnettakhome.Text) / 12).ToString();

            //others calc

            txtothermonpf.Text = (Convert.ToInt32(txtotheryrpf.Text) / 12).ToString();
            txtothermonesic.Text = (Convert.ToInt32(txtotheryresic.Text) / 12).ToString();
            txtothermonmedic.Text = (Convert.ToInt32(txtotheryrmedic.Text) / 12).ToString();
            txtothermonbonus.Text = (Convert.ToInt32(txtotheryrbonus.Text) / 12).ToString();
            txtothermonmealvou.Text = (Convert.ToInt32(txtotheryrmealvou.Text) / 12).ToString();

            float otherpfyr;
            float otheresicyr;
            float othermedic;
            float otherbonus;
            float othermealvou;
            float totalothersyr;

            otherpfyr = Convert.ToInt32(txtotheryrpf.Text);
            otheresicyr = Convert.ToInt32(txtotheryresic.Text);
            othermedic = Convert.ToInt32(txtotheryrmedic.Text);
            otherbonus = Convert.ToInt32(txtotheryrbonus.Text);
            othermealvou = Convert.ToInt32(txtotheryrmealvou.Text);

            totalothersyr = otherpfyr + otheresicyr + othermedic + otherbonus + othermealvou;

            //final CTC calc

            float totfinalctc;

            totfinalctc = nettakehomeyr + totalothersyr;

            txtyrfinalctc.Text = totfinalctc.ToString();

            txtmonfinalctc.Text = (Convert.ToInt32(txtyrfinalctc.Text) / 12).ToString();
            





        }

        private void salarystructure_Load(object sender, EventArgs e)
        {

            //initialise textbox

            float basic = 0;

            txtearnyrbasic.Text = basic.ToString();
            txtearnyrhra.Text = basic.ToString();
            txtearnyrlta.Text = basic.ToString();
            txtearnyrconvey.Text = basic.ToString();
            txtearnyrsplallow.Text = basic.ToString();
            txtearnyrattrallow.Text = basic.ToString();
            txtearnyrmedallow.Text = basic.ToString();
                              
            txtreimbyrrelocallow.Text = basic.ToString();
            txtreimbyrvehicmaintnce.Text = basic.ToString();
            txtreimbyrdriverallow.Text = basic.ToString();

            txtdeducyresic.Text = basic.ToString();
            txtdeducyrpfdeduc.Text = basic.ToString();

            txtotheryrbonus.Text = basic.ToString();
            txtotheryresic.Text = basic.ToString();
            txtotheryrmealvou.Text = basic.ToString();
            txtotheryrpf.Text = basic.ToString();
            txtotheryrmedic.Text = basic.ToString();



            //txtyrfinalctc.Text=totfinalctc.ToString();

            //txtearnmonbasic.Text = ;


            conn.Open();
            SqlCommand cmd = new SqlCommand("select empcode from tblemployee", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "tblemployee");
            cmbempcode.DataSource = ds.Tables["tblemployee"];
            cmbempcode.DisplayMember = "empcode";
            cmbempcode.ValueMember = "empcode";
            cmbempcode.SelectedIndex = -1;

            conn.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            conn.Open();
            
            //SqlCommand cmd = new SqlCommand("insert into salstructure(empid,basic,hra,lta,conveyence,splallow,attirallow,mediallow,driverallow,vechiclemaint,relocallow,pfdeduc,esic,otherpf,otheresic,othermediclaim,otherbonus,othermealvou,grosstakhome,totmonthtakhome,nettakhome,finalctc,basicmon,hramon,ltamon,conveyencemon,splallowmon,attirallowmon,medicallowmon,driverallowmon,vechicmaintmon,relocmon,pfmon,esicmon,otherpfmon,otheresicmon,othermediclaimmon,otherbonusmon,othermealvoumon,grosstakhomemon,totmontakhomemon,nettakhomemon,finalctcmon)values('" +cmbempcode.Text+ "' ,'" +txtearnyrbasic.Text+ "','" +txtearnyrhra.Text+ "','" + txtearnyrlta.Text+ "','" +txtearnyrconvey.Text+ "','" + txtearnyrsplallow.Text + "','" +txtearnyrattrallow.Text+ "','" +txtearnyrmedallow.Text+ "','" +txtreimbmondriverallow.Text+ "','" +txtreimbyrvehicmaintnce.Text+ "','" +txtreimbyrrelocallow.Text+ "','" +txtdeducyrpfdeduc.Text+ "','" +txtdeducyresic.Text+ "','" +txtotheryrpf.Text+ "','" +txtotheryresic.Text+ "','" +txtotheryrmedic.Text+ "','" +txtotheryrbonus.Text+ "','" +txtotheryrmealvou.Text+ "','" +txtgrossyrtakhome.Text+ "','" +txtyrtotmontakhome.Text+ "','" +txtyrnettakhome.Text+ "','" +txtyrfinalctc.Text+ "','" +txtearnmonbasic.Text+ "','" +txtearnmonhra.Text+ "','" +txtearnmonlta.Text+ "','" +txtearnmonconvey+ "','" +txtearnmonsplallow.Text+ "','" +txtearnmonattrallow.Text+ "','" +txtearnmonmedallow.Text+ "','" +txtreimbmondriverallow.Text+ "','" +txtreimbmonvehicmaintnce.Text+ "','" +txtreimbmonrelocallow.Text+ "','" +txtdeducmonpfdeduc.Text+ "','" +txtdeducmonesic.Text+ "','" +txtothermonpf.Text+ "','" +txtothermonesic.Text+ "','" +txtothermonmedic.Text+ "','" +txtothermonbonus.Text+ "','" +txtothermonmealvou.Text+ "','" +txtgrossmontakhome.Text+ "','" +txtmontotmontakhome.Text+ "','" +txtmonnettakhome.Text+ "','" +txtmonfinalctc.Text+ "' )",conn);
            SqlCommand cmd = new SqlCommand("insert into salstructure(empcode,basic,hra,lta,conveyence,splallow,attirallow,mediallow,driverallow,vechiclemaint,relocallow,pfdeduc,esic,otherpf,otheresic,othermediclaim,otherbonus,othermealvou,grosstakhome,totmonthtakhome,nettakhome,finalctc,basicmon,hramon,ltamon,conveyencemon,splallowmon,attirallowmon,medicallowmon,driverallowmon,vechicmaintmon,relocmon,pfmon,esicmon,otherpfmon,otheresicmon,othermediclaimmon,otherbonusmon,othermealvoumon,grosstakhomemon,totmontakhomemon,nettakhomemon,finalctcmon)values('" + cmbempcode.Text + "','" + txtearnyrbasic.Text + "','" + txtearnyrhra.Text + "','" + txtearnyrlta.Text + "','" + txtearnyrconvey.Text + "','" + txtearnyrsplallow.Text + "','" + txtearnyrattrallow.Text + "','" + txtearnyrmedallow.Text + "','" + txtreimbyrdriverallow.Text + "','" + txtreimbyrvehicmaintnce.Text + "','" + txtreimbyrrelocallow.Text + "','" + txtdeducyrpfdeduc.Text + "','" + txtdeducyresic.Text + "','" + txtotheryrpf.Text + "','" + txtotheryresic.Text + "','" + txtotheryrmedic.Text + "','" + txtotheryrbonus.Text + "','" + txtotheryrmealvou.Text + "','" + txtgrossyrtakhome.Text + "','" + txtyrtotmontakhome.Text + "','" + txtyrnettakhome.Text + "','" + txtyrfinalctc.Text + "','" + txtearnmonbasic.Text + "','" + txtearnmonhra.Text + "','" + txtearnmonlta.Text + "','" + txtearnmonconvey.Text + "','" + txtearnmonsplallow.Text + "','" + txtearnmonattrallow.Text + "','" + txtearnmonmedallow.Text + "','" + txtreimbmondriverallow.Text + "','" + txtreimbmonvehicmaintnce.Text + "','" + txtreimbmonrelocallow.Text + "','" + txtdeducmonpfdeduc.Text + "','" + txtdeducmonesic.Text + "','" + txtothermonpf.Text + "','" + txtothermonesic.Text + "','" + txtothermonmedic.Text + "','" + txtothermonbonus.Text + "','" + txtothermonmealvou.Text + "','" + txtgrossmontakhome.Text + "','" + txtmontotmontakhome.Text + "','" + txtmonnettakhome.Text + "','" + txtmonfinalctc.Text + "' )", conn);

            
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Saved Successfully");

            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string cmbempval = cmbempcode.Text;


            salstrutureprint salstrcutfrm = new salstrutureprint();
            //salstrcutfrm.method(cmbempval);


            salstrcutfrm.Show();

            
           
           
            
            
        }

       

       

        

        

       

       

       
    }
}
