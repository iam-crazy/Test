﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UniforPayroll
{
    public partial class banksalstaement : Form
    {
        public banksalstaement()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CRsalarystatement crsalstate = new CRsalarystatement();
           
            crsalstate.SetDatabaseLogon("sa", "x", "UNIMAA0004-PC\\Sqlexpress", "unipayroll");
            
             crystalReportViewer1.SelectionFormula = "{command.fmonth}=('" + comboBox1.Text + "')";
            crystalReportViewer1.ReportSource = crsalstate;

        }
    }
}
