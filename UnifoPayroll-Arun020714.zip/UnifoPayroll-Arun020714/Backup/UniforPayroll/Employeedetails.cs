﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{
    public partial class Employeedetails : Form

        

    {

        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        public Employeedetails()


        {
            InitializeComponent();
        }

       

        private void Employeedetails_Load(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Maximized;

            lblempcode.Enabled = false;
            txtempname.Enabled = false;
            txtpermenadd.Enabled = false;
            txtpreadd.Enabled = false;
            dtpdob.Enabled = false;
            cmbgender.Enabled = false;
            cmbmaritialstatus.Enabled = false;
            txtphone.Enabled = false;
            txtmobile.Enabled = false;
            txtemail.Enabled = false;
            txtbankaccname.Enabled = false;
            txtbankaccno.Enabled = false;
            txtbankname.Enabled = false;
            txtbankbranch.Enabled = false;
            txtbankcity.Enabled = false;
            cmbdesig.Enabled = false;
            cmbdept.Enabled = false;
            cmbbranch.Enabled = false;
            cmbreportto.Enabled = false;
            dtpdoj.Enabled = false;
            dtpdor.Enabled = false;
            txtpanno.Enabled = false;
            txtpassportno.Enabled = false;
            txtdrivlicno.Enabled = false;
            txtblood.Enabled = false;
            txtbankcity.Enabled = false;
            txtbankbranch.Enabled = false;


            btnsave.Enabled = false;
            btnedit.Enabled = false;
            
            
            if(conn.State==ConnectionState.Open)
            {
                conn.Close();

            }


            conn.Open();
            SqlCommand cmd = new SqlCommand("select brname from mbranch", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds,"mbranch");
            cmbbranch.DataSource = ds.Tables["mbranch"];
            cmbbranch.DisplayMember = "brname";
            cmbbranch.ValueMember = "brname";
            cmbbranch.SelectedIndex = -1;

            
            SqlCommand cmd1 = new SqlCommand("select deptcode from mdept", conn);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1, "mdept");
            cmbdept.DataSource = ds1.Tables["mdept"];
            cmbdept.DisplayMember = "deptcode";
            //cmbbranch.ValueMember = "deptname";
            cmbdept.SelectedIndex = -1;

            

            SqlCommand cmd2 = new SqlCommand("select designame from mdesignation", conn);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2, "mdesignation");
            cmbdesig.DataSource = ds2.Tables["mdesignation"];
            cmbdesig.DisplayMember = "designame";

            cmbdesig.SelectedIndex = -1;
            conn.Close();

        }

        

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtempname.Focus();
            
            lblempcode.Enabled = true;
            txtempname.Enabled = true;
            txtpermenadd.Enabled = true;
            txtpreadd.Enabled = true;
            dtpdob.Enabled = true;
            cmbgender.Enabled = true;
            cmbmaritialstatus.Enabled = true;
            txtphone.Enabled = true;
            txtmobile.Enabled = true;
            txtemail.Enabled = true;
            txtbankaccname.Enabled = true;
            txtbankaccno.Enabled = true;
            txtbankname.Enabled = true;
            txtbankbranch.Enabled = true;
            txtbankcity.Enabled = true;
            cmbdesig.Enabled = true;
            cmbdept.Enabled = true;
            cmbbranch.Enabled = true;
            cmbreportto.Enabled = true;
            dtpdoj.Enabled = true;
            dtpdor.Enabled = true;
            txtpanno.Enabled = true;
            txtpassportno.Enabled = true;
            txtdrivlicno.Enabled = true;
            txtblood.Enabled = true;
            txtbankcity.Enabled = true;
            txtbankbranch.Enabled = true;

            btnsave.Enabled = true;
            btnedit.Enabled = false;

            
            int Num1 =0000 ;

            conn.Open();
            SqlCommand cmd = new SqlCommand("Select MAX(empid) from tblemployee", conn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Num1 = int.Parse(dr[0].ToString());
                
            }
            dr.Close();
            textBox1.Text = "UNIMAA" + (Num1 + 1).ToString();
            conn.Close();

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into tblemployee(empcode,name,preaddr,peraddr,dob,gender,maritialstatus,phoneno,mobiletno,designation,emailid,accname,accno,bank,bankbranch,bankcity,dept,branch,reportingto,doj,dor,panno,passportno,drivinglicno,blood)values('" +textBox1.Text+ "', '" + txtempname.Text + "','" + txtpreadd.Text + "','" + txtpermenadd.Text + "','" + dtpdob.Text + "','" + cmbgender.Text + "','" + cmbmaritialstatus.Text + "','" + txtphone.Text + "','" + txtmobile.Text + "','" + txtemail.Text + "','" + txtbankaccname.Text + "','" + txtbankaccno.Text + "','" + txtbankname.Text + "','" + txtbankbranch.Text + "','" + txtbankcity.Text + "','" + cmbdesig.Text + "','" + cmbdept.Text + "','" + cmbbranch.Text + "','" + cmbreportto.Text + "','" + dtpdoj.Text + "','" + dtpdor.Text + "','" + txtpanno.Text + "','" + txtpassportno.Text + "','" + txtdrivlicno.Text + "','" + txtblood.Text + "')", conn);
            
            
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Saved Successfully");
        }

        private void lblempcode_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

       
    }
}
