﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;


namespace UniforPayroll
{
    public partial class frmpayslip : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        public frmpayslip()
        {
            InitializeComponent();
        }

        private void frmpayslip_Load(object sender, EventArgs e)
        {

            btncalc.Enabled = false;
            btnsave.Enabled = false;
            btnprint.Enabled = false;
            btnclear.Enabled = false;
            

            txtdate.Text = DateTime.Now.ToString("dd-MMM-yyyy");

            txtdate.Enabled = false;

            loadpayslips_datagrid();
           
            
            load_dept();
            
            //load_emp();

            txtearnmonbasic.Enabled = false;
            txtearnmonhra.Enabled = false;
            txtearnmonlta.Enabled = false;
            txtearnmonconvey.Enabled = false;
            txtearnmonattrallow.Enabled = false;
            txtearnmonsplallow.Enabled = false;
            txtearnmonmedallow.Enabled = false;
            txtdeducmonpfdeduc.Enabled = false;
            txtdeducmonesic.Enabled = false;
            //txtothermonmedic.Enabled = false;
            //txtothermonbonus.Enabled = false;
            cmbdept.Enabled = false;
            cmbemp.Enabled = false;

            txtbox_init();
        }


        public void loadpayslips_datagrid()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select empcode,empname,dept,designation,fmonth,fyear,createddate from salarygen", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnCount = 7;

            dataGridView1.Columns[0].Name = "empcode";
            dataGridView1.Columns[0].HeaderText = "Emp Code";
            dataGridView1.Columns[0].DataPropertyName = "empcode";

            dataGridView1.Columns[1].Name = "empname";
            dataGridView1.Columns[1].HeaderText = "Employee Name";
            dataGridView1.Columns[1].DataPropertyName = "empName";

            dataGridView1.Columns[2].Name = "Dept";
            dataGridView1.Columns[2].HeaderText = "Department";
            dataGridView1.Columns[2].DataPropertyName = "Dept";

            dataGridView1.Columns[3].Name = "Designation";
            dataGridView1.Columns[3].HeaderText = "Designation";
            dataGridView1.Columns[3].DataPropertyName = "Designation";

            dataGridView1.Columns[4].Name = "fMonth";
            dataGridView1.Columns[4].HeaderText = "Month";
            dataGridView1.Columns[4].DataPropertyName = "fMonth";

            dataGridView1.Columns[5].Name = "fYear";
            dataGridView1.Columns[5].HeaderText = "Year";
            dataGridView1.Columns[5].DataPropertyName = "fYear";

            dataGridView1.Columns[6].Name = "Createddate";
            dataGridView1.Columns[6].HeaderText = "Created date";
            dataGridView1.Columns[6].DataPropertyName = "createddate";

            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = dt;

            conn.Close();

        }


        public void load_dept()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            //conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ("select deptcode,deptname from mdept where active='true' ");
            //cmd.Parameters.AddWithValue("@dept", dept);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter();
            SqlDataReader dr;
            conn.Open();

            da.SelectCommand = cmd;

            da.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {


                cmbdept.ValueMember = "deptcode";
                cmbdept.DisplayMember = "deptname";
                cmbdept.DataSource = ds.Tables[0];



            }
            conn.Close();

            

            //txtbox_init();
        }

         public void clear_textbox()
    {


        txtempcode1.Text = "";
        txtempname.Text = "";
        txtdept.Text = "";
        txtdesign.Text = "";  
        txtearnmonbasic.Text = "";
        txtearnmonhra.Text = "";
        txtearnmonlta.Text = "";
        txtearnmonconvey.Text = "";
        txtearnmonattrallow.Text = "";
        txtearnmonsplallow.Text = "";
        txtearnmonmedallow.Text = "";
        txtdeducmonpfdeduc.Text = "";
        txtdeducmonesic.Text = "";
        //txtothermonmedic.Text = "";
        //txtothermonbonus.Text = "";
        txtotherallow.Text = "";
        txtsalarrear.Text = "";
        txtotherpay.Text = "";
        txttotearn.Text = "";
        txtlop.Text = "";
        txtloan.Text = "";
        txtotherdeduc.Text = "";
        txttotdeduc.Text = "";
        txtnetsalary.Text = "";

    }
         public void txtbox_init()
         {
             float basic = 0;

             txtempcode1.Text = "";
             txtempname.Text = "";
             txtdept.Text = "";
             txtdesign.Text = "";
             txtearnmonbasic.Text = basic.ToString();
             txtearnmonhra.Text = basic.ToString();
             txtearnmonlta.Text = basic.ToString();
             txtearnmonconvey.Text = basic.ToString();
             txtearnmonattrallow.Text = basic.ToString();
             txtearnmonsplallow.Text = basic.ToString();
             txtearnmonmedallow.Text = basic.ToString();
             txtdeducmonpfdeduc.Text = basic.ToString();
             txtdeducmonesic.Text = basic.ToString();
             //txtothermonmedic.Text = basic.ToString();
             //txtothermonbonus.Text = basic.ToString();
             txtotherallow.Text = basic.ToString();
             txtsalarrear.Text = basic.ToString();
             txtotherpay.Text = basic.ToString();
             txttotearn.Text = basic.ToString();
             txtlop.Text = basic.ToString();
             txtloan.Text = basic.ToString();
             txtotherdeduc.Text = basic.ToString();
             txttotdeduc.Text = basic.ToString();
             txtnetsalary.Text = basic.ToString();
             txtnoofpaydays.Text = basic.ToString();
             txtmediclaimri.Text = basic.ToString();
             txtearnbonus.Text = basic.ToString();
             txtptax.Text = basic.ToString();
             txttds.Text = basic.ToString();

            // cmbdept.Text = "Select";
        //     cmbemp.Text = "Select";
             cmbmonth.Text = "Select";
             cmbyear.Text = "Select";
             txtdate.Text = DateTime.Now.ToString("dd-MMM-yyyy"); ;
         }
        

        private void cmbemp_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        

        private void btnsave_Click(object sender, EventArgs e)
        {
            
            btncalc.Enabled = false;
            btnprint.Enabled = true;
            btnclear.Enabled = true;

            if (cmbyear.Text=="Select")
            {
                MessageBox.Show("Please Select Year");
                cmbyear.Focus();
                btnsave.Enabled = true;
            }
            else
                if (cmbmonth.Text == "Select")
                {
                    MessageBox.Show("Please Select month");
                    cmbmonth.Focus();
                    btnsave.Enabled = true;
                }
                else
                    if (txtnoofpaydays.Text == "0")
                    {
                        MessageBox.Show("Please enter No of Paydays");
                        txtnoofpaydays.Focus();
                        btnsave.Enabled = true;
                    }

                    else
                    {
                        load_salarygenerate();
                    }
            dataGridView1.Refresh();
        }

        private void load_salarygenerate()
        {

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }

            conn.Open();

            SqlCommand cmd = new SqlCommand("insert into salarygen(empcode,empname,dept,designation,createddate,fyear,fmonth,basic,hra,lta,convey,splallow,attirallow,medicallow,otherallow,salarrear,mediclaimri,bonus,otherpay,pf,esic,lop,loan,otherdeduc,totearn,totdeduc,netsal,paydays,remarks,ptax,tds)values('" + txtempcode1.Text + "','" + txtempname.Text + "','" + txtdept.Text + "','" + txtdesign.Text + "','" + txtdate.Text + "','" + cmbyear.Text + "','" + cmbmonth.Text + "','" + txtearnmonbasic.Text + "','" + txtearnmonhra.Text + "','" + txtearnmonlta.Text + "','" + txtearnmonconvey.Text + "','" + txtearnmonsplallow.Text + "','" + txtearnmonattrallow.Text + "','" + txtearnmonmedallow.Text + "','" + txtotherallow.Text + "','" + txtsalarrear.Text + "','" + txtmediclaimri.Text + "','" + txtearnbonus.Text + "','" + txtotherpay.Text + "','" + txtdeducmonpfdeduc.Text + "','" + txtdeducmonesic.Text + "','" + txtlop.Text + "','" + txtloan.Text + "','" + txtotherdeduc.Text + "','" + txttotearn.Text + "','" + txttotdeduc.Text + "','" + txtnetsalary.Text + "','" +txtnoofpaydays.Text+ "','" +txtremarks.Text+ "','" +txtptax.Text+ "','" +txttds.Text+ "')", conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Pay Generated Successfully");

            conn.Close();

        }

        private void btncalc_Click_1(object sender, EventArgs e)
        {
            if (txtearnmonbasic.Text.Length == 0)
            {
                MessageBox.Show("There is no salary structure created for the selected Employee");
            }
            else
            {

                float basic, hra, lta, convey, splallow, attir, medic, otherallow, salarr, otherpay, mediclaimri, earnbonus, totearn, ptax, tds;

                otherpay = Convert.ToInt32(txtotherpay.Text);
                basic = Convert.ToInt32(txtearnmonbasic.Text);
                hra = Convert.ToInt32(txtearnmonhra.Text);
                lta = Convert.ToInt32(txtearnmonlta.Text);
                convey = Convert.ToInt32(txtearnmonconvey.Text);
                splallow = Convert.ToInt32(txtearnmonsplallow.Text);
                attir = Convert.ToInt32(txtearnmonattrallow.Text);
                medic = Convert.ToInt32(txtearnmonmedallow.Text);
                otherallow = Convert.ToInt32(txtotherallow.Text);
                salarr = Convert.ToInt32(txtsalarrear.Text);
                mediclaimri = Convert.ToInt32(txtmediclaimri.Text);
                earnbonus = Convert.ToInt32(txtearnbonus.Text);
                totearn = basic + hra + lta + convey + splallow + attir + medic + otherallow + salarr + otherpay + mediclaimri + earnbonus;

                txttotearn.Text = (totearn).ToString();

                //deduction calc

                float pf, esic, mediclaim, bonus, lop, loan, otherdedu, totdeduc;

                pf = Convert.ToInt32(txtdeducmonpfdeduc.Text);
                esic = Convert.ToInt32(txtdeducmonesic.Text);
                //mediclaim = Convert.ToInt32(txtothermonmedic.Text);
                //bonus = Convert.ToInt32(txtothermonbonus.Text);
                lop = Convert.ToInt32(txtlop.Text);
                loan = Convert.ToInt32(txtloan.Text);
                otherdedu = Convert.ToInt32(txtotherdeduc.Text);
                ptax = Convert.ToInt32(txtptax.Text);
                tds = Convert.ToInt32(txttds.Text);
                totdeduc = pf + esic + lop + loan + otherdedu + ptax + tds;

                txttotdeduc.Text = (totdeduc).ToString();

                //Net Salary calc

                float netsal;

                netsal = (totearn - totdeduc);

                txtnetsalary.Text = netsal.ToString();

                btnsave.Enabled = true;

            }
            
        }

        private void cmbdept_SelectedIndexChanged(object sender, EventArgs e)
        {
            

            
                            if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
                //conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = ("select empcode,name from tblemployee where dept= '" + cmbdept.Text + "' and empstatus='Active' ");
                //cmd.Parameters.AddWithValue("@dept", dept);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                conn.Open();
                da.Fill(ds);
                conn.Close();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    //cmbemp.ValueMember = "empcode";
                    //cmbemp.DisplayMember = "name";
                    //cmbemp.DataSource = ds.Tables[0];
                    cmbemp.ValueMember = "empcode";
                    cmbemp.DisplayMember = "name";
                    cmbemp.DataSource = ds.Tables[0];
                }
                 

        }

        

        private void btnprint_Click(object sender, EventArgs e)
        {
            Form2 frmprint = new Form2();
            frmprint.passvalue = txtempcode1.Text;

            

            frmprint.Show();

           

            UniforPayroll.payslipprint payprint = new payslipprint();
            //payprint.SetDatabaseLogon
           
            
        }

        
               
            public string empcodepass
        {
            get{return txtempcode1.Text;}


        }

            private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {


                tabControl1.SelectTab(1);
                btnnewpay.Enabled = true;
                btnprint.Enabled = true;

                SqlDataReader dr;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtempcode1.Text = row.Cells["empcode"].Value.ToString();
            }

            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from salarygen where empcode='" + txtempcode1.Text + "'", conn);

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                txtdate.Text = dr[5].ToString();
                txtempname.Text = dr[2].ToString();
                txtdept.Text = dr[3].ToString();
                txtdesign.Text = dr[4].ToString();
                cmbyear.Text = dr[6].ToString();
                cmbmonth.Text = dr[7].ToString();
                txtearnmonbasic.Text = dr[8].ToString();
                txtearnmonhra.Text = dr[9].ToString();
                txtearnmonlta.Text = dr[10].ToString();
                txtearnmonconvey.Text = dr[11].ToString();
                txtearnmonsplallow.Text = dr[12].ToString();
                txtearnmonattrallow.Text = dr[13].ToString();
                txtearnmonmedallow.Text = dr[14].ToString();
                txtotherallow.Text = dr[15].ToString();
                txtsalarrear.Text = dr[16].ToString();
                txtmediclaimri.Text = dr[17].ToString();
                txtearnbonus.Text = dr[18].ToString();
                txtotherpay.Text = dr[19].ToString();

                txtdeducmonpfdeduc.Text = dr[20].ToString();
                txtdeducmonesic.Text = dr[21].ToString();
                //txtothermonmedic.Text = dr[22].ToString();
                //txtothermonbonus.Text = dr[23].ToString();
                txtlop.Text = dr[24].ToString();
                txtsalarrear.Text = dr[25].ToString();
                txtotherdeduc.Text = dr[26].ToString();
                txttotearn.Text = dr[27].ToString();
                txttotdeduc.Text = dr[28].ToString();
                txtnetsalary.Text = dr[29].ToString();
                txtnoofpaydays.Text = dr[30].ToString();
                txtptax.Text = dr[31].ToString();
                txttds.Text = dr[32].ToString();

            }
            conn.Close();

            }

            private void btnnewpay_Click(object sender, EventArgs e)
            {
                txtbox_init();
                btncalc.Enabled = true;
                cmbemp.Enabled = true;
                cmbdept.Enabled = true;
            }

            private void tabPage2_Click(object sender, EventArgs e)
            {

            }

            private void button1_Click(object sender, EventArgs e)
            {
                //clear textboxes
                clear_textbox();
                float basic = 0;
                txtlop.Text = basic.ToString();
                txtloan.Text = basic.ToString();
                txtotherallow.Text = basic.ToString();
                txtsalarrear.Text = basic.ToString();
                txtotherdeduc.Text = basic.ToString();
                txtotherpay.Text = basic.ToString();



                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
                conn.Open();

                //bind emp details
                SqlCommand cmd = new SqlCommand("select * from tblemployee  where  name= '" + cmbemp.Text + "' ", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                SqlDataReader dr;
                try
                {
                    dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        string strcode = (string)dr["empcode"];
                        string strname = (string)dr["name"];
                        string strdept = (string)dr["dept"];
                        string strdesign = (string)dr["designation"];
                        txtempcode1.Text = strcode;
                        txtempname.Text = strname;
                        txtdept.Text = strdept;
                        txtdesign.Text = strdesign;

                    }
                }
                catch (Exception es)
                {
                    MessageBox.Show(es.Message);
                }
                conn.Close();
                //Bind Salary details
                conn.Open();
                SqlCommand cmd1 = new SqlCommand("select * from salstructure  where empcode= '" + txtempcode1.Text + "'  ", conn);
                SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                SqlDataReader dr1;
                try
                {
                    dr1 = cmd1.ExecuteReader();
                    while (dr1.Read())
                    {
                        string strbasic = (string)dr1["basicmon"].ToString();
                        string strhra = (string)dr1["hramon"].ToString();
                        string strlta = (string)dr1["ltamon"].ToString();
                        string strconvey = (string)dr1["conveyencemon"].ToString();
                        string strsplallow = (string)dr1["splallowmon"].ToString();
                        string strattir = (string)dr1["attirallowmon"].ToString();
                        string strmedic = (string)dr1["medicallowmon"].ToString();
                        //string strotherallow = (string)dr1["lta"].ToString();
                        string strpfmon = (string)dr1["pfmon"].ToString();
                        string stresic = (string)dr1["esicmon"].ToString();
                        //string strmediclaim = (string)dr1["othermediclaimmon"].ToString();
                        //string strbonus = (string)dr1["otherbonusmon"].ToString();


                        txtearnmonbasic.Text = strbasic;
                        txtearnmonhra.Text = strhra;
                        txtearnmonlta.Text = strlta;
                        txtearnmonconvey.Text = strconvey;
                        txtearnmonattrallow.Text = strattir;
                        txtearnmonsplallow.Text = strsplallow;
                        txtearnmonmedallow.Text = strmedic;
                        txtdeducmonpfdeduc.Text = strpfmon;
                        txtdeducmonesic.Text = stresic;
                        //txtothermonmedic.Text = strmediclaim;
                        //txtothermonbonus.Text = strbonus;

                        // txtdesign.Text = strdesign;

                    }
                }
                catch (Exception es1)
                {
                    MessageBox.Show(es1.Message);
                }

                conn.Close();

            }

            

           

            

       

      
     
    }

    }

