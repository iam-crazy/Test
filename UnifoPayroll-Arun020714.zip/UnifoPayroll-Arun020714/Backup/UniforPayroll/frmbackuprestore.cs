﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace UniforPayroll
{
    public partial class frmbackuprestore : Form
    {
        public frmbackuprestore()
        {
            InitializeComponent();
        }

        private void btnbackup_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog SaveFD1 = new SaveFileDialog();
                string FileName = "";
                SaveFD1.InitialDirectory = "D:";
                SaveFD1.FileName = "";
                SaveFD1.Title = "Backup ";
                SaveFD1.DefaultExt = "mdf";
                SaveFD1.Filter = " (*.mdf)|*.mdf|All Files|*.*";
                //SaveFD1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"; 
                SaveFD1.FilterIndex = 1;
                SaveFD1.RestoreDirectory = true;
                if (SaveFD1.ShowDialog() == DialogResult.OK)
                {

                    FileName = SaveFD1.FileName;
                    Backup(FileName);
                    MessageBox.Show("Backup Process is Completed Successfully !", "Backup Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while backup " + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        protected void Backup(string path)
        {
                       // -- CREATE FILE BACKUP 

            string src = @"D:\unireports.mdf";
            string dst = path;
            System.IO.File.Copy(src, dst, true);
        }
        
    }
}
