﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UniforPayroll
{
    public partial class Mainform : Form
    {
        public Mainform()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really Quit?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {

                Application.Exit();

            }

        }

        private void branchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masterbranch childform = new Masterbranch();
            childform.MdiParent = this;
            childform.Show();

        }

        private void departmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masterdepartment childform = new Masterdepartment();
            childform.MdiParent = this;
            childform.Show();
        }

        private void designationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masterdesignation childform = new Masterdesignation();
            childform.MdiParent = this;
            childform.Show();
        }

        private void addNewEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmempdetails childform = new frmempdetails();
            childform.MdiParent = this;
            childform.Show();
        }

        private void salaryStructureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            salarystructure childform = new salarystructure();
            childform.MdiParent = this;
            childform.Show();
        }

        private void employeeListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            emplist childform = new emplist();
            childform.MdiParent = this;
            childform.Show();
        }

        private void payrollToolStripMenuItem_Click(object sender, EventArgs e)
        {

            frmpayslip childform = new frmpayslip();
            childform.MdiParent = this;
            childform.Show();
        }

        private void salaryStatementBankToolStripMenuItem_Click(object sender, EventArgs e)
        {
            banksalstaement childform = new banksalstaement();
            childform.MdiParent = this;
            childform.Show();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmpasswordchange childform = new frmpasswordchange();
            childform.MdiParent = this;
            childform.Show();
        }

        private void dBBackupRestoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmbackuprestore childform = new frmbackuprestore();
            childform.MdiParent = this;
            childform.Show();
        }

        private void Mainform_Load(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls) 
            { 
                if (control is MdiClient) 
            {
                control.BackColor = System.Drawing.SystemColors.GradientInactiveCaption; 
                    break; 
            }
            } 
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmsaladvance childform = new frmsaladvance();
            childform.MdiParent = this;
            childform.Show();

        }

        
    }
}
