﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{
  

    public partial class Masterbranch : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        SqlCommand sCommand;

        SqlDataAdapter sAdapter;

        SqlCommandBuilder sBuilder;
        
        DataSet sDs;

        DataTable sTable;

        public Masterbranch()
        {
            InitializeComponent();
        }

        private void Masterbranch_Load(object sender, EventArgs e)
        {
            label5.Enabled = false;
            label5.Visible = false;
            label5.Text = DateTime.Now.ToString("dd-MMM-yyyy");
            
            txtbrcity.Enabled = false;
            txtbrcode.Enabled = false;
            txtbrname.Enabled = false;
            cmbactive.Text = "Select";
            //btndel.Enabled = true;
            btnedit.Enabled = false;
            btnsave.Enabled = false;
            

            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from mbranch",conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da=new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnCount = 5;

            dataGridView1.Columns[0].Name = "Branchcode";
            dataGridView1.Columns[0].HeaderText="Branch Code";
            dataGridView1.Columns[0].DataPropertyName = "brcode";

            dataGridView1.Columns[1].Name = "Branchname";
            dataGridView1.Columns[1].HeaderText = "Branch Name";
            dataGridView1.Columns[1].DataPropertyName = "brname";

            dataGridView1.Columns[2].Name = "Branchcity";
            dataGridView1.Columns[2].HeaderText = "Branch City";
            dataGridView1.Columns[2].DataPropertyName = "brcity";

            dataGridView1.Columns[3].Name = "modified";
            dataGridView1.Columns[3].HeaderText = "ModifiedOn";
            dataGridView1.Columns[3].DataPropertyName = "modifiedon";

            dataGridView1.Columns[4].Name = "Active";
            dataGridView1.Columns[4].HeaderText = "Active";
            dataGridView1.Columns[4].DataPropertyName = "Active";

            dataGridView1.DataSource = dt;
            dataGridView1.ReadOnly = true;


            //sCommand = new SqlCommand(sql, connection);

            sAdapter = new SqlDataAdapter(cmd);

            sBuilder = new SqlCommandBuilder(sAdapter);

            sDs = new DataSet();

            sAdapter.Fill(sDs, "mbranch");

            sTable = sDs.Tables["mbranch"];

            //dataGridView1.DataSource = ds;
            //dataGridView1.DataMember = "mbranch";

            conn.Close();

        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtbrcity.Enabled = true;
            txtbrcode.Enabled = true;
            txtbrname.Enabled = true;
            cmbactive.SelectedIndex = 0;
            btnsave.Enabled = true;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            if (txtbrcode.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Branch code");
                txtbrcode.Focus();
            }
            else

                if (txtbrname.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter Branch Name");
                    txtbrname.Focus();
                }
            else
                    if (txtbrcity.Text.Length == 0)
                    {
                        MessageBox.Show("Please Enter City Name");
                        txtbrcity.Focus();
                    }
            
                        else    
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("insert into mbranch(brcode,brname,brcity,active,modifiedon)values('" + txtbrcode.Text + "','" + txtbrname.Text + "','" + txtbrcity.Text + "','" +cmbactive.Text+ "','" +label5.Text+ "')", conn);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Saved Successfully");

                        txtbrcity.Text = "";
                        txtbrcode.Text = "";
                        txtbrname.Text = "";



                        txtbrcity.Enabled = false;
                        txtbrcode.Enabled = false;
                        txtbrname.Enabled = false;

                        //btndel.Enabled = false;
                        btnedit.Enabled = false;
                        btnsave.Enabled = false;
                        btnnew.Enabled = true;

                        SqlCommand cmd1 = new SqlCommand("select * from mbranch", conn);
                        SqlDataAdapter da = new SqlDataAdapter(cmd1);
                        DataSet ds = new DataSet();
                        da.Fill(ds, "mbranch");
                        dataGridView1.DataSource = ds;
                        dataGridView1.DataMember = "mbranch";
                        dataGridView1.ReadOnly = true;
                        conn.Close();
                    }

        }

        private void btndel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to delete this row ?", "Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);

                sAdapter.Update(sTable);


            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtbrcode.Text = row.Cells["branchcode"].Value.ToString();
            }
  
        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            btnsave.Enabled = false;
            btnedit.Enabled = true;
            btnnew.Enabled = true;

            txtbrcity.Enabled = true;
            txtbrcode.Enabled = true;
            txtbrname.Enabled = true;

            SqlDataReader dr;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtbrcode.Text = row.Cells["branchcode"].Value.ToString();
            }

            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from mbranch where brcode='" + txtbrcode.Text + "'  " , conn);

            //SqlDataReader dr = new SqlDataReader();
            dr = cmd.ExecuteReader();

            while(dr.Read())
            {

                txtbrname.Text = dr[1].ToString();
                txtbrcity.Text = dr[2].ToString();
                cmbactive.Text = dr[3].ToString();
            }
            conn.Close();

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            txtbrcode.Enabled = false;
            txtbrname.Enabled = true;
            txtbrcity.Enabled = true;

            
            conn.Open();
            SqlCommand cmd = new SqlCommand("update mbranch set brname='" + txtbrname.Text + "',brcity='" + txtbrcity.Text + "',active='" + cmbactive.Text + "' where brcode='" + txtbrcode.Text + "',modifiedon='" + label5.Text + "' ", conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Updated Successfully");

            txtbrcity.Text = "";
            txtbrcode.Text = "";
            txtbrname.Text = "";



            txtbrcity.Enabled = false;
            txtbrcode.Enabled = false;
            txtbrname.Enabled = false;
            cmbactive.Text = "Select";

            //btndel.Enabled = false;
            btnedit.Enabled = false;
            btnsave.Enabled = false;
            btnnew.Enabled = true;

            SqlCommand cmd1 = new SqlCommand("select * from mbranch", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataSet ds = new DataSet();
            da.Fill(ds, "mbranch");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "mbranch";
            dataGridView1.ReadOnly = true;
            conn.Close();
        }

        

        private void txtbrcode_Leave(object sender, EventArgs e)
        {
            if (txtbrcode.Text.Length != 6)
            {
                MessageBox.Show("Code Should be 6 Digit Characters");
                txtbrcode.Focus();
            }
        }

        

        
    }
}
