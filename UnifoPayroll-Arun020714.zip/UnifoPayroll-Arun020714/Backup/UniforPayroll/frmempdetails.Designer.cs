﻿namespace UniforPayroll
{
    partial class frmempdetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmempdetails));
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnempnew = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btnempserach = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.cmbempdept = new System.Windows.Forms.ComboBox();
            this.cmbempbranch1 = new System.Windows.Forms.ComboBox();
            this.label56 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnnew = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.picempphoto = new System.Windows.Forms.PictureBox();
            this.btnimgupload = new System.Windows.Forms.Button();
            this.txtImagePath = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtempcode = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtblood = new System.Windows.Forms.TextBox();
            this.lblblood = new System.Windows.Forms.Label();
            this.txtfathername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpdob = new System.Windows.Forms.DateTimePicker();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.cmbmaritialstatus = new System.Windows.Forms.ComboBox();
            this.cmbgender = new System.Windows.Forms.ComboBox();
            this.txtpermenadd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtpreadd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.cmbempstatus = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.dtpdatresign = new System.Windows.Forms.DateTimePicker();
            this.dtpdatjoin = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbreportingto = new System.Windows.Forms.ComboBox();
            this.cmbbranch1 = new System.Windows.Forms.ComboBox();
            this.cmbdeprt = new System.Windows.Forms.ComboBox();
            this.cmbdesign = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.WorkExperience = new System.Windows.Forms.GroupBox();
            this.txtyrsofworked = new System.Windows.Forms.TextBox();
            this.txtprevdesign = new System.Windows.Forms.TextBox();
            this.txtprevempler = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtmajor = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtqualif = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.cmbfinyear = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtcreateddate = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.cmbsalaryby = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.txtyrfinalctc = new System.Windows.Forms.TextBox();
            this.txtmonfinalctc = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.txtyrnettakhome = new System.Windows.Forms.TextBox();
            this.txtmonnettakhom = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.txtyrtotmontakhome = new System.Windows.Forms.TextBox();
            this.txtmontotmontakhome = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtothermonprodincentvmon = new System.Windows.Forms.TextBox();
            this.txtotheryrprodincentv = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtothermonpf = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtotheryrpf = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtotheryresic = new System.Windows.Forms.TextBox();
            this.txtothermonmealvou = new System.Windows.Forms.TextBox();
            this.txtothermonesic = new System.Windows.Forms.TextBox();
            this.txtotheryrmealvou = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtotheryrmedic = new System.Windows.Forms.TextBox();
            this.txtothermonbonus = new System.Windows.Forms.TextBox();
            this.txtothermonmedic = new System.Windows.Forms.TextBox();
            this.txtotheryrbonus = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtearnmonbasic = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtearnyrbasic = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtearnyrhra = new System.Windows.Forms.TextBox();
            this.txtearnmonhra = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtearnyrlta = new System.Windows.Forms.TextBox();
            this.txtearnmonlta = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtearnyrconvey = new System.Windows.Forms.TextBox();
            this.txtearnmonconvey = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtearnyrsplallow = new System.Windows.Forms.TextBox();
            this.txtearnmonsplallow = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtearnyrattrallow = new System.Windows.Forms.TextBox();
            this.txtearnmonattrallow = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtearnyrmedallow = new System.Windows.Forms.TextBox();
            this.txtearnmonmedallow = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtdeducmonpfdeduc = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtdeducyrpfdeduc = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtdeducyresic = new System.Windows.Forms.TextBox();
            this.txtdeducmonesic = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtreimbmondriverallow = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtreimbyrdriverallow = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtreimbyrvehicmaintnce = new System.Windows.Forms.TextBox();
            this.txtreimbmonvehicmaintnce = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtreimbyrrelocallow = new System.Windows.Forms.TextBox();
            this.txtreimbmonrelocallow = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.txtgrossmontakhome = new System.Windows.Forms.TextBox();
            this.txtgrossyrtakhome = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtifsccode = new System.Windows.Forms.TextBox();
            this.txtpanno = new System.Windows.Forms.TextBox();
            this.lblpanno = new System.Windows.Forms.Label();
            this.lblbankcity = new System.Windows.Forms.Label();
            this.txtbankcity = new System.Windows.Forms.TextBox();
            this.txtbankbranch = new System.Windows.Forms.TextBox();
            this.txtbankname = new System.Windows.Forms.TextBox();
            this.txtbankaccno = new System.Windows.Forms.TextBox();
            this.txtbankaccname = new System.Windows.Forms.TextBox();
            this.lblaccname = new System.Windows.Forms.Label();
            this.lblbranch = new System.Windows.Forms.Label();
            this.lblbank = new System.Windows.Forms.Label();
            this.lblaccno = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dtpdor = new System.Windows.Forms.DateTimePicker();
            this.dtpdoj = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.lbldoj = new System.Windows.Forms.Label();
            this.cmbreportto = new System.Windows.Forms.ComboBox();
            this.cmbbranch = new System.Windows.Forms.ComboBox();
            this.cmbdept = new System.Windows.Forms.ComboBox();
            this.cmbdesig = new System.Windows.Forms.ComboBox();
            this.lblreportingto = new System.Windows.Forms.Label();
            this.lblbr = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbldesignation = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picempphoto)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.WorkExperience.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl2.Location = new System.Drawing.Point(12, 12);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1024, 600);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage5.Controls.Add(this.btnempnew);
            this.tabPage5.Controls.Add(this.dataGridView1);
            this.tabPage5.Controls.Add(this.groupBox12);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1016, 571);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Employee List";
            // 
            // btnempnew
            // 
            this.btnempnew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnempnew.Location = new System.Drawing.Point(854, 71);
            this.btnempnew.Name = "btnempnew";
            this.btnempnew.Size = new System.Drawing.Size(139, 28);
            this.btnempnew.TabIndex = 34;
            this.btnempnew.Text = "Add New Employee";
            this.btnempnew.UseVisualStyleBackColor = true;
            this.btnempnew.Click += new System.EventHandler(this.btnempnew_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(169, 128);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(687, 194);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btnempserach);
            this.groupBox12.Controls.Add(this.label55);
            this.groupBox12.Controls.Add(this.cmbempdept);
            this.groupBox12.Controls.Add(this.cmbempbranch1);
            this.groupBox12.Controls.Add(this.label56);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(172, 42);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(676, 80);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Employee List Select";
            // 
            // btnempserach
            // 
            this.btnempserach.Location = new System.Drawing.Point(572, 29);
            this.btnempserach.Name = "btnempserach";
            this.btnempserach.Size = new System.Drawing.Size(87, 24);
            this.btnempserach.TabIndex = 4;
            this.btnempserach.Text = "Search";
            this.btnempserach.UseVisualStyleBackColor = true;
            this.btnempserach.Click += new System.EventHandler(this.btnempserach_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(286, 34);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(81, 17);
            this.label55.TabIndex = 3;
            this.label55.Text = "Select Dept";
            // 
            // cmbempdept
            // 
            this.cmbempdept.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbempdept.FormattingEnabled = true;
            this.cmbempdept.Location = new System.Drawing.Point(393, 29);
            this.cmbempdept.Name = "cmbempdept";
            this.cmbempdept.Size = new System.Drawing.Size(121, 24);
            this.cmbempdept.TabIndex = 2;
            this.cmbempdept.Text = "Select";
            // 
            // cmbempbranch1
            // 
            this.cmbempbranch1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbempbranch1.FormattingEnabled = true;
            this.cmbempbranch1.Items.AddRange(new object[] {
            "Select"});
            this.cmbempbranch1.Location = new System.Drawing.Point(126, 26);
            this.cmbempbranch1.Name = "cmbempbranch1";
            this.cmbempbranch1.Size = new System.Drawing.Size(121, 24);
            this.cmbempbranch1.TabIndex = 1;
            this.cmbempbranch1.Text = "Select";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(7, 29);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(96, 17);
            this.label56.TabIndex = 0;
            this.label56.Text = "Select Branch";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1016, 571);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Pesonal Details";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnupdate);
            this.groupBox3.Controls.Add(this.btncancel);
            this.groupBox3.Controls.Add(this.btnsave);
            this.groupBox3.Controls.Add(this.btnnew);
            this.groupBox3.Location = new System.Drawing.Point(499, 28);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(149, 176);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // btnupdate
            // 
            this.btnupdate.Enabled = false;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(27, 96);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(99, 29);
            this.btnupdate.TabIndex = 37;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btncancel
            // 
            this.btncancel.Enabled = false;
            this.btncancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(27, 134);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(99, 29);
            this.btncancel.TabIndex = 36;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Location = new System.Drawing.Point(27, 60);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(99, 29);
            this.btnsave.TabIndex = 34;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnnew
            // 
            this.btnnew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnew.Location = new System.Drawing.Point(27, 22);
            this.btnnew.Name = "btnnew";
            this.btnnew.Size = new System.Drawing.Size(99, 29);
            this.btnnew.TabIndex = 33;
            this.btnnew.Text = "New";
            this.btnnew.UseVisualStyleBackColor = true;
            this.btnnew.Click += new System.EventHandler(this.btnnew_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.picempphoto);
            this.groupBox2.Controls.Add(this.btnimgupload);
            this.groupBox2.Controls.Add(this.txtImagePath);
            this.groupBox2.Location = new System.Drawing.Point(499, 227);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(149, 255);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Emp Photo";
            // 
            // picempphoto
            // 
            this.picempphoto.Image = global::UniforPayroll.Properties.Resources.NotAvailable;
            this.picempphoto.InitialImage = ((System.Drawing.Image)(resources.GetObject("picempphoto.InitialImage")));
            this.picempphoto.Location = new System.Drawing.Point(13, 22);
            this.picempphoto.Name = "picempphoto";
            this.picempphoto.Size = new System.Drawing.Size(130, 139);
            this.picempphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picempphoto.TabIndex = 4;
            this.picempphoto.TabStop = false;
            // 
            // btnimgupload
            // 
            this.btnimgupload.Location = new System.Drawing.Point(13, 198);
            this.btnimgupload.Name = "btnimgupload";
            this.btnimgupload.Size = new System.Drawing.Size(130, 30);
            this.btnimgupload.TabIndex = 5;
            this.btnimgupload.Text = "Upload Photo";
            this.btnimgupload.UseVisualStyleBackColor = true;
            this.btnimgupload.Click += new System.EventHandler(this.btnimgupload_Click);
            // 
            // txtImagePath
            // 
            this.txtImagePath.Enabled = false;
            this.txtImagePath.Location = new System.Drawing.Point(13, 155);
            this.txtImagePath.Name = "txtImagePath";
            this.txtImagePath.Size = new System.Drawing.Size(130, 23);
            this.txtImagePath.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtempcode);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.lblemail);
            this.groupBox1.Controls.Add(this.txtblood);
            this.groupBox1.Controls.Add(this.lblblood);
            this.groupBox1.Controls.Add(this.txtfathername);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.dtpdob);
            this.groupBox1.Controls.Add(this.txtmobile);
            this.groupBox1.Controls.Add(this.txtphone);
            this.groupBox1.Controls.Add(this.txtempname);
            this.groupBox1.Controls.Add(this.cmbmaritialstatus);
            this.groupBox1.Controls.Add(this.cmbgender);
            this.groupBox1.Controls.Add(this.txtpermenadd);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtpreadd);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(487, 524);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Information";
            // 
            // txtempcode
            // 
            this.txtempcode.BackColor = System.Drawing.Color.GhostWhite;
            this.txtempcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtempcode.Enabled = false;
            this.txtempcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtempcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtempcode.Location = new System.Drawing.Point(168, 28);
            this.txtempcode.Name = "txtempcode";
            this.txtempcode.Size = new System.Drawing.Size(124, 23);
            this.txtempcode.TabIndex = 70;
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.GhostWhite;
            this.txtemail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(166, 490);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(212, 22);
            this.txtemail.TabIndex = 11;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(12, 490);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(56, 16);
            this.lblemail.TabIndex = 68;
            this.lblemail.Text = "Email Id";
            // 
            // txtblood
            // 
            this.txtblood.BackColor = System.Drawing.Color.GhostWhite;
            this.txtblood.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtblood.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtblood.Location = new System.Drawing.Point(166, 457);
            this.txtblood.Name = "txtblood";
            this.txtblood.Size = new System.Drawing.Size(92, 22);
            this.txtblood.TabIndex = 10;
            // 
            // lblblood
            // 
            this.lblblood.AutoSize = true;
            this.lblblood.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblblood.Location = new System.Drawing.Point(13, 457);
            this.lblblood.Name = "lblblood";
            this.lblblood.Size = new System.Drawing.Size(88, 17);
            this.lblblood.TabIndex = 66;
            this.lblblood.Text = "Blood Group";
            // 
            // txtfathername
            // 
            this.txtfathername.BackColor = System.Drawing.Color.GhostWhite;
            this.txtfathername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtfathername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfathername.Location = new System.Drawing.Point(166, 89);
            this.txtfathername.Name = "txtfathername";
            this.txtfathername.Size = new System.Drawing.Size(298, 22);
            this.txtfathername.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 17);
            this.label4.TabIndex = 64;
            this.label4.Text = "Father\'s Name";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(38, 235);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 63;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(53, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 13);
            this.label5.TabIndex = 62;
            this.label5.Text = "Same as present Addr";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 17);
            this.label8.TabIndex = 60;
            this.label8.Text = "Emp Code";
            // 
            // dtpdob
            // 
            this.dtpdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdob.Location = new System.Drawing.Point(166, 295);
            this.dtpdob.Name = "dtpdob";
            this.dtpdob.Size = new System.Drawing.Size(92, 23);
            this.dtpdob.TabIndex = 5;
            // 
            // txtmobile
            // 
            this.txtmobile.BackColor = System.Drawing.Color.GhostWhite;
            this.txtmobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.Location = new System.Drawing.Point(166, 427);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(212, 22);
            this.txtmobile.TabIndex = 9;
            // 
            // txtphone
            // 
            this.txtphone.BackColor = System.Drawing.Color.GhostWhite;
            this.txtphone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtphone.Location = new System.Drawing.Point(166, 393);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(212, 22);
            this.txtphone.TabIndex = 8;
            // 
            // txtempname
            // 
            this.txtempname.BackColor = System.Drawing.Color.GhostWhite;
            this.txtempname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtempname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtempname.Location = new System.Drawing.Point(166, 62);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(298, 22);
            this.txtempname.TabIndex = 1;
            // 
            // cmbmaritialstatus
            // 
            this.cmbmaritialstatus.BackColor = System.Drawing.Color.Lavender;
            this.cmbmaritialstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbmaritialstatus.FormattingEnabled = true;
            this.cmbmaritialstatus.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Widow"});
            this.cmbmaritialstatus.Location = new System.Drawing.Point(166, 358);
            this.cmbmaritialstatus.Name = "cmbmaritialstatus";
            this.cmbmaritialstatus.Size = new System.Drawing.Size(159, 24);
            this.cmbmaritialstatus.TabIndex = 7;
            this.cmbmaritialstatus.Text = "Select";
            // 
            // cmbgender
            // 
            this.cmbgender.BackColor = System.Drawing.Color.Lavender;
            this.cmbgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbgender.FormattingEnabled = true;
            this.cmbgender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbgender.Location = new System.Drawing.Point(166, 328);
            this.cmbgender.Name = "cmbgender";
            this.cmbgender.Size = new System.Drawing.Size(159, 24);
            this.cmbgender.TabIndex = 6;
            this.cmbgender.Text = "Select";
            // 
            // txtpermenadd
            // 
            this.txtpermenadd.BackColor = System.Drawing.Color.GhostWhite;
            this.txtpermenadd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtpermenadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpermenadd.Location = new System.Drawing.Point(166, 208);
            this.txtpermenadd.Multiline = true;
            this.txtpermenadd.Name = "txtpermenadd";
            this.txtpermenadd.Size = new System.Drawing.Size(298, 80);
            this.txtpermenadd.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 16);
            this.label9.TabIndex = 53;
            this.label9.Text = "Permenant Address";
            // 
            // txtpreadd
            // 
            this.txtpreadd.BackColor = System.Drawing.Color.GhostWhite;
            this.txtpreadd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtpreadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreadd.Location = new System.Drawing.Point(166, 118);
            this.txtpreadd.Multiline = true;
            this.txtpreadd.Name = "txtpreadd";
            this.txtpreadd.Size = new System.Drawing.Size(298, 80);
            this.txtpreadd.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 122);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 16);
            this.label10.TabIndex = 51;
            this.label10.Text = "Present Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 427);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 16);
            this.label11.TabIndex = 50;
            this.label11.Text = "Mobile Number";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(12, 393);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 16);
            this.label12.TabIndex = 49;
            this.label12.Text = "Phone Number";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(12, 366);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 16);
            this.label13.TabIndex = 48;
            this.label13.Text = "Maritial Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 328);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 17);
            this.label14.TabIndex = 47;
            this.label14.Text = "Gender";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 300);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 16);
            this.label15.TabIndex = 46;
            this.label15.Text = "Date Of Birth";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 62);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 17);
            this.label16.TabIndex = 44;
            this.label16.Text = "Name";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.WorkExperience);
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1016, 571);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Job Information";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox3);
            this.groupBox4.Controls.Add(this.label58);
            this.groupBox4.Controls.Add(this.cmbempstatus);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.dtpdatresign);
            this.groupBox4.Controls.Add(this.dtpdatjoin);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.cmbreportingto);
            this.groupBox4.Controls.Add(this.cmbbranch1);
            this.groupBox4.Controls.Add(this.cmbdeprt);
            this.groupBox4.Controls.Add(this.cmbdesign);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Location = new System.Drawing.Point(15, 14);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(395, 331);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Job Info";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Trainee",
            "Probation",
            "Permanent",
            "Temporary"});
            this.comboBox3.Location = new System.Drawing.Point(142, 225);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(207, 24);
            this.comboBox3.TabIndex = 25;
            this.comboBox3.Text = "Select";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(17, 225);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(72, 17);
            this.label58.TabIndex = 26;
            this.label58.Text = "Emp Type";
            // 
            // cmbempstatus
            // 
            this.cmbempstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbempstatus.FormattingEnabled = true;
            this.cmbempstatus.Items.AddRange(new object[] {
            "Active",
            "Resigned"});
            this.cmbempstatus.Location = new System.Drawing.Point(142, 190);
            this.cmbempstatus.Name = "cmbempstatus";
            this.cmbempstatus.Size = new System.Drawing.Size(207, 24);
            this.cmbempstatus.TabIndex = 6;
            this.cmbempstatus.Text = "Select";
            this.cmbempstatus.SelectedIndexChanged += new System.EventHandler(this.cmbempstatus_SelectedIndexChanged_1);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(17, 190);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 17);
            this.label21.TabIndex = 24;
            this.label21.Text = "Emp Status";
            // 
            // dtpdatresign
            // 
            this.dtpdatresign.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdatresign.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdatresign.Location = new System.Drawing.Point(142, 260);
            this.dtpdatresign.Name = "dtpdatresign";
            this.dtpdatresign.Size = new System.Drawing.Size(89, 23);
            this.dtpdatresign.TabIndex = 23;
            // 
            // dtpdatjoin
            // 
            this.dtpdatjoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdatjoin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdatjoin.Location = new System.Drawing.Point(142, 162);
            this.dtpdatjoin.Name = "dtpdatjoin";
            this.dtpdatjoin.Size = new System.Drawing.Size(89, 23);
            this.dtpdatjoin.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "Date Of Resigned";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 17);
            this.label7.TabIndex = 20;
            this.label7.Text = "Date Of Join";
            // 
            // cmbreportingto
            // 
            this.cmbreportingto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreportingto.FormattingEnabled = true;
            this.cmbreportingto.Location = new System.Drawing.Point(142, 130);
            this.cmbreportingto.Name = "cmbreportingto";
            this.cmbreportingto.Size = new System.Drawing.Size(207, 24);
            this.cmbreportingto.TabIndex = 4;
            this.cmbreportingto.Text = "Select";
            // 
            // cmbbranch1
            // 
            this.cmbbranch1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbranch1.FormattingEnabled = true;
            this.cmbbranch1.Location = new System.Drawing.Point(142, 97);
            this.cmbbranch1.Name = "cmbbranch1";
            this.cmbbranch1.Size = new System.Drawing.Size(207, 24);
            this.cmbbranch1.TabIndex = 3;
            this.cmbbranch1.Text = "Select";
            // 
            // cmbdeprt
            // 
            this.cmbdeprt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdeprt.FormattingEnabled = true;
            this.cmbdeprt.Location = new System.Drawing.Point(142, 66);
            this.cmbdeprt.Name = "cmbdeprt";
            this.cmbdeprt.Size = new System.Drawing.Size(207, 24);
            this.cmbdeprt.TabIndex = 2;
            this.cmbdeprt.Text = "Select";
            // 
            // cmbdesign
            // 
            this.cmbdesign.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdesign.FormattingEnabled = true;
            this.cmbdesign.Location = new System.Drawing.Point(142, 33);
            this.cmbdesign.Name = "cmbdesign";
            this.cmbdesign.Size = new System.Drawing.Size(207, 24);
            this.cmbdesign.TabIndex = 1;
            this.cmbdesign.Text = "Select";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(17, 130);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 17);
            this.label17.TabIndex = 15;
            this.label17.Text = "Reporting To";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(17, 95);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 17);
            this.label18.TabIndex = 14;
            this.label18.Text = "Branch";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(17, 66);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 17);
            this.label19.TabIndex = 13;
            this.label19.Text = "Department";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(17, 33);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 17);
            this.label20.TabIndex = 12;
            this.label20.Text = "Designation";
            // 
            // WorkExperience
            // 
            this.WorkExperience.Controls.Add(this.txtyrsofworked);
            this.WorkExperience.Controls.Add(this.txtprevdesign);
            this.WorkExperience.Controls.Add(this.txtprevempler);
            this.WorkExperience.Controls.Add(this.label24);
            this.WorkExperience.Controls.Add(this.label23);
            this.WorkExperience.Controls.Add(this.label22);
            this.WorkExperience.Location = new System.Drawing.Point(15, 362);
            this.WorkExperience.Name = "WorkExperience";
            this.WorkExperience.Size = new System.Drawing.Size(437, 109);
            this.WorkExperience.TabIndex = 2;
            this.WorkExperience.TabStop = false;
            this.WorkExperience.Text = "Work Experience";
            // 
            // txtyrsofworked
            // 
            this.txtyrsofworked.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrsofworked.Location = new System.Drawing.Point(158, 81);
            this.txtyrsofworked.Name = "txtyrsofworked";
            this.txtyrsofworked.Size = new System.Drawing.Size(132, 23);
            this.txtyrsofworked.TabIndex = 11;
            // 
            // txtprevdesign
            // 
            this.txtprevdesign.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtprevdesign.Location = new System.Drawing.Point(158, 52);
            this.txtprevdesign.Name = "txtprevdesign";
            this.txtprevdesign.Size = new System.Drawing.Size(254, 23);
            this.txtprevdesign.TabIndex = 10;
            // 
            // txtprevempler
            // 
            this.txtprevempler.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtprevempler.Location = new System.Drawing.Point(158, 23);
            this.txtprevempler.Name = "txtprevempler";
            this.txtprevempler.Size = new System.Drawing.Size(254, 23);
            this.txtprevempler.TabIndex = 9;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 82);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 17);
            this.label24.TabIndex = 2;
            this.label24.Text = "Years of Worked";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 51);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(83, 17);
            this.label23.TabIndex = 1;
            this.label23.Text = "Designation";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(7, 23);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(126, 17);
            this.label22.TabIndex = 0;
            this.label22.Text = "Previous Employer";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtmajor);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.txtqualif);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Location = new System.Drawing.Point(427, 25);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(360, 246);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Educational Details";
            // 
            // txtmajor
            // 
            this.txtmajor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmajor.Location = new System.Drawing.Point(160, 58);
            this.txtmajor.Name = "txtmajor";
            this.txtmajor.Size = new System.Drawing.Size(166, 23);
            this.txtmajor.TabIndex = 8;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 62);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(134, 17);
            this.label26.TabIndex = 2;
            this.label26.Text = "Major/Specialisation";
            // 
            // txtqualif
            // 
            this.txtqualif.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtqualif.Location = new System.Drawing.Point(160, 25);
            this.txtqualif.Name = "txtqualif";
            this.txtqualif.Size = new System.Drawing.Size(166, 23);
            this.txtqualif.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 29);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(138, 17);
            this.label25.TabIndex = 0;
            this.label25.Text = "Highest Qualification";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage2.Controls.Add(this.label62);
            this.tabPage2.Controls.Add(this.label61);
            this.tabPage2.Controls.Add(this.cmbfinyear);
            this.tabPage2.Controls.Add(this.label60);
            this.tabPage2.Controls.Add(this.txtcreateddate);
            this.tabPage2.Controls.Add(this.label59);
            this.tabPage2.Controls.Add(this.groupBox13);
            this.tabPage2.Controls.Add(this.label51);
            this.tabPage2.Controls.Add(this.label52);
            this.tabPage2.Controls.Add(this.groupBox11);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Controls.Add(this.label50);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1016, 571);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Salary Structure";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(609, 24);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(0, 17);
            this.label62.TabIndex = 89;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(558, 24);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(51, 17);
            this.label61.TabIndex = 88;
            this.label61.Text = "Sal.ID";
            this.label61.Visible = false;
            // 
            // cmbfinyear
            // 
            this.cmbfinyear.FormattingEnabled = true;
            this.cmbfinyear.Items.AddRange(new object[] {
            "2013-14",
            "2014-15",
            "2015-16"});
            this.cmbfinyear.Location = new System.Drawing.Point(416, 21);
            this.cmbfinyear.Name = "cmbfinyear";
            this.cmbfinyear.Size = new System.Drawing.Size(77, 24);
            this.cmbfinyear.TabIndex = 87;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(352, 24);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(69, 17);
            this.label60.TabIndex = 86;
            this.label60.Text = "Fin.Year";
            // 
            // txtcreateddate
            // 
            this.txtcreateddate.Enabled = false;
            this.txtcreateddate.Location = new System.Drawing.Point(146, 18);
            this.txtcreateddate.Name = "txtcreateddate";
            this.txtcreateddate.Size = new System.Drawing.Size(76, 23);
            this.txtcreateddate.TabIndex = 85;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(45, 21);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(104, 17);
            this.label59.TabIndex = 84;
            this.label59.Text = "Created Date";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button3);
            this.groupBox13.Controls.Add(this.button1);
            this.groupBox13.Controls.Add(this.button2);
            this.groupBox13.Controls.Add(this.button4);
            this.groupBox13.Location = new System.Drawing.Point(782, 94);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(124, 201);
            this.groupBox13.TabIndex = 83;
            this.groupBox13.TabStop = false;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(6, 32);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 26);
            this.button3.TabIndex = 77;
            this.button3.Text = "Calculate";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 26);
            this.button1.TabIndex = 78;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 157);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 26);
            this.button2.TabIndex = 79;
            this.button2.Text = "Print";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(6, 116);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 26);
            this.button4.TabIndex = 80;
            this.button4.Text = "Re Structure";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(639, 66);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(84, 19);
            this.label51.TabIndex = 82;
            this.label51.Text = "Per Month";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(542, 66);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(89, 19);
            this.label52.TabIndex = 81;
            this.label52.Text = "Per Annum";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.cmbsalaryby);
            this.groupBox11.Controls.Add(this.label53);
            this.groupBox11.Location = new System.Drawing.Point(751, 345);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(229, 53);
            this.groupBox11.TabIndex = 76;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Select Salary by";
            // 
            // cmbsalaryby
            // 
            this.cmbsalaryby.FormattingEnabled = true;
            this.cmbsalaryby.Items.AddRange(new object[] {
            "Bank",
            "Cash",
            "Cheque"});
            this.cmbsalaryby.Location = new System.Drawing.Point(91, 22);
            this.cmbsalaryby.Name = "cmbsalaryby";
            this.cmbsalaryby.Size = new System.Drawing.Size(121, 24);
            this.cmbsalaryby.TabIndex = 1;
            this.cmbsalaryby.SelectedIndexChanged += new System.EventHandler(this.cmbsalaryby_SelectedIndexChanged);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(17, 23);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(68, 17);
            this.label53.TabIndex = 0;
            this.label53.Text = "Salary By";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(255, 66);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(84, 19);
            this.label49.TabIndex = 73;
            this.label49.Text = "Per Month";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.txtyrfinalctc);
            this.panel4.Controls.Add(this.txtmonfinalctc);
            this.panel4.Location = new System.Drawing.Point(361, 467);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(382, 44);
            this.panel4.TabIndex = 72;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(22, 16);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(78, 17);
            this.label39.TabIndex = 45;
            this.label39.Text = "Final CTC";
            // 
            // txtyrfinalctc
            // 
            this.txtyrfinalctc.BackColor = System.Drawing.Color.AliceBlue;
            this.txtyrfinalctc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrfinalctc.Enabled = false;
            this.txtyrfinalctc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyrfinalctc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtyrfinalctc.Location = new System.Drawing.Point(180, 14);
            this.txtyrfinalctc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtyrfinalctc.Name = "txtyrfinalctc";
            this.txtyrfinalctc.Size = new System.Drawing.Size(87, 24);
            this.txtyrfinalctc.TabIndex = 46;
            // 
            // txtmonfinalctc
            // 
            this.txtmonfinalctc.BackColor = System.Drawing.Color.AliceBlue;
            this.txtmonfinalctc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmonfinalctc.Enabled = false;
            this.txtmonfinalctc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonfinalctc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmonfinalctc.Location = new System.Drawing.Point(279, 14);
            this.txtmonfinalctc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmonfinalctc.Name = "txtmonfinalctc";
            this.txtmonfinalctc.Size = new System.Drawing.Size(87, 24);
            this.txtmonfinalctc.TabIndex = 47;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(157, 66);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(89, 19);
            this.label50.TabIndex = 72;
            this.label50.Text = "Per Annum";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label40);
            this.panel3.Controls.Add(this.txtyrnettakhome);
            this.panel3.Controls.Add(this.txtmonnettakhom);
            this.panel3.Location = new System.Drawing.Point(358, 185);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(382, 37);
            this.panel3.TabIndex = 73;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(15, 7);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(120, 17);
            this.label40.TabIndex = 33;
            this.label40.Text = "Net Take Home";
            // 
            // txtyrnettakhome
            // 
            this.txtyrnettakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtyrnettakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrnettakhome.Enabled = false;
            this.txtyrnettakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyrnettakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtyrnettakhome.Location = new System.Drawing.Point(184, 4);
            this.txtyrnettakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtyrnettakhome.Name = "txtyrnettakhome";
            this.txtyrnettakhome.Size = new System.Drawing.Size(87, 22);
            this.txtyrnettakhome.TabIndex = 34;
            // 
            // txtmonnettakhom
            // 
            this.txtmonnettakhom.BackColor = System.Drawing.Color.AliceBlue;
            this.txtmonnettakhom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmonnettakhom.Enabled = false;
            this.txtmonnettakhom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonnettakhom.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmonnettakhom.Location = new System.Drawing.Point(279, 5);
            this.txtmonnettakhom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmonnettakhom.Name = "txtmonnettakhom";
            this.txtmonnettakhom.Size = new System.Drawing.Size(87, 22);
            this.txtmonnettakhom.TabIndex = 35;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.txtyrtotmontakhome);
            this.panel2.Controls.Add(this.txtmontotmontakhome);
            this.panel2.Location = new System.Drawing.Point(6, 467);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(349, 44);
            this.panel2.TabIndex = 71;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(-2, 16);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(151, 17);
            this.label34.TabIndex = 45;
            this.label34.Text = "Monthly Take Home";
            // 
            // txtyrtotmontakhome
            // 
            this.txtyrtotmontakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtyrtotmontakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrtotmontakhome.Enabled = false;
            this.txtyrtotmontakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyrtotmontakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtyrtotmontakhome.Location = new System.Drawing.Point(156, 14);
            this.txtyrtotmontakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtyrtotmontakhome.Name = "txtyrtotmontakhome";
            this.txtyrtotmontakhome.Size = new System.Drawing.Size(87, 22);
            this.txtyrtotmontakhome.TabIndex = 46;
            // 
            // txtmontotmontakhome
            // 
            this.txtmontotmontakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtmontotmontakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmontotmontakhome.Enabled = false;
            this.txtmontotmontakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmontotmontakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmontotmontakhome.Location = new System.Drawing.Point(249, 14);
            this.txtmontotmontakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmontotmontakhome.Name = "txtmontotmontakhome";
            this.txtmontotmontakhome.Size = new System.Drawing.Size(87, 22);
            this.txtmontotmontakhome.TabIndex = 47;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtothermonprodincentvmon);
            this.groupBox9.Controls.Add(this.txtotheryrprodincentv);
            this.groupBox9.Controls.Add(this.label41);
            this.groupBox9.Controls.Add(this.txtothermonpf);
            this.groupBox9.Controls.Add(this.label42);
            this.groupBox9.Controls.Add(this.txtotheryrpf);
            this.groupBox9.Controls.Add(this.label43);
            this.groupBox9.Controls.Add(this.txtotheryresic);
            this.groupBox9.Controls.Add(this.txtothermonmealvou);
            this.groupBox9.Controls.Add(this.txtothermonesic);
            this.groupBox9.Controls.Add(this.txtotheryrmealvou);
            this.groupBox9.Controls.Add(this.label44);
            this.groupBox9.Controls.Add(this.label45);
            this.groupBox9.Controls.Add(this.txtotheryrmedic);
            this.groupBox9.Controls.Add(this.txtothermonbonus);
            this.groupBox9.Controls.Add(this.txtothermonmedic);
            this.groupBox9.Controls.Add(this.txtotheryrbonus);
            this.groupBox9.Controls.Add(this.label46);
            this.groupBox9.Location = new System.Drawing.Point(358, 228);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(382, 192);
            this.groupBox9.TabIndex = 71;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Miscellaneous";
            // 
            // txtothermonprodincentvmon
            // 
            this.txtothermonprodincentvmon.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonprodincentvmon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonprodincentvmon.Enabled = false;
            this.txtothermonprodincentvmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonprodincentvmon.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonprodincentvmon.Location = new System.Drawing.Point(279, 160);
            this.txtothermonprodincentvmon.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonprodincentvmon.Name = "txtothermonprodincentvmon";
            this.txtothermonprodincentvmon.Size = new System.Drawing.Size(87, 22);
            this.txtothermonprodincentvmon.TabIndex = 65;
            // 
            // txtotheryrprodincentv
            // 
            this.txtotheryrprodincentv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrprodincentv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrprodincentv.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrprodincentv.Location = new System.Drawing.Point(183, 160);
            this.txtotheryrprodincentv.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrprodincentv.Name = "txtotheryrprodincentv";
            this.txtotheryrprodincentv.Size = new System.Drawing.Size(87, 22);
            this.txtotheryrprodincentv.TabIndex = 18;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(28, 162);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(133, 16);
            this.label41.TabIndex = 63;
            this.label41.Text = "Productivity Incentive";
            // 
            // txtothermonpf
            // 
            this.txtothermonpf.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonpf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonpf.Enabled = false;
            this.txtothermonpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonpf.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonpf.Location = new System.Drawing.Point(279, 21);
            this.txtothermonpf.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonpf.Name = "txtothermonpf";
            this.txtothermonpf.Size = new System.Drawing.Size(87, 22);
            this.txtothermonpf.TabIndex = 50;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(28, 23);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(25, 16);
            this.label42.TabIndex = 48;
            this.label42.Text = "PF";
            // 
            // txtotheryrpf
            // 
            this.txtotheryrpf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrpf.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrpf.Location = new System.Drawing.Point(183, 21);
            this.txtotheryrpf.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrpf.Name = "txtotheryrpf";
            this.txtotheryrpf.Size = new System.Drawing.Size(87, 22);
            this.txtotheryrpf.TabIndex = 13;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(28, 51);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(38, 16);
            this.label43.TabIndex = 51;
            this.label43.Text = "ESIC";
            // 
            // txtotheryresic
            // 
            this.txtotheryresic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryresic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryresic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryresic.Location = new System.Drawing.Point(183, 49);
            this.txtotheryresic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryresic.Name = "txtotheryresic";
            this.txtotheryresic.Size = new System.Drawing.Size(87, 22);
            this.txtotheryresic.TabIndex = 14;
            // 
            // txtothermonmealvou
            // 
            this.txtothermonmealvou.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonmealvou.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonmealvou.Enabled = false;
            this.txtothermonmealvou.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonmealvou.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonmealvou.Location = new System.Drawing.Point(279, 131);
            this.txtothermonmealvou.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonmealvou.Name = "txtothermonmealvou";
            this.txtothermonmealvou.Size = new System.Drawing.Size(87, 22);
            this.txtothermonmealvou.TabIndex = 62;
            // 
            // txtothermonesic
            // 
            this.txtothermonesic.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonesic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonesic.Enabled = false;
            this.txtothermonesic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonesic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonesic.Location = new System.Drawing.Point(279, 49);
            this.txtothermonesic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonesic.Name = "txtothermonesic";
            this.txtothermonesic.Size = new System.Drawing.Size(87, 22);
            this.txtothermonesic.TabIndex = 53;
            // 
            // txtotheryrmealvou
            // 
            this.txtotheryrmealvou.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrmealvou.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrmealvou.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrmealvou.Location = new System.Drawing.Point(183, 131);
            this.txtotheryrmealvou.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrmealvou.Name = "txtotheryrmealvou";
            this.txtotheryrmealvou.Size = new System.Drawing.Size(87, 22);
            this.txtotheryrmealvou.TabIndex = 17;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(28, 76);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(70, 16);
            this.label44.TabIndex = 54;
            this.label44.Text = "Mediclaim";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(28, 133);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(91, 16);
            this.label45.TabIndex = 60;
            this.label45.Text = "Meal Voucher";
            // 
            // txtotheryrmedic
            // 
            this.txtotheryrmedic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrmedic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrmedic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrmedic.Location = new System.Drawing.Point(183, 74);
            this.txtotheryrmedic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrmedic.Name = "txtotheryrmedic";
            this.txtotheryrmedic.Size = new System.Drawing.Size(87, 22);
            this.txtotheryrmedic.TabIndex = 15;
            // 
            // txtothermonbonus
            // 
            this.txtothermonbonus.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonbonus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonbonus.Enabled = false;
            this.txtothermonbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonbonus.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonbonus.Location = new System.Drawing.Point(279, 101);
            this.txtothermonbonus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonbonus.Name = "txtothermonbonus";
            this.txtothermonbonus.Size = new System.Drawing.Size(87, 22);
            this.txtothermonbonus.TabIndex = 59;
            // 
            // txtothermonmedic
            // 
            this.txtothermonmedic.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonmedic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonmedic.Enabled = false;
            this.txtothermonmedic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonmedic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonmedic.Location = new System.Drawing.Point(279, 74);
            this.txtothermonmedic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonmedic.Name = "txtothermonmedic";
            this.txtothermonmedic.Size = new System.Drawing.Size(87, 22);
            this.txtothermonmedic.TabIndex = 56;
            // 
            // txtotheryrbonus
            // 
            this.txtotheryrbonus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrbonus.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrbonus.Location = new System.Drawing.Point(183, 101);
            this.txtotheryrbonus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrbonus.Name = "txtotheryrbonus";
            this.txtotheryrbonus.Size = new System.Drawing.Size(87, 22);
            this.txtotheryrbonus.TabIndex = 16;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(28, 103);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(46, 16);
            this.label46.TabIndex = 57;
            this.label46.Text = "Bonus";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtearnmonbasic);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.txtearnyrbasic);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.txtearnyrhra);
            this.groupBox7.Controls.Add(this.txtearnmonhra);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.txtearnyrlta);
            this.groupBox7.Controls.Add(this.txtearnmonlta);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.txtearnyrconvey);
            this.groupBox7.Controls.Add(this.txtearnmonconvey);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.txtearnyrsplallow);
            this.groupBox7.Controls.Add(this.txtearnmonsplallow);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.txtearnyrattrallow);
            this.groupBox7.Controls.Add(this.txtearnmonattrallow);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.txtearnyrmedallow);
            this.groupBox7.Controls.Add(this.txtearnmonmedallow);
            this.groupBox7.Location = new System.Drawing.Point(3, 77);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(349, 210);
            this.groupBox7.TabIndex = 64;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Earnings";
            // 
            // txtearnmonbasic
            // 
            this.txtearnmonbasic.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonbasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonbasic.Enabled = false;
            this.txtearnmonbasic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonbasic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonbasic.Location = new System.Drawing.Point(249, 22);
            this.txtearnmonbasic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonbasic.Name = "txtearnmonbasic";
            this.txtearnmonbasic.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonbasic.TabIndex = 2;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(12, 24);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(42, 16);
            this.label27.TabIndex = 0;
            this.label27.Text = "Basic";
            // 
            // txtearnyrbasic
            // 
            this.txtearnyrbasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrbasic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrbasic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrbasic.Location = new System.Drawing.Point(154, 22);
            this.txtearnyrbasic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrbasic.Name = "txtearnyrbasic";
            this.txtearnyrbasic.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrbasic.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(12, 51);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(37, 16);
            this.label28.TabIndex = 5;
            this.label28.Text = "HRA";
            // 
            // txtearnyrhra
            // 
            this.txtearnyrhra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrhra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrhra.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrhra.Location = new System.Drawing.Point(154, 49);
            this.txtearnyrhra.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrhra.Name = "txtearnyrhra";
            this.txtearnyrhra.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrhra.TabIndex = 2;
            // 
            // txtearnmonhra
            // 
            this.txtearnmonhra.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonhra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonhra.Enabled = false;
            this.txtearnmonhra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonhra.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonhra.Location = new System.Drawing.Point(249, 49);
            this.txtearnmonhra.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonhra.Name = "txtearnmonhra";
            this.txtearnmonhra.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonhra.TabIndex = 7;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(12, 78);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(33, 16);
            this.label29.TabIndex = 8;
            this.label29.Text = "LTA";
            // 
            // txtearnyrlta
            // 
            this.txtearnyrlta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrlta.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrlta.Location = new System.Drawing.Point(154, 76);
            this.txtearnyrlta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrlta.Name = "txtearnyrlta";
            this.txtearnyrlta.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrlta.TabIndex = 3;
            // 
            // txtearnmonlta
            // 
            this.txtearnmonlta.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonlta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonlta.Enabled = false;
            this.txtearnmonlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonlta.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonlta.Location = new System.Drawing.Point(249, 76);
            this.txtearnmonlta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonlta.Name = "txtearnmonlta";
            this.txtearnmonlta.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonlta.TabIndex = 10;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(12, 105);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(84, 16);
            this.label30.TabIndex = 11;
            this.label30.Text = "Conveyence";
            // 
            // txtearnyrconvey
            // 
            this.txtearnyrconvey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrconvey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrconvey.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrconvey.Location = new System.Drawing.Point(154, 103);
            this.txtearnyrconvey.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrconvey.Name = "txtearnyrconvey";
            this.txtearnyrconvey.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrconvey.TabIndex = 4;
            // 
            // txtearnmonconvey
            // 
            this.txtearnmonconvey.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonconvey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonconvey.Enabled = false;
            this.txtearnmonconvey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonconvey.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonconvey.Location = new System.Drawing.Point(249, 103);
            this.txtearnmonconvey.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonconvey.Name = "txtearnmonconvey";
            this.txtearnmonconvey.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonconvey.TabIndex = 13;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(12, 132);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(119, 16);
            this.label31.TabIndex = 14;
            this.label31.Text = "Special Allowance";
            // 
            // txtearnyrsplallow
            // 
            this.txtearnyrsplallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrsplallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrsplallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrsplallow.Location = new System.Drawing.Point(154, 130);
            this.txtearnyrsplallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrsplallow.Name = "txtearnyrsplallow";
            this.txtearnyrsplallow.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrsplallow.TabIndex = 5;
            // 
            // txtearnmonsplallow
            // 
            this.txtearnmonsplallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonsplallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonsplallow.Enabled = false;
            this.txtearnmonsplallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonsplallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonsplallow.Location = new System.Drawing.Point(249, 130);
            this.txtearnmonsplallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonsplallow.Name = "txtearnmonsplallow";
            this.txtearnmonsplallow.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonsplallow.TabIndex = 16;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(9, 159);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(103, 16);
            this.label32.TabIndex = 17;
            this.label32.Text = "Attire Allowance";
            // 
            // txtearnyrattrallow
            // 
            this.txtearnyrattrallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrattrallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrattrallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrattrallow.Location = new System.Drawing.Point(154, 157);
            this.txtearnyrattrallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrattrallow.Name = "txtearnyrattrallow";
            this.txtearnyrattrallow.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrattrallow.TabIndex = 6;
            // 
            // txtearnmonattrallow
            // 
            this.txtearnmonattrallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonattrallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonattrallow.Enabled = false;
            this.txtearnmonattrallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonattrallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonattrallow.Location = new System.Drawing.Point(249, 157);
            this.txtearnmonattrallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonattrallow.Name = "txtearnmonattrallow";
            this.txtearnmonattrallow.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonattrallow.TabIndex = 19;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(12, 186);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(121, 16);
            this.label33.TabIndex = 20;
            this.label33.Text = "Medical Allownace";
            // 
            // txtearnyrmedallow
            // 
            this.txtearnyrmedallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrmedallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrmedallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrmedallow.Location = new System.Drawing.Point(154, 184);
            this.txtearnyrmedallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrmedallow.Name = "txtearnyrmedallow";
            this.txtearnyrmedallow.Size = new System.Drawing.Size(87, 22);
            this.txtearnyrmedallow.TabIndex = 7;
            // 
            // txtearnmonmedallow
            // 
            this.txtearnmonmedallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonmedallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonmedallow.Enabled = false;
            this.txtearnmonmedallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonmedallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonmedallow.Location = new System.Drawing.Point(249, 184);
            this.txtearnmonmedallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonmedallow.Name = "txtearnmonmedallow";
            this.txtearnmonmedallow.Size = new System.Drawing.Size(87, 22);
            this.txtearnmonmedallow.TabIndex = 22;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtdeducmonpfdeduc);
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Controls.Add(this.txtdeducyrpfdeduc);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.txtdeducyresic);
            this.groupBox10.Controls.Add(this.txtdeducmonesic);
            this.groupBox10.Location = new System.Drawing.Point(358, 76);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(382, 92);
            this.groupBox10.TabIndex = 70;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Deductions";
            // 
            // txtdeducmonpfdeduc
            // 
            this.txtdeducmonpfdeduc.BackColor = System.Drawing.SystemColors.Info;
            this.txtdeducmonpfdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducmonpfdeduc.Enabled = false;
            this.txtdeducmonpfdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducmonpfdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducmonpfdeduc.Location = new System.Drawing.Point(279, 32);
            this.txtdeducmonpfdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducmonpfdeduc.Name = "txtdeducmonpfdeduc";
            this.txtdeducmonpfdeduc.Size = new System.Drawing.Size(87, 22);
            this.txtdeducmonpfdeduc.TabIndex = 29;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(28, 34);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 16);
            this.label47.TabIndex = 27;
            this.label47.Text = "PF Deduction";
            // 
            // txtdeducyrpfdeduc
            // 
            this.txtdeducyrpfdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducyrpfdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducyrpfdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducyrpfdeduc.Location = new System.Drawing.Point(184, 32);
            this.txtdeducyrpfdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducyrpfdeduc.Name = "txtdeducyrpfdeduc";
            this.txtdeducyrpfdeduc.Size = new System.Drawing.Size(87, 22);
            this.txtdeducyrpfdeduc.TabIndex = 11;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(28, 62);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(38, 16);
            this.label48.TabIndex = 30;
            this.label48.Text = "ESIC";
            // 
            // txtdeducyresic
            // 
            this.txtdeducyresic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducyresic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducyresic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducyresic.Location = new System.Drawing.Point(184, 60);
            this.txtdeducyresic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducyresic.Name = "txtdeducyresic";
            this.txtdeducyresic.Size = new System.Drawing.Size(87, 22);
            this.txtdeducyresic.TabIndex = 12;
            // 
            // txtdeducmonesic
            // 
            this.txtdeducmonesic.BackColor = System.Drawing.SystemColors.Info;
            this.txtdeducmonesic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducmonesic.Enabled = false;
            this.txtdeducmonesic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducmonesic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducmonesic.Location = new System.Drawing.Point(279, 60);
            this.txtdeducmonesic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducmonesic.Name = "txtdeducmonesic";
            this.txtdeducmonesic.Size = new System.Drawing.Size(87, 22);
            this.txtdeducmonesic.TabIndex = 32;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtreimbmondriverallow);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.txtreimbyrdriverallow);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Controls.Add(this.txtreimbyrvehicmaintnce);
            this.groupBox8.Controls.Add(this.txtreimbmonvehicmaintnce);
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Controls.Add(this.txtreimbyrrelocallow);
            this.groupBox8.Controls.Add(this.txtreimbmonrelocallow);
            this.groupBox8.Location = new System.Drawing.Point(0, 345);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(349, 103);
            this.groupBox8.TabIndex = 70;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Reimburesments";
            // 
            // txtreimbmondriverallow
            // 
            this.txtreimbmondriverallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtreimbmondriverallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbmondriverallow.Enabled = false;
            this.txtreimbmondriverallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbmondriverallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbmondriverallow.Location = new System.Drawing.Point(249, 24);
            this.txtreimbmondriverallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbmondriverallow.Name = "txtreimbmondriverallow";
            this.txtreimbmondriverallow.Size = new System.Drawing.Size(87, 22);
            this.txtreimbmondriverallow.TabIndex = 38;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(12, 26);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(109, 16);
            this.label35.TabIndex = 36;
            this.label35.Text = "Driver Allowance";
            // 
            // txtreimbyrdriverallow
            // 
            this.txtreimbyrdriverallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbyrdriverallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbyrdriverallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbyrdriverallow.Location = new System.Drawing.Point(155, 24);
            this.txtreimbyrdriverallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbyrdriverallow.Name = "txtreimbyrdriverallow";
            this.txtreimbyrdriverallow.Size = new System.Drawing.Size(87, 22);
            this.txtreimbyrdriverallow.TabIndex = 8;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(12, 53);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(133, 16);
            this.label36.TabIndex = 39;
            this.label36.Text = "Vehicle Manitanance";
            // 
            // txtreimbyrvehicmaintnce
            // 
            this.txtreimbyrvehicmaintnce.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbyrvehicmaintnce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbyrvehicmaintnce.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbyrvehicmaintnce.Location = new System.Drawing.Point(155, 51);
            this.txtreimbyrvehicmaintnce.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbyrvehicmaintnce.Name = "txtreimbyrvehicmaintnce";
            this.txtreimbyrvehicmaintnce.Size = new System.Drawing.Size(87, 22);
            this.txtreimbyrvehicmaintnce.TabIndex = 9;
            // 
            // txtreimbmonvehicmaintnce
            // 
            this.txtreimbmonvehicmaintnce.BackColor = System.Drawing.SystemColors.Info;
            this.txtreimbmonvehicmaintnce.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbmonvehicmaintnce.Enabled = false;
            this.txtreimbmonvehicmaintnce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbmonvehicmaintnce.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbmonvehicmaintnce.Location = new System.Drawing.Point(249, 51);
            this.txtreimbmonvehicmaintnce.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbmonvehicmaintnce.Name = "txtreimbmonvehicmaintnce";
            this.txtreimbmonvehicmaintnce.Size = new System.Drawing.Size(87, 22);
            this.txtreimbmonvehicmaintnce.TabIndex = 41;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(12, 81);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(138, 16);
            this.label37.TabIndex = 42;
            this.label37.Text = "Relocation Allowance";
            // 
            // txtreimbyrrelocallow
            // 
            this.txtreimbyrrelocallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbyrrelocallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbyrrelocallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbyrrelocallow.Location = new System.Drawing.Point(155, 79);
            this.txtreimbyrrelocallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbyrrelocallow.Name = "txtreimbyrrelocallow";
            this.txtreimbyrrelocallow.Size = new System.Drawing.Size(87, 22);
            this.txtreimbyrrelocallow.TabIndex = 10;
            // 
            // txtreimbmonrelocallow
            // 
            this.txtreimbmonrelocallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtreimbmonrelocallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbmonrelocallow.Enabled = false;
            this.txtreimbmonrelocallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbmonrelocallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbmonrelocallow.Location = new System.Drawing.Point(249, 79);
            this.txtreimbmonrelocallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbmonrelocallow.Name = "txtreimbmonrelocallow";
            this.txtreimbmonrelocallow.Size = new System.Drawing.Size(87, 22);
            this.txtreimbmonrelocallow.TabIndex = 44;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.txtgrossmontakhome);
            this.panel1.Controls.Add(this.txtgrossyrtakhome);
            this.panel1.Location = new System.Drawing.Point(3, 293);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(349, 39);
            this.panel1.TabIndex = 69;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(0, 12);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(138, 17);
            this.label38.TabIndex = 23;
            this.label38.Text = "Gross Take Home";
            // 
            // txtgrossmontakhome
            // 
            this.txtgrossmontakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtgrossmontakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtgrossmontakhome.Enabled = false;
            this.txtgrossmontakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrossmontakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtgrossmontakhome.Location = new System.Drawing.Point(249, 8);
            this.txtgrossmontakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtgrossmontakhome.Name = "txtgrossmontakhome";
            this.txtgrossmontakhome.Size = new System.Drawing.Size(87, 22);
            this.txtgrossmontakhome.TabIndex = 25;
            // 
            // txtgrossyrtakhome
            // 
            this.txtgrossyrtakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtgrossyrtakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtgrossyrtakhome.Enabled = false;
            this.txtgrossyrtakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrossyrtakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtgrossyrtakhome.Location = new System.Drawing.Point(152, 10);
            this.txtgrossyrtakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtgrossyrtakhome.Name = "txtgrossyrtakhome";
            this.txtgrossyrtakhome.Size = new System.Drawing.Size(87, 22);
            this.txtgrossyrtakhome.TabIndex = 24;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1016, 571);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Bank Acc Details";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label57);
            this.groupBox6.Controls.Add(this.txtifsccode);
            this.groupBox6.Controls.Add(this.txtpanno);
            this.groupBox6.Controls.Add(this.lblpanno);
            this.groupBox6.Controls.Add(this.lblbankcity);
            this.groupBox6.Controls.Add(this.txtbankcity);
            this.groupBox6.Controls.Add(this.txtbankbranch);
            this.groupBox6.Controls.Add(this.txtbankname);
            this.groupBox6.Controls.Add(this.txtbankaccno);
            this.groupBox6.Controls.Add(this.txtbankaccname);
            this.groupBox6.Controls.Add(this.lblaccname);
            this.groupBox6.Controls.Add(this.lblbranch);
            this.groupBox6.Controls.Add(this.lblbank);
            this.groupBox6.Controls.Add(this.lblaccno);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(39, 32);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(380, 272);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Bank Details";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(9, 167);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(74, 17);
            this.label57.TabIndex = 13;
            this.label57.Text = "IFSC Code";
            // 
            // txtifsccode
            // 
            this.txtifsccode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtifsccode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtifsccode.Location = new System.Drawing.Point(126, 164);
            this.txtifsccode.Name = "txtifsccode";
            this.txtifsccode.Size = new System.Drawing.Size(207, 23);
            this.txtifsccode.TabIndex = 12;
            // 
            // txtpanno
            // 
            this.txtpanno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtpanno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpanno.Location = new System.Drawing.Point(125, 237);
            this.txtpanno.Name = "txtpanno";
            this.txtpanno.Size = new System.Drawing.Size(207, 23);
            this.txtpanno.TabIndex = 11;
            // 
            // lblpanno
            // 
            this.lblpanno.AutoSize = true;
            this.lblpanno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpanno.Location = new System.Drawing.Point(9, 237);
            this.lblpanno.Name = "lblpanno";
            this.lblpanno.Size = new System.Drawing.Size(58, 17);
            this.lblpanno.TabIndex = 10;
            this.lblpanno.Text = "PAN No";
            // 
            // lblbankcity
            // 
            this.lblbankcity.AutoSize = true;
            this.lblbankcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbankcity.Location = new System.Drawing.Point(9, 204);
            this.lblbankcity.Name = "lblbankcity";
            this.lblbankcity.Size = new System.Drawing.Size(31, 17);
            this.lblbankcity.TabIndex = 9;
            this.lblbankcity.Text = "City";
            // 
            // txtbankcity
            // 
            this.txtbankcity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbankcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankcity.Location = new System.Drawing.Point(126, 201);
            this.txtbankcity.Name = "txtbankcity";
            this.txtbankcity.Size = new System.Drawing.Size(207, 23);
            this.txtbankcity.TabIndex = 8;
            // 
            // txtbankbranch
            // 
            this.txtbankbranch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbankbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankbranch.Location = new System.Drawing.Point(126, 132);
            this.txtbankbranch.Name = "txtbankbranch";
            this.txtbankbranch.Size = new System.Drawing.Size(207, 23);
            this.txtbankbranch.TabIndex = 7;
            // 
            // txtbankname
            // 
            this.txtbankname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbankname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankname.Location = new System.Drawing.Point(126, 97);
            this.txtbankname.Name = "txtbankname";
            this.txtbankname.Size = new System.Drawing.Size(207, 23);
            this.txtbankname.TabIndex = 6;
            // 
            // txtbankaccno
            // 
            this.txtbankaccno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbankaccno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankaccno.Location = new System.Drawing.Point(126, 65);
            this.txtbankaccno.Name = "txtbankaccno";
            this.txtbankaccno.Size = new System.Drawing.Size(207, 23);
            this.txtbankaccno.TabIndex = 5;
            // 
            // txtbankaccname
            // 
            this.txtbankaccname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbankaccname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankaccname.Location = new System.Drawing.Point(126, 33);
            this.txtbankaccname.Name = "txtbankaccname";
            this.txtbankaccname.Size = new System.Drawing.Size(207, 23);
            this.txtbankaccname.TabIndex = 4;
            // 
            // lblaccname
            // 
            this.lblaccname.AutoSize = true;
            this.lblaccname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccname.Location = new System.Drawing.Point(7, 33);
            this.lblaccname.Name = "lblaccname";
            this.lblaccname.Size = new System.Drawing.Size(100, 17);
            this.lblaccname.TabIndex = 3;
            this.lblaccname.Text = "Account Name";
            // 
            // lblbranch
            // 
            this.lblbranch.AutoSize = true;
            this.lblbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbranch.Location = new System.Drawing.Point(9, 132);
            this.lblbranch.Name = "lblbranch";
            this.lblbranch.Size = new System.Drawing.Size(53, 17);
            this.lblbranch.TabIndex = 2;
            this.lblbranch.Text = "Branch";
            // 
            // lblbank
            // 
            this.lblbank.AutoSize = true;
            this.lblbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbank.Location = new System.Drawing.Point(9, 102);
            this.lblbank.Name = "lblbank";
            this.lblbank.Size = new System.Drawing.Size(77, 17);
            this.lblbank.TabIndex = 1;
            this.lblbank.Text = "BankName";
            // 
            // lblaccno
            // 
            this.lblaccno.AutoSize = true;
            this.lblaccno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccno.Location = new System.Drawing.Point(6, 70);
            this.lblaccno.Name = "lblaccno";
            this.lblaccno.Size = new System.Drawing.Size(81, 17);
            this.lblaccno.TabIndex = 0;
            this.lblaccno.Text = "Account No";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dtpdor
            // 
            this.dtpdor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdor.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdor.Location = new System.Drawing.Point(126, 189);
            this.dtpdor.Name = "dtpdor";
            this.dtpdor.Size = new System.Drawing.Size(89, 23);
            this.dtpdor.TabIndex = 11;
            // 
            // dtpdoj
            // 
            this.dtpdoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdoj.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdoj.Location = new System.Drawing.Point(126, 159);
            this.dtpdoj.Name = "dtpdoj";
            this.dtpdoj.Size = new System.Drawing.Size(89, 23);
            this.dtpdoj.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Date Of Resigned";
            // 
            // lbldoj
            // 
            this.lbldoj.AutoSize = true;
            this.lbldoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldoj.Location = new System.Drawing.Point(7, 158);
            this.lbldoj.Name = "lbldoj";
            this.lbldoj.Size = new System.Drawing.Size(87, 17);
            this.lbldoj.TabIndex = 8;
            this.lbldoj.Text = "Date Of Join";
            // 
            // cmbreportto
            // 
            this.cmbreportto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreportto.FormattingEnabled = true;
            this.cmbreportto.Location = new System.Drawing.Point(126, 127);
            this.cmbreportto.Name = "cmbreportto";
            this.cmbreportto.Size = new System.Drawing.Size(207, 25);
            this.cmbreportto.TabIndex = 7;
            this.cmbreportto.Text = "Select";
            // 
            // cmbbranch
            // 
            this.cmbbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbranch.FormattingEnabled = true;
            this.cmbbranch.Location = new System.Drawing.Point(126, 94);
            this.cmbbranch.Name = "cmbbranch";
            this.cmbbranch.Size = new System.Drawing.Size(207, 25);
            this.cmbbranch.TabIndex = 6;
            this.cmbbranch.Text = "Select";
            // 
            // cmbdept
            // 
            this.cmbdept.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdept.FormattingEnabled = true;
            this.cmbdept.Location = new System.Drawing.Point(126, 63);
            this.cmbdept.Name = "cmbdept";
            this.cmbdept.Size = new System.Drawing.Size(207, 25);
            this.cmbdept.TabIndex = 5;
            this.cmbdept.Text = "Select";
            // 
            // cmbdesig
            // 
            this.cmbdesig.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdesig.FormattingEnabled = true;
            this.cmbdesig.Location = new System.Drawing.Point(126, 30);
            this.cmbdesig.Name = "cmbdesig";
            this.cmbdesig.Size = new System.Drawing.Size(207, 25);
            this.cmbdesig.TabIndex = 4;
            this.cmbdesig.Text = "Select";
            // 
            // lblreportingto
            // 
            this.lblreportingto.AutoSize = true;
            this.lblreportingto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreportingto.Location = new System.Drawing.Point(6, 127);
            this.lblreportingto.Name = "lblreportingto";
            this.lblreportingto.Size = new System.Drawing.Size(91, 17);
            this.lblreportingto.TabIndex = 3;
            this.lblreportingto.Text = "Reporting To";
            // 
            // lblbr
            // 
            this.lblbr.AutoSize = true;
            this.lblbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbr.Location = new System.Drawing.Point(6, 92);
            this.lblbr.Name = "lblbr";
            this.lblbr.Size = new System.Drawing.Size(53, 17);
            this.lblbr.TabIndex = 2;
            this.lblbr.Text = "Branch";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Department";
            // 
            // lbldesignation
            // 
            this.lbldesignation.AutoSize = true;
            this.lbldesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldesignation.Location = new System.Drawing.Point(6, 30);
            this.lbldesignation.Name = "lbldesignation";
            this.lbldesignation.Size = new System.Drawing.Size(83, 17);
            this.lbldesignation.TabIndex = 0;
            this.lbldesignation.Text = "Designation";
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(584, 29);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 4;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(286, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Select Dept";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(393, 29);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 25);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "Select";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Select"});
            this.comboBox2.Location = new System.Drawing.Point(126, 26);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 25);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.Text = "Select";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(7, 29);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(96, 17);
            this.label54.TabIndex = 0;
            this.label54.Text = "Select Branch";
            // 
            // frmempdetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 579);
            this.Controls.Add(this.tabControl2);
            this.Name = "frmempdetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Details";
            this.Load += new System.EventHandler(this.frmempdetails_Load);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picempphoto)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.WorkExperience.ResumeLayout(false);
            this.WorkExperience.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtfathername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpdob;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.ComboBox cmbmaritialstatus;
        private System.Windows.Forms.ComboBox cmbgender;
        private System.Windows.Forms.TextBox txtpermenadd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtpreadd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox picempphoto;
        private System.Windows.Forms.Button btnimgupload;
        private System.Windows.Forms.TextBox txtImagePath;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnnew;
        private System.Windows.Forms.DateTimePicker dtpdor;
        private System.Windows.Forms.DateTimePicker dtpdoj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbldoj;
        private System.Windows.Forms.ComboBox cmbreportto;
        private System.Windows.Forms.ComboBox cmbbranch;
        private System.Windows.Forms.ComboBox cmbdept;
        private System.Windows.Forms.ComboBox cmbdesig;
        private System.Windows.Forms.Label lblreportingto;
        private System.Windows.Forms.Label lblbr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbldesignation;
        private System.Windows.Forms.TextBox txtblood;
        private System.Windows.Forms.Label lblblood;
        private System.Windows.Forms.GroupBox WorkExperience;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtyrsofworked;
        private System.Windows.Forms.TextBox txtprevdesign;
        private System.Windows.Forms.TextBox txtprevempler;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtmajor;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtqualif;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lblbankcity;
        private System.Windows.Forms.TextBox txtbankcity;
        private System.Windows.Forms.TextBox txtbankbranch;
        private System.Windows.Forms.TextBox txtbankname;
        private System.Windows.Forms.TextBox txtbankaccno;
        private System.Windows.Forms.TextBox txtbankaccname;
        private System.Windows.Forms.Label lblaccname;
        private System.Windows.Forms.Label lblbranch;
        private System.Windows.Forms.Label lblbank;
        private System.Windows.Forms.Label lblaccno;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtearnmonbasic;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtearnyrbasic;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtearnyrhra;
        private System.Windows.Forms.TextBox txtearnmonhra;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtearnyrlta;
        private System.Windows.Forms.TextBox txtearnmonlta;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtearnyrconvey;
        private System.Windows.Forms.TextBox txtearnmonconvey;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtearnyrsplallow;
        private System.Windows.Forms.TextBox txtearnmonsplallow;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtearnyrattrallow;
        private System.Windows.Forms.TextBox txtearnmonattrallow;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtearnyrmedallow;
        private System.Windows.Forms.TextBox txtearnmonmedallow;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtyrtotmontakhome;
        private System.Windows.Forms.TextBox txtmontotmontakhome;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtreimbmondriverallow;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtreimbyrdriverallow;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtreimbyrvehicmaintnce;
        private System.Windows.Forms.TextBox txtreimbmonvehicmaintnce;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtreimbyrrelocallow;
        private System.Windows.Forms.TextBox txtreimbmonrelocallow;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtgrossmontakhome;
        private System.Windows.Forms.TextBox txtgrossyrtakhome;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtyrfinalctc;
        private System.Windows.Forms.TextBox txtmonfinalctc;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtyrnettakhome;
        private System.Windows.Forms.TextBox txtmonnettakhom;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtothermonprodincentvmon;
        private System.Windows.Forms.TextBox txtotheryrprodincentv;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtothermonpf;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtotheryrpf;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtotheryresic;
        private System.Windows.Forms.TextBox txtothermonmealvou;
        private System.Windows.Forms.TextBox txtothermonesic;
        private System.Windows.Forms.TextBox txtotheryrmealvou;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtotheryrmedic;
        private System.Windows.Forms.TextBox txtothermonbonus;
        private System.Windows.Forms.TextBox txtothermonmedic;
        private System.Windows.Forms.TextBox txtotheryrbonus;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtdeducmonpfdeduc;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtdeducyrpfdeduc;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtdeducyresic;
        private System.Windows.Forms.TextBox txtdeducmonesic;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox cmbsalaryby;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtpanno;
        private System.Windows.Forms.Label lblpanno;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cmbempstatus;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DateTimePicker dtpdatresign;
        private System.Windows.Forms.DateTimePicker dtpdatjoin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbreportingto;
        private System.Windows.Forms.ComboBox cmbbranch1;
        private System.Windows.Forms.ComboBox cmbdeprt;
        private System.Windows.Forms.ComboBox cmbdesign;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtempcode;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnempserach;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox cmbempdept;
        private System.Windows.Forms.ComboBox cmbempbranch1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnempnew;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtifsccode;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.ComboBox cmbfinyear;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtcreateddate;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
    }
}