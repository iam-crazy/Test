﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{
    public partial class emplist : Form
    {

        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");


        public emplist()
        {
            InitializeComponent();
        }

        private void emplist_Load(object sender, EventArgs e)
        {
            load_dept();
            load_branch();
            load_emplistgrid();

        }

        private void load_emplistgrid()
        {

            conn.Open();
           
                SqlCommand cmd = new SqlCommand("select empcode,name,dept,branch from tblemployee", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.ColumnCount = 4;

                dataGridView1.Columns[0].Name = "empcode";
                dataGridView1.Columns[0].HeaderText = "Emp Code";
                dataGridView1.Columns[0].DataPropertyName = "empcode";

                dataGridView1.Columns[1].Name = "Name";
                dataGridView1.Columns[1].HeaderText = "Name";
                dataGridView1.Columns[1].DataPropertyName = "Name";

                dataGridView1.Columns[2].Name = "Dept";
                dataGridView1.Columns[2].HeaderText = "Department";
                dataGridView1.Columns[2].DataPropertyName = "Department";

                dataGridView1.Columns[3].Name = "Branch";
                dataGridView1.Columns[3].HeaderText = "Branch";
                dataGridView1.Columns[3].DataPropertyName = "Branch";

                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = dt;


                conn.Close();

                



        }


        private void load_dept()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select deptname from mdept", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);            
            cmbdept.DataSource = dt;
            cmbdept.DisplayMember = "deptname";
            cmbdept.ValueMember = "deptname";
            cmbdept.SelectedIndex = -1;
            conn.Close();
        }

        private void load_branch()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select brname from mbranch", conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbbranch.DataSource = dt;
            cmbbranch.DisplayMember = "brname";
            cmbbranch.ValueMember = "brname";
            cmbbranch.SelectedIndex = -1;
            conn.Close();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            conn.Open();

            SqlCommand cmd = new SqlCommand("select empcode,name,dept,branch from tblemployee where branch= '" +cmbbranch.Text+ "' and dept='" +cmbdept.Text+ "' ", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
             //cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            //dataGridView1.ColumnCount = 4;

            

            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = dt;
            conn.Close();  
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            salarystructure salstrfrm = new salarystructure();
            salstrfrm.Show();
            

        }
    }
}
