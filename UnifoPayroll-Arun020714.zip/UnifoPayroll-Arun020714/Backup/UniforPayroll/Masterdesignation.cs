﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{
    public partial class Masterdesignation : Form
    {

        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        SqlCommand sCommand;

        SqlDataAdapter sAdapter;

        SqlCommandBuilder sBuilder;

        DataSet sDs;

        DataTable sTable;


        public Masterdesignation()
        {
            InitializeComponent();
        }

        private void Masterdesignation_Load(object sender, EventArgs e)
        {

            label4.Enabled = false;
            label4.Visible = false;
            label4.Text = DateTime.Now.ToString("dd-MMM-yyyy");

            txtdesigcode.Enabled = false;
            txtdesigname.Enabled = false;
            cmbactive.Text = "Select";
            
            btnedit.Enabled = false;
            btnsave.Enabled = false;


            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from mdesignation", conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnCount = 4;

            dataGridView1.Columns[0].Name = "desigcode";
            dataGridView1.Columns[0].HeaderText = "Desination Code";
            dataGridView1.Columns[0].DataPropertyName = "desigcode";

            dataGridView1.Columns[1].Name = "designame";
            dataGridView1.Columns[1].HeaderText = "Designation Name";
            dataGridView1.Columns[1].DataPropertyName = "DesigNAME";


            dataGridView1.Columns[2].Name = "modifiedon";
            dataGridView1.Columns[2].HeaderText = "ModifiedOn";
            dataGridView1.Columns[2].DataPropertyName = "modifiedon";


            dataGridView1.Columns[3].Name = "Active";
            dataGridView1.Columns[3].HeaderText = "Active";
            dataGridView1.Columns[3].DataPropertyName = "Active";

            dataGridView1.DataSource = dt;
            dataGridView1.ReadOnly = true;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            
            if (txtdesigcode.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Designation code");
                txtdesigcode.Focus();
            }
            else

                if (txtdesigname.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter Designation Name");
                    txtdesigname.Focus();
                }
                else
                {



                    if (conn.State == ConnectionState.Open) 
                    {
                        conn.Close();

                    }



                    conn.Open();
                    SqlCommand cmd = new SqlCommand("insert into mdesignation(desigcode,designame,active,modifiedon)values('" + txtdesigcode.Text + "','" + txtdesigname.Text + "','" +cmbactive+ "','" +label4.Text+ "')", conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Saved Successfully");

                    txtdesigname.Text = "";
                    txtdesigcode.Text = "";
                    cmbactive.Text = "Select";

                    txtdesigcode.Enabled = false;
                    txtdesigname.Enabled = false;


                    btnedit.Enabled = false;
                    btnsave.Enabled = false;
                    btnnew.Enabled = true;

                    SqlCommand cmd1 = new SqlCommand("select * from mdesignation", conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "mdesignation");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "mdesignation";
                    dataGridView1.ReadOnly = true;
                    conn.Close();
                }
        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtdesigname.Text = "";
            txtdesigcode.Text = "";
            txtdesigcode.Focus();
            txtdesigcode.Enabled = true;
            txtdesigname.Enabled = true;
            btnsave.Enabled=true;
            btnedit.Enabled = false;
            cmbactive.SelectedIndex = 0;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtdesigcode.Enabled = false;
            txtdesigname.Enabled = true;

            btnsave.Enabled = false;
            btnnew.Enabled = true;
            btnedit.Enabled = true;


            SqlDataReader dr;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtdesigcode.Text = row.Cells["desigcode"].Value.ToString();
            }

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }


            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from mdesignation where desigcode='" + txtdesigcode.Text + "'", conn);

            //SqlDataReader dr = new SqlDataReader();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                txtdesigname.Text = dr[1].ToString();
                cmbactive.Text = dr[2].ToString();
            }
            conn.Close();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (txtdesigcode.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Designation code");
                txtdesigcode.Focus();
            }
            else

                if (txtdesigname.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter Designation Name");
                    txtdesigname.Focus();
                }
                else
                {



                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();

                    }



                    conn.Open();
                    SqlCommand cmd = new SqlCommand("update mdesignation set designame='" + txtdesigname.Text + "',active='" + cmbactive.Text + "',modifiedon='" + label4.Text + "' where desigcode='" + txtdesigcode.Text + "'", conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated Successfully");

                    txtdesigname.Text = "";
                    txtdesigcode.Text = "";
                    cmbactive.Text = "Select";

                    txtdesigcode.Enabled = false;
                    txtdesigname.Enabled = false;


                    btnedit.Enabled = false;
                    btnsave.Enabled = false;
                    btnnew.Enabled = true;

                    SqlCommand cmd1 = new SqlCommand("select * from mdesignation", conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "mdesignation");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "mdesignation";
                    dataGridView1.ReadOnly = true;
                    conn.Close();
                }
        }

        
    }
}
