﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{
    public partial class Masterdepartment : Form
    {

        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        SqlCommand sCommand;

        SqlDataAdapter sAdapter;

        SqlCommandBuilder sBuilder;

        DataSet sDs;

        DataTable sTable;

        public Masterdepartment()
        {
            InitializeComponent();
        }

        private void Masterdepartment_Load(object sender, EventArgs e)
        {
            label4.Enabled = false;
            label4.Visible = false;
            label4.Text = DateTime.Now.ToString("dd-MMM-yyyy");

            txtdeptcode.Enabled = false;
            txtdeptname.Enabled = false;
            cmbactive.SelectedIndex = 0;

            //btndel.Enabled = false;
            btnedit.Enabled = false;
            btnsave.Enabled = false;



            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from mdept", conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnCount = 4;

            dataGridView1.Columns[0].Name = "deptcode";
            dataGridView1.Columns[0].HeaderText = "Dept Code";
            dataGridView1.Columns[0].DataPropertyName = "deptcode";

            dataGridView1.Columns[1].Name = "deptname";
            dataGridView1.Columns[1].HeaderText = "Dept Name";
            dataGridView1.Columns[1].DataPropertyName = "DEPTNAME";

            dataGridView1.Columns[2].Name = "Active";
            dataGridView1.Columns[2].HeaderText = "Active";
            dataGridView1.Columns[2].DataPropertyName = "Active";

            dataGridView1.Columns[3].Name = "Modified";
            dataGridView1.Columns[3].HeaderText = "Modified On";
            dataGridView1.Columns[3].DataPropertyName = "modifiedon";

            

            dataGridView1.DataSource = dt;
            dataGridView1.ReadOnly = true;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {


            if (txtdeptcode.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Department code");
                txtdeptcode.Focus();
            }
            else

                if (txtdeptname.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter Department Name");
                    txtdeptname.Focus();
                }
            else
            {

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();

                }



                conn.Open();
                SqlCommand cmd = new SqlCommand("insert into mdept(deptcode,deptname,active,modifiedon)values('" + txtdeptcode.Text + "','" + txtdeptname.Text + "','" + cmbactive.Text + "','" +label4.Text + "')", conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Saved Successfully");

                txtdeptname.Text = "";
                txtdeptcode.Text = "";
                cmbactive.SelectedIndex = 0;





                txtdeptcode.Enabled = false;
                txtdeptname.Enabled = false;

                //btndel.Enabled = false;
                btnedit.Enabled = false;
                btnsave.Enabled = false;
                btnnew.Enabled = true;

                SqlCommand cmd1 = new SqlCommand("select * from mdept", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd1);
                DataSet ds = new DataSet();
                da.Fill(ds, "mdept");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "mdept";
                dataGridView1.ReadOnly = true;
                conn.Close();
            }
            
        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            btnsave.Enabled = true;
            btnedit.Enabled = false;
            //btndel.Enabled = false;

            txtdeptcode.Enabled = true;
            txtdeptname.Enabled = true;

            txtdeptcode.Text = "";
            txtdeptname.Text = "";

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            btnedit.Enabled = true;
            btnnew.Enabled = true;
            btnsave.Enabled = false;

            txtdeptcode.Enabled = false;
            txtdeptname.Enabled = true;
            

            
            SqlDataReader dr;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtdeptcode.Text = row.Cells["deptcode"].Value.ToString();
            }

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }


            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from mdept where deptcode='" + txtdeptcode.Text + "'", conn);

            //SqlDataReader dr = new SqlDataReader();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                txtdeptname.Text = dr[1].ToString();
                cmbactive.Text = dr[2].ToString();
            }
            conn.Close();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {

            txtdeptcode.Enabled = false;

            if (txtdeptcode.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Department code");
                txtdeptcode.Focus();
            }
            else

                if (txtdeptname.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter Department Name");
                    txtdeptname.Focus();
                }
                else
                {

                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();

                    }



                    conn.Open();
                    SqlCommand cmd = new SqlCommand("Update mdept set deptname='" + txtdeptname.Text + "',active='" + cmbactive.Text + "',modifiedon='" +label4.Text + "' where deptcode='" + txtdeptcode.Text + "'", conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Saved Successfully");

                    txtdeptname.Text = "";
                    txtdeptcode.Text = "";
                    cmbactive.SelectedIndex = 0;






                    txtdeptname.Enabled = false;

                    //btndel.Enabled = false;
                    btnedit.Enabled = false;
                    btnsave.Enabled = false;
                    btnnew.Enabled = true;

                    SqlCommand cmd1 = new SqlCommand("select * from mdept", conn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "mdept");
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "mdept";
                    dataGridView1.ReadOnly = true;
                    conn.Close();
                }

        }

        private void txtbrcode_Leave(object sender, EventArgs e)
        {
            
        }

       
       
    }
}
