﻿namespace UniforPayroll
{
    partial class salarystructure
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtearnyrbasic = new System.Windows.Forms.TextBox();
            this.txtearnmonbasic = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtearnmonhra = new System.Windows.Forms.TextBox();
            this.txtearnyrhra = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtearnmonlta = new System.Windows.Forms.TextBox();
            this.txtearnyrlta = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtearnmonconvey = new System.Windows.Forms.TextBox();
            this.txtearnyrconvey = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtearnmonsplallow = new System.Windows.Forms.TextBox();
            this.txtearnyrsplallow = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtearnmonattrallow = new System.Windows.Forms.TextBox();
            this.txtearnyrattrallow = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtearnmonmedallow = new System.Windows.Forms.TextBox();
            this.txtearnyrmedallow = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtgrossmontakhome = new System.Windows.Forms.TextBox();
            this.txtgrossyrtakhome = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtdeducmonpfdeduc = new System.Windows.Forms.TextBox();
            this.txtdeducyrpfdeduc = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtdeducmonesic = new System.Windows.Forms.TextBox();
            this.txtdeducyresic = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtmonnettakhome = new System.Windows.Forms.TextBox();
            this.txtyrnettakhome = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtreimbmondriverallow = new System.Windows.Forms.TextBox();
            this.txtreimbyrdriverallow = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtreimbmonvehicmaintnce = new System.Windows.Forms.TextBox();
            this.txtreimbyrvehicmaintnce = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtreimbmonrelocallow = new System.Windows.Forms.TextBox();
            this.txtreimbyrrelocallow = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtmontotmontakhome = new System.Windows.Forms.TextBox();
            this.txtyrtotmontakhome = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtothermonpf = new System.Windows.Forms.TextBox();
            this.txtotheryrpf = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtothermonesic = new System.Windows.Forms.TextBox();
            this.txtotheryresic = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtothermonmedic = new System.Windows.Forms.TextBox();
            this.txtotheryrmedic = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtothermonbonus = new System.Windows.Forms.TextBox();
            this.txtotheryrbonus = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtothermonmealvou = new System.Windows.Forms.TextBox();
            this.txtotheryrmealvou = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.txtyrfinalctc = new System.Windows.Forms.TextBox();
            this.txtmonfinalctc = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbempcode = new System.Windows.Forms.ComboBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txtprodincentvmon = new System.Windows.Forms.TextBox();
            this.txtprodincentv = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Basic";
            // 
            // txtearnyrbasic
            // 
            this.txtearnyrbasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrbasic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrbasic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrbasic.Location = new System.Drawing.Point(260, 40);
            this.txtearnyrbasic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrbasic.Name = "txtearnyrbasic";
            this.txtearnyrbasic.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrbasic.TabIndex = 1;
            // 
            // txtearnmonbasic
            // 
            this.txtearnmonbasic.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonbasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonbasic.Enabled = false;
            this.txtearnmonbasic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonbasic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonbasic.Location = new System.Drawing.Point(421, 40);
            this.txtearnmonbasic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonbasic.Name = "txtearnmonbasic";
            this.txtearnmonbasic.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonbasic.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(300, 47);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Yearly";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(451, 47);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Monthly";
            // 
            // txtearnmonhra
            // 
            this.txtearnmonhra.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonhra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonhra.Enabled = false;
            this.txtearnmonhra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonhra.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonhra.Location = new System.Drawing.Point(421, 67);
            this.txtearnmonhra.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonhra.Name = "txtearnmonhra";
            this.txtearnmonhra.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonhra.TabIndex = 7;
            // 
            // txtearnyrhra
            // 
            this.txtearnyrhra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrhra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrhra.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrhra.Location = new System.Drawing.Point(260, 67);
            this.txtearnyrhra.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrhra.Name = "txtearnyrhra";
            this.txtearnyrhra.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrhra.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 69);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "HRA";
            // 
            // txtearnmonlta
            // 
            this.txtearnmonlta.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonlta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonlta.Enabled = false;
            this.txtearnmonlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonlta.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonlta.Location = new System.Drawing.Point(421, 94);
            this.txtearnmonlta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonlta.Name = "txtearnmonlta";
            this.txtearnmonlta.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonlta.TabIndex = 10;
            // 
            // txtearnyrlta
            // 
            this.txtearnyrlta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrlta.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrlta.Location = new System.Drawing.Point(260, 94);
            this.txtearnyrlta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrlta.Name = "txtearnyrlta";
            this.txtearnyrlta.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrlta.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 96);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "LTA";
            // 
            // txtearnmonconvey
            // 
            this.txtearnmonconvey.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonconvey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonconvey.Enabled = false;
            this.txtearnmonconvey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonconvey.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonconvey.Location = new System.Drawing.Point(421, 121);
            this.txtearnmonconvey.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonconvey.Name = "txtearnmonconvey";
            this.txtearnmonconvey.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonconvey.TabIndex = 13;
            // 
            // txtearnyrconvey
            // 
            this.txtearnyrconvey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrconvey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrconvey.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrconvey.Location = new System.Drawing.Point(260, 121);
            this.txtearnyrconvey.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrconvey.Name = "txtearnyrconvey";
            this.txtearnyrconvey.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrconvey.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 123);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Conveyence";
            // 
            // txtearnmonsplallow
            // 
            this.txtearnmonsplallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonsplallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonsplallow.Enabled = false;
            this.txtearnmonsplallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonsplallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonsplallow.Location = new System.Drawing.Point(421, 148);
            this.txtearnmonsplallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonsplallow.Name = "txtearnmonsplallow";
            this.txtearnmonsplallow.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonsplallow.TabIndex = 16;
            // 
            // txtearnyrsplallow
            // 
            this.txtearnyrsplallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrsplallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrsplallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrsplallow.Location = new System.Drawing.Point(260, 148);
            this.txtearnyrsplallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrsplallow.Name = "txtearnyrsplallow";
            this.txtearnyrsplallow.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrsplallow.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 150);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Special Allowance";
            // 
            // txtearnmonattrallow
            // 
            this.txtearnmonattrallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonattrallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonattrallow.Enabled = false;
            this.txtearnmonattrallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonattrallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonattrallow.Location = new System.Drawing.Point(421, 175);
            this.txtearnmonattrallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonattrallow.Name = "txtearnmonattrallow";
            this.txtearnmonattrallow.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonattrallow.TabIndex = 19;
            // 
            // txtearnyrattrallow
            // 
            this.txtearnyrattrallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrattrallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrattrallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrattrallow.Location = new System.Drawing.Point(260, 175);
            this.txtearnyrattrallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrattrallow.Name = "txtearnyrattrallow";
            this.txtearnyrattrallow.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrattrallow.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 177);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Attire Allowance";
            // 
            // txtearnmonmedallow
            // 
            this.txtearnmonmedallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtearnmonmedallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonmedallow.Enabled = false;
            this.txtearnmonmedallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonmedallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonmedallow.Location = new System.Drawing.Point(421, 202);
            this.txtearnmonmedallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonmedallow.Name = "txtearnmonmedallow";
            this.txtearnmonmedallow.Size = new System.Drawing.Size(133, 22);
            this.txtearnmonmedallow.TabIndex = 22;
            // 
            // txtearnyrmedallow
            // 
            this.txtearnyrmedallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnyrmedallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnyrmedallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnyrmedallow.Location = new System.Drawing.Point(260, 202);
            this.txtearnyrmedallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnyrmedallow.Name = "txtearnyrmedallow";
            this.txtearnyrmedallow.Size = new System.Drawing.Size(133, 22);
            this.txtearnyrmedallow.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 204);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Medical Allownace";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(25, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 17);
            this.label10.TabIndex = 23;
            this.label10.Text = "Gross Take Home";
            // 
            // txtgrossmontakhome
            // 
            this.txtgrossmontakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtgrossmontakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtgrossmontakhome.Enabled = false;
            this.txtgrossmontakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrossmontakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtgrossmontakhome.Location = new System.Drawing.Point(418, 10);
            this.txtgrossmontakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtgrossmontakhome.Name = "txtgrossmontakhome";
            this.txtgrossmontakhome.Size = new System.Drawing.Size(133, 22);
            this.txtgrossmontakhome.TabIndex = 25;
            // 
            // txtgrossyrtakhome
            // 
            this.txtgrossyrtakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtgrossyrtakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtgrossyrtakhome.Enabled = false;
            this.txtgrossyrtakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrossyrtakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtgrossyrtakhome.Location = new System.Drawing.Point(257, 12);
            this.txtgrossyrtakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtgrossyrtakhome.Name = "txtgrossyrtakhome";
            this.txtgrossyrtakhome.Size = new System.Drawing.Size(133, 22);
            this.txtgrossyrtakhome.TabIndex = 24;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(600, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 24);
            this.button1.TabIndex = 26;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtdeducmonpfdeduc
            // 
            this.txtdeducmonpfdeduc.BackColor = System.Drawing.SystemColors.Info;
            this.txtdeducmonpfdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducmonpfdeduc.Enabled = false;
            this.txtdeducmonpfdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducmonpfdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducmonpfdeduc.Location = new System.Drawing.Point(421, 38);
            this.txtdeducmonpfdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducmonpfdeduc.Name = "txtdeducmonpfdeduc";
            this.txtdeducmonpfdeduc.Size = new System.Drawing.Size(133, 22);
            this.txtdeducmonpfdeduc.TabIndex = 29;
            // 
            // txtdeducyrpfdeduc
            // 
            this.txtdeducyrpfdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducyrpfdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducyrpfdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducyrpfdeduc.Location = new System.Drawing.Point(260, 38);
            this.txtdeducyrpfdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducyrpfdeduc.Name = "txtdeducyrpfdeduc";
            this.txtdeducyrpfdeduc.Size = new System.Drawing.Size(133, 22);
            this.txtdeducyrpfdeduc.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(28, 40);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 16);
            this.label11.TabIndex = 27;
            this.label11.Text = "PF Deduction";
            // 
            // txtdeducmonesic
            // 
            this.txtdeducmonesic.BackColor = System.Drawing.SystemColors.Info;
            this.txtdeducmonesic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducmonesic.Enabled = false;
            this.txtdeducmonesic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducmonesic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducmonesic.Location = new System.Drawing.Point(421, 66);
            this.txtdeducmonesic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducmonesic.Name = "txtdeducmonesic";
            this.txtdeducmonesic.Size = new System.Drawing.Size(133, 22);
            this.txtdeducmonesic.TabIndex = 32;
            // 
            // txtdeducyresic
            // 
            this.txtdeducyresic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducyresic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducyresic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducyresic.Location = new System.Drawing.Point(260, 66);
            this.txtdeducyresic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducyresic.Name = "txtdeducyresic";
            this.txtdeducyresic.Size = new System.Drawing.Size(133, 22);
            this.txtdeducyresic.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(28, 68);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 16);
            this.label12.TabIndex = 30;
            this.label12.Text = "ESIC";
            // 
            // txtmonnettakhome
            // 
            this.txtmonnettakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtmonnettakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmonnettakhome.Enabled = false;
            this.txtmonnettakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonnettakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmonnettakhome.Location = new System.Drawing.Point(421, 17);
            this.txtmonnettakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmonnettakhome.Name = "txtmonnettakhome";
            this.txtmonnettakhome.Size = new System.Drawing.Size(133, 22);
            this.txtmonnettakhome.TabIndex = 35;
            // 
            // txtyrnettakhome
            // 
            this.txtyrnettakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtyrnettakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrnettakhome.Enabled = false;
            this.txtyrnettakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyrnettakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtyrnettakhome.Location = new System.Drawing.Point(260, 19);
            this.txtyrnettakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtyrnettakhome.Name = "txtyrnettakhome";
            this.txtyrnettakhome.Size = new System.Drawing.Size(133, 22);
            this.txtyrnettakhome.TabIndex = 34;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 22);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 17);
            this.label13.TabIndex = 33;
            this.label13.Text = "Net Take Home";
            // 
            // txtreimbmondriverallow
            // 
            this.txtreimbmondriverallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtreimbmondriverallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbmondriverallow.Enabled = false;
            this.txtreimbmondriverallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbmondriverallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbmondriverallow.Location = new System.Drawing.Point(421, 32);
            this.txtreimbmondriverallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbmondriverallow.Name = "txtreimbmondriverallow";
            this.txtreimbmondriverallow.Size = new System.Drawing.Size(133, 22);
            this.txtreimbmondriverallow.TabIndex = 38;
            // 
            // txtreimbyrdriverallow
            // 
            this.txtreimbyrdriverallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbyrdriverallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbyrdriverallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbyrdriverallow.Location = new System.Drawing.Point(260, 32);
            this.txtreimbyrdriverallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbyrdriverallow.Name = "txtreimbyrdriverallow";
            this.txtreimbyrdriverallow.Size = new System.Drawing.Size(133, 22);
            this.txtreimbyrdriverallow.TabIndex = 37;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(28, 34);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 16);
            this.label14.TabIndex = 36;
            this.label14.Text = "Driver Allowance";
            // 
            // txtreimbmonvehicmaintnce
            // 
            this.txtreimbmonvehicmaintnce.BackColor = System.Drawing.SystemColors.Info;
            this.txtreimbmonvehicmaintnce.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbmonvehicmaintnce.Enabled = false;
            this.txtreimbmonvehicmaintnce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbmonvehicmaintnce.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbmonvehicmaintnce.Location = new System.Drawing.Point(421, 59);
            this.txtreimbmonvehicmaintnce.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbmonvehicmaintnce.Name = "txtreimbmonvehicmaintnce";
            this.txtreimbmonvehicmaintnce.Size = new System.Drawing.Size(133, 22);
            this.txtreimbmonvehicmaintnce.TabIndex = 41;
            // 
            // txtreimbyrvehicmaintnce
            // 
            this.txtreimbyrvehicmaintnce.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbyrvehicmaintnce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbyrvehicmaintnce.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbyrvehicmaintnce.Location = new System.Drawing.Point(260, 59);
            this.txtreimbyrvehicmaintnce.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbyrvehicmaintnce.Name = "txtreimbyrvehicmaintnce";
            this.txtreimbyrvehicmaintnce.Size = new System.Drawing.Size(133, 22);
            this.txtreimbyrvehicmaintnce.TabIndex = 40;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(28, 61);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(133, 16);
            this.label15.TabIndex = 39;
            this.label15.Text = "Vehicle Manitanance";
            // 
            // txtreimbmonrelocallow
            // 
            this.txtreimbmonrelocallow.BackColor = System.Drawing.SystemColors.Info;
            this.txtreimbmonrelocallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbmonrelocallow.Enabled = false;
            this.txtreimbmonrelocallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbmonrelocallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbmonrelocallow.Location = new System.Drawing.Point(421, 87);
            this.txtreimbmonrelocallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbmonrelocallow.Name = "txtreimbmonrelocallow";
            this.txtreimbmonrelocallow.Size = new System.Drawing.Size(133, 22);
            this.txtreimbmonrelocallow.TabIndex = 44;
            // 
            // txtreimbyrrelocallow
            // 
            this.txtreimbyrrelocallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtreimbyrrelocallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreimbyrrelocallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtreimbyrrelocallow.Location = new System.Drawing.Point(260, 87);
            this.txtreimbyrrelocallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtreimbyrrelocallow.Name = "txtreimbyrrelocallow";
            this.txtreimbyrrelocallow.Size = new System.Drawing.Size(133, 22);
            this.txtreimbyrrelocallow.TabIndex = 43;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(28, 89);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(138, 16);
            this.label16.TabIndex = 42;
            this.label16.Text = "Relocation Allowance";
            // 
            // txtmontotmontakhome
            // 
            this.txtmontotmontakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtmontotmontakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmontotmontakhome.Enabled = false;
            this.txtmontotmontakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmontotmontakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmontotmontakhome.Location = new System.Drawing.Point(415, 14);
            this.txtmontotmontakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmontotmontakhome.Name = "txtmontotmontakhome";
            this.txtmontotmontakhome.Size = new System.Drawing.Size(133, 22);
            this.txtmontotmontakhome.TabIndex = 47;
            // 
            // txtyrtotmontakhome
            // 
            this.txtyrtotmontakhome.BackColor = System.Drawing.Color.AliceBlue;
            this.txtyrtotmontakhome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrtotmontakhome.Enabled = false;
            this.txtyrtotmontakhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyrtotmontakhome.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtyrtotmontakhome.Location = new System.Drawing.Point(254, 14);
            this.txtyrtotmontakhome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtyrtotmontakhome.Name = "txtyrtotmontakhome";
            this.txtyrtotmontakhome.Size = new System.Drawing.Size(133, 22);
            this.txtyrtotmontakhome.TabIndex = 46;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(22, 16);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(193, 17);
            this.label17.TabIndex = 45;
            this.label17.Text = "Total Monthly Take Home";
            // 
            // txtothermonpf
            // 
            this.txtothermonpf.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonpf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonpf.Enabled = false;
            this.txtothermonpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonpf.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonpf.Location = new System.Drawing.Point(421, 21);
            this.txtothermonpf.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonpf.Name = "txtothermonpf";
            this.txtothermonpf.Size = new System.Drawing.Size(133, 22);
            this.txtothermonpf.TabIndex = 50;
            // 
            // txtotheryrpf
            // 
            this.txtotheryrpf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrpf.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrpf.Location = new System.Drawing.Point(260, 21);
            this.txtotheryrpf.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrpf.Name = "txtotheryrpf";
            this.txtotheryrpf.Size = new System.Drawing.Size(133, 22);
            this.txtotheryrpf.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(28, 23);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 16);
            this.label18.TabIndex = 48;
            this.label18.Text = "PF";
            // 
            // txtothermonesic
            // 
            this.txtothermonesic.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonesic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonesic.Enabled = false;
            this.txtothermonesic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonesic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonesic.Location = new System.Drawing.Point(421, 49);
            this.txtothermonesic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonesic.Name = "txtothermonesic";
            this.txtothermonesic.Size = new System.Drawing.Size(133, 22);
            this.txtothermonesic.TabIndex = 53;
            // 
            // txtotheryresic
            // 
            this.txtotheryresic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryresic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryresic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryresic.Location = new System.Drawing.Point(260, 49);
            this.txtotheryresic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryresic.Name = "txtotheryresic";
            this.txtotheryresic.Size = new System.Drawing.Size(133, 22);
            this.txtotheryresic.TabIndex = 52;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(28, 51);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 16);
            this.label19.TabIndex = 51;
            this.label19.Text = "ESIC";
            // 
            // txtothermonmedic
            // 
            this.txtothermonmedic.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonmedic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonmedic.Enabled = false;
            this.txtothermonmedic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonmedic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonmedic.Location = new System.Drawing.Point(421, 74);
            this.txtothermonmedic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonmedic.Name = "txtothermonmedic";
            this.txtothermonmedic.Size = new System.Drawing.Size(133, 22);
            this.txtothermonmedic.TabIndex = 56;
            // 
            // txtotheryrmedic
            // 
            this.txtotheryrmedic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrmedic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrmedic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrmedic.Location = new System.Drawing.Point(260, 74);
            this.txtotheryrmedic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrmedic.Name = "txtotheryrmedic";
            this.txtotheryrmedic.Size = new System.Drawing.Size(133, 22);
            this.txtotheryrmedic.TabIndex = 55;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(28, 76);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 16);
            this.label20.TabIndex = 54;
            this.label20.Text = "Mediclaim";
            // 
            // txtothermonbonus
            // 
            this.txtothermonbonus.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonbonus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonbonus.Enabled = false;
            this.txtothermonbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonbonus.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonbonus.Location = new System.Drawing.Point(421, 101);
            this.txtothermonbonus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonbonus.Name = "txtothermonbonus";
            this.txtothermonbonus.Size = new System.Drawing.Size(133, 22);
            this.txtothermonbonus.TabIndex = 59;
            // 
            // txtotheryrbonus
            // 
            this.txtotheryrbonus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrbonus.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrbonus.Location = new System.Drawing.Point(260, 101);
            this.txtotheryrbonus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrbonus.Name = "txtotheryrbonus";
            this.txtotheryrbonus.Size = new System.Drawing.Size(133, 22);
            this.txtotheryrbonus.TabIndex = 58;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(28, 103);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 16);
            this.label21.TabIndex = 57;
            this.label21.Text = "Bonus";
            // 
            // txtothermonmealvou
            // 
            this.txtothermonmealvou.BackColor = System.Drawing.SystemColors.Info;
            this.txtothermonmealvou.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtothermonmealvou.Enabled = false;
            this.txtothermonmealvou.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtothermonmealvou.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtothermonmealvou.Location = new System.Drawing.Point(421, 131);
            this.txtothermonmealvou.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtothermonmealvou.Name = "txtothermonmealvou";
            this.txtothermonmealvou.Size = new System.Drawing.Size(133, 22);
            this.txtothermonmealvou.TabIndex = 62;
            // 
            // txtotheryrmealvou
            // 
            this.txtotheryrmealvou.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotheryrmealvou.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotheryrmealvou.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotheryrmealvou.Location = new System.Drawing.Point(260, 131);
            this.txtotheryrmealvou.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotheryrmealvou.Name = "txtotheryrmealvou";
            this.txtotheryrmealvou.Size = new System.Drawing.Size(133, 22);
            this.txtotheryrmealvou.TabIndex = 61;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(28, 133);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(91, 16);
            this.label22.TabIndex = 60;
            this.label22.Text = "Meal Voucher";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtearnmonbasic);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtearnyrbasic);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtearnyrhra);
            this.groupBox1.Controls.Add(this.txtearnmonhra);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtearnyrlta);
            this.groupBox1.Controls.Add(this.txtearnmonlta);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtearnyrconvey);
            this.groupBox1.Controls.Add(this.txtearnmonconvey);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtearnyrsplallow);
            this.groupBox1.Controls.Add(this.txtearnmonsplallow);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtearnyrattrallow);
            this.groupBox1.Controls.Add(this.txtearnmonattrallow);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtearnyrmedallow);
            this.groupBox1.Controls.Add(this.txtearnmonmedallow);
            this.groupBox1.Location = new System.Drawing.Point(12, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(583, 237);
            this.groupBox1.TabIndex = 63;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Earnings";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtdeducmonpfdeduc);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtdeducyrpfdeduc);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtdeducyresic);
            this.groupBox2.Controls.Add(this.txtdeducmonesic);
            this.groupBox2.Location = new System.Drawing.Point(622, 66);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(583, 103);
            this.groupBox2.TabIndex = 64;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Deductions";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txtgrossmontakhome);
            this.panel1.Controls.Add(this.txtgrossyrtakhome);
            this.panel1.Location = new System.Drawing.Point(12, 310);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(583, 39);
            this.panel1.TabIndex = 65;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtreimbmondriverallow);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txtreimbyrdriverallow);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txtreimbyrvehicmaintnce);
            this.groupBox3.Controls.Add(this.txtreimbmonvehicmaintnce);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtreimbyrrelocallow);
            this.groupBox3.Controls.Add(this.txtreimbmonrelocallow);
            this.groupBox3.Location = new System.Drawing.Point(12, 355);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(583, 115);
            this.groupBox3.TabIndex = 66;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Reimburesments";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtprodincentvmon);
            this.groupBox4.Controls.Add(this.txtprodincentv);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.txtothermonpf);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.txtotheryrpf);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.txtotheryresic);
            this.groupBox4.Controls.Add(this.txtothermonmealvou);
            this.groupBox4.Controls.Add(this.txtothermonesic);
            this.groupBox4.Controls.Add(this.txtotheryrmealvou);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.txtotheryrmedic);
            this.groupBox4.Controls.Add(this.txtothermonbonus);
            this.groupBox4.Controls.Add(this.txtothermonmedic);
            this.groupBox4.Controls.Add(this.txtotheryrbonus);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Location = new System.Drawing.Point(622, 268);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(583, 192);
            this.groupBox4.TabIndex = 67;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Others";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.txtyrtotmontakhome);
            this.panel2.Controls.Add(this.txtmontotmontakhome);
            this.panel2.Location = new System.Drawing.Point(12, 476);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(580, 44);
            this.panel2.TabIndex = 68;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.txtyrnettakhome);
            this.panel3.Controls.Add(this.txtmonnettakhome);
            this.panel3.Location = new System.Drawing.Point(622, 189);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(583, 48);
            this.panel3.TabIndex = 69;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.txtyrfinalctc);
            this.panel4.Controls.Add(this.txtmonfinalctc);
            this.panel4.Location = new System.Drawing.Point(625, 476);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(580, 44);
            this.panel4.TabIndex = 69;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(22, 16);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(78, 17);
            this.label23.TabIndex = 45;
            this.label23.Text = "Final CTC";
            // 
            // txtyrfinalctc
            // 
            this.txtyrfinalctc.BackColor = System.Drawing.Color.AliceBlue;
            this.txtyrfinalctc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyrfinalctc.Enabled = false;
            this.txtyrfinalctc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyrfinalctc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtyrfinalctc.Location = new System.Drawing.Point(254, 14);
            this.txtyrfinalctc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtyrfinalctc.Name = "txtyrfinalctc";
            this.txtyrfinalctc.Size = new System.Drawing.Size(133, 22);
            this.txtyrfinalctc.TabIndex = 46;
            // 
            // txtmonfinalctc
            // 
            this.txtmonfinalctc.BackColor = System.Drawing.Color.AliceBlue;
            this.txtmonfinalctc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmonfinalctc.Enabled = false;
            this.txtmonfinalctc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonfinalctc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmonfinalctc.Location = new System.Drawing.Point(415, 14);
            this.txtmonfinalctc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmonfinalctc.Name = "txtmonfinalctc";
            this.txtmonfinalctc.Size = new System.Drawing.Size(133, 22);
            this.txtmonfinalctc.TabIndex = 47;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(1077, 47);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 19);
            this.label24.TabIndex = 71;
            this.label24.Text = "Monthly";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(906, 47);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 19);
            this.label25.TabIndex = 70;
            this.label25.Text = "Yearly";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(134, 13);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(73, 15);
            this.label26.TabIndex = 73;
            this.label26.Text = "Emp Code";
            // 
            // cmbempcode
            // 
            this.cmbempcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbempcode.FormattingEnabled = true;
            this.cmbempcode.Location = new System.Drawing.Point(228, 13);
            this.cmbempcode.Name = "cmbempcode";
            this.cmbempcode.Size = new System.Drawing.Size(121, 23);
            this.cmbempcode.TabIndex = 74;
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(695, 32);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 75;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(795, 32);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 76;
            this.button2.Text = "Print";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtprodincentvmon
            // 
            this.txtprodincentvmon.BackColor = System.Drawing.SystemColors.Info;
            this.txtprodincentvmon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtprodincentvmon.Enabled = false;
            this.txtprodincentvmon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprodincentvmon.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtprodincentvmon.Location = new System.Drawing.Point(421, 160);
            this.txtprodincentvmon.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtprodincentvmon.Name = "txtprodincentvmon";
            this.txtprodincentvmon.Size = new System.Drawing.Size(133, 22);
            this.txtprodincentvmon.TabIndex = 65;
            // 
            // txtprodincentv
            // 
            this.txtprodincentv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtprodincentv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprodincentv.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtprodincentv.Location = new System.Drawing.Point(260, 160);
            this.txtprodincentv.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtprodincentv.Name = "txtprodincentv";
            this.txtprodincentv.Size = new System.Drawing.Size(133, 22);
            this.txtprodincentv.TabIndex = 64;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(28, 162);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(133, 16);
            this.label27.TabIndex = 63;
            this.label27.Text = "Productivity Incentive";
            // 
            // salarystructure
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 700);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.cmbempcode);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "salarystructure";
            this.Text = "salarystructure";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.salarystructure_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtearnyrbasic;
        private System.Windows.Forms.TextBox txtearnmonbasic;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtearnmonhra;
        private System.Windows.Forms.TextBox txtearnyrhra;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtearnmonlta;
        private System.Windows.Forms.TextBox txtearnyrlta;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtearnmonconvey;
        private System.Windows.Forms.TextBox txtearnyrconvey;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtearnmonsplallow;
        private System.Windows.Forms.TextBox txtearnyrsplallow;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtearnmonattrallow;
        private System.Windows.Forms.TextBox txtearnyrattrallow;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtearnmonmedallow;
        private System.Windows.Forms.TextBox txtearnyrmedallow;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtgrossmontakhome;
        private System.Windows.Forms.TextBox txtgrossyrtakhome;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtdeducmonpfdeduc;
        private System.Windows.Forms.TextBox txtdeducyrpfdeduc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtdeducmonesic;
        private System.Windows.Forms.TextBox txtdeducyresic;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtmonnettakhome;
        private System.Windows.Forms.TextBox txtyrnettakhome;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtreimbmondriverallow;
        private System.Windows.Forms.TextBox txtreimbyrdriverallow;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtreimbmonvehicmaintnce;
        private System.Windows.Forms.TextBox txtreimbyrvehicmaintnce;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtreimbmonrelocallow;
        private System.Windows.Forms.TextBox txtreimbyrrelocallow;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtmontotmontakhome;
        private System.Windows.Forms.TextBox txtyrtotmontakhome;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtothermonpf;
        private System.Windows.Forms.TextBox txtotheryrpf;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtothermonesic;
        private System.Windows.Forms.TextBox txtotheryresic;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtothermonmedic;
        private System.Windows.Forms.TextBox txtotheryrmedic;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtothermonbonus;
        private System.Windows.Forms.TextBox txtotheryrbonus;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtothermonmealvou;
        private System.Windows.Forms.TextBox txtotheryrmealvou;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtyrfinalctc;
        private System.Windows.Forms.TextBox txtmonfinalctc;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbempcode;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtprodincentvmon;
        private System.Windows.Forms.TextBox txtprodincentv;
        private System.Windows.Forms.Label label27;
    }
}