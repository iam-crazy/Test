﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{
    public partial class frmsaladvance : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");
        public frmsaladvance()
        {
            InitializeComponent();
        }

       
    }

}
