﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniforPayroll
{

    

    public partial class frmpasswordchange : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        private string getpassvalue;
        public string passvalue
        {
            get { return getpassvalue; }
            set { getpassvalue = value; }
        }

        public frmpasswordchange()
        {
            InitializeComponent();
        }

       
        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtoldpassword.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Old Password");
                txtoldpassword.Focus();
            }
            else
                if (txtnewpassword.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter New Password");
                    txtnewpassword.Focus();
                }

                else
                    if (txtconfirmpassword.Text.Length == 0)
                    {
                        MessageBox.Show("Please Enter Confirm Password");
                        txtconfirmpassword.Focus();
                    }

                    else
                    {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from tbluser where username=@username and password=@password", conn);
                    cmd.Parameters.AddWithValue("@username", txtusername.Text);
                    cmd.Parameters.AddWithValue("@password", txtoldpassword.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                       SqlCommand cmd1 = new SqlCommand("update tbluser set password = '" + txtnewpassword.Text + "' where username ='" + txtusername.Text + "' ",conn);
                    
                    //conn.Open();
                    int i = cmd1.ExecuteNonQuery();
                    conn.Close();
                    if (i > 0)
                    {

                        MessageBox.Show("Your Password is Changed...");
                    }
                    else
                    {
                        MessageBox.Show("Wrong User or Password");
                    }
                        
                    }
                    //conn.Close();
                    }
           
            

        }

        private void frmpasswordchange_Load(object sender, EventArgs e)
        {
            //txtusername.Text = getpassvalue;
            txtusername.Text = "Admin";
        }

       

       
    }
}
