﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UniforPayroll
{
    public partial class Form2 : Form
    {
        private string getpassvalue;
        public string passvalue
        {
            get { return getpassvalue; }
            set { getpassvalue = value; }
        }

        public Form2( )
        {
            InitializeComponent();
            
        }

         

        private void Form2_Load(object sender, EventArgs e)
        {


            textBox1.Text = getpassvalue;
            
            UniforPayroll.payslipprint payprint=new payslipprint();
            payprint.SetDatabaseLogon("sa", "x", "UNIMAA0004-PC\\Sqlexpress", "unipayroll");
            crystalReportViewer1.SelectionFormula = "{command.empcode}=('" +textBox1.Text +"')";

            crystalReportViewer1.ReportSource = payprint;
            //crystalReportViewer1.SelectionFormula=
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
