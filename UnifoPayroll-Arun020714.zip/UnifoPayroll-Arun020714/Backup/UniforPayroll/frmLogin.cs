﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace UniforPayroll
{
    public partial class frmLogin : Form
    {

        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        public frmLogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            //frmServerconn frmsercon = new frmServerconn();
            //frmsercon.Show();

            if (txtusername.Text.Length == 0)
            {
                MessageBox.Show("Please Enter UserName");
                txtusername.Focus();
            }
            else
                if (txtpassword.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter Password");
                    txtpassword.Focus();
                }

                else
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from tbluser where username=@username and password=@password", conn);
                    cmd.Parameters.AddWithValue("@username", txtusername.Text);
                    cmd.Parameters.AddWithValue("@password", txtpassword.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {

                        this.Hide();

                        Mainform mainfrm = new Mainform();
                        mainfrm.Show();

                        


                    }

                    else
                    {
                        MessageBox.Show("Wrong Username or Password");

                        txtusername.Text = "";
                        txtpassword.Text = "";
                        txtusername.Focus();
                    }

                }
            conn.Close();

            frmpasswordchange frmpasschange = new frmpasswordchange();
            frmpasschange.passvalue = txtusername.Text;


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
       
    }
}
