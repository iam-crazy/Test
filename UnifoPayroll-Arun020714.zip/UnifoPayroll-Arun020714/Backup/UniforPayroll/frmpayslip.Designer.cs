﻿namespace UniforPayroll
{
    partial class frmpayslip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnnewpay = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnprint = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btncalc = new System.Windows.Forms.Button();
            this.txtdate = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtremarks = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cmbdept = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txttds = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtptax = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtnoofpaydays = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtearnbonus = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtmediclaimri = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtnetsalary = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txttotdeduc = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txttotearn = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtotherdeduc = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtloan = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtotherpay = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtsalarrear = new System.Windows.Forms.TextBox();
            this.txtlop = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtdeducmonesic = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtdeducmonpfdeduc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtotherallow = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtearnmonbasic = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtearnmonhra = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtearnmonlta = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtearnmonconvey = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtearnmonsplallow = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtearnmonattrallow = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtearnmonmedallow = new System.Windows.Forms.TextBox();
            this.cmbmonth = new System.Windows.Forms.ComboBox();
            this.cmbyear = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtdesign = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtdept = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtempcode1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbemp = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(61, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(912, 682);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(904, 653);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Payslip List";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(97, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(678, 176);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScrollMargin = new System.Drawing.Size(1200, 700);
            this.tabPage2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.txtdate);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.txtremarks);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(904, 653);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Pay Generation";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnnewpay);
            this.groupBox4.Controls.Add(this.btnclear);
            this.groupBox4.Controls.Add(this.btnprint);
            this.groupBox4.Controls.Add(this.btnsave);
            this.groupBox4.Controls.Add(this.btncalc);
            this.groupBox4.Location = new System.Drawing.Point(740, 38);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(133, 203);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            // 
            // btnnewpay
            // 
            this.btnnewpay.Location = new System.Drawing.Point(14, 12);
            this.btnnewpay.Name = "btnnewpay";
            this.btnnewpay.Size = new System.Drawing.Size(106, 23);
            this.btnnewpay.TabIndex = 19;
            this.btnnewpay.Text = "New Pay";
            this.btnnewpay.UseVisualStyleBackColor = true;
            this.btnnewpay.Click += new System.EventHandler(this.btnnewpay_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(14, 162);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(106, 23);
            this.btnclear.TabIndex = 18;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            // 
            // btnprint
            // 
            this.btnprint.Location = new System.Drawing.Point(14, 124);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(106, 24);
            this.btnprint.TabIndex = 16;
            this.btnprint.Text = "Print PaySlip";
            this.btnprint.UseVisualStyleBackColor = true;
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(14, 85);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(106, 25);
            this.btnsave.TabIndex = 15;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(14, 46);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(109, 25);
            this.btncalc.TabIndex = 17;
            this.btncalc.Text = "Calculate Pay";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click_1);
            // 
            // txtdate
            // 
            this.txtdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdate.Location = new System.Drawing.Point(603, 8);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(126, 23);
            this.txtdate.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(505, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(92, 17);
            this.label20.TabIndex = 21;
            this.label20.Text = "Created Date";
            // 
            // txtremarks
            // 
            this.txtremarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtremarks.Location = new System.Drawing.Point(112, 600);
            this.txtremarks.Multiline = true;
            this.txtremarks.Name = "txtremarks";
            this.txtremarks.Size = new System.Drawing.Size(564, 30);
            this.txtremarks.TabIndex = 20;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(27, 608);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 17);
            this.label19.TabIndex = 19;
            this.label19.Text = "Remarks";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cmbemp);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.cmbdept);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Location = new System.Drawing.Point(27, 26);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(703, 51);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Select Employee";
            // 
            // cmbdept
            // 
            this.cmbdept.FormattingEnabled = true;
            this.cmbdept.Location = new System.Drawing.Point(166, 22);
            this.cmbdept.Name = "cmbdept";
            this.cmbdept.Size = new System.Drawing.Size(121, 24);
            this.cmbdept.TabIndex = 23;
            this.cmbdept.Text = "Select";
            this.cmbdept.SelectedIndexChanged += new System.EventHandler(this.cmbdept_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(78, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 16;
            this.label3.Text = "Department";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(318, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Employee";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txttds);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.txtptax);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.txtnoofpaydays);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtearnbonus);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtmediclaimri);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.txttotdeduc);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txttotearn);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtotherdeduc);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtloan);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtotherpay);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtsalarrear);
            this.groupBox2.Controls.Add(this.txtlop);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.txtdeducmonesic);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.txtdeducmonpfdeduc);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtotherallow);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.txtearnmonbasic);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.txtearnmonhra);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.txtearnmonlta);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txtearnmonconvey);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.txtearnmonsplallow);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.txtearnmonattrallow);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.txtearnmonmedallow);
            this.groupBox2.Controls.Add(this.cmbmonth);
            this.groupBox2.Controls.Add(this.cmbyear);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(27, 144);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(697, 369);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pay Details";
            // 
            // txttds
            // 
            this.txttds.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txttds.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttds.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txttds.Location = new System.Drawing.Point(489, 196);
            this.txttds.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txttds.Name = "txttds";
            this.txttds.Size = new System.Drawing.Size(97, 22);
            this.txttds.TabIndex = 96;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(334, 198);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 16);
            this.label23.TabIndex = 95;
            this.label23.Text = "TDS Deduction";
            // 
            // txtptax
            // 
            this.txtptax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtptax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtptax.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtptax.Location = new System.Drawing.Point(489, 173);
            this.txtptax.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtptax.Name = "txtptax";
            this.txtptax.Size = new System.Drawing.Size(97, 22);
            this.txtptax.TabIndex = 94;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(334, 175);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(109, 16);
            this.label22.TabIndex = 93;
            this.label22.Text = "Professional Tax";
            // 
            // txtnoofpaydays
            // 
            this.txtnoofpaydays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtnoofpaydays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoofpaydays.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtnoofpaydays.Location = new System.Drawing.Point(564, 25);
            this.txtnoofpaydays.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtnoofpaydays.Name = "txtnoofpaydays";
            this.txtnoofpaydays.Size = new System.Drawing.Size(97, 22);
            this.txtnoofpaydays.TabIndex = 92;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(454, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(109, 17);
            this.label21.TabIndex = 91;
            this.label21.Text = "No Of Pay Days";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(27, 293);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 16);
            this.label18.TabIndex = 89;
            this.label18.Text = "Bonus";
            // 
            // txtearnbonus
            // 
            this.txtearnbonus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnbonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnbonus.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnbonus.Location = new System.Drawing.Point(171, 291);
            this.txtearnbonus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnbonus.Name = "txtearnbonus";
            this.txtearnbonus.Size = new System.Drawing.Size(97, 22);
            this.txtearnbonus.TabIndex = 90;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(28, 270);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 16);
            this.label17.TabIndex = 87;
            this.label17.Text = "Mediclaim(RI)";
            // 
            // txtmediclaimri
            // 
            this.txtmediclaimri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmediclaimri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmediclaimri.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmediclaimri.Location = new System.Drawing.Point(171, 268);
            this.txtmediclaimri.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmediclaimri.Name = "txtmediclaimri";
            this.txtmediclaimri.Size = new System.Drawing.Size(97, 22);
            this.txtmediclaimri.TabIndex = 88;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtnetsalary);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Location = new System.Drawing.Point(321, 245);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(299, 50);
            this.groupBox3.TabIndex = 86;
            this.groupBox3.TabStop = false;
            // 
            // txtnetsalary
            // 
            this.txtnetsalary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtnetsalary.Enabled = false;
            this.txtnetsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnetsalary.ForeColor = System.Drawing.Color.Green;
            this.txtnetsalary.Location = new System.Drawing.Point(172, 21);
            this.txtnetsalary.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtnetsalary.Name = "txtnetsalary";
            this.txtnetsalary.Size = new System.Drawing.Size(97, 24);
            this.txtnetsalary.TabIndex = 87;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Green;
            this.label16.Location = new System.Drawing.Point(21, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 18);
            this.label16.TabIndex = 86;
            this.label16.Text = "Net Salary";
            // 
            // txttotdeduc
            // 
            this.txttotdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txttotdeduc.Enabled = false;
            this.txttotdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txttotdeduc.Location = new System.Drawing.Point(490, 219);
            this.txttotdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txttotdeduc.Name = "txttotdeduc";
            this.txttotdeduc.Size = new System.Drawing.Size(97, 22);
            this.txttotdeduc.TabIndex = 83;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(337, 219);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(126, 16);
            this.label15.TabIndex = 82;
            this.label15.Text = "Total Deductions";
            // 
            // txttotearn
            // 
            this.txttotearn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txttotearn.Enabled = false;
            this.txttotearn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotearn.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txttotearn.Location = new System.Drawing.Point(171, 343);
            this.txttotearn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txttotearn.Name = "txttotearn";
            this.txttotearn.Size = new System.Drawing.Size(97, 22);
            this.txttotearn.TabIndex = 81;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(27, 343);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 16);
            this.label14.TabIndex = 80;
            this.label14.Text = "Total Earnings";
            // 
            // txtotherdeduc
            // 
            this.txtotherdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotherdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotherdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotherdeduc.Location = new System.Drawing.Point(489, 150);
            this.txtotherdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotherdeduc.Name = "txtotherdeduc";
            this.txtotherdeduc.Size = new System.Drawing.Size(97, 22);
            this.txtotherdeduc.TabIndex = 79;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(334, 152);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 16);
            this.label13.TabIndex = 78;
            this.label13.Text = "Other Deductions";
            // 
            // txtloan
            // 
            this.txtloan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtloan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloan.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtloan.Location = new System.Drawing.Point(489, 127);
            this.txtloan.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtloan.Name = "txtloan";
            this.txtloan.Size = new System.Drawing.Size(97, 22);
            this.txtloan.TabIndex = 77;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(334, 129);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(146, 16);
            this.label12.TabIndex = 76;
            this.label12.Text = "Loan/Salary Adavance";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(27, 316);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 16);
            this.label11.TabIndex = 74;
            this.label11.Text = "Other Payments";
            // 
            // txtotherpay
            // 
            this.txtotherpay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotherpay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotherpay.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotherpay.Location = new System.Drawing.Point(171, 314);
            this.txtotherpay.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotherpay.Name = "txtotherpay";
            this.txtotherpay.Size = new System.Drawing.Size(97, 22);
            this.txtotherpay.TabIndex = 75;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 247);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 16);
            this.label10.TabIndex = 72;
            this.label10.Text = "Salary Arrear";
            // 
            // txtsalarrear
            // 
            this.txtsalarrear.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsalarrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalarrear.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtsalarrear.Location = new System.Drawing.Point(171, 245);
            this.txtsalarrear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtsalarrear.Name = "txtsalarrear";
            this.txtsalarrear.Size = new System.Drawing.Size(97, 22);
            this.txtsalarrear.TabIndex = 73;
            // 
            // txtlop
            // 
            this.txtlop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtlop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlop.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtlop.Location = new System.Drawing.Point(489, 104);
            this.txtlop.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtlop.Name = "txtlop";
            this.txtlop.Size = new System.Drawing.Size(97, 22);
            this.txtlop.TabIndex = 71;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(334, 60);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(25, 16);
            this.label47.TabIndex = 62;
            this.label47.Text = "PF";
            // 
            // txtdeducmonesic
            // 
            this.txtdeducmonesic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducmonesic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducmonesic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducmonesic.Location = new System.Drawing.Point(489, 81);
            this.txtdeducmonesic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducmonesic.Name = "txtdeducmonesic";
            this.txtdeducmonesic.Size = new System.Drawing.Size(97, 22);
            this.txtdeducmonesic.TabIndex = 65;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(334, 83);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(38, 16);
            this.label48.TabIndex = 64;
            this.label48.Text = "ESIC";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(334, 106);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(34, 16);
            this.label45.TabIndex = 70;
            this.label45.Text = "LOP";
            // 
            // txtdeducmonpfdeduc
            // 
            this.txtdeducmonpfdeduc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdeducmonpfdeduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeducmonpfdeduc.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdeducmonpfdeduc.Location = new System.Drawing.Point(489, 58);
            this.txtdeducmonpfdeduc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtdeducmonpfdeduc.Name = "txtdeducmonpfdeduc";
            this.txtdeducmonpfdeduc.Size = new System.Drawing.Size(97, 22);
            this.txtdeducmonpfdeduc.TabIndex = 63;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 225);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 16);
            this.label7.TabIndex = 49;
            this.label7.Text = "Other Allowances";
            // 
            // txtotherallow
            // 
            this.txtotherallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtotherallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtotherallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtotherallow.Location = new System.Drawing.Point(171, 222);
            this.txtotherallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtotherallow.Name = "txtotherallow";
            this.txtotherallow.Size = new System.Drawing.Size(97, 22);
            this.txtotherallow.TabIndex = 50;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(29, 59);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(42, 16);
            this.label27.TabIndex = 35;
            this.label27.Text = "Basic";
            // 
            // txtearnmonbasic
            // 
            this.txtearnmonbasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonbasic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonbasic.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonbasic.Location = new System.Drawing.Point(171, 57);
            this.txtearnmonbasic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonbasic.Name = "txtearnmonbasic";
            this.txtearnmonbasic.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonbasic.TabIndex = 36;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(29, 83);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(37, 16);
            this.label28.TabIndex = 37;
            this.label28.Text = "HRA";
            // 
            // txtearnmonhra
            // 
            this.txtearnmonhra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonhra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonhra.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonhra.Location = new System.Drawing.Point(171, 81);
            this.txtearnmonhra.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonhra.Name = "txtearnmonhra";
            this.txtearnmonhra.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonhra.TabIndex = 38;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(29, 107);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(33, 16);
            this.label29.TabIndex = 39;
            this.label29.Text = "LTA";
            // 
            // txtearnmonlta
            // 
            this.txtearnmonlta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonlta.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonlta.Location = new System.Drawing.Point(171, 105);
            this.txtearnmonlta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonlta.Name = "txtearnmonlta";
            this.txtearnmonlta.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonlta.TabIndex = 40;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(29, 131);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(84, 16);
            this.label30.TabIndex = 41;
            this.label30.Text = "Conveyence";
            // 
            // txtearnmonconvey
            // 
            this.txtearnmonconvey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonconvey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonconvey.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonconvey.Location = new System.Drawing.Point(171, 129);
            this.txtearnmonconvey.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonconvey.Name = "txtearnmonconvey";
            this.txtearnmonconvey.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonconvey.TabIndex = 42;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(29, 155);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(119, 16);
            this.label31.TabIndex = 43;
            this.label31.Text = "Special Allowance";
            // 
            // txtearnmonsplallow
            // 
            this.txtearnmonsplallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonsplallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonsplallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonsplallow.Location = new System.Drawing.Point(171, 153);
            this.txtearnmonsplallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonsplallow.Name = "txtearnmonsplallow";
            this.txtearnmonsplallow.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonsplallow.TabIndex = 44;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(30, 178);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(103, 16);
            this.label32.TabIndex = 45;
            this.label32.Text = "Attire Allowance";
            // 
            // txtearnmonattrallow
            // 
            this.txtearnmonattrallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonattrallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonattrallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonattrallow.Location = new System.Drawing.Point(171, 176);
            this.txtearnmonattrallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonattrallow.Name = "txtearnmonattrallow";
            this.txtearnmonattrallow.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonattrallow.TabIndex = 46;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(29, 201);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(121, 16);
            this.label33.TabIndex = 47;
            this.label33.Text = "Medical Allownace";
            // 
            // txtearnmonmedallow
            // 
            this.txtearnmonmedallow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtearnmonmedallow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtearnmonmedallow.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtearnmonmedallow.Location = new System.Drawing.Point(171, 199);
            this.txtearnmonmedallow.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtearnmonmedallow.Name = "txtearnmonmedallow";
            this.txtearnmonmedallow.Size = new System.Drawing.Size(97, 22);
            this.txtearnmonmedallow.TabIndex = 48;
            // 
            // cmbmonth
            // 
            this.cmbmonth.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbmonth.FormattingEnabled = true;
            this.cmbmonth.Items.AddRange(new object[] {
            "JAN",
            "FEB",
            "MAR",
            "APR",
            "MAY",
            "JUN",
            "JUL",
            "AUG",
            "SEP",
            "OCT",
            "NOV",
            "DEC"});
            this.cmbmonth.Location = new System.Drawing.Point(304, 26);
            this.cmbmonth.Name = "cmbmonth";
            this.cmbmonth.Size = new System.Drawing.Size(121, 24);
            this.cmbmonth.TabIndex = 22;
            // 
            // cmbyear
            // 
            this.cmbyear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbyear.FormattingEnabled = true;
            this.cmbyear.Items.AddRange(new object[] {
            "2013",
            "2014",
            "2015"});
            this.cmbyear.Location = new System.Drawing.Point(90, 26);
            this.cmbyear.Name = "cmbyear";
            this.cmbyear.Size = new System.Drawing.Size(121, 24);
            this.cmbyear.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(233, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "Month";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(35, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "Year";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtdesign);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtdept);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtempname);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtempcode1);
            this.groupBox1.Location = new System.Drawing.Point(27, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(703, 74);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Details";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 17);
            this.label5.TabIndex = 21;
            this.label5.Text = "Department";
            // 
            // txtdesign
            // 
            this.txtdesign.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdesign.Location = new System.Drawing.Point(469, 47);
            this.txtdesign.Name = "txtdesign";
            this.txtdesign.Size = new System.Drawing.Size(228, 23);
            this.txtdesign.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(355, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 17);
            this.label6.TabIndex = 19;
            this.label6.Text = "Designation";
            // 
            // txtdept
            // 
            this.txtdept.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdept.Location = new System.Drawing.Point(141, 44);
            this.txtdept.Name = "txtdept";
            this.txtdept.Size = new System.Drawing.Size(183, 23);
            this.txtdept.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 17;
            this.label4.Text = "Emp Code";
            // 
            // txtempname
            // 
            this.txtempname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtempname.Location = new System.Drawing.Point(469, 22);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(228, 23);
            this.txtempname.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(355, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "Emp Name";
            // 
            // txtempcode1
            // 
            this.txtempcode1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtempcode1.Location = new System.Drawing.Point(141, 19);
            this.txtempcode1.Name = "txtempcode1";
            this.txtempcode1.Size = new System.Drawing.Size(128, 23);
            this.txtempcode1.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(564, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 26);
            this.button1.TabIndex = 24;
            this.button1.Text = "Process";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbemp
            // 
            this.cmbemp.FormattingEnabled = true;
            this.cmbemp.Location = new System.Drawing.Point(417, 22);
            this.cmbemp.Name = "cmbemp";
            this.cmbemp.Size = new System.Drawing.Size(121, 24);
            this.cmbemp.TabIndex = 24;
            // 
            // frmpayslip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1366, 746);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmpayslip";
            this.Text = "PaySlip Generation";
            this.Load += new System.EventHandler(this.frmpayslip_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtempcode1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtdesign;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtdept;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbyear;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbmonth;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtearnmonbasic;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtearnmonhra;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtearnmonlta;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtearnmonconvey;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtearnmonsplallow;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtearnmonattrallow;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtearnmonmedallow;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtotherallow;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtsalarrear;
        private System.Windows.Forms.TextBox txtlop;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtdeducmonesic;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtdeducmonpfdeduc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtotherpay;
        private System.Windows.Forms.TextBox txttotearn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtotherdeduc;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtloan;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtnetsalary;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txttotdeduc;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnprint;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox txtremarks;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtearnbonus;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtmediclaimri;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtdate;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtnoofpaydays;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbdept;
        private System.Windows.Forms.TextBox txtptax;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txttds;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnnewpay;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmbemp;

    }
}