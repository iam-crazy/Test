﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.Drawing.Imaging;
using Microsoft.VisualBasic;
using System.IO;

namespace UniforPayroll
{
    public partial class frmempdetails : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        public frmempdetails()
        {
            InitializeComponent();
        }

        DataSet ds;

        

        private void btnimgupload_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "All Files(*.*)|*.*";
            openFileDialog1.Multiselect = false;
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;
            openFileDialog1.OpenFile();
            txtImagePath.Text = openFileDialog1.FileName;
            picempphoto.ImageLocation = txtImagePath.Text;
        }

        private void cmbempstatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            

            

        }

       

        private void frmempdetails_Load(object sender, EventArgs e)
        {
            
            WindowState = FormWindowState.Maximized;

            //emp list tab load

            load_dept();
            load_branch();
            load_emplistgrid();
            salstructload();

            label62.Visible = false;

            //emp personal details load
            
            txtempname.Enabled = false;
            txtpermenadd.Enabled = false;
            txtpreadd.Enabled = false;
            dtpdob.Enabled = false;
            cmbgender.Enabled = false;
            cmbmaritialstatus.Enabled = false;
            txtphone.Enabled = false;
            txtmobile.Enabled = false;
            txtemail.Enabled = false;
            txtbankaccname.Enabled = false;
            txtbankaccno.Enabled = false;
            txtbankname.Enabled = false;
            txtbankbranch.Enabled = false;
            txtbankcity.Enabled = false;
            cmbdesig.Enabled = false;
            cmbdept.Enabled = false;
            cmbbranch.Enabled = false;
            cmbreportto.Enabled = false;
            dtpdoj.Enabled = false;
            dtpdor.Enabled = false;
            txtpanno.Enabled = false;
            //txtpassportno.Enabled = false;
            //txtdrivlicno.Enabled = false;
            txtblood.Enabled = false;
            txtbankcity.Enabled = false;
            txtbankbranch.Enabled = false;
            checkBox2.Enabled = false;

            btnsave.Enabled = false;
            //btnedit.Enabled = false;

            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = false;
            button4.Enabled = false;

            txtcreateddate.Text = DateTime.Now.ToString("dd-MMM-yyyy");

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();

            }


            conn.Open();
            SqlCommand cmd = new SqlCommand("select brname from mbranch", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "mbranch");
            cmbbranch1.DataSource = ds.Tables["mbranch"];
            cmbbranch1.DisplayMember = "brname";
            cmbbranch1.ValueMember = "brname";
            cmbbranch1.SelectedIndex = -1;


            SqlCommand cmd1 = new SqlCommand("select deptname from mdept", conn);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1, "mdept");
            cmbdeprt.DataSource = ds1.Tables["mdept"];
            cmbdeprt.DisplayMember = "deptname";
            //cmbbranch.ValueMember = "deptname";
            cmbdeprt.SelectedIndex = -1;



            SqlCommand cmd2 = new SqlCommand("select designame from mdesignation", conn);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2, "mdesignation");
            cmbdesign.DataSource = ds2.Tables["mdesignation"];
            cmbdesign.DisplayMember = "designame";

            cmbdesign.SelectedIndex = -1;
            conn.Close();

            dtpdatresign.Enabled = false;
        }

        private void cmbsalaryby_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtempname.Focus();

            
            txtempname.Enabled = true;
            txtpermenadd.Enabled = true;
            txtpreadd.Enabled = true;
            dtpdob.Enabled = true;
            cmbgender.Enabled = true;
            cmbmaritialstatus.Enabled = true;
            txtphone.Enabled = true;
            txtmobile.Enabled = true;
            txtemail.Enabled = true;
            txtbankaccname.Enabled = true;
            txtbankaccno.Enabled = true;
            txtbankname.Enabled = true;
            txtbankbranch.Enabled = true;
            txtbankcity.Enabled = true;
            cmbdesig.Enabled = true;
            cmbdept.Enabled = true;
            cmbbranch.Enabled = true;
            cmbreportto.Enabled = true;
            dtpdoj.Enabled = true;
            dtpdor.Enabled = true;
            txtpanno.Enabled = true;
            //txtpassportno.Enabled = true;
            //txtdrivlicno.Enabled = true;
            txtblood.Enabled = true;
            txtbankcity.Enabled = true;
            txtbankbranch.Enabled = true;

            btnsave.Enabled = true;
            //btnedit.Enabled = false;


            int Num1 = 0000;

            conn.Open();
            SqlCommand cmd = new SqlCommand("Select MAX(empid) from tblemployee", conn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Num1 = int.Parse(dr[0].ToString());

            }
            dr.Close();

            if (Num1.ToString().Length == 1)
            {
                txtempcode.Text = "UNIMAA000" + (Num1 + 1).ToString();
            }
            if(Num1.ToString().Length == 2)
            {
                txtempcode.Text = "UNIMAA00" + (Num1 + 1).ToString();
            }
            if (Num1.ToString().Length == 3)
            {
                txtempcode.Text = "UNIMAA0" + (Num1 + 1).ToString();
            }
            if (Num1.ToString().Length == 4)
            {
                txtempcode.Text = "UNIMAA" + (Num1 + 1).ToString();
            }

            txtempname.Text =Convert.ToString(Num1.ToString().Length) ;
            conn.Close();

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtempname.Text.Length == 0)
            {
                MessageBox.Show("Please Enter Employee Name");
                txtempname.Focus();
            }

            else
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }


                conn.Open();
                SqlCommand cmd = new SqlCommand("insert into tblemployee(empcode,name,preaddr,peraddr,dob,gender,maritialstatus,phoneno,mobiletno,designation,emailid,accname,accno,bank,bankbranch,bankcity,dept,branch,reportingto,doj,dor,panno,blood,fathername,empstatus,preemployer,predesign,preyearsworked,eduhighquaL,edumajor,ifsccode,empphoto)values('" + txtempcode.Text + "', '" + txtempname.Text + "','" + txtpreadd.Text + "','" + txtpermenadd.Text + "','" + dtpdob.Text + "','" + cmbgender.Text + "','" + cmbmaritialstatus.Text + "','" + txtphone.Text + "','" + txtmobile.Text + "','" + cmbdesign.Text + "','" + txtemail.Text + "','" + txtbankaccname.Text + "','" + txtbankaccno.Text + "','" + txtbankname.Text + "','" + txtbankbranch.Text + "','" + txtbankcity.Text + "','" + cmbdeprt.Text + "','" + cmbbranch1.Text + "','" + cmbreportto.Text + "','" + dtpdoj.Text + "','" + dtpdor.Text + "','" + txtpanno.Text + "','" + txtblood.Text + "','" + txtfathername.Text + "','" + cmbempstatus.Text + "','" + txtprevempler.Text + "','" + txtprevdesign.Text + "','" + txtyrsofworked.Text + "','" + txtqualif.Text + "','" + txtmajor.Text + "','" + txtifsccode.Text + "',@photo)", conn);
                if (picempphoto.Image != null)
                {
                    
                    MemoryStream ms = new MemoryStream();

                    picempphoto.Image.Save(ms, ImageFormat.Jpeg);
                    byte[] photo_aray = new byte[ms.Length];
                    ms.Position = 0;
                    ms.Read(photo_aray, 0, photo_aray.Length);
                    cmd.Parameters.AddWithValue("@photo", photo_aray);
                }   
               
                cmd.ExecuteNonQuery();

                
                MessageBox.Show("Record Saved Successfully");

                //If (Not txtImagePath.Text = Nothing And Not String.IsNullOrEmpty(txtImagePath.Text)) Then
                //FileCopy(txtImagePath.Text, objDAL.CurDir & "EmployeePhoto\" & txtEmployeeID.Text & "_" & txtempName.Text & "." & txtImagePath.Text.Split(New Char(), ("."))(1).ToString());
            //End If
                conn.Close();
            }

        }
       
             
       


        private void button3_Click(object sender, EventArgs e)
        {
            txtearnmonbasic.Text = (Convert.ToInt32(txtearnyrbasic.Text) / 12).ToString();
            txtearnmonhra.Text = (Convert.ToInt32(txtearnyrhra.Text) / 12).ToString();
            txtearnmonlta.Text = (Convert.ToInt32(txtearnyrlta.Text) / 12).ToString();
            txtearnmonconvey.Text = (Convert.ToInt32(txtearnyrconvey.Text) / 12).ToString();
            txtearnmonsplallow.Text = (Convert.ToInt32(txtearnyrsplallow.Text) / 12).ToString();
            txtearnmonattrallow.Text = (Convert.ToInt32(txtearnyrattrallow.Text) / 12).ToString();
            txtearnmonmedallow.Text = (Convert.ToInt32(txtearnyrmedallow.Text) / 12).ToString();

            //Gross take home calc
            float grosstakhomeyr;

            txtgrossyrtakhome.Text = ((Convert.ToInt32(txtearnyrbasic.Text)) + (Convert.ToInt32(txtearnyrhra.Text)) + (Convert.ToInt32(txtearnyrlta.Text)) + (Convert.ToInt32(txtearnyrconvey.Text)) + (Convert.ToInt32(txtearnyrsplallow.Text)) + (Convert.ToInt32(txtearnyrattrallow.Text)) + (Convert.ToInt32(txtearnyrmedallow.Text))).ToString();
            txtgrossmontakhome.Text = (Convert.ToInt32(txtgrossyrtakhome.Text) / 12).ToString();

            grosstakhomeyr = Convert.ToInt32(txtgrossyrtakhome.Text);


            txtreimbmondriverallow.Text = (Convert.ToInt32(txtreimbyrdriverallow.Text) / 12).ToString();
            txtreimbmonvehicmaintnce.Text = (Convert.ToInt32(txtreimbyrvehicmaintnce.Text) / 12).ToString();
            txtreimbmonrelocallow.Text = (Convert.ToInt32(txtreimbyrrelocallow.Text) / 12).ToString();

            //Monthly take home calc

            txtyrtotmontakhome.Text = ((Convert.ToInt32(txtgrossyrtakhome.Text)) + (Convert.ToInt32(txtreimbyrdriverallow.Text)) + (Convert.ToInt32(txtreimbyrvehicmaintnce.Text)) + (Convert.ToInt32(txtreimbyrrelocallow.Text))).ToString();
            txtmontotmontakhome.Text = (Convert.ToInt32(txtyrtotmontakhome.Text) / 12).ToString();

            float totmontakehomeyr;
            totmontakehomeyr = Convert.ToInt32(txtyrtotmontakhome.Text);

            //deduction calc

            txtdeducmonpfdeduc.Text = (Convert.ToInt32(txtdeducyrpfdeduc.Text) / 12).ToString();
            txtdeducmonesic.Text = (Convert.ToInt32(txtdeducyresic.Text) / 12).ToString();

            float totdeductionyearly;
            float totdeductionmonthly;
            float pfdeducyr;
            float esicdeducyr;
            pfdeducyr = Convert.ToInt32(txtdeducyrpfdeduc.Text);
            esicdeducyr = Convert.ToInt32(txtdeducyresic.Text);
            totdeductionyearly = pfdeducyr + esicdeducyr;
            totdeductionmonthly = totdeductionyearly / 12;

            //Nettake home calc
            float nettakehomeyr;
            nettakehomeyr = totmontakehomeyr - totdeductionyearly;
            txtyrnettakhome.Text = nettakehomeyr.ToString();
            txtmonnettakhom.Text = (Convert.ToInt32(txtyrnettakhome.Text) / 12).ToString();

            //others calc

            txtothermonpf.Text = (Convert.ToInt32(txtotheryrpf.Text) / 12).ToString();
            txtothermonesic.Text = (Convert.ToInt32(txtotheryresic.Text) / 12).ToString();
            txtothermonmedic.Text = (Convert.ToInt32(txtotheryrmedic.Text) / 12).ToString();
            txtothermonbonus.Text = (Convert.ToInt32(txtotheryrbonus.Text) / 12).ToString();
            txtothermonmealvou.Text = (Convert.ToInt32(txtotheryrmealvou.Text) / 12).ToString();
            txtothermonprodincentvmon.Text = (Convert.ToInt32(txtotheryrprodincentv.Text) / 12).ToString();

            float otherpfyr;
            float otheresicyr;
            float othermedic;
            float otherbonus;
            float othermealvou;
            float totalothersyr;
            float otherprodincetv;

            otherpfyr = Convert.ToInt32(txtotheryrpf.Text);
            otheresicyr = Convert.ToInt32(txtotheryresic.Text);
            othermedic = Convert.ToInt32(txtotheryrmedic.Text);
            otherbonus = Convert.ToInt32(txtotheryrbonus.Text);
            othermealvou = Convert.ToInt32(txtotheryrmealvou.Text);
            otherprodincetv = Convert.ToInt32(txtotheryrprodincentv.Text);

            totalothersyr = otherpfyr + otheresicyr + othermedic + otherbonus + othermealvou+otherprodincetv;

            //final CTC calc

            float totfinalctc;

            totfinalctc = nettakehomeyr + totalothersyr;

            txtyrfinalctc.Text = totfinalctc.ToString();

            txtmonfinalctc.Text = (Convert.ToInt32(txtyrfinalctc.Text) / 12).ToString();
            




        }

        private void button1_Click(object sender, EventArgs e)
        {

            button1.Enabled = false;
            button4.Enabled = true;
            button3.Enabled = true;
            conn.Open();

            //SqlCommand cmd = new SqlCommand("insert into salstructure(empid,basic,hra,lta,conveyence,splallow,attirallow,mediallow,driverallow,vechiclemaint,relocallow,pfdeduc,esic,otherpf,otheresic,othermediclaim,otherbonus,othermealvou,grosstakhome,totmonthtakhome,nettakhome,finalctc,basicmon,hramon,ltamon,conveyencemon,splallowmon,attirallowmon,medicallowmon,driverallowmon,vechicmaintmon,relocmon,pfmon,esicmon,otherpfmon,otheresicmon,othermediclaimmon,otherbonusmon,othermealvoumon,grosstakhomemon,totmontakhomemon,nettakhomemon,finalctcmon)values('" +cmbempcode.Text+ "' ,'" +txtearnyrbasic.Text+ "','" +txtearnyrhra.Text+ "','" + txtearnyrlta.Text+ "','" +txtearnyrconvey.Text+ "','" + txtearnyrsplallow.Text + "','" +txtearnyrattrallow.Text+ "','" +txtearnyrmedallow.Text+ "','" +txtreimbmondriverallow.Text+ "','" +txtreimbyrvehicmaintnce.Text+ "','" +txtreimbyrrelocallow.Text+ "','" +txtdeducyrpfdeduc.Text+ "','" +txtdeducyresic.Text+ "','" +txtotheryrpf.Text+ "','" +txtotheryresic.Text+ "','" +txtotheryrmedic.Text+ "','" +txtotheryrbonus.Text+ "','" +txtotheryrmealvou.Text+ "','" +txtgrossyrtakhome.Text+ "','" +txtyrtotmontakhome.Text+ "','" +txtyrnettakhome.Text+ "','" +txtyrfinalctc.Text+ "','" +txtearnmonbasic.Text+ "','" +txtearnmonhra.Text+ "','" +txtearnmonlta.Text+ "','" +txtearnmonconvey+ "','" +txtearnmonsplallow.Text+ "','" +txtearnmonattrallow.Text+ "','" +txtearnmonmedallow.Text+ "','" +txtreimbmondriverallow.Text+ "','" +txtreimbmonvehicmaintnce.Text+ "','" +txtreimbmonrelocallow.Text+ "','" +txtdeducmonpfdeduc.Text+ "','" +txtdeducmonesic.Text+ "','" +txtothermonpf.Text+ "','" +txtothermonesic.Text+ "','" +txtothermonmedic.Text+ "','" +txtothermonbonus.Text+ "','" +txtothermonmealvou.Text+ "','" +txtgrossmontakhome.Text+ "','" +txtmontotmontakhome.Text+ "','" +txtmonnettakhome.Text+ "','" +txtmonfinalctc.Text+ "' )",conn);
            SqlCommand cmd = new SqlCommand("insert into salstructure(empcode,basic,hra,lta,conveyence,splallow,attirallow,mediallow,driverallow,vechiclemaint,relocallow,pfdeduc,esic,otherpf,otheresic,othermediclaim,otherbonus,othermealvou,grosstakhome,totmonthtakhome,nettakhome,finalctc,basicmon,hramon,ltamon,conveyencemon,splallowmon,attirallowmon,medicallowmon,driverallowmon,vechicmaintmon,relocmon,pfmon,esicmon,otherpfmon,otheresicmon,othermediclaimmon,otherbonusmon,othermealvoumon,grosstakhomemon,totmontakhomemon,nettakhomemon,finalctcmon)values('" +txtempcode.Text+ "','" + txtearnyrbasic.Text + "','" + txtearnyrhra.Text + "','" + txtearnyrlta.Text + "','" + txtearnyrconvey.Text + "','" + txtearnyrsplallow.Text + "','" + txtearnyrattrallow.Text + "','" + txtearnyrmedallow.Text + "','" + txtreimbyrdriverallow.Text + "','" + txtreimbyrvehicmaintnce.Text + "','" + txtreimbyrrelocallow.Text + "','" + txtdeducyrpfdeduc.Text + "','" + txtdeducyresic.Text + "','" + txtotheryrpf.Text + "','" + txtotheryresic.Text + "','" + txtotheryrmedic.Text + "','" + txtotheryrbonus.Text + "','" + txtotheryrmealvou.Text + "','" + txtgrossyrtakhome.Text + "','" + txtyrtotmontakhome.Text + "','" + txtyrnettakhome.Text + "','" + txtyrfinalctc.Text + "','" + txtearnmonbasic.Text + "','" + txtearnmonhra.Text + "','" + txtearnmonlta.Text + "','" + txtearnmonconvey.Text + "','" + txtearnmonsplallow.Text + "','" + txtearnmonattrallow.Text + "','" + txtearnmonmedallow.Text + "','" + txtreimbmondriverallow.Text + "','" + txtreimbmonvehicmaintnce.Text + "','" + txtreimbmonrelocallow.Text + "','" + txtdeducmonpfdeduc.Text + "','" + txtdeducmonesic.Text + "','" + txtothermonpf.Text + "','" + txtothermonesic.Text + "','" + txtothermonmedic.Text + "','" + txtothermonbonus.Text + "','" + txtothermonmealvou.Text + "','" + txtgrossmontakhome.Text + "','" + txtmontotmontakhome.Text + "','" + txtmonnettakhom.Text + "','" + txtmonfinalctc.Text + "' )", conn);

            if(conn.State==ConnectionState.Closed)
            {
                conn.Open();
            }

            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Saved Successfully");


            conn.Close();


        }
        public string empcodepass
        {
            get { return txtempcode.Text; }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            salstrutureprint salstrcutfrm = new salstrutureprint();
            //salstrcutfrm.method(cmbempval);
            salstrcutfrm.passvalue = txtempcode.Text;
            salstrcutfrm.salid =Convert.ToInt32( label62.Text);

            salstrcutfrm.Show();
        }

        private void load_emplistgrid()
        {

            conn.Open();

            SqlCommand cmd = new SqlCommand("select empcode,name,dept,designation,branch,dob,doj,phoneno,empstatus from tblemployee where empstatus='Active'", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnCount = 8;

            dataGridView1.Columns[0].Name = "empcode";
            dataGridView1.Columns[0].HeaderText = "Emp Code";
            dataGridView1.Columns[0].DataPropertyName = "empcode";

            dataGridView1.Columns[1].Name = "Name";
            dataGridView1.Columns[1].HeaderText = "Name";
            dataGridView1.Columns[1].DataPropertyName = "Name";

            dataGridView1.Columns[2].Name = "Dept";
            dataGridView1.Columns[2].HeaderText = "Department";
            dataGridView1.Columns[2].DataPropertyName = "dept";

            dataGridView1.Columns[4].Name = "Designation";
            dataGridView1.Columns[4].HeaderText = "Designation";
            dataGridView1.Columns[4].DataPropertyName = "Designation";
            
            dataGridView1.Columns[3].Name = "Branch";
            dataGridView1.Columns[3].HeaderText = "Branch";
            dataGridView1.Columns[3].DataPropertyName = "Branch";

            dataGridView1.Columns[4].Name = "Empstatus1";
            dataGridView1.Columns[4].HeaderText = "Status";
            dataGridView1.Columns[4].DataPropertyName = "empstatus";

            dataGridView1.Columns[5].Name = "Designation";
            dataGridView1.Columns[5].HeaderText = "Designation";
            dataGridView1.Columns[5].DataPropertyName = "Designation";

            dataGridView1.Columns[6].Name = "DateofJoining";
            dataGridView1.Columns[6].HeaderText = "Date of Joining";
            dataGridView1.Columns[6].DataPropertyName = "doj";

            dataGridView1.Columns[7].Name = "DateofBirth";
            dataGridView1.Columns[7].HeaderText = "Date of Birth";
            dataGridView1.Columns[7].DataPropertyName = "dob";


            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = dt;


            conn.Close();
        




        }


        private void load_dept()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select deptname from mdept", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            cmbempdept.DataSource = dt;
            cmbempdept.DisplayMember = "deptname";
            cmbempdept.ValueMember = "deptname";
            cmbempdept.SelectedIndex = -1;
            conn.Close();
        }

        private void load_branch()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select brname from mbranch", conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbempbranch1.DataSource = dt;
            cmbempbranch1.DisplayMember = "brname";
            cmbempbranch1.ValueMember = "brname";
            cmbempbranch1.SelectedIndex = -1;
            conn.Close();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            conn.Open();

            SqlCommand cmd = new SqlCommand("select empcode,name,dept,branch from tblemployee where branch= '" + cmbbranch.Text + "' and dept='" + cmbdept.Text + "' ", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            //cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            //dataGridView1.ColumnCount = 4;



            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void btnempserach_Click(object sender, EventArgs e)
        {
            
            conn.Open();

            SqlCommand cmd = new SqlCommand("select empcode,name,dept,branch from tblemployee where branch= '" + cmbempbranch1.Text + "' and dept='" + cmbempdept.Text + "' ", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            //dataGridView1.ColumnCount = 4;



            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = dt;
            conn.Close();

            dataGridView1.Refresh();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int empcode;

            conn.Open();
            empcode = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["empcode"].Value.ToString());
            //Branchcode = dataGridView1.Rows[e.RowIndex].Cells["Branchcode"];
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from tblemployee where empcode=" + empcode + "";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                txtempcode.Text = dr["empcode"].ToString();
                //txtbrname.Text = dr["branchname"].ToString();
                //txtbrcity.Text = dr["branchcity"].ToString();
            }

            conn.Close();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            string add;
            add=Convert.ToString(txtpreadd.Text);

            if (checkBox2.Checked == true)
            {

                txtpermenadd.Text = add.ToString();

            }
            else
                txtpermenadd.Text = "";

        }

        private void cmbempstatus_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (cmbempstatus.Text == "Resigned")
            {
                dtpdatresign.Enabled = true;


            }
            else
                dtpdatresign.Enabled = false;
        }

        public void tabControl2_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if(e.TabPage==tabPage3)
            {
                e.Cancel = true;
            }

        }

        private void btnempnew_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(1);
            btnnew.Enabled = false;
            btnsave.Enabled = true;

            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;

            txtempname.Focus();
            checkBox2.Enabled = true;

            txtempname.Enabled = true;
            txtpermenadd.Enabled = true;
            txtpreadd.Enabled = true;
            dtpdob.Enabled = true;
            cmbgender.Enabled = true;
            cmbmaritialstatus.Enabled = true;
            txtphone.Enabled = true;
            txtmobile.Enabled = true;
            txtemail.Enabled = true;
            txtbankaccname.Enabled = true;
            txtbankaccno.Enabled = true;
            txtbankname.Enabled = true;
            txtbankbranch.Enabled = true;
            txtbankcity.Enabled = true;
            cmbdesig.Enabled = true;
            cmbdept.Enabled = true;
            cmbbranch.Enabled = true;
            cmbreportto.Enabled = true;
            dtpdoj.Enabled = true;
            dtpdor.Enabled = true;
            txtpanno.Enabled = true;
            //txtpassportno.Enabled = true;
            //txtdrivlicno.Enabled = true;
            txtblood.Enabled = true;
            txtbankcity.Enabled = true;
            txtbankbranch.Enabled = true;
            txtifsccode.Enabled = true;
            txtfathername.Enabled = true;
            cmbempstatus.Enabled = true;
            txtqualif.Enabled = true;
            txtmajor.Enabled = true;
            txtprevdesign.Enabled = true;
            txtprevempler.Enabled = true;
            txtyrsofworked.Enabled = true;

            btnsave.Enabled = true;
            //btnedit.Enabled = false;


            int Num1 = 0;

            conn.Open();
            SqlCommand cmd = new SqlCommand("Select MAX(empid) from tblemployee", conn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Num1 = int.Parse(dr[0].ToString());

            }
            dr.Close();

            if (Num1.ToString().Length == 1)
            {
                txtempcode.Text = "UNIMAA000" + (Num1 + 1).ToString();
            }
            if (Num1.ToString().Length == 2)
            {
                txtempcode.Text = "UNIMAA00" + (Num1 + 1).ToString();
            }
            if (Num1.ToString().Length == 3)
            {
                txtempcode.Text = "UNIMAA0" + (Num1 + 1).ToString();
            }
            if (Num1.ToString().Length == 4)
            {
                txtempcode.Text = "UNIMAA" + (Num1 + 1).ToString();
            }

            //txtempname.Text = Convert.ToString(Num1.ToString().Length);
            conn.Close();


        }



        

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            tabControl2.SelectTab(1);
            
            SqlDataReader dr;

            btnnew.Enabled = false;
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btncancel.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;


            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtempcode.Text = row.Cells["empcode"].Value.ToString();
            }

            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tblemployee where empcode='" + txtempcode.Text + "'", conn);

            //SqlDataReader dr = new SqlDataReader();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                txtempname.Text = dr[2].ToString();
                txtfathername.Text = dr[26].ToString();
                txtpreadd.Text = dr[3].ToString();
                txtpermenadd.Text = dr[4].ToString();
                //dtpdob.Text = dr[5].ToString();
                cmbgender.Text = dr[6].ToString();
                cmbmaritialstatus.Text = dr[7].ToString();
                txtphone.Text = dr[8].ToString();
                txtmobile.Text = dr[9].ToString();
                cmbdesign.Text = dr[10].ToString();
                txtemail.Text = dr[11].ToString();
                txtbankaccname.Text = dr[12].ToString();
                txtbankaccno.Text = dr[13].ToString();
                txtbankname.Text = dr[14].ToString();
                txtbankbranch.Text = dr[15].ToString();
                txtbankcity.Text = dr[16].ToString();
                cmbdeprt.Text = dr[17].ToString();
                cmbbranch1.Text = dr[18].ToString();
                cmbreportingto.Text = dr[19].ToString();
                // dtpdatjoin.Text = dr[20].ToString();
                //dtpdatresign.Text = dr[21].ToString();
                txtpanno.Text = dr[22].ToString();
                txtblood.Text = dr[25].ToString();

                cmbempstatus.Text = dr[27].ToString();
                txtifsccode.Text = dr[33].ToString();
                txtprevempler.Text = dr[28].ToString();
                txtprevdesign.Text = dr[29].ToString();
                txtyrsofworked.Text = dr[30].ToString();
                txtqualif.Text = dr[31].ToString();
                txtmajor.Text = dr[32].ToString();

            }
            conn.Close();
            SqlDataReader dr1;
            conn.Open();
            SqlCommand cmd1 = new SqlCommand("select * from salstructure where empcode='" + txtempcode.Text + "'", conn);

            //SqlDataReader dr = new SqlDataReader();
            dr1 = cmd1.ExecuteReader();

            while (dr1.Read())
            {
                label62.Text = dr1[0].ToString();
                txtearnyrbasic.Text = dr1[2].ToString();
                txtearnyrhra.Text = dr1[3].ToString();
                txtearnyrlta.Text = dr1[4].ToString();
                txtearnyrconvey.Text = dr1[5].ToString();
                txtearnyrsplallow.Text = dr1[6].ToString();
                txtearnyrattrallow.Text = dr1[7].ToString();
                txtearnyrmedallow.Text = dr1[8].ToString();
                txtreimbyrdriverallow.Text = dr1[9].ToString();
                txtreimbyrvehicmaintnce.Text = dr1[10].ToString();
                txtreimbyrrelocallow.Text = dr1[11].ToString();
                txtdeducyrpfdeduc.Text = dr1[12].ToString();
                txtdeducyresic.Text = dr1[13].ToString();
                txtotheryrpf.Text = dr1[14].ToString();
                txtotheryresic.Text = dr1[15].ToString();
                txtotheryrmedic.Text = dr1[16].ToString();
                txtotheryrbonus.Text = dr1[17].ToString();
                txtotheryrmealvou.Text = dr1[18].ToString();

                txtgrossyrtakhome.Text = dr1[19].ToString();
                txtyrtotmontakhome.Text = dr1[20].ToString();
                txtyrnettakhome.Text = dr1[21].ToString();
                txtyrfinalctc.Text = dr1[22].ToString();

                txtearnmonbasic.Text = dr1[23].ToString();
                txtearnmonhra.Text = dr1[24].ToString();
                txtearnmonlta.Text = dr1[25].ToString();
                txtearnmonconvey.Text = dr1[26].ToString();
                txtearnmonsplallow.Text = dr1[27].ToString();
                txtearnmonattrallow.Text = dr1[28].ToString();
                txtearnmonmedallow.Text = dr1[29].ToString();
                txtreimbmondriverallow.Text = dr1[30].ToString();
                txtreimbmonvehicmaintnce.Text = dr1[31].ToString();
                txtreimbmonrelocallow.Text = dr1[32].ToString();
                txtdeducmonpfdeduc.Text = dr1[33].ToString();
                txtdeducmonesic.Text = dr1[34].ToString();
                txtothermonpf.Text = dr1[35].ToString();
                txtothermonesic.Text = dr1[36].ToString();
                txtothermonmedic.Text = dr1[37].ToString();
                txtothermonbonus.Text = dr1[38].ToString();
                txtothermonmealvou.Text = dr1[39].ToString();
                txtotheryrprodincentv.Text = dr1[44].ToString();
                txtothermonprodincentvmon.Text = dr1[45].ToString();

                txtgrossmontakhome.Text = dr1[40].ToString();
                txtmontotmontakhome.Text = dr1[41].ToString();
                txtmonnettakhom.Text = dr1[42].ToString();
                txtmonfinalctc.Text = dr1[43].ToString();

                cmbsalaryby.Text = dr1[46].ToString();
   


            }
            conn.Close();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {


            conn.Open();
            SqlCommand cmd = new SqlCommand("update tblemployee set name='" + txtempname.Text + "',preaddr='" + txtpreadd.Text + "',peraddr='" + txtpermenadd.Text + "',dob='" + dtpdob.Text + "',gender='" + cmbgender.Text + "',maritialstatus='" + cmbmaritialstatus.Text + "',phoneno='" + txtphone.Text + "',mobiletno='" + txtmobile.Text + "',designation='" + cmbdesign.Text + "',emailid='" + txtemail.Text + "',accname='" + txtbankaccname.Text + "',accno='" + txtbankaccno.Text + "',bank='" + txtbankname.Text + "',bankbranch='" + txtbankbranch.Text + "',bankcity='" + txtbankcity.Text + "',dept='" + cmbdeprt.Text + "',branch='" + cmbbranch1.Text + "',reportingto='" + cmbreportingto.Text + "',doj='" + dtpdoj.Text + "',dor='" + dtpdor.Text + "',panno='" + txtpanno.Text + "',blood='" + txtblood.Text + "',fathername='" + txtfathername.Text + "',empstatus='" + cmbempstatus.Text + "',preemployer='" + txtprevempler.Text + "',predesign='" + txtprevdesign.Text + "',preyearsworked='" + txtyrsofworked.Text + "',eduhighquaL='" + txtqualif.Text + "',edumajor='" + txtmajor.Text + "',ifsccode='" +txtifsccode.Text +"',empphoto=@photo where empcode='" +txtempcode.Text+"'", conn);

            if (picempphoto.Image != null)
            {

                MemoryStream ms = new MemoryStream();

                picempphoto.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_aray = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_aray, 0, photo_aray.Length);
                cmd.Parameters.AddWithValue("@photo", photo_aray);
            }   

            cmd.ExecuteNonQuery();
            conn.Close();
           
            MessageBox.Show("Record updated Successfully");
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
            tabControl2.SelectTab(1);

            txtenabtrue();


            btnnew.Enabled = true;
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btncancel.Enabled = true;
            
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;

            button1.Enabled = true;


            
            SqlDataReader dr;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                txtempcode.Text = row.Cells["empcode"].Value.ToString();
            }

            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tblemployee where  empcode='" + txtempcode.Text + "'", conn);

            //SqlDataReader dr = new SqlDataReader();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                txtempname.Text = dr[2].ToString();
                txtfathername.Text = dr[26].ToString();
                txtpreadd.Text = dr[3].ToString();
                txtpermenadd.Text = dr[4].ToString();
                //dtpdob.Text = dr[5].ToString();
                cmbgender.Text = dr[6].ToString();
                cmbmaritialstatus.Text = dr[7].ToString();
                txtphone.Text = dr[8].ToString();
                txtmobile.Text = dr[9].ToString();
                cmbdesign.Text = dr[10].ToString();
                txtemail.Text = dr[11].ToString();
                txtbankaccname.Text = dr[12].ToString();
                txtbankaccno.Text = dr[13].ToString();
                txtbankname.Text = dr[14].ToString();
                txtbankbranch.Text = dr[15].ToString();
                txtbankcity.Text = dr[16].ToString();
                cmbdeprt.Text = dr[17].ToString();
                cmbbranch1.Text = dr[18].ToString();
                cmbreportingto.Text = dr[19].ToString();
                // dtpdatjoin.Text = dr[20].ToString();
                //dtpdatresign.Text = dr[21].ToString();
                txtpanno.Text = dr[22].ToString();
                txtblood.Text = dr[25].ToString();

                cmbempstatus.Text = dr[27].ToString();
                txtifsccode.Text = dr[33].ToString();
                txtprevempler.Text = dr[28].ToString();
                txtprevdesign.Text = dr[29].ToString();
                txtyrsofworked.Text = dr[30].ToString();
                txtqualif.Text = dr[31].ToString();
                txtmajor.Text = dr[32].ToString();
                txtifsccode.Text = dr[33].ToString();


               
               
                                byte[] photo_aray;
                               
                    picempphoto.Image = null;
                    
                    if (dr[34] != System.DBNull.Value)
                    {
                       
                        photo_aray = (byte[])dr[34];
                        MemoryStream ms = new MemoryStream(photo_aray);
                        picempphoto.Image = Image.FromStream(ms);
                    }
             
                             
                

            }


            conn.Close();
            SqlDataReader dr1;
            conn.Open();
            SqlCommand cmd1 = new SqlCommand("select * from salstructure where empcode='" + txtempcode.Text + "'", conn);

            //SqlDataReader dr = new SqlDataReader();
            dr1 = cmd1.ExecuteReader();

            while (dr1.Read())
            {
                label62.Text = dr1[0].ToString();
                txtearnyrbasic.Text = dr1[2].ToString();
                txtearnyrhra.Text = dr1[3].ToString();
                txtearnyrlta.Text = dr1[4].ToString();
                txtearnyrconvey.Text = dr1[5].ToString();
                txtearnyrsplallow.Text = dr1[6].ToString();
                txtearnyrattrallow.Text = dr1[7].ToString();
                txtearnyrmedallow.Text = dr1[8].ToString();
                txtreimbyrdriverallow.Text = dr1[9].ToString();
                txtreimbyrvehicmaintnce.Text = dr1[10].ToString();
                txtreimbyrrelocallow.Text = dr1[11].ToString();
                txtdeducyrpfdeduc.Text = dr1[12].ToString();
                txtdeducyresic.Text = dr1[13].ToString();
                txtotheryrpf.Text = dr1[14].ToString();
                txtotheryresic.Text = dr1[15].ToString();
                txtotheryrmedic.Text = dr1[16].ToString();
                txtotheryrbonus.Text = dr1[17].ToString();
                txtotheryrmealvou.Text = dr1[18].ToString();

                txtgrossyrtakhome.Text = dr1[19].ToString();
                txtyrtotmontakhome.Text = dr1[20].ToString();
                txtyrnettakhome.Text = dr1[21].ToString();
                txtyrfinalctc.Text = dr1[22].ToString();

                txtearnmonbasic.Text = dr1[23].ToString();
                txtearnmonhra.Text = dr1[24].ToString();
                txtearnmonlta.Text = dr1[25].ToString();
                txtearnmonconvey.Text = dr1[26].ToString();
                txtearnmonsplallow.Text = dr1[27].ToString();
                txtearnmonattrallow.Text = dr1[28].ToString();
                txtearnmonmedallow.Text = dr1[29].ToString();
                txtreimbmondriverallow.Text = dr1[30].ToString();
                txtreimbmonvehicmaintnce.Text = dr1[31].ToString();
                txtreimbmonrelocallow.Text = dr1[32].ToString();
                txtdeducmonpfdeduc.Text = dr1[33].ToString();
                txtdeducmonesic.Text = dr1[34].ToString();
                txtothermonpf.Text = dr1[35].ToString();
                txtothermonesic.Text = dr1[36].ToString();
                txtothermonmedic.Text = dr1[37].ToString();
                txtothermonbonus.Text = dr1[38].ToString();
                txtothermonmealvou.Text = dr1[39].ToString();
                txtothermonprodincentvmon.Text = dr1[45].ToString();
                txtotheryrprodincentv.Text = dr1[44].ToString();

                txtgrossmontakhome.Text = dr1[40].ToString();
                txtmontotmontakhome.Text = dr1[41].ToString();
                txtmonnettakhom.Text = dr1[42].ToString();
                txtmonfinalctc.Text = dr1[43].ToString();
                
                cmbsalaryby.Text = dr1[46].ToString();


            }
            conn.Close();
        }

       public void txtenabtrue()
    {
        txtempname.Enabled = true;
            txtpermenadd.Enabled = true;
            txtpreadd.Enabled = true;
            dtpdob.Enabled = true;
            cmbgender.Enabled = true;
            cmbmaritialstatus.Enabled = true;
            txtphone.Enabled = true;
            txtmobile.Enabled = true;
            txtemail.Enabled = true;
            txtbankaccname.Enabled = true;
            txtbankaccno.Enabled = true;
            txtbankname.Enabled = true;
            txtbankbranch.Enabled = true;
            txtbankcity.Enabled = true;
            cmbdesig.Enabled = true;
            cmbdept.Enabled = true;
            cmbbranch.Enabled = true;
            cmbreportto.Enabled = true;
            dtpdoj.Enabled = true;
            dtpdor.Enabled = true;
            txtpanno.Enabled = true;
            //txtpassportno.Enabled = true;
            //txtdrivlicno.Enabled = true;
            txtblood.Enabled = true;
            txtbankcity.Enabled = true;
            txtbankbranch.Enabled = true;
       
    }

       public void cntrlvalidation()
       {
                      
               if (txtempname.Text.Length == 0)
               {
                   MessageBox.Show("Please Enter Employee Name");
                   txtempname.Focus();
               }
                  }


       public void salstructload()
    {
        float basic = 0;

        txtearnyrbasic.Text = basic.ToString();
        txtearnyrhra.Text = basic.ToString();
        txtearnyrlta.Text = basic.ToString();
        txtearnyrmedallow.Text = basic.ToString();
        txtearnyrsplallow.Text = basic.ToString();
        txtearnyrattrallow.Text = basic.ToString();
        txtearnyrconvey.Text = basic.ToString();
        txtreimbyrdriverallow.Text = basic.ToString();
        txtreimbyrrelocallow.Text = basic.ToString();
        txtreimbyrvehicmaintnce.Text = basic.ToString();
        txtdeducyresic.Text = basic.ToString();
        txtdeducyrpfdeduc.Text = basic.ToString();
        txtotheryrbonus.Text = basic.ToString();
        txtotheryresic.Text = basic.ToString();
        txtotheryrpf.Text = basic.ToString();
        txtotheryrmedic.Text = basic.ToString();
        txtotheryrmealvou.Text = basic.ToString();
        txtotheryrprodincentv.Text = basic.ToString();

        txtearnmonbasic.Text = basic.ToString();
        txtearnmonhra.Text = basic.ToString();
        txtearnmonlta.Text = basic.ToString();
        txtearnmonmedallow.Text = basic.ToString();
        txtearnmonsplallow.Text = basic.ToString();
        txtearnmonattrallow.Text = basic.ToString();
        txtearnmonconvey.Text = basic.ToString();
        txtreimbmondriverallow.Text = basic.ToString();
        txtreimbmonrelocallow.Text = basic.ToString();
        txtreimbmonvehicmaintnce.Text = basic.ToString();
        txtdeducmonesic.Text = basic.ToString();
        txtdeducmonpfdeduc.Text = basic.ToString();
        txtothermonbonus.Text = basic.ToString();
        txtothermonesic.Text = basic.ToString();
        txtothermonpf.Text = basic.ToString();
        txtothermonmedic.Text = basic.ToString();
        txtothermonmealvou.Text = basic.ToString();
        txtotheryrprodincentv.Text = basic.ToString();
    }

       private void button4_Click(object sender, EventArgs e)
       {
           if (conn.State == ConnectionState.Closed)
           {
               conn.Open();
           }
           //SqlCommand cmd = new SqlCommand("update salstructure set empcode='" + txtempcode.Text + "',basic='" + txtearnyrbasic.Text + "',hra='" + txtearnyrhra.Text + "',lta='" + txtearnyrlta.Text + "',conveyence='" + txtearnyrconvey.Text + "',splallow='" + txtearnyrsplallow.Text + "',attirallow='" + txtearnyrattrallow.Text + "',mediallow='" + txtearnyrmedallow.Text + "',driverallow='" + txtreimbyrdriverallow.Text + "',vechiclemaint='" + txtreimbyrvehicmaintnce.Text + "',relocallow='" + txtreimbyrrelocallow.Text + "',pfdeduc='" + txtdeducyrpfdeduc.Text + "',esic='" + txtdeducyresic.Text + "',otherpf='" + txtotheryrpf.Text + "',otheresic='" + txtotheryresic.Text + "',othermediclaim='" + txtotheryrmedic.Text + "',otherbonus='" + txtotheryresic.Text + "',othermealvou='" + txtotheryrmealvou.Text + "',grosstakhome='" + txtgrossyrtakhome.Text + "',totmonthtakhome='" + txtyrtotmontakhome.Text + "',nettakhome='" + txtyrnettakhome.Text + "',finalctc='" + txtyrfinalctc.Text + "',basicmon='" + txtearnmonbasic.Text + "',hramon='" + txtearnmonhra.Text + "',ltamon='" + txtearnmonlta.Text + "',conveyencemon='" + txtearnmonconvey.Text + "',splallowmon='" + txtearnmonsplallow.Text + "',attirallowmon='" + txtearnmonattrallow.Text + "',medicallowmon='" + txtearnmonmedallow.Text + "',driverallowmon='" + txtreimbmondriverallow.Text + "',vechicmaintmon='" + txtreimbmonvehicmaintnce.Text + "',relocmon='" + txtreimbmonrelocallow.Text + "',pfmon='" + txtdeducmonpfdeduc.Text + "',esicmon='" + txtdeducmonesic.Text + "',otherpfmon='" + txtothermonpf.Text + "',otheresicmon='" + txtothermonesic.Text + "',othermediclaimmon='" + txtothermonmedic.Text + "',otherbonusmon='" + txtothermonbonus.Text + "',othermealvoumon='" + txtothermonmealvou.Text + "',grosstakhomemon='" + txtgrossmontakhome.Text + "',totmontakhomemon='" + txtmontotmontakhome.Text + "',nettakhomemon='" + txtmonnettakhom.Text + "',finalctcmon='" + txtmonfinalctc.Text + "',prodincentive='" + txtotheryrprodincentv.Text + "',prodincentivemon='" +txtothermonprodincentvmon.Text+ "' where salid='"+label62.Text+"'" , conn);
           SqlCommand cmd = new SqlCommand("insert into salstructure(empcode,basic,hra,lta,conveyence,splallow,attirallow,mediallow,driverallow,vechiclemaint,relocallow,pfdeduc,esic,otherpf,otheresic,othermediclaim,otherbonus,othermealvou,grosstakhome,totmonthtakhome,nettakhome,finalctc,basicmon,hramon,ltamon,conveyencemon,splallowmon,attirallowmon,medicallowmon,driverallowmon,vechicmaintmon,relocmon,pfmon,esicmon,otherpfmon,otheresicmon,othermediclaimmon,otherbonusmon,othermealvoumon,grosstakhomemon,totmontakhomemon,nettakhomemon,finalctcmon)values('" + txtempcode.Text + "','" + txtearnyrbasic.Text + "','" + txtearnyrhra.Text + "','" + txtearnyrlta.Text + "','" + txtearnyrconvey.Text + "','" + txtearnyrsplallow.Text + "','" + txtearnyrattrallow.Text + "','" + txtearnyrmedallow.Text + "','" + txtreimbyrdriverallow.Text + "','" + txtreimbyrvehicmaintnce.Text + "','" + txtreimbyrrelocallow.Text + "','" + txtdeducyrpfdeduc.Text + "','" + txtdeducyresic.Text + "','" + txtotheryrpf.Text + "','" + txtotheryresic.Text + "','" + txtotheryrmedic.Text + "','" + txtotheryrbonus.Text + "','" + txtotheryrmealvou.Text + "','" + txtgrossyrtakhome.Text + "','" + txtyrtotmontakhome.Text + "','" + txtyrnettakhome.Text + "','" + txtyrfinalctc.Text + "','" + txtearnmonbasic.Text + "','" + txtearnmonhra.Text + "','" + txtearnmonlta.Text + "','" + txtearnmonconvey.Text + "','" + txtearnmonsplallow.Text + "','" + txtearnmonattrallow.Text + "','" + txtearnmonmedallow.Text + "','" + txtreimbmondriverallow.Text + "','" + txtreimbmonvehicmaintnce.Text + "','" + txtreimbmonrelocallow.Text + "','" + txtdeducmonpfdeduc.Text + "','" + txtdeducmonesic.Text + "','" + txtothermonpf.Text + "','" + txtothermonesic.Text + "','" + txtothermonmedic.Text + "','" + txtothermonbonus.Text + "','" + txtothermonmealvou.Text + "','" + txtgrossmontakhome.Text + "','" + txtmontotmontakhome.Text + "','" + txtmonnettakhom.Text + "','" + txtmonfinalctc.Text + "' )", conn);

           cmd.ExecuteNonQuery();
           MessageBox.Show("Record Updated Successfully");

           conn.Close();
       }

       

      

        
        
        
    }
}
