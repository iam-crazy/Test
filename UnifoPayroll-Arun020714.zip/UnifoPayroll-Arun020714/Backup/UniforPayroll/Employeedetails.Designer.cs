﻿namespace UniforPayroll
{
    partial class Employeedetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblempcode = new System.Windows.Forms.Label();
            this.dtpdob = new System.Windows.Forms.DateTimePicker();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.cmbmaritialstatus = new System.Windows.Forms.ComboBox();
            this.cmbgender = new System.Windows.Forms.ComboBox();
            this.txtpermenadd = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtpreadd = new System.Windows.Forms.TextBox();
            this.lblpresentadd = new System.Windows.Forms.Label();
            this.lblmobileno = new System.Windows.Forms.Label();
            this.lblphoneno = new System.Windows.Forms.Label();
            this.lblmaritialstatus = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblbankcity = new System.Windows.Forms.Label();
            this.txtbankcity = new System.Windows.Forms.TextBox();
            this.txtbankbranch = new System.Windows.Forms.TextBox();
            this.txtbankname = new System.Windows.Forms.TextBox();
            this.txtbankaccno = new System.Windows.Forms.TextBox();
            this.txtbankaccname = new System.Windows.Forms.TextBox();
            this.lblaccname = new System.Windows.Forms.Label();
            this.lblbranch = new System.Windows.Forms.Label();
            this.lblbank = new System.Windows.Forms.Label();
            this.lblaccno = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dtpdor = new System.Windows.Forms.DateTimePicker();
            this.dtpdoj = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.lbldoj = new System.Windows.Forms.Label();
            this.cmbreportto = new System.Windows.Forms.ComboBox();
            this.cmbbranch = new System.Windows.Forms.ComboBox();
            this.cmbdept = new System.Windows.Forms.ComboBox();
            this.cmbdesig = new System.Windows.Forms.ComboBox();
            this.lblreportingto = new System.Windows.Forms.Label();
            this.lblbr = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbldesignation = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtblood = new System.Windows.Forms.TextBox();
            this.txtdrivlicno = new System.Windows.Forms.TextBox();
            this.txtpassportno = new System.Windows.Forms.TextBox();
            this.txtpanno = new System.Windows.Forms.TextBox();
            this.lblblood = new System.Windows.Forms.Label();
            this.lbldrivinglicenseno = new System.Windows.Forms.Label();
            this.lblpassportno = new System.Windows.Forms.Label();
            this.lblpanno = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnedit = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnnew = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblempcode);
            this.groupBox1.Controls.Add(this.dtpdob);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.txtmobile);
            this.groupBox1.Controls.Add(this.txtphone);
            this.groupBox1.Controls.Add(this.txtempname);
            this.groupBox1.Controls.Add(this.cmbmaritialstatus);
            this.groupBox1.Controls.Add(this.cmbgender);
            this.groupBox1.Controls.Add(this.txtpermenadd);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtpreadd);
            this.groupBox1.Controls.Add(this.lblpresentadd);
            this.groupBox1.Controls.Add(this.lblmobileno);
            this.groupBox1.Controls.Add(this.lblphoneno);
            this.groupBox1.Controls.Add(this.lblmaritialstatus);
            this.groupBox1.Controls.Add(this.lblemail);
            this.groupBox1.Controls.Add(this.lblgender);
            this.groupBox1.Controls.Add(this.lbldob);
            this.groupBox1.Controls.Add(this.lblname);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(19, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(477, 618);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(159, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "UNIMAA0006";
            // 
            // lblempcode
            // 
            this.lblempcode.AutoSize = true;
            this.lblempcode.Location = new System.Drawing.Point(51, 33);
            this.lblempcode.Name = "lblempcode";
            this.lblempcode.Size = new System.Drawing.Size(108, 17);
            this.lblempcode.TabIndex = 20;
            this.lblempcode.Text = "Emp Code111";
            this.lblempcode.Click += new System.EventHandler(this.lblempcode_Click);
            // 
            // dtpdob
            // 
            this.dtpdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdob.Location = new System.Drawing.Point(159, 393);
            this.dtpdob.Name = "dtpdob";
            this.dtpdob.Size = new System.Drawing.Size(92, 23);
            this.dtpdob.TabIndex = 19;
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(159, 590);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(212, 22);
            this.txtemail.TabIndex = 18;
            // 
            // txtmobile
            // 
            this.txtmobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.Location = new System.Drawing.Point(159, 560);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(212, 22);
            this.txtmobile.TabIndex = 17;
            // 
            // txtphone
            // 
            this.txtphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtphone.Location = new System.Drawing.Point(159, 526);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(212, 22);
            this.txtphone.TabIndex = 16;
            // 
            // txtempname
            // 
            this.txtempname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtempname.Location = new System.Drawing.Point(159, 88);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(298, 22);
            this.txtempname.TabIndex = 1;
            // 
            // cmbmaritialstatus
            // 
            this.cmbmaritialstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbmaritialstatus.FormattingEnabled = true;
            this.cmbmaritialstatus.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Widow"});
            this.cmbmaritialstatus.Location = new System.Drawing.Point(159, 469);
            this.cmbmaritialstatus.Name = "cmbmaritialstatus";
            this.cmbmaritialstatus.Size = new System.Drawing.Size(159, 24);
            this.cmbmaritialstatus.TabIndex = 13;
            this.cmbmaritialstatus.Text = "Select";
            // 
            // cmbgender
            // 
            this.cmbgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbgender.FormattingEnabled = true;
            this.cmbgender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbgender.Location = new System.Drawing.Point(159, 426);
            this.cmbgender.Name = "cmbgender";
            this.cmbgender.Size = new System.Drawing.Size(159, 24);
            this.cmbgender.TabIndex = 12;
            this.cmbgender.Text = "Select";
            // 
            // txtpermenadd
            // 
            this.txtpermenadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpermenadd.Location = new System.Drawing.Point(159, 258);
            this.txtpermenadd.Multiline = true;
            this.txtpermenadd.Name = "txtpermenadd";
            this.txtpermenadd.Size = new System.Drawing.Size(298, 115);
            this.txtpermenadd.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Permenant Address";
            // 
            // txtpreadd
            // 
            this.txtpreadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreadd.Location = new System.Drawing.Point(159, 122);
            this.txtpreadd.Multiline = true;
            this.txtpreadd.Name = "txtpreadd";
            this.txtpreadd.Size = new System.Drawing.Size(298, 115);
            this.txtpreadd.TabIndex = 9;
            // 
            // lblpresentadd
            // 
            this.lblpresentadd.AutoSize = true;
            this.lblpresentadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpresentadd.Location = new System.Drawing.Point(5, 120);
            this.lblpresentadd.Name = "lblpresentadd";
            this.lblpresentadd.Size = new System.Drawing.Size(108, 16);
            this.lblpresentadd.TabIndex = 8;
            this.lblpresentadd.Text = "Present Address";
            // 
            // lblmobileno
            // 
            this.lblmobileno.AutoSize = true;
            this.lblmobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmobileno.Location = new System.Drawing.Point(5, 560);
            this.lblmobileno.Name = "lblmobileno";
            this.lblmobileno.Size = new System.Drawing.Size(100, 16);
            this.lblmobileno.TabIndex = 7;
            this.lblmobileno.Text = "Mobile Number";
            // 
            // lblphoneno
            // 
            this.lblphoneno.AutoSize = true;
            this.lblphoneno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphoneno.Location = new System.Drawing.Point(5, 526);
            this.lblphoneno.Name = "lblphoneno";
            this.lblphoneno.Size = new System.Drawing.Size(98, 16);
            this.lblphoneno.TabIndex = 6;
            this.lblphoneno.Text = "Phone Number";
            // 
            // lblmaritialstatus
            // 
            this.lblmaritialstatus.AutoSize = true;
            this.lblmaritialstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmaritialstatus.Location = new System.Drawing.Point(5, 469);
            this.lblmaritialstatus.Name = "lblmaritialstatus";
            this.lblmaritialstatus.Size = new System.Drawing.Size(91, 16);
            this.lblmaritialstatus.TabIndex = 5;
            this.lblmaritialstatus.Text = "Maritial Status";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(5, 590);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(56, 16);
            this.lblemail.TabIndex = 3;
            this.lblemail.Text = "Email Id";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.Location = new System.Drawing.Point(5, 426);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(56, 17);
            this.lblgender.TabIndex = 2;
            this.lblgender.Text = "Gender";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldob.Location = new System.Drawing.Point(5, 398);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(82, 16);
            this.lbldob.TabIndex = 1;
            this.lbldob.Text = "Date Of Birth";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(5, 88);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(45, 17);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblbankcity);
            this.groupBox2.Controls.Add(this.txtbankcity);
            this.groupBox2.Controls.Add(this.txtbankbranch);
            this.groupBox2.Controls.Add(this.txtbankname);
            this.groupBox2.Controls.Add(this.txtbankaccno);
            this.groupBox2.Controls.Add(this.txtbankaccname);
            this.groupBox2.Controls.Add(this.lblaccname);
            this.groupBox2.Controls.Add(this.lblbranch);
            this.groupBox2.Controls.Add(this.lblbank);
            this.groupBox2.Controls.Add(this.lblaccno);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(502, 66);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(339, 194);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bank Details";
            // 
            // lblbankcity
            // 
            this.lblbankcity.AutoSize = true;
            this.lblbankcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbankcity.Location = new System.Drawing.Point(10, 165);
            this.lblbankcity.Name = "lblbankcity";
            this.lblbankcity.Size = new System.Drawing.Size(31, 17);
            this.lblbankcity.TabIndex = 9;
            this.lblbankcity.Text = "City";
            // 
            // txtbankcity
            // 
            this.txtbankcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankcity.Location = new System.Drawing.Point(126, 165);
            this.txtbankcity.Name = "txtbankcity";
            this.txtbankcity.Size = new System.Drawing.Size(207, 23);
            this.txtbankcity.TabIndex = 8;
            // 
            // txtbankbranch
            // 
            this.txtbankbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankbranch.Location = new System.Drawing.Point(126, 132);
            this.txtbankbranch.Name = "txtbankbranch";
            this.txtbankbranch.Size = new System.Drawing.Size(207, 23);
            this.txtbankbranch.TabIndex = 7;
            // 
            // txtbankname
            // 
            this.txtbankname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankname.Location = new System.Drawing.Point(126, 97);
            this.txtbankname.Name = "txtbankname";
            this.txtbankname.Size = new System.Drawing.Size(207, 23);
            this.txtbankname.TabIndex = 6;
            // 
            // txtbankaccno
            // 
            this.txtbankaccno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankaccno.Location = new System.Drawing.Point(126, 65);
            this.txtbankaccno.Name = "txtbankaccno";
            this.txtbankaccno.Size = new System.Drawing.Size(207, 23);
            this.txtbankaccno.TabIndex = 5;
            // 
            // txtbankaccname
            // 
            this.txtbankaccname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankaccname.Location = new System.Drawing.Point(126, 33);
            this.txtbankaccname.Name = "txtbankaccname";
            this.txtbankaccname.Size = new System.Drawing.Size(207, 23);
            this.txtbankaccname.TabIndex = 4;
            // 
            // lblaccname
            // 
            this.lblaccname.AutoSize = true;
            this.lblaccname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccname.Location = new System.Drawing.Point(7, 33);
            this.lblaccname.Name = "lblaccname";
            this.lblaccname.Size = new System.Drawing.Size(100, 17);
            this.lblaccname.TabIndex = 3;
            this.lblaccname.Text = "Account Name";
            // 
            // lblbranch
            // 
            this.lblbranch.AutoSize = true;
            this.lblbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbranch.Location = new System.Drawing.Point(9, 131);
            this.lblbranch.Name = "lblbranch";
            this.lblbranch.Size = new System.Drawing.Size(53, 17);
            this.lblbranch.TabIndex = 2;
            this.lblbranch.Text = "Branch";
            // 
            // lblbank
            // 
            this.lblbank.AutoSize = true;
            this.lblbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbank.Location = new System.Drawing.Point(9, 97);
            this.lblbank.Name = "lblbank";
            this.lblbank.Size = new System.Drawing.Size(77, 17);
            this.lblbank.TabIndex = 1;
            this.lblbank.Text = "BankName";
            // 
            // lblaccno
            // 
            this.lblaccno.AutoSize = true;
            this.lblaccno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccno.Location = new System.Drawing.Point(6, 65);
            this.lblaccno.Name = "lblaccno";
            this.lblaccno.Size = new System.Drawing.Size(81, 17);
            this.lblaccno.TabIndex = 0;
            this.lblaccno.Text = "Account No";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dtpdor);
            this.groupBox3.Controls.Add(this.dtpdoj);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.lbldoj);
            this.groupBox3.Controls.Add(this.cmbreportto);
            this.groupBox3.Controls.Add(this.cmbbranch);
            this.groupBox3.Controls.Add(this.cmbdept);
            this.groupBox3.Controls.Add(this.cmbdesig);
            this.groupBox3.Controls.Add(this.lblreportingto);
            this.groupBox3.Controls.Add(this.lblbr);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.lbldesignation);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(502, 279);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(339, 217);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Job Details";
            // 
            // dtpdor
            // 
            this.dtpdor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdor.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdor.Location = new System.Drawing.Point(126, 189);
            this.dtpdor.Name = "dtpdor";
            this.dtpdor.Size = new System.Drawing.Size(89, 23);
            this.dtpdor.TabIndex = 11;
            // 
            // dtpdoj
            // 
            this.dtpdoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdoj.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdoj.Location = new System.Drawing.Point(126, 159);
            this.dtpdoj.Name = "dtpdoj";
            this.dtpdoj.Size = new System.Drawing.Size(89, 23);
            this.dtpdoj.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Date Of Resigned";
            // 
            // lbldoj
            // 
            this.lbldoj.AutoSize = true;
            this.lbldoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldoj.Location = new System.Drawing.Point(7, 158);
            this.lbldoj.Name = "lbldoj";
            this.lbldoj.Size = new System.Drawing.Size(87, 17);
            this.lbldoj.TabIndex = 8;
            this.lbldoj.Text = "Date Of Join";
            // 
            // cmbreportto
            // 
            this.cmbreportto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreportto.FormattingEnabled = true;
            this.cmbreportto.Location = new System.Drawing.Point(126, 127);
            this.cmbreportto.Name = "cmbreportto";
            this.cmbreportto.Size = new System.Drawing.Size(207, 24);
            this.cmbreportto.TabIndex = 7;
            this.cmbreportto.Text = "Select";
            // 
            // cmbbranch
            // 
            this.cmbbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbranch.FormattingEnabled = true;
            this.cmbbranch.Location = new System.Drawing.Point(126, 94);
            this.cmbbranch.Name = "cmbbranch";
            this.cmbbranch.Size = new System.Drawing.Size(207, 24);
            this.cmbbranch.TabIndex = 6;
            this.cmbbranch.Text = "Select";
            // 
            // cmbdept
            // 
            this.cmbdept.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdept.FormattingEnabled = true;
            this.cmbdept.Location = new System.Drawing.Point(126, 63);
            this.cmbdept.Name = "cmbdept";
            this.cmbdept.Size = new System.Drawing.Size(207, 24);
            this.cmbdept.TabIndex = 5;
            this.cmbdept.Text = "Select";
            // 
            // cmbdesig
            // 
            this.cmbdesig.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdesig.FormattingEnabled = true;
            this.cmbdesig.Location = new System.Drawing.Point(126, 30);
            this.cmbdesig.Name = "cmbdesig";
            this.cmbdesig.Size = new System.Drawing.Size(207, 24);
            this.cmbdesig.TabIndex = 4;
            this.cmbdesig.Text = "Select";
            // 
            // lblreportingto
            // 
            this.lblreportingto.AutoSize = true;
            this.lblreportingto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreportingto.Location = new System.Drawing.Point(6, 127);
            this.lblreportingto.Name = "lblreportingto";
            this.lblreportingto.Size = new System.Drawing.Size(91, 17);
            this.lblreportingto.TabIndex = 3;
            this.lblreportingto.Text = "Reporting To";
            // 
            // lblbr
            // 
            this.lblbr.AutoSize = true;
            this.lblbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbr.Location = new System.Drawing.Point(6, 92);
            this.lblbr.Name = "lblbr";
            this.lblbr.Size = new System.Drawing.Size(53, 17);
            this.lblbr.TabIndex = 2;
            this.lblbr.Text = "Branch";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Department";
            // 
            // lbldesignation
            // 
            this.lbldesignation.AutoSize = true;
            this.lbldesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldesignation.Location = new System.Drawing.Point(6, 30);
            this.lbldesignation.Name = "lbldesignation";
            this.lbldesignation.Size = new System.Drawing.Size(83, 17);
            this.lbldesignation.TabIndex = 0;
            this.lbldesignation.Text = "Designation";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtblood);
            this.groupBox4.Controls.Add(this.txtdrivlicno);
            this.groupBox4.Controls.Add(this.txtpassportno);
            this.groupBox4.Controls.Add(this.txtpanno);
            this.groupBox4.Controls.Add(this.lblblood);
            this.groupBox4.Controls.Add(this.lbldrivinglicenseno);
            this.groupBox4.Controls.Add(this.lblpassportno);
            this.groupBox4.Controls.Add(this.lblpanno);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(502, 497);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(339, 187);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Other Details";
            // 
            // txtblood
            // 
            this.txtblood.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtblood.Location = new System.Drawing.Point(126, 126);
            this.txtblood.Name = "txtblood";
            this.txtblood.Size = new System.Drawing.Size(107, 23);
            this.txtblood.TabIndex = 7;
            // 
            // txtdrivlicno
            // 
            this.txtdrivlicno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdrivlicno.Location = new System.Drawing.Point(126, 96);
            this.txtdrivlicno.Name = "txtdrivlicno";
            this.txtdrivlicno.Size = new System.Drawing.Size(207, 23);
            this.txtdrivlicno.TabIndex = 6;
            // 
            // txtpassportno
            // 
            this.txtpassportno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassportno.Location = new System.Drawing.Point(126, 66);
            this.txtpassportno.Name = "txtpassportno";
            this.txtpassportno.Size = new System.Drawing.Size(207, 23);
            this.txtpassportno.TabIndex = 5;
            // 
            // txtpanno
            // 
            this.txtpanno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpanno.Location = new System.Drawing.Point(126, 34);
            this.txtpanno.Name = "txtpanno";
            this.txtpanno.Size = new System.Drawing.Size(207, 23);
            this.txtpanno.TabIndex = 4;
            // 
            // lblblood
            // 
            this.lblblood.AutoSize = true;
            this.lblblood.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblblood.Location = new System.Drawing.Point(10, 121);
            this.lblblood.Name = "lblblood";
            this.lblblood.Size = new System.Drawing.Size(88, 17);
            this.lblblood.TabIndex = 3;
            this.lblblood.Text = "Blood Group";
            // 
            // lbldrivinglicenseno
            // 
            this.lbldrivinglicenseno.AutoSize = true;
            this.lbldrivinglicenseno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldrivinglicenseno.Location = new System.Drawing.Point(7, 93);
            this.lbldrivinglicenseno.Name = "lbldrivinglicenseno";
            this.lbldrivinglicenseno.Size = new System.Drawing.Size(123, 17);
            this.lbldrivinglicenseno.TabIndex = 2;
            this.lbldrivinglicenseno.Text = "DrivingLicence No";
            // 
            // lblpassportno
            // 
            this.lblpassportno.AutoSize = true;
            this.lblpassportno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassportno.Location = new System.Drawing.Point(7, 66);
            this.lblpassportno.Name = "lblpassportno";
            this.lblpassportno.Size = new System.Drawing.Size(86, 17);
            this.lblpassportno.TabIndex = 1;
            this.lblpassportno.Text = "Passport No";
            // 
            // lblpanno
            // 
            this.lblpanno.AutoSize = true;
            this.lblpanno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpanno.Location = new System.Drawing.Point(7, 38);
            this.lblpanno.Name = "lblpanno";
            this.lblpanno.Size = new System.Drawing.Size(58, 17);
            this.lblpanno.TabIndex = 0;
            this.lblpanno.Text = "PAN No";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(438, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnedit
            // 
            this.btnedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedit.Location = new System.Drawing.Point(910, 163);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(75, 23);
            this.btnedit.TabIndex = 32;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = true;
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Location = new System.Drawing.Point(910, 125);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 30;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnnew
            // 
            this.btnnew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnew.Location = new System.Drawing.Point(910, 81);
            this.btnnew.Name = "btnnew";
            this.btnnew.Size = new System.Drawing.Size(75, 23);
            this.btnnew.TabIndex = 29;
            this.btnnew.Text = "New";
            this.btnnew.UseVisualStyleBackColor = true;
            this.btnnew.Click += new System.EventHandler(this.btnnew_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(921, 239);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 33;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dateTimePicker1);
            this.groupBox5.Controls.Add(this.dateTimePicker2);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.comboBox1);
            this.groupBox5.Controls.Add(this.comboBox2);
            this.groupBox5.Controls.Add(this.comboBox3);
            this.groupBox5.Controls.Add(this.comboBox4);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(502, 279);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(339, 217);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Job Details";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(126, 189);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(89, 23);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(126, 159);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(89, 23);
            this.dateTimePicker2.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Date Of Resigned";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Date Of Join";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(126, 127);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(207, 24);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.Text = "Select";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(126, 94);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(207, 24);
            this.comboBox2.TabIndex = 6;
            this.comboBox2.Text = "Select";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(126, 63);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(207, 24);
            this.comboBox3.TabIndex = 5;
            this.comboBox3.Text = "Select";
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(126, 30);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(207, 24);
            this.comboBox4.TabIndex = 4;
            this.comboBox4.Text = "Select";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Reporting To";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Branch";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 17);
            this.label9.TabIndex = 1;
            this.label9.Text = "Department";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Designation";
            // 
            // Employeedetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1135, 746);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnnew);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Employeedetails";
            this.Text = "Employee Details";
            this.Load += new System.EventHandler(this.Employeedetails_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblmobileno;
        private System.Windows.Forms.Label lblphoneno;
        private System.Windows.Forms.Label lblmaritialstatus;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblaccno;
        private System.Windows.Forms.Label lblaccname;
        private System.Windows.Forms.Label lblbranch;
        private System.Windows.Forms.Label lblbank;
        private System.Windows.Forms.Label lblbankcity;
        private System.Windows.Forms.TextBox txtbankcity;
        private System.Windows.Forms.TextBox txtbankbranch;
        private System.Windows.Forms.TextBox txtbankname;
        private System.Windows.Forms.TextBox txtbankaccno;
        private System.Windows.Forms.TextBox txtbankaccname;
        private System.Windows.Forms.Label lblpresentadd;
        private System.Windows.Forms.TextBox txtpermenadd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtpreadd;
        private System.Windows.Forms.ComboBox cmbgender;
        private System.Windows.Forms.ComboBox cmbmaritialstatus;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbldesignation;
        private System.Windows.Forms.ComboBox cmbdesig;
        private System.Windows.Forms.Label lblreportingto;
        private System.Windows.Forms.Label lblbr;
        private System.Windows.Forms.ComboBox cmbreportto;
        private System.Windows.Forms.ComboBox cmbbranch;
        private System.Windows.Forms.ComboBox cmbdept;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblpanno;
        private System.Windows.Forms.TextBox txtpanno;
        private System.Windows.Forms.Label lblblood;
        private System.Windows.Forms.Label lbldrivinglicenseno;
        private System.Windows.Forms.Label lblpassportno;
        private System.Windows.Forms.TextBox txtblood;
        private System.Windows.Forms.TextBox txtdrivlicno;
        private System.Windows.Forms.TextBox txtpassportno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbldoj;
        private System.Windows.Forms.DateTimePicker dtpdoj;
        private System.Windows.Forms.DateTimePicker dtpdor;
        private System.Windows.Forms.DateTimePicker dtpdob;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblempcode;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnnew;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

