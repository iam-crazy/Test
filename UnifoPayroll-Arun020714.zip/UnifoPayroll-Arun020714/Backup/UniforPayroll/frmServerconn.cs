﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;

namespace UniforPayroll
{
    public partial class frmServerconn : Form
    {
        public frmServerconn()
        {
            InitializeComponent();
        }

        private void frmServerconn_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                StringBuilder con = new StringBuilder("Data Source=");
                con.Append(txtserver.Text);
                con.Append(";Initial Catalog=");
                con.Append(txtdatabase.Text);
                con.Append(";Persist Security Info=True;");
                con.Append("User ID=sa;Password=x");

                string strcon = con.ToString();
                textBox1.Text = strcon.ToString();

                updateconfigfile(strcon);

                //Create new sql connection
                SqlConnection conn = new SqlConnection();

                //to refresh connection string each time else it will use             previous connection string
                ConfigurationManager.RefreshSection("connectionStrings");
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["con"].ToString();
                //To check new connection string is working or not
                SqlDataAdapter da = new SqlDataAdapter("select * from mdept", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                comboBox1.DataSource = dt;
                //comboBox1.ValueMember="
                comboBox1.DisplayMember = "deptname";

            }
            catch (Exception E)
            {
                MessageBox.Show(".This is invalid connection", "Incorrect server/Database" + E);
            }
        }

        public void updateconfigfile(string con)
        {
            //updating config file
            XmlDocument XmlDoc = new XmlDocument();
            //Loading the Config file
            XmlDoc.Load(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
            foreach (XmlElement xElement in XmlDoc.DocumentElement)
            {
                if (xElement.Name == "connectionStrings")
                {
                    //setting the coonection string
                    xElement.FirstChild.Attributes[2].Value = con;
                }
            }
            //writing the connection string in config file
            XmlDoc.Save(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
        }
        
    }
}
