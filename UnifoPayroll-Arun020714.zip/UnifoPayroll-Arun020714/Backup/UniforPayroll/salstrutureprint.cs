﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;

namespace UniforPayroll
{
    public partial class salstrutureprint : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=UNIMAA0004-PC\\SQLEXPRESS;Initial Catalog=unipayroll;Persist Security Info=True;User ID=sa;Password=x");

        private string getpassvalue;
        public string passvalue
        {
            get { return getpassvalue; }
            set { getpassvalue = value; }
        }

        private int getsalid;
        public int salid
        {
            get { return getsalid; }
            set { getsalid = value; }
        }

        public salstrutureprint()
        {
            InitializeComponent();
        }

        public void Method(string str)
        {
            textBox1.Text = str;
        }

        public void Method(int sal)
        {
            label1.Text=Convert.ToInt32(sal).ToString();
        }

        private void salstrutureprint_Load(object sender, EventArgs e)
        {


            //TextBox1.Text = getpassvalue;
            textBox1.Text = getpassvalue;
            label1.Text=Convert.ToInt32(getsalid).ToString();

            //UniforPayroll.payslipprint payprint = new payslipprint();
            CrystalReport1 salstructprint = new CrystalReport1();
            salstructprint.SetDatabaseLogon("sa", "x", "UNIMAA0004-PC\\Sqlexpress", "unipayroll");
            //payprint.SetDatabaseLogon("sa", "x", "UNIMAA0004-PC\\Sqlexpress", "unipayroll");
           crystalReportViewer1.SelectionFormula = "{tblemployee.empcode}=('" + textBox1.Text + "')and  {tblemployee.empcode}=('" + textBox1.Text + "')";

            crystalReportViewer1.ReportSource = salstructprint;
            
            
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }

        
    }
}
