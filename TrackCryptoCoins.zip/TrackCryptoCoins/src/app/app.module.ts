import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { CoinComparisonComponent } from './pages/coin-comparison/coin-comparison.component';
import { CoinDetailsComponent } from './pages/coin-details/coin-details.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { DataService } from './@services/data.service';
import {DataTableModule} from 'primeng/datatable';
import {DialogModule} from 'primeng/dialog';
import {DropdownModule} from 'primeng/dropdown';
import { FooterComponent } from './@core/footer/footer.component';
import { HeaderComponent } from './@core/header/header.component';
import { HistoryDetailsComponent } from './pages/history-details/history-details.component';
import { HttpClientModule } from '@angular/common/http';
import { MenuComponent } from './@core/menu/menu.component';
import { NgModule } from '@angular/core';
import { NvD3Module } from 'ng2-nvd3';
import { SummaryComponent } from './pages/summary/summary.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    MenuComponent,
    CoinComparisonComponent,
    CoinDetailsComponent,
    DashboardComponent,
    HistoryDetailsComponent,
    SummaryComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    DataTableModule,
    DropdownModule,
    NvD3Module,
    DialogModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
