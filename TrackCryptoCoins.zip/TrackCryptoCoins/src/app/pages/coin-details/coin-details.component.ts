import 'rxjs/add/operator/map';
import 'd3';
import 'nvd3';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { AfterViewInit, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';

import {ChartExtension} from '../../shared/methods/ChartExtension';
import { CoinList } from '../../shared/model/CoinList';
import { CommonExtension } from './../../shared/methods/CommonExtension';
import { DataService } from '../../@services/data.service';
import { HttpClient } from '@angular/common/http';
import { IcoinDetail } from '../../shared/interfaces/IcoinDetail';
import { NvD3Component } from 'ng2-nvd3';
import { Observable } from 'rxjs/Observable';
import {SelectItem} from 'primeng/api';

declare let d3: any;

@Component({
  selector: 'app-coin-details',
  templateUrl: './coin-details.component.html',
  providers: [ChartExtension, CommonExtension],
  styleUrls: [
    './coin-details.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class CoinDetailsComponent implements OnInit {
  public result: IcoinDetail;
  public options;
  @ViewChild('nvd3') nvd3;
  public data = [];
  coinList: SelectItem[];
  selectedCoin: string;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dataService: DataService,
    private chartExtension: ChartExtension,
    private http: HttpClient,
    private commonExtension: CommonExtension) {
    const code = this.route.snapshot.paramMap.get('id');
    this.getCoinList(code);
  }

  getCoinList(obj: string): void {
    if (obj !== '') {
      this.dataService.getAll<CoinList[]>('https://coincap.io/map').subscribe((res) =>
      // tslint:disable-next-line:one-line
      {   this.coinList =   this.commonExtension.MapCoinList(res, ''); }
      );
      this.selectedCoin = obj;

      this.getCoinDetail(obj);
    }
  }

  MapCoinList(input: CoinList[]): CoinList[] {
    const output: CoinList[] = [];
    if (input !== null) {
    for (const customer of input) {
      // tslint:disable-next-line:max-line-length
      if ( customer.name !== null && customer.name !== undefined && customer.name !== 'undefined' && customer.name !== '' && customer.symbol !== '') {
      this.newMethod(output, customer);
      }
    }
  }
    return output;
  }

  private newMethod(output: CoinList[], customer: CoinList) {
    output.push(customer);
  }


  getCoinDetail(obj: string): void {
    console.log(obj);
      if (obj !== '') {
        this.dataService.get<IcoinDetail>('https://coincap.io/page/' + obj).subscribe((res) =>
        this.result =  this.getDescendantProp(res));
        this.options = this.chartExtension.getOptionsForAreaChart();
        this.data = [];
        this.dataService.getAll<any>('https://coincap.io/history/7day/' + obj).subscribe((res) =>
        this.data = [
                      { values: this.MapHistoryData(res, 'price'), key: 'Price' }
                    ]);
        }
  }

  MapHistoryData(input: any, key: string): any {
    return input[key];
  }

  getDescendantProp (obj: IcoinDetail): IcoinDetail {
    obj.fullName = obj.display_name + ' (' + obj.id + ')';
    if (obj.cap24hrChange > 0)    {
    obj.style =  ' bg-success ';
    }
    // tslint:disable-next-line:one-line
    else {
      obj.style = ' bg-danger ';
  }
    return obj;
  }
  ngOnInit() {
  }

}
