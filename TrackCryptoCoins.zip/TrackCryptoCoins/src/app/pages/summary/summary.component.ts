import 'rxjs/add/operator/map';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../../@services/data.service';
import { HttpClient } from '@angular/common/http';
import { IcoinDetails } from '../../shared/interfaces/IcoinDetails';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  result: IcoinDetails[];
  loading: boolean;
  constructor(private dataService: DataService, private http: HttpClient) {
    this.loading = true;
    this.dataService.getAll<IcoinDetails[]>('https://coincap.io/front').subscribe((res) =>
    // tslint:disable-next-line:one-line
    {
      this.result =  this.mapSummaryDetails(res);
      this.loading = false;
    });
  }

  mapSummaryDetails (obj: IcoinDetails[]): IcoinDetails[] {
    let int = 1;
    const  output: IcoinDetails[] = [];
    for (const customer of obj) {
      customer.index = int;
      output.push(customer);
      int++;
    }
    return output;
  }
  ngOnInit() {
  }
}
