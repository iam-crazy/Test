import 'd3';
import 'nvd3';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { AfterViewInit, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';

import {ChartExtension} from '../../shared/methods/ChartExtension';
import { CoinList } from '../../shared/model/CoinList';
import { CommonExtension } from '../../shared/methods/CommonExtension';
import { DataService } from '../../@services/data.service';
import { HistoryDetail } from '../../shared/model/HistoryDetail';
import { HttpClient } from '@angular/common/http';
import { IcoinDetail } from '../../shared/interfaces/IcoinDetail';
import { NvD3Component } from 'ng2-nvd3';
import { Observable } from 'rxjs/Observable';
import {SelectItem} from 'primeng/api';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-history-details',
  templateUrl: './history-details.component.html',
  styleUrls: ['./history-details.component.css'],
  providers: [ChartExtension, CommonExtension]
})
export class HistoryDetailsComponent implements OnInit {
  public result: IcoinDetail;
  public options;
  loading: boolean;
  public object1;
  @ViewChild('nvd3') nvd3;
  public data = [];
  coinList: SelectItem[];
  historyDetails: HistoryDetail[]= [];
  selectedCoin: string ;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private dataService: DataService,
    private http: HttpClient,
    private chartExtension: ChartExtension,
    private commonExtension: CommonExtension) {
    this.GetCoinList('ETC');
  }

  GetCoinList(obj: string): void {
    if (obj !== '') {
      this.dataService.getAll<CoinList[]>('https://coincap.io/map').subscribe((res) =>
      this.coinList =   this.commonExtension.MapCoinList(res, '')
      );
      this.getCoinHistoryDetails(obj);
      this.selectedCoin = obj;
    }
  }

  getCoinHistoryDetails(obj: string): void {
    this.loading = true;
      if (obj !== '') {
        this.options = this.chartExtension.getOptionsForAreaChart();

        this.dataService.getAll<any>('https://coincap.io/history/7day/' + obj).subscribe((res) =>
        this.data = [
                      { values: this.commonExtension.mapHistoryData(res, 'market_cap'), key: 'market_cap' },
                      { values: this.commonExtension.mapHistoryData(res, 'price'), key: 'price' },
                      { values: this.commonExtension.mapHistoryData(res, 'volume'), key: 'volume' }
                    ]);

        this.dataService.getAll<any>('https://coincap.io/history/7day/' + obj).subscribe((res) =>
        // tslint:disable-next-line:one-line
        {

          this.historyDetails = this.commonExtension.MapHistorySummary(res);
        });
        }
    this.loading = false;
  }

  ngOnInit(): void {
  }

}
