import 'rxjs/add/operator/map';

import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DataService } from '../../@services/data.service';
import { HttpClient } from '@angular/common/http';
import { IcoinDetails } from '../../shared/interfaces/IcoinDetails';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
   result: IcoinDetails[];
  constructor(private dataService: DataService, private http: HttpClient) {
    this.dataService.getAll<IcoinDetails[]>('https://coincap.io/front').subscribe((res) =>
    this.result =  this.getDescendantProp(res)
  );
  }
  ngOnInit(): void {
      }

     getDescendantProp (obj: IcoinDetails[]): IcoinDetails[] {
      let int = 1;
      const  output: IcoinDetails[] = [];
      for (const customer of obj) {
        switch (int) {
         case 1:
         customer.style = 'widget widget-stat widget-stat-right bg-inverse text-white';
         break;
         case 2:
         customer.style = 'widget widget-stat widget-stat-right bg-success text-white';
         break;
         case 3:
         customer.style = 'widget widget-stat widget-stat-right bg-primary text-white';
         break;
         case 4:
         customer.style = 'widget widget-stat widget-stat-right bg-info text-white';
         break;
         case 5:
         customer.style = 'widget widget-stat widget-stat-right bg-lightBlue text-white';
         break;
         case 6:
         customer.style = 'widget widget-stat widget-stat-right bg-purple text-white';
         break;
         case 7:
         customer.style = 'widget widget-stat widget-stat-right bg-lightGreen text-white';
         break;
         default:
         customer.style = 'widget widget-stat widget-stat-right bg-danger text-white';
         break;
        }
        output.push(customer);
        int++;
        if (int >= 9) {
          int = 1;
        }
      }

      return output;
      }

}
