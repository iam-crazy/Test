import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoinComparisonComponent } from './coin-comparison.component';

describe('CoinComparisonComponent', () => {
  let component: CoinComparisonComponent;
  let fixture: ComponentFixture<CoinComparisonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoinComparisonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoinComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
