import 'rxjs/add/operator/map';
import 'd3';
import 'nvd3';
import 'rxjs/add/operator/mergeMap';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { AfterViewInit, Component, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';

import {ChartExtension} from '../../shared/methods/ChartExtension';
import { CoinList } from '../../shared/model/CoinList';
import { CommonExtension } from '../../shared/methods/CommonExtension';
import { DataService } from '../../@services/data.service';
import { HttpClient } from '@angular/common/http';
import { IcoinDetail } from '../../shared/interfaces/IcoinDetail';
import { NvD3Component } from 'ng2-nvd3';
import { Observable } from 'rxjs/Observable';
import {SelectItem} from 'primeng/api';

declare let d3: any;

@Component({
  selector: 'app-coin-comparison',
  templateUrl: './coin-comparison.component.html',
  styleUrls: ['./coin-comparison.component.css'],
  providers: [ChartExtension, CommonExtension],
  encapsulation: ViewEncapsulation.None
})
export class CoinComparisonComponent implements OnInit {
  public result1: IcoinDetail;
  public result2: IcoinDetail;
  public price1 = 0;
  public price2 = 0;
  public name1;
  public name2;
  public dataAreaChart1 = [];
  public optionsAreaChart1;
  public dataAreaChart2 = [];
  public optionsAreaChart2;
  public dataBarChart = [];
  public optionsPieChart;
  public dataPieChart = [];
  public optionsBarChart;
  @ViewChild('nvd3') nvd3;
  coinList1: SelectItem[];
  coinList2: SelectItem[];
  selectedCoin1: string;
  selectedCoin2: string;
  // tslint:disable-next-line:max-line-length
  constructor(private route: ActivatedRoute,
    private router: Router,
    private dataService: DataService,
    private http: HttpClient,
    private chartExtension: ChartExtension,
    private commonExtension: CommonExtension) {
      this.getCoinList('BTC', 'ETC');
  }

  getCoinList(obj1: string, obj2: string): void {
      this.dataService.getAll<CoinList[]>('https://coincap.io/map').subscribe((res) =>
      this.coinList1 =  this.commonExtension.MapCoinList(res, obj2)
      );
      this.dataService.getAll<CoinList[]>('https://coincap.io/map').subscribe((res) =>
      this.coinList2 =  this.commonExtension.MapCoinList(res, obj1)
      );
      this.selectedCoin1 = 'BTC';
      this.selectedCoin2 = 'ETC';
      this.getCoinDetail1(obj1);
      this.getCoinDetail2(obj2);
      this.getAreaChart1(obj1);
      this.getAreaChart2(obj2);
  }

  getCoinDetail1(obj: string): void {
    if (obj !== '') {
      this.dataService.getAll<CoinList[]>('https://coincap.io/map').subscribe((res) =>
      this.coinList2 =  this.commonExtension.MapCoinList(res, obj));
      this.dataService.get<IcoinDetail>('https://coincap.io/page/' + obj).subscribe((res) =>
      this.result1 =  this.commonExtension.getDescendantProp(res));
      this.getAreaChart1(obj);
      this.getBarChart(obj, this.selectedCoin2);
      this.getPieChart(obj, this.selectedCoin2);
    }
  }

  getCoinDetail2(obj: string): void {
      if (obj !== '') {
      this.dataService.getAll<CoinList[]>('https://coincap.io/map').subscribe((res) =>
      this.coinList1 =  this.commonExtension.MapCoinList(res, obj));
        this.dataService.get<IcoinDetail>('https://coincap.io/page/' + obj).subscribe((res) =>
        this.result2 =  this.commonExtension.getDescendantProp(res));
        this.getAreaChart2(obj);
        this.getBarChart(this.selectedCoin1, obj);
        this.getPieChart(this.selectedCoin1, obj);
      }
  }

  getAreaChart1(obj: string): void {
    if (obj !== '') {
      this.optionsAreaChart1 = this.chartExtension.getOptionsForAreaChart();
      this.dataService.getAll<any>('https://coincap.io/history/7day/' + obj).subscribe((res) =>
      this.dataAreaChart1 = [
                    { values: this.commonExtension.mapHistoryData(res, 'price'), key: 'price' }
                  ]);
      }
}

getAreaChart2(obj: string): void {
  if (obj !== '') {
    this.optionsAreaChart2 = this.chartExtension.getOptionsForAreaChart();
    this.dataService.getAll<any>('https://coincap.io/history/7day/' + obj).subscribe((res) =>
    this.dataAreaChart2 = [
                  { values: this.commonExtension.mapHistoryData(res, 'price'), key: 'price' }
                ]);
    }
}

  getPieChart(obj1: string, obj2: string): void {
    this.optionsPieChart = this.chartExtension.getOptionsForPieChart();
    this.dataService.getAll<IcoinDetail>('https://coincap.io/page/' + obj1).subscribe((res1) =>
    this.dataService.getAll<IcoinDetail>('https://coincap.io/page/' + obj2).subscribe((res2) =>
    this.dataPieChart =  [
      {
          x: res1.id,
          y: res1.price
      },
      {
          x: res2.id,
          y: res2.price
      }])
    );
  }

  getBarChart(obj1: string, obj2: string): void {
      this.optionsBarChart = this.chartExtension.getOptionsForBarChart();
      this.dataService.getAll<IcoinDetail>('https://coincap.io/page/' + obj1).subscribe((res1) =>
      this.dataService.getAll<IcoinDetail>('https://coincap.io/page/' + obj2).subscribe((res2) =>
      this.dataBarChart =  [
        {
            key: 'data',
            values: [
                {
                    x : res1.id ,
                    y : res1.cap24hrChange
                } ,
                {
                    x : res2.id,
                    y : res2.cap24hrChange
                }
            ]
        }
    ])
    );
  }

  ngOnInit() {
  }

}
