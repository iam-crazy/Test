export class HistoryDetail {
  DateTimeValue: string;
  MarketCap: string;
  Price: string;
  Volume: string;
}
