export class CoinList {
  name: string;
  symbol: string;
}
