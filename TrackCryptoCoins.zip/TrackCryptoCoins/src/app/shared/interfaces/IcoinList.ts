export interface IcoinList {
  name: string;
  symbol: string;
}
