export class IcoinDetails {
  cap24hrChange: string;
  long: string;
  mktcap: string;
  perc: string;
  price: string;
  shapeshift: string;
  short: string;
  supply: string;
  usdVolume: string;
  volume: string;
  vwapData: string;
  vwapDataBTC: string;
  index: number;
  style: string;
}

