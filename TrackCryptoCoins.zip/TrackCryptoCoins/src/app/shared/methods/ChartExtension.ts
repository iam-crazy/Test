import { CoinList } from './../model/CoinList';
import { DataService } from './../../@services/data.service';
import { IcoinDetail } from './../interfaces/IcoinDetail';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ChartExtension {

  public getOptionsForAreaChart(): object {
    return {
      chart: {
          type: 'stackedAreaChart',
          height: 450,
          margin : {
              top: 30,
              right: 10,
              bottom: 50,
              left: 100
          },
          x: function(d){return d[0]; },
          y: function(d){return d[1]; },
          useInteractiveGuideline: true,
          xAxis: {
              showMaxMin: false,
              axisLabel: 'Last 7 days',
              tickFormat: function(d) {
                  return d3.time.format('%d %b %H:%M:%S')(new Date(d));
              }
          },
          yAxis: {
              axisLabel: '',
              tickFormat: function(d){
                if (isNaN(d) === true)
            // tslint:disable-next-line:one-line
            {
              return 0;
            }
            // tslint:disable-next-line:one-line
            else{ return d; }
              },
              rotateLabels: -90
          },
          zoom: {
              enabled: true,
              scaleExtent: [1, 10],
              useFixedDomain: false,
              useNiceScale: false,
              horizontalOff: false,
              verticalOff: true,
              unzoomEventType: 'dblclick.zoom'
          }
      }
    };
  }

  public getOptionsForPieChart(): object {
    return {
        chart: {
          type: 'pieChart',
          height: 450,
          x: function(d){return d.x; },
          y: function(d){return d.y; }
          },
          showLabels: true,
          duration: 500,
          labelThreshold: 0.01,
          labelSunbeamLayout: true,
          legend: {
              margin: {
                  top: 5,
                  right: 35,
                  bottom: 5,
                  left: 0
              }
          }
      };
    }

    public getOptionsForBarChart(): object {
  return {
        chart: {
          type: 'discreteBarChart',
          height: 450,
          margin : {
              top: 20,
              right: 20,
              bottom: 50,
              left: 70
          },
          x: function(d){return d.x; },
          y: function(d){return d.y; },
          showValues: true,
          valueFormat: function(d){
            if (isNaN(d) === true)
            // tslint:disable-next-line:one-line
            {
              return 0;
            }
            // tslint:disable-next-line:one-line
            else{  return d; }
          },
          xAxis: {
              axisLabel: 'X Axis'
          },
          yAxis: {
              axisLabel: 'Y Axis',
              axisLabelDistance: 0
          }
      }
    };
  }
}
