import { CoinList } from './../model/CoinList';
import { DataService } from './../../@services/data.service';
import { HistoryDetail } from './../model/HistoryDetail';
import { IcoinDetail } from './../interfaces/IcoinDetail';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class RestClient {
}
