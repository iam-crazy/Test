import 'd3';
import 'nvd3';

import { CoinList } from './../model/CoinList';
import { DataService } from './../../@services/data.service';
import { HistoryDetail } from './../model/HistoryDetail';
import { IcoinDetail } from './../interfaces/IcoinDetail';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {SelectItem} from 'primeng/api';

@Injectable()
export class CommonExtension {
  public getDescendantProp (obj: IcoinDetail): IcoinDetail {
    obj.fullName = obj.display_name + ' (' + obj.id + ')';
    if (obj.cap24hrChange > 0)    {
    obj.style =  ' bg-success ';
    }
    // tslint:disable-next-line:one-line
    else {
      obj.style = ' bg-danger ';
    }
    return obj;
  }

  public getCoinDetail(obj: string, dataService: DataService): IcoinDetail {
    let output: IcoinDetail;
    dataService.get<IcoinDetail>('https://coincap.io/page/' + obj).subscribe((res) =>
    output =  this.getDescendantProp(res));
    return output;
  }

  public newMethod(output: CoinList[], customer: CoinList) {
    output.push(customer);
  }

  public mapHistoryData(input: any, key: string): any {
    if (input !== null)
    // tslint:disable-next-line:one-line
    {
      return input[key];
    }
    // tslint:disable-next-line:one-line
    else{
      return [];
    }
  }

  public MapHistorySummary(input: any): HistoryDetail[] {
    const output: HistoryDetail[] = [];
    if (input !== null) {
        const obj1 = this.mapHistoryData(input, 'market_cap');
        const obj2 = this.mapHistoryData(input, 'price');
        const obj3 = this.mapHistoryData(input, 'volume');
        for (let i = 0, iLen = obj1.length; i < iLen; i++) {
          const  historyDetails = new HistoryDetail();
          historyDetails.DateTimeValue = d3.time.format('%d %b %H:%M:%S')(new Date(obj2[i][0]));
          historyDetails.MarketCap = obj1[i][1];
          historyDetails.Price = obj2[i][1];
          historyDetails.Volume = obj3[i][1];
          output.push(historyDetails);
        }
      }
      return output;
    }

    public MapCoinList(input: CoinList[], coinName: string ): SelectItem[] {
      const output: SelectItem[] = [];
      for (const customer of input) {
        // tslint:disable-next-line:max-line-length
        if (customer.symbol !== coinName && customer.name !== null && customer.name !== undefined && customer.name !== 'undefined' && customer.name !== '' && customer.symbol !== '') {
          output.push({ label: customer.name, value: customer.symbol });
        }
      }
      return output;
    }

}
