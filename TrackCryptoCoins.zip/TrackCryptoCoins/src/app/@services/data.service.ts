import 'rxjs/add/operator/map';

import { HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class DataService {

    constructor(private http: HttpClient) {
    }

    public getAll<T>(url: string): Observable<T> {
        return this.http.get<T>(url);
    }

    public get<T>(url: string): Observable<T> {
        return this.http.get<T>(url);
    }

    public getSingle<T>(code: string, url: string): Observable<T> {
        return this.http.get<T>(url + code);
    }

    public add<T>(itemName: string, url: string): Observable<T> {
        const toAdd = JSON.stringify({ ItemName: itemName });

        return this.http.post<T>(url, toAdd);
    }

    public update<T>(id: number, itemToUpdate: any, url: string): Observable<T> {
        return this.http
            .put<T>(url + id, JSON.stringify(itemToUpdate));
    }

    public delete<T>(id: number, url: string): Observable<T> {
        return this.http.delete<T>(url + id);
    }
}


@Injectable()
export class CustomInterceptor implements HttpInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (!req.headers.has('Content-Type')) {
            req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
        }

        req = req.clone({ headers: req.headers.set('Access-Control-Expose-Headers', 'Access-Control-*') });
        req = req.clone({ headers: req.headers.set('Access-Control-Allow-Headers',
        'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept') });
        req = req.clone({ headers: req.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, HEAD') });
        req = req.clone({ headers: req.headers.set('Allow', 'GET, POST, PUT, DELETE, OPTIONS, HEAD') });

        return next.handle(req);
    }
}
