import { RouterModule, Routes } from '@angular/router';

import { CoinComparisonComponent } from './pages/coin-comparison/coin-comparison.component';
import { CoinDetailsComponent } from './pages/coin-details/coin-details.component';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { HistoryDetailsComponent } from './pages/history-details/history-details.component';
import { NgModule } from '@angular/core';
import { SummaryComponent } from './pages/summary/summary.component';

const routes: Routes = [
  { path: '', redirectTo: '/Dashboard', pathMatch: 'full' },
  {
    path: 'Dashboard',
    component: DashboardComponent
  },
  {
   path: 'Dashboard/Detail/:id',
   component: CoinDetailsComponent
 },
  {
    path: 'Summary',
    component: SummaryComponent
  },
  {
    path: 'Summary/Detail/:id',
    component: CoinDetailsComponent
  },
  {
    path: 'Detail/:id',
    component: CoinDetailsComponent
  },
  {
    path: 'History',
    component: HistoryDetailsComponent
  },
  {
    path: 'CoinComparison',
    component: CoinComparisonComponent
  }
];
@NgModule({
  imports: [ CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
