export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyBM3qLounBE97JNuZ_QZ27_tVd7iPaa20g',
    authDomain: 'nirubantestweb.firebaseapp.com',
    databaseURL: 'https://nirubantestweb.firebaseio.com',
    projectId: 'nirubantestweb',
    storageBucket: 'nirubantestweb.appspot.com',
    messagingSenderId: '306644775039'
  }
};
