import { AppComponent } from './app.component';
import { LoginComponent } from './page/login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout/layout.component';
import { PageNotFoundComponent } from './page/page-not-found/page-not-found.component';
import { EmployeeComponent } from './page/employee/employee.component';
import { AttendanceComponent } from './page/attendance/attendance.component';
import { NewattendanceComponent } from './page/attendance/newattendance/newattendance.component';
import { NewEmployeeComponent } from './page/employee/new-employee/new-employee.component';
import { BankComponent } from './page/bank/bank.component';
import { NewbankComponent } from './page/bank/newbank/newbank.component';
import {DashboardComponent } from './page/dashboard/dashboard.component';
import { SalaryComponent } from './page/salary/salary.component';
import { PaidListComponent } from './page/salary/paid-list/paid-list.component';

const appRoutes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        component: DashboardComponent
      },
      {
        path: 'header',
        component: DashboardComponent
      },
      {
        path: 'employee',
        component: EmployeeComponent
      },
      {
        path: 'attendance',
        component: AttendanceComponent
      },
      {
        path: 'newattendance',
        component: NewattendanceComponent
      },
      {
        path: 'newattendance/:key',
        component: NewattendanceComponent
      },

      {
        path: 'newemployee',
        component: NewEmployeeComponent
      },
      {
        path: 'newemployee/:key',
        component: NewEmployeeComponent
      },
      {
        path: 'account',
        component: BankComponent
      },
      {
        path: 'newaccount',
        component: NewbankComponent
      },
      {
        path: 'newaccount/:key',
        component: NewbankComponent
      },
      {
        path: 'salary',
        component: SalaryComponent
      },
      {
        path: 'paidlist',
        component: PaidListComponent
      }
    ]
  },

  {
    path: '**',
    component: PageNotFoundComponent
  }
];

export const routing = RouterModule.forRoot(appRoutes);
