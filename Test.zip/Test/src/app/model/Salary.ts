import { BaseModel } from './Attendance';
import { constant } from './constant';
import { isNullOrUndefined } from 'util';
import { Extension } from '../extensions/Extension';

export class SalaryDetailWithChildern {
  key: string;
  totalMinutes: number;
  date: Date;
  from: Date;
  to: Date;
  remarks: string;
  employee: BaseModel;
  generalShiftAmount: number;
  extraShiftAmount: number;
  totalSalary: number;
}

export class SalaryDeposit {
  key: string;
  employee: BaseModel;
  from: Date;
  to: Date;
  amount: number;
}
export class SalaryDetail {
  key: string;
  totalMinutes: number;
  date: Date;
  from: Date;
  to: Date;
  isEditable = true;
  remarks: string;
  employee: BaseModel;
  generalShiftMinutes: number;
  extraShiftMinutes: number;
  generalShiftAmount: number;
  extraShiftAmount: number;
  generalShiftTotalAmount: number;
  extraShiftTotalAmount: number;
  totalSalary: number;
  children: SalaryDetail[];

  public CalculateMinutes() {
    this.totalMinutes = Extension.GetDateDifferanceInMinutes(
      this.to,
      this.from
    );
    this.generalShiftMinutes =
      this.totalMinutes > 480 ? 480 : this.totalMinutes;
    this.extraShiftMinutes =
      this.totalMinutes > 480 ? this.totalMinutes - 480 : 0;
  }

  public CalculateAmount() {
    if (
      !isNullOrUndefined(this.generalShiftAmount) &&
      !isNullOrUndefined(this.extraShiftAmount) &&
      !isNullOrUndefined(this.generalShiftMinutes) &&
      !isNullOrUndefined(this.extraShiftMinutes)
    ) {
      const shiftPerMinuteAmount = this.generalShiftAmount / 480;
      const extraHourPerMinuteAmount = this.extraShiftAmount / 240;
      this.generalShiftTotalAmount =
        this.generalShiftMinutes * shiftPerMinuteAmount;
      this.extraShiftTotalAmount =
        this.extraShiftMinutes * extraHourPerMinuteAmount;
      this.totalSalary =
        this.generalShiftTotalAmount + this.extraShiftTotalAmount;
    }
  }
}
