class Constants {
  readonly roles: any[] = [
    { label: '', value: '' },
    { label: 'Manager', value: 'Manager' },
    { label: 'Driver', value: 'Driver' },
    { label: 'Chemist', value: 'Chemist' },
    { label: 'Employee', value: 'Employee' },
    { label: 'Accountant', value: 'Accountant' }
  ];

  readonly types: any[] = [
    { label: '', value: '' },
    { label: 'Permanent', value: 'Permanent' },
    { label: 'Temporary', value: 'Temporary' }
  ];

  readonly firebase: any = {
    employee: 'employee',
    attendance: 'attendance',
    bank: 'bank',
    salary: 'salary'
  };
}

export const constant = new Constants();
