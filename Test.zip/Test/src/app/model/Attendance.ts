import { Component } from '@angular/core';
import { Time } from 'ngx-bootstrap/timepicker/timepicker.models';
import * as firebase from 'firebase/app';

export class BaseModel {
  key: string;
  name: string;
}

export class AttendanceDetail {
  date: Date;
  from: Date;
  to: Date;
  employee: BaseModel;
  remarks: string;
}

export class AttendanceDetailFireBase {
  date: Date;
  from: Date;
  to: Date;
  employee: string;
  remarks: string;
}

export class AttendanceDetailFireBaseWithKey extends AttendanceDetailFireBase {
  key: string;
}

export class AttendanceDetailWithKey {
  key: string;
  hours: string;
  date: Date;
  from: Date;
  to: Date;
  remarks: string;
  employee: BaseModel;
}
