import { AuthService } from './../services/auth.service';
import { SessionBehaviour } from '../framework/SessionBehaviour';

export class OnBaseInit {
  constructor(public auth: AuthService, public session: SessionBehaviour) {
    if (!auth.authenticated) {
      auth.authState = this.session.getSessionStorage('userloginDetail');
    }
    auth.IsValidUser();
  }
}
