import { Component } from '@angular/core';
import { Time } from 'ngx-bootstrap/timepicker/timepicker.models';
import * as firebase from 'firebase/app';

export class BankDetail {
  date: Date;
  type: string;
  description: string;
  amount: number;
}
export class BankStatement {
  date: Date;
  description: string;
  credit: number;
  debit: number;
  balance: number;
}

export class BankDetailFireBaseWithKey extends BankDetail {
  key: string;
}
