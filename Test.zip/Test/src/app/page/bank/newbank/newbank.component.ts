import { Component, OnInit } from '@angular/core';
import { BankDetail } from '../../../model/Bank';
import { constant } from '../../../model/constant';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { BaseValidator } from '../../../model/BaseValidator';
import { FirebasecloudstoreService } from '../../../services/firebasecloudstore.service';

import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-newbank',
  templateUrl: './newbank.component.html',
  styleUrls: ['./newbank.component.css']
})
export class NewbankComponent implements OnInit {
  public myForm: FormGroup; // our model driven form
  key: string;

  onlyAmount: RegExp = /^([0-9]+)(.[0-9]+)?$/;
  bank: BankDetail = new BankDetail();
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private _fb: FormBuilder,
    private firebase: FirebasecloudstoreService
  ) {
    this.route.params.subscribe(params => (this.key = params.key));
  }

  saveBank(model: BankDetail, isValid: boolean) {
    BaseValidator.ValidateFormControl(this.myForm);
    if (isValid) {
      if (isNullOrUndefined(this.key)) {
        this.firebase.add(constant.firebase.bank, model);
      } else {
        this.firebase.update(constant.firebase.bank, model, this.key);
      }
      this.router.navigate(['/account']);
    } else {
      console.log(model);
    }
  }

  cancelBank(e) {
    this.router.navigate(['/account']);
  }

  clearBank(e) {
    if (isNullOrUndefined(this.key)) {
      this.myForm.reset();
    } else {
      this.myForm.setValue(this.bank);
    }
  }

  ngOnInit() {
    this.myForm = new FormGroup({
      type: new FormControl('', [<any>Validators.required]),
      date: new FormControl('', [<any>Validators.required]),
      description: new FormControl('', [
        <any>Validators.required,
        <any>Validators.minLength(10)
      ]),
      amount: new FormControl('', [<any>Validators.required])
    });
    if (!isNullOrUndefined(this.key)) {
      this.firebase
        .getSingle(constant.firebase.bank, this.key)
        .subscribe(item => {
          this.bank = item;
          console.log(this.bank);
          this.myForm.setValue(this.bank);
        });
    }
  }
}
