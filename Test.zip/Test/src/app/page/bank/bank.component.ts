import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankDetailFireBaseWithKey, BankStatement } from '../../model/Bank';
import { FirebasecloudstoreService } from '../../services/firebasecloudstore.service';
import { constant } from '../../model/constant';
import { Observable } from 'rxjs/Observable';
import { ConfirmationService } from 'primeng/api';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {
  public myForm: FormGroup;
  accountView = false;
  bankDetails: BankDetailFireBaseWithKey[];
  banks: BankDetailFireBaseWithKey[];
  statements: BankStatement[] = [];
  constructor(
    private router: Router,
    private firebaseService: FirebasecloudstoreService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.myForm = new FormGroup({
      type: new FormControl(''),
      from: new FormControl(''),
      to: new FormControl('')
    });
    this.firebaseService
      .getWhere(constant.firebase.bank, order => order.orderBy('date', 'asc'))
      .subscribe(item => {
        this.bankDetails = item;
        this.banks = item;
        this.GetStatement();
      });
  }
  newAttendance(e) {
    this.router.navigate(['/newaccount']);
  }
  editAttendance(key: string) {
    this.router.navigate(['/newaccount/' + key]);
  }
  clearAttendance(e) {
    this.myForm.reset();
  }
  GetStatement() {
    if (this.statements.length === 0) {
      let balance = 0;
      this.banks.forEach(function(s) {
        const statement = new BankStatement();
        statement.date = s.date;
        statement.description = s.description;
        if (s.type === 'Credit') {
          statement.credit = s.amount;
          balance += parseFloat(s.amount + '');
        } else {
          statement.debit = s.amount;
          balance -= parseFloat(s.amount + '');
        }
        statement.balance = balance;
        this.statements.push(statement);
      }, this);
    }
  }

  filterAttendance() {
    this.banks = this.bankDetails;
    this.accountView = false;
    this.statements = [];
    const filterValue = this.myForm.value;
    if (!isNullOrUndefined(filterValue.type) && filterValue.type !== '') {
      this.banks = this.banks.filter(function(s) {
        return s.type === filterValue.type;
      });
    }

    if (!isNullOrUndefined(filterValue.from) && filterValue.from !== '') {
      this.banks = this.banks.filter(function(s) {
        return s.date >= filterValue.from;
      });
    }
    if (!isNullOrUndefined(filterValue.to) && filterValue.to !== '') {
      this.banks = this.banks.filter(function(s) {
        return s.date <= filterValue.to;
      });
    }
    this.GetStatement();
  }
  deleteAttendance(key: string) {
    this.confirmationService.confirm({
      message: 'Are you sure to delete this bank detail?',
      accept: () => {
        this.firebaseService.delete(constant.firebase.bank, key);
        this.firebaseService
          .get(constant.firebase.bank)
          .subscribe(item => (this.banks = item));
      }
    });
  }
}
