import { Component, OnInit } from '@angular/core';
import {
  AttendanceDetail,
  BaseModel,
  AttendanceDetailFireBaseWithKey
} from '../../../model/Attendance';
import { constant } from '../../../model/constant';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { BaseValidator } from '../../../model/BaseValidator';
import { FirebasecloudstoreService } from '../../../services/firebasecloudstore.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-newattendance',
  templateUrl: './newattendance.component.html',
  styleUrls: ['./newattendance.component.css']
})
export class NewattendanceComponent implements OnInit {
  public myForm: FormGroup; // our model driven form
  employees: BaseModel[];
  key: string;
  attendance: AttendanceDetail = new AttendanceDetail();
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private _fb: FormBuilder,
    private firebase: FirebasecloudstoreService
  ) {
    this.route.params.subscribe(params => (this.key = params.key));
  }

  saveAttendance(model: AttendanceDetailFireBaseWithKey, isValid: boolean) {
    BaseValidator.ValidateFormControl(this.myForm);
    if (isValid) {
      if (model.from < model.to) {
        model.employee = this.myForm.value.employee.key;
        if (isNullOrUndefined(this.key)) {
          this.firebase.add(constant.firebase.attendance, model);
        } else {
          this.firebase.update(constant.firebase.attendance, model, this.key);
        }
        this.router.navigate(['/attendance']);
      } else {
        alert('To must be greater than from');
      }
    }
  }

  cancelAttendance(e) {
    this.router.navigate(['/attendance']);
  }

  clearAttendance(e) {
    if (isNullOrUndefined(this.key)) {
      this.myForm.reset();
    } else {
      this.myForm.setValue(this.attendance);
    }
  }

  ngOnInit() {
    this.firebase
      .get(constant.firebase.employee)
      .subscribe(item => (this.employees = item));
    this.myForm = new FormGroup({
      date: new FormControl('', [<any>Validators.required]),
      from: new FormControl('', [<any>Validators.required]),
      to: new FormControl('', [<any>Validators.required]),
      employee: new FormControl('', [<any>Validators.required]),
      remarks: new FormControl('')
    });
    if (!isNullOrUndefined(this.key)) {
      this.firebase
        .getSingle(constant.firebase.attendance, this.key)
        .subscribe(item => {
          this.attendance = item;
          this.attendance.employee = this.employees.find(
            f => f.key === item.employee
          );
          this.myForm.setValue(this.attendance);
        });
    }
  }
}
