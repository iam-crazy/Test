import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  AttendanceDetailFireBase,
  AttendanceDetailWithKey,
  BaseModel
} from '../../model/Attendance';
import { FirebasecloudstoreService } from '../../services/firebasecloudstore.service';
import { constant } from '../../model/constant';
import { Observable } from 'rxjs/Observable';
import { ConfirmationService } from 'primeng/api';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { isNullOrUndefined } from 'util';
import { Extension } from '../../extensions/Extension';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  public myForm: FormGroup;
  employees: BaseModel[] = [];
  attendanceDetails: AttendanceDetailWithKey[];
  attendances: AttendanceDetailWithKey[];
  constructor(
    private router: Router,
    private firebaseService: FirebasecloudstoreService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.myForm = new FormGroup({
      from: new FormControl(''),
      to: new FormControl(''),
      employee: new FormControl('')
    });
    this.initAttendance();
  }
  initAttendance() {
    this.firebaseService
      .get(constant.firebase.employee)
      .subscribe(item => (this.employees = item));
    this.firebaseService.get(constant.firebase.attendance).subscribe(item => {
      this.attendanceDetails = [];
      item.forEach(s => {
        const attendenceKey = s as AttendanceDetailWithKey;
        attendenceKey.hours = Extension.DateDiffInHours(
          attendenceKey.to,
          attendenceKey.from
        );
        attendenceKey.employee = this.employees.find(f => f.key === s.employee);
        this.attendanceDetails.push(attendenceKey);
      });
      this.attendances = this.attendanceDetails;
    });
  }
  newAttendance(e) {
    this.router.navigate(['/newattendance']);
  }
  editAttendance(key: string) {
    this.router.navigate(['/newattendance/' + key]);
  }
  clearAttendance(e) {
    this.myForm.reset();
  }

  filterAttendance() {
    debugger;
    this.attendances = this.attendanceDetails;
    const filterValue = this.myForm.value;
    if (!isNullOrUndefined(filterValue.from) && filterValue.from !== '') {
      this.attendances = this.attendances.filter(function(s) {
        return s.date >= (filterValue.from as Date);
      });
    }

    if (!isNullOrUndefined(filterValue.to) && filterValue.to !== '') {
      this.attendances = this.attendances.filter(function(s) {
        return s.date <= (filterValue.to as Date);
      });
    }

    if (
      !isNullOrUndefined(filterValue.employee) &&
      filterValue.employee !== ''
    ) {
      this.attendances = this.attendances.filter(function(s) {
        return s.employee.key === filterValue.employee.key;
      });
    }
  }
  deleteAttendance(attendance: AttendanceDetailWithKey) {
    this.confirmationService.confirm({
      message: 'Are you sure to delete this attendance detail?',
      accept: () => {
        this.firebaseService.delete(
          constant.firebase.attendance,
          attendance.key
        );
        this.initAttendance();
      }
    });
  }
}
