import { Component, OnInit } from '@angular/core';
import { AuthService } from './../../services/auth.service';
import { SessionBehaviour } from '../../framework/SessionBehaviour';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
  AbstractControl
} from '@angular/forms';
import { isNullOrUndefined } from 'util';
import { BaseValidator } from '../../model/BaseValidator';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public myForm: FormGroup; // our model driven form
  user = {
    email: '',
    password: ''
  };
  constructor(
    private authService: AuthService,
    private session: SessionBehaviour,
    private _fb: FormBuilder
  ) {}

  ngOnInit() {
    this.myForm = new FormGroup({
      email: new FormControl('', [
        <any>Validators.required,
        <any>Validators.minLength(5),
        Validators.email
      ]),
      password: new FormControl('', [
        <any>Validators.required,
        <any>Validators.minLength(5)
      ])
    });
  }

  signInWithEmail(model: any, isValid: boolean) {
    BaseValidator.ValidateFormControl(this.myForm);
    if (isValid) {
      this.authService
        .emailLogin(model.email, model.password)
        .then(res => {
          console.log('T');
          this.session.setSessionStorage(
            'userloginDetail',
            this.authService.currentUser
          );
        })
        .catch(err => console.log('error: ' + err));
    }
  }
}
