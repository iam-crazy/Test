import { Component, OnInit, Query } from '@angular/core';
import { Router } from '@angular/router';
import { SalaryDetail, SalaryDeposit } from '../../model/Salary';
import { FirebasecloudstoreService } from '../../services/firebasecloudstore.service';
import { constant } from '../../model/constant';
import { Observable } from 'rxjs/Observable';
import { ConfirmationService } from 'primeng/api';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { isNullOrUndefined } from 'util';
import { BaseModel } from '../../model/Attendance';
import { BankDetail } from '../../model/Bank';
import { BaseValidator } from '../../model/BaseValidator';
import { QueryFn } from 'angularfire2/firestore';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-salary',
  templateUrl: './salary.component.html',
  styleUrls: ['./salary.component.css'],
  providers: [SalaryDetail]
})
export class SalaryComponent implements OnInit {
  public myForm: FormGroup;
  employees: BaseModel[];
  salaryDetails: SalaryDetail[];
  from: Date;
  to: Date;

  constructor(
    private router: Router,
    private firebaseService: FirebasecloudstoreService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    this.myForm = new FormGroup({
      from: new FormControl('', [<any>Validators.required]),
      to: new FormControl('', [<any>Validators.required]),
      employee: new FormControl('')
    });
    this.firebaseService
      .get(constant.firebase.employee)
      .subscribe(item => (this.employees = item));
  }

  initAttendance() {
    this.firebaseService
      .getWhere(constant.firebase.attendance, ref =>
        this.GetWhereCondition(ref)
      )
      .subscribe(item => {
        this.salaryDetails = [];
        const fromValue = this.myForm.value;
        item.forEach(s => {
          if (
            isNullOrUndefined(fromValue.employee) ||
            fromValue.employee === '' ||
            fromValue.employee.key === s.employee
          ) {
            const empSalary: SalaryDetail = this.salaryDetails.find(
              d => d.key === s.employee
            );
            const employee = this.employees.find(f => f.key === s.employee);
            const salary: SalaryDetail = new SalaryDetail();
            salary.date = s.date;
            salary.from = s.from;
            salary.to = s.to;
            salary.key = s.employee;
            salary.CalculateMinutes();
            salary.employee = employee;

            if (isNullOrUndefined(empSalary)) {
              const newSalary = new SalaryDetail();
              newSalary.children = [];
              newSalary.children.push(salary);
              newSalary.isEditable = false;
              newSalary.key = s.employee;
              newSalary.totalMinutes = salary.totalMinutes;
              newSalary.generalShiftMinutes = salary.generalShiftMinutes;
              newSalary.extraShiftMinutes = salary.extraShiftMinutes;
              newSalary.employee = employee;
              this.salaryDetails.push(newSalary);
            } else {
              empSalary.totalMinutes += salary.totalMinutes;
              empSalary.generalShiftMinutes += salary.generalShiftMinutes;
              empSalary.extraShiftMinutes += salary.extraShiftMinutes;
              empSalary.children.push(salary);
            }
          }
        });
      });
  }

  GetWhereCondition(whereClause: firebase.firestore.CollectionReference): any {
    // if (!isNullOrUndefined(fromValue.employee) && fromValue.employee !== '') {
    //   return whereClause
    //     .where('date', '>=', this.from)
    //     .where('date', '<=', this.to)
    //     .where('employee', '==', fromValue.employee.key);
    // } else {
    return whereClause
      .where('date', '>=', this.from)
      .where('date', '<=', this.to);
    // }
  }

  clearAttendance(e) {
    this.myForm.reset();
    this.salaryDetails = [];
  }

  amountUpdated(key) {
    const salary: SalaryDetail = this.salaryDetails.find(d => d.key === key);
    salary.CalculateAmount();
    salary.children.forEach(function(s) {
      s.generalShiftAmount = salary.generalShiftAmount;
      s.extraShiftAmount = salary.extraShiftAmount;
      s.CalculateAmount();
    });
  }

  paidSalary(e: SalaryDetail) {
    let valid = false;
    const sub = this.firebaseService
      .getWhere(constant.firebase.salary, ref =>
        ref.where('employee', '==', e.employee.key)
      )
      .subscribe(item => {
        console.log('Test1');
        valid =
          item.length === 0 ||
          !item.some(function(v) {
            return (
              (v.from >= this.from && v.from <= this.to) ||
              (v.to >= this.from && v.to <= this.to)
            );
          }, this);
        sub.unsubscribe();
        if (!valid) {
          alert('For Some date salary have been given already.');
        } else {
          this.paySalary(e);
        }
      });
  }

  paySalary(e: SalaryDetail) {
    this.confirmationService.confirm({
      message:
        'Are you sure to pay amount this employee, it cannot be edited in future?',
      accept: () => {
        const bankDetail: any = {};
        bankDetail.amount = e.totalSalary;
        bankDetail.type = 'Debit';
        bankDetail.date = new Date();
        bankDetail.description =
          e.employee.name +
          ' salary for period from ' +
          this.from.toLocaleDateString() +
          ' to ' +
          this.to.toLocaleDateString() +
          ' of amount ' +
          e.totalSalary;
        this.firebaseService.add(constant.firebase.bank, bankDetail);
        const paidSalary: any = {};
        paidSalary.employee = e.employee.key;
        const dates = e.children.map(function(v) {
          return v.date;
        });
        paidSalary.from = new Date(Math.min.apply(null, dates));
        paidSalary.to = new Date(Math.max.apply(null, dates));
        paidSalary.amount = e.totalSalary;
        this.firebaseService.add(constant.firebase.salary, paidSalary);
        this.clearAttendance(e);
      }
    });
  }

  filterAttendance() {
    BaseValidator.ValidateFormControl(this.myForm);
    const filterValue = this.myForm.value;
    if (this.myForm.valid) {
      this.from = filterValue.from;
      this.to = filterValue.to;
      this.initAttendance();
    }
  }

  GetPaidDetail(e) {
    this.router.navigate(['/paidlist']);
  }
}
