import { Component, OnInit, Query } from '@angular/core';
import { Router } from '@angular/router';
import { SalaryDeposit } from '../../../model/Salary';
import { FirebasecloudstoreService } from '../../../services/firebasecloudstore.service';
import { constant } from '../../../model/constant';
import { Observable } from 'rxjs/Observable';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { isNullOrUndefined } from 'util';
import { BaseModel } from '../../../model/Attendance';
import { BankDetail } from '../../../model/Bank';
import { BaseValidator } from '../../../model/BaseValidator';
import { QueryFn } from 'angularfire2/firestore';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-paid-list',
  templateUrl: './paid-list.component.html',
  styleUrls: ['./paid-list.component.css']
})
export class PaidListComponent implements OnInit {
  paidDetails: SalaryDeposit[];
  constructor(
    private router: Router,
    private firebaseService: FirebasecloudstoreService
  ) {}

  ngOnInit() {
    this.initAttendance();
  }
  initAttendance() {
    let employees: BaseModel[];
    this.firebaseService
      .get(constant.firebase.employee)
      .subscribe(item => (employees = item));
    this.firebaseService.get(constant.firebase.salary).subscribe(item => {
      this.paidDetails = [];
      item.forEach(s => {
        const paidSalary = s as SalaryDeposit;
        paidSalary.employee = employees.find(f => f.key === s.employee);
        this.paidDetails.push(paidSalary);
      });
      console.table(this.paidDetails);
    });
  }

  GetSalaryDetail(e) {
    this.router.navigate(['/salary']);
  }
}
