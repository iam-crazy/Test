import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetailFireBase } from '../../model/EmployeeDetail';
import { FirebasecloudstoreService } from '../../services/firebasecloudstore.service';
import { constant } from '../../model/constant';
import { Observable } from 'rxjs/Observable';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employees: EmployeeDetailFireBase[];
  // tslint:disable-next-line:max-line-length
  constructor(
    private router: Router,
    private firebaseService: FirebasecloudstoreService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit() {
    const rr = this.firebaseService.get(constant.firebase.employee);
    rr.subscribe(item => (this.employees = item as EmployeeDetailFireBase[]));
  }
  newemployee(e) {
    this.router.navigate(['/newemployee']);
  }
  editEmployee(employee: EmployeeDetailFireBase) {
    this.router.navigate(['/newemployee/' + employee.key]);
  }

  deleteEmployee(employee: EmployeeDetailFireBase) {
    this.confirmationService.confirm({
      message: 'Are you sure to delete this employee?',
      accept: () => {
        this.firebaseService.delete(constant.firebase.employee, employee.key);
        this.firebaseService
          .get(constant.firebase.employee)
          .subscribe(item => (this.employees = item));
      }
    });
  }
}
