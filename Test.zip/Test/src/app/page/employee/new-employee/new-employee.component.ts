import { Component, OnInit } from '@angular/core';
import { EmployeeDetail } from '../../../model/EmployeeDetail';
import { constant } from '../../../model/constant';
import { Router, ActivatedRoute } from '@angular/router';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
import { BaseValidator } from '../../../model/BaseValidator';
import { FirebasecloudstoreService } from '../../../services/firebasecloudstore.service';

import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-new-employee',
  templateUrl: './new-employee.component.html',
  styleUrls: ['./new-employee.component.css']
})
export class NewEmployeeComponent implements OnInit {
  public myForm: FormGroup; // our model driven form
  roles: any[] = constant.roles;
  types: any[] = constant.types;
  key: string;
  emp: EmployeeDetail = new EmployeeDetail();
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private _fb: FormBuilder,
    private firebase: FirebasecloudstoreService
  ) {
    this.route.params.subscribe(params => (this.key = params.key));
  }

  saveEmployee(model: EmployeeDetail, isValid: boolean) {
    BaseValidator.ValidateFormControl(this.myForm);
    if (isValid) {
      if (isNullOrUndefined(this.key)) {
        this.firebase.add(constant.firebase.employee, model);
      } else {
        this.firebase.update(constant.firebase.employee, model, this.key);
      }
      this.router.navigate(['/employee']);
    }
  }

  cancelEmployee(e) {
    this.router.navigate(['/employee']);
  }

  clearEmployee(e) {
    if (isNullOrUndefined(this.key)) {
      this.myForm.reset();
    } else {
      this.myForm.setValue(this.emp);
    }
  }

  ngOnInit() {
    this.myForm = new FormGroup({
      name: new FormControl('', [
        <any>Validators.required,
        <any>Validators.minLength(5)
      ]),
      address: new FormControl(''),
      city: new FormControl(''),
      role: new FormControl('', [<any>Validators.required]),
      type: new FormControl('', [<any>Validators.required]),
      phonenumber: new FormControl('', [
        <any>Validators.required,
        <any>Validators.minLength(10)
      ]),
      remarks: new FormControl(''),
      status: new FormControl(true),
      referencename: new FormControl('', [<any>Validators.required]),
      referencephonenumber: new FormControl('')
    });
    if (!isNullOrUndefined(this.key)) {
      this.firebase
        .getSingle(constant.firebase.employee, this.key)
        .subscribe(item => {
          this.emp = item;
          console.log(this.emp);
          this.myForm.setValue(this.emp);
        });
    }
  }
}
