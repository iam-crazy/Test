import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AuthService } from './../../services/auth.service';
import { OnBaseInit } from './../../model/OnBaseInit';
import { SessionBehaviour } from '../../framework/SessionBehaviour';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent extends OnBaseInit implements OnInit {
  items: MenuItem[];
  constructor(public auth: AuthService, public session: SessionBehaviour) {
    super(auth, session);
  }
  signout(e) {
    this.auth.signOut();
    this.session.clearAll();
  }

  ngOnInit() {
    this.items = [
      {
        label: 'Home',
        icon: 'fa-home',
        routerLink: ['/header']
      },
      {
        label: 'Employee',
        icon: 'fa-edit',
        routerLink: ['/employee']
      },
      {
        label: 'Attendance',
        icon: 'fa-signal',
        routerLink: ['/attendance']
      },
      {
        label: 'Account',
        icon: 'fa-university',
        routerLink: ['/account']
      },
      {
        label: 'Salary',
        icon: 'fa-money',
        routerLink: ['/salary']
      }
    ];
  }
}
