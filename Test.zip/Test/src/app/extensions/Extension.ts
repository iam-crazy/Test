import { constant } from '../model/constant';
import { FirebasecloudstoreService } from '../services/firebasecloudstore.service';
import * as firebase from 'firebase/app';
import { BaseModel } from '../model/Attendance';
import { element } from 'protractor';

class ExtensionClass {
  DateDiffInHours(date_future, date_now): string {
    // get total seconds between the times
    let delta = Math.abs(date_future - date_now) / 1000;

    // calculate (and subtract) whole days
    const days = Math.floor(delta / 86400);
    delta -= days * 86400;

    // calculate (and subtract) whole hours
    const hours = Math.floor(delta / 3600) % 24;
    delta -= hours * 3600;

    // calculate (and subtract) whole minutes
    const minutes = Math.floor(delta / 60) % 60;
    delta -= minutes * 60;

    // what's left is seconds
    const seconds = delta % 60;

    return hours + ':' + minutes;
  }

  GetDateDifferanceInMinutes(date_future: Date, date_now: Date): number {
    date_future.setSeconds(0, 0);
    date_now.setSeconds(0, 0);
    const diff = date_future.getTime() - date_now.getTime();
    return Math.round(diff / 60000);
  }
}
export const Extension = new ExtensionClass();
