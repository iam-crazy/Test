import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'minutesToTimeString'
})
export class MinutesToTimeStringPipe implements PipeTransform {
  transform(value: number, args?: any): any {
    return Math.trunc(value / 60) + ':' + Math.trunc(value % 60);
  }
}
