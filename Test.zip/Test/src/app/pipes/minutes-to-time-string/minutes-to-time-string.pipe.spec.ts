import { MinutesToTimeStringPipe } from './minutes-to-time-string.pipe';

describe('MinutesToTimeStringPipe', () => {
  it('create an instance', () => {
    const pipe = new MinutesToTimeStringPipe();
    expect(pipe).toBeTruthy();
  });
});
