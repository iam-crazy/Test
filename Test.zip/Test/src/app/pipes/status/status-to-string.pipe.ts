import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'statusToString'
})
export class StatusToStringPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if (value) {
      return '<span class=\'label label-success\'><i class=\'fa fa-thumbs-up\'></i></span> &nbsp; Active';
    } else {
      return '<span class=\'label label-danger\'><i class=\'fa fa-thumbs-down\'></i></span> &nbsp; Inactive';
    }
  }
}
