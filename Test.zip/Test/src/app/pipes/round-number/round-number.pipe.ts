import { Pipe, PipeTransform } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'roundNumber'
})
export class RoundNumberPipe extends DecimalPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    return super.transform(value, args);
  }
}
