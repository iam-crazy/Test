﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentActivityRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentActivityRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model.Pagination;
    using Objects;

    /// <summary>
    /// Declare IEquipmentActivityRepository.
    /// </summary>
    public interface IEquipmentActivityRepository
    {
        /// <summary>
        /// Gets the equipment activity.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="equipmentNumber">The equipment Number.</param>
        /// <returns>Returns The Equipment Activity Id.</returns>
        Task<EquipmentActivity> GetEquipmentActivity(int id, string equipmentNumber);

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="equipmentActivity">The Save data.</param>
        /// <returns>Returns The Save Data.</returns>
        IList<long> Save(IList<EquipmentActivity> equipmentActivity);

        /// <summary>
        /// Searches the equipment activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns the equipment number.</returns>
        Task<IList<Equipment>> SearchEquipmentActivity(string equipmentNumber);

        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <returns>Returns Equipment Activity Lists.</returns>
        Task<PageResponse<EquipmentActivity>> GetEquipmentActivityList(EquipmentActivityFilter activityFilter);

        /// <summary>
        /// Cancels the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <param name="equipmentStateId">The equipment state identifier.</param>
        /// <returns>Returns The Cancel Data.</returns>
        Task<int> Cancel(IList<CancelEquipmentActivity> data, byte? equipmentStateId);

        /// <summary>
        /// Gets the previous activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <returns>Returns The previous activity.</returns>
        Task<EquipmentActivity> GetPreviousActivity(string equipmentNumber, DateTime activityDateTime);

        /// <summary>
        /// Gets the previous activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <returns>Returns The previous activity.</returns>
        Task<EquipmentActivity> GetNextActivity(string equipmentNumber, DateTime activityDateTime);

        /// <summary>
        /// Checks the equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="voyage">The voyage value.</param>
        /// <returns>Returns The equipment activity.</returns>
        Task<ValidateEquipment> CheckEquipment(string equipmentActivityId, string equipmentNumber, int activityReferentialId, DateTime activityDateTime, int locationId, int vesselId, int voyageId, string voyage);

        /// <summary>
        /// Gets the relevant equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <returns>Returns The relevant equipment.</returns>
        Task<IList<EquipmentActivity>> GetRelevantEquipment(int equipmentActivityId);

        /// <summary>
        /// Gets the valid activity count.
        /// </summary>
        /// <returns>Valid activity count.</returns>
        Task<int> SearchValidActivityCount();

        /// <summary>
        /// Checks the equipment activity.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns The equipment activity.</returns>
        Task<bool> CheckEquipmentActivity(int? validationRuleId);

        /// <summary>
        /// Gets the equipment activity ids.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns The equipment activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification = "DoNotNestGenericTypesInMemberSignatures")]
        Task<IList<long>> GetEquipmentActivityIds(int? validationRuleId);

        /// <summary>
        /// Gets the valid activity count.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <returns>
        /// Valid activity count.
        /// </returns>
        Task<IList<Tuple<int?, string, string, int>>> SearchValidActivityCount(EquipmentActivityFilter activityFilter);

        /// <summary>
        /// Determines whether [has equipment activity duplicate] [the specified equipment activity identifier].
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <returns>Returns Equipment Duplicate.</returns>
        Task<bool> HasEquipmentActivityDuplicate(long equipmentActivityId, long equipmentId, int activityReferentialId, DateTime activityDate, int locationId, int vesselId, int voyageId, string feederVoyage);

        /// <summary>
        /// Determines whether [has equipment activity valid] [the specified equipment identifier].
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <returns>Returns Equipment Valid.</returns>
        Task<bool> HasEquipmentActivityValid(long equipmentId, DateTime activityDate);
    }
}