﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentNoteRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentNoteRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare IEquipmentNoteRepository.
    /// </summary>
    public interface IEquipmentNoteRepository
    {
        /// <summary>
        /// Gets the equipment note.
        /// </summary>
        /// <param name="equipmentNoteId">The equipment note identifier.</param>
        /// <returns>Returns The Equipment note Data.</returns>
        Task<IList<EquipmentNote>> GetEquipmentNote(int equipmentNoteId);

        /// <summary>
        /// Saves the specified equipment note data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipment note data.</param>
        /// <returns>Returns The Equipment note Data.</returns>
        Task Save(EquipmentNote equipmentNoteData);
    }
}
