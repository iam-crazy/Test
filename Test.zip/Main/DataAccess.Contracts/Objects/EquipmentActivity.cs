//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivity.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivity.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare EquipmentActivity.
    /// </summary>
    [Table("eme.EquipmentActivity")]
    public partial class EquipmentActivity
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivity"/> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "DoNotCallOverridableMethodsInConstructors")]
        public EquipmentActivity()
        {
            this.EquipmentActivityErrors = new HashSet<EquipmentActivityError>();
            this.EquipmentActivityNotes = new HashSet<EquipmentActivityNote>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the activity referential.
        /// </summary>
        /// <value>
        /// The activity referential.
        /// </value>
        public virtual ActivityReferential Activity { get; set; }

        /// <summary>
        /// Gets or sets the activity date time.
        /// </summary>
        /// <value>
        /// The activity date time.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime ActivityDateTime { get; set; }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the activity UTC date time.
        /// </summary>
        /// <value>
        /// The activity UTC date time.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime ActivityUTCDateTime { get; set; }

        /// <summary>
        /// Gets or sets the BL number.
        /// </summary>
        /// <value>
        /// The BL number.
        /// </value>
        [StringLength(50)]
        public string BLNumber { get; set; }

        /// <summary>
        /// Gets or sets the booking number.
        /// </summary>
        /// <value>
        /// The booking number.
        /// </value>
        [StringLength(50)]
        public string BookingNumber { get; set; }

        /// <summary>
        /// Gets or sets the cancel remarks.
        /// </summary>
        /// <value>
        /// The cancel remarks.
        /// </value>
        [StringLength(500)]
        public string CancelRemarks { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the delivery location identifier.
        /// </summary>
        /// <value>
        /// The delivery location identifier.
        /// </value>
        [Column("LocationIdDelivery")]
        public int? DeliveryLocationId { get; set; }

        /// <summary>
        /// Gets or sets the depot equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The depot equipment handling facility identifier.
        /// </value>
        [Column("EquipmentHandlingFacilityIdDepot")]
        public int? DepotEquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets the destination location identifier.
        /// </summary>
        /// <value>
        /// The destination location identifier.
        /// </value>
        [Column("LocationIdDestination")]
        public int? DestinationLocationId { get; set; }

        /// <summary>
        /// Gets or sets the discharge port identifier.
        /// </summary>
        /// <value>
        /// The discharge port identifier.
        /// </value>
        [Column("PortIdDischarge")]
        public int? DischargePortId { get; set; }

        /// <summary>
        /// Gets or sets the equipment.
        /// </summary>
        /// <value>
        /// The equipment.
        /// </value>
        public virtual Equipment Equipment { get; set; }

        /// <summary>
        /// Gets or sets the cancel equipment activities.
        /// </summary>
        /// <value>
        /// The cancel equipment activities.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "Readonly")]
        public virtual EquipmentActivityCancelReason EquipmentActivityCancelReason { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity cancel reason identifier.
        /// </summary>
        /// <value>
        /// The equipment activity cancel reason identifier.
        /// </value>
        public byte? EquipmentActivityCancelReasonId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity errors.
        /// </summary>
        /// <value>
        /// The equipment activity errors.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "Readonly")]
        public virtual ICollection<EquipmentActivityError> EquipmentActivityErrors { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity notes.
        /// </summary>
        /// <value>
        /// The equipment activity notes.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EquipmentActivityNote> EquipmentActivityNotes { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity state identifier.
        /// </summary>
        /// <value>
        /// The equipment activity state identifier.
        /// </value>
        [StringLength(1)]
        public string EquipmentActivityState { get; set; }

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the state of the equipment.
        /// </summary>
        /// <value>
        /// The state of the equipment.
        /// </value>
        public virtual EquipmentState EquipmentState { get; set; }

        /// <summary>
        /// Gets or sets the equipment state identifier.
        /// </summary>
        /// <value>
        /// The equipment state identifier.
        /// </value>
        public byte? EquipmentStateId { get; set; }

        /// <summary>
        /// Gets or sets the leasing company reference.
        /// </summary>
        /// <value>
        /// The leasing company reference.
        /// </value>
        [StringLength(50)]
        public string LeasingCompanyReference { get; set; }

        /// <summary>
        /// Gets or sets the loading port identifier.
        /// </summary>
        /// <value>
        /// The loading port identifier.
        /// </value>
        [Column("PortIdLoad")]
        public int? LoadingPortId { get; set; }

        /// <summary>
        /// Gets or sets the location identifier.
        /// </summary>
        /// <value>
        /// The location identifier.
        /// </value>
        public int LocationId { get; set; }

        /// <summary>
        /// Gets or sets the logistics status identifier.
        /// </summary>
        /// <value>
        /// The logistics status identifier.
        /// </value>
        public byte? LogisticsStatusId { get; set; }

        /// <summary>
        /// Gets or sets the MSC authorization reference.
        /// </summary>
        /// <value>
        /// The MSC authorization reference.
        /// </value>
        [StringLength(50)]
        public string MSCAuthorizationReference { get; set; }

        /// <summary>
        /// Gets or sets the pick up reference.
        /// </summary>
        /// <value>
        /// The pick up reference.
        /// </value>
        [StringLength(50)]
        [Column("PickUpReference")]
        public string PickupReference { get; set; }

        /// <summary>
        /// Gets or sets the receipt location identifier.
        /// </summary>
        /// <value>
        /// The receipt location identifier.
        /// </value>
        [Column("LocationIdReceipt")]
        public int? ReceiptLocationId { get; set; }

        /// <summary>
        /// Gets or sets the return depot equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The return depot equipment handling facility identifier.
        /// </value>
        [Column("EquipmentHandlingFacilityIdReturnDepot")]
        public int? ReturnDepotEquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets the return equipment authorization number.
        /// </summary>
        /// <value>
        /// The return equipment authorization number.
        /// </value>
        [StringLength(50)]
        public string ReturnEquipmentAuthorizationNumber { get; set; }

        /// <summary>
        /// Gets or sets the return location identifier.
        /// </summary>
        /// <value>
        /// The return location identifier.
        /// </value>
        [Column("LocationIdReturn")]
        public int? ReturnLocationId { get; set; }

        /// <summary>
        /// Gets or sets the return terminal equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The return terminal equipment handling facility identifier.
        /// </value>
        [Column("EquipmentHandlingFacilityIdReturnTerminal")]
        public int? ReturnTerminalEquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets the SCAC code identifier.
        /// </summary>
        /// <value>
        /// The SCAC code identifier.
        /// </value>
        public int? SCACCodeId { get; set; }

        /// <summary>
        /// Gets or sets the seal number.
        /// </summary>
        /// <value>
        /// The seal number.
        /// </value>
        [StringLength(50)]
        public string SealNumber { get; set; }

        /// <summary>
        /// Gets or sets the shipping instruction number.
        /// </summary>
        /// <value>
        /// The shipping instruction number.
        /// </value>
        [StringLength(50)]
        public string ShippingInstructionNumber { get; set; }

        /// <summary>
        /// Gets or sets the terminal equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The terminal equipment handling facility identifier.
        /// </value>
        [Column("EquipmentHandlingFacilityIdTerminal")]
        public int? TerminalEquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets the transshipment port identifier.
        /// </summary>
        /// <value>
        /// The transshipment port identifier.
        /// </value>
        [Column("PortIdTranshipment")]
        public int? TransshipmentPortId { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the vessel identifier.
        /// </summary>
        /// <value>
        /// The vessel identifier.
        /// </value>
        public int? VesselId { get; set; }

        /// <summary>
        /// Gets or sets the voyage.
        /// </summary>
        /// <value>
        /// The voyage.
        /// </value>
        public string Voyage { get; set; }

        /// <summary>
        /// Gets or sets the voyage eta.
        /// </summary>
        /// <value>
        /// The voyage eta.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? VoyageETA { get; set; }

        /// <summary>
        /// Gets or sets the voyage ETD.
        /// </summary>
        /// <value>
        /// The voyage ETD.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? VoyageETD { get; set; }

        /// <summary>
        /// Gets or sets the voyage identifier.
        /// </summary>
        /// <value>
        /// The voyage identifier.
        /// </value>
        public int? VoyageId { get; set; }

        #endregion
    }
}
