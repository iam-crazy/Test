//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityState.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityState.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare EquipmentActivityState.
    /// </summary>
    [Table("eme.EquipmentActivityState")]
    public partial class EquipmentActivityState
    {
        /// <summary>
        /// Gets or sets the equipment activity state identifier.
        /// </summary>
        /// <value>
        /// The equipment activity state identifier.
        /// </value>
        public int EquipmentActivityStateId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public int EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the activity state identifier.
        /// </summary>
        /// <value>
        /// The activity state identifier.
        /// </value>
        public int ActivityStateId { get; set; }

        /// <summary>
        /// Gets or sets the activity state reason identifier.
        /// </summary>
        /// <value>
        /// The activity state reason identifier.
        /// </value>
        public int? ActivityStateReasonId { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        [StringLength(500)]
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity.
        /// </summary>
        /// <value>
        /// The equipment activity.
        /// </value>
        public virtual EquipmentActivity EquipmentActivity { get; set; }
    }
}