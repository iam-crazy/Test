//-----------------------------------------------------------------------
// <copyright file = "ReferentialValidationRule.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialValidationRule.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare ReferentialValidationRule.
    /// </summary>
    [Table("eme.ReferentialValidationRule")]
    public partial class ReferentialValidationRule
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReferentialValidationRule"/> class.
        /// </summary>
        public ReferentialValidationRule()
        {
        }

        /// <summary>
        /// Gets or sets the referential validation rule identifier.
        /// </summary>
        /// <value>
        /// The referential validation rule identifier.
        /// </value>
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public short ReferentialValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>
        public short ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the effective date.
        /// </summary>
        /// <value>
        /// The effective date.
        /// </value>
        [Column("EffectiveFrom")]
        public DateTime EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets the effective to.
        /// </summary>
        /// <value>
        /// The effective to.
        /// </value>
        public DateTime? EffectiveTo { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the activity referential.
        /// </summary>
        /// <value>
        /// The activity referential.
        /// </value>
        public virtual ActivityReferential ActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the validation rule.
        /// </summary>
        /// <value>
        /// The validation rule.
        /// </value>
        public virtual ValidationRule ValidationRule { get; set; }
    }
}