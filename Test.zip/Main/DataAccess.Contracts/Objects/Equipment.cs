//-----------------------------------------------------------------------
// <copyright file = "Equipment.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>Declare TimelineRepository.</summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Defines the Equipment.
    /// </summary>
    [Table("eme.Equipment")]
    public partial class Equipment
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Equipment"/> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "DoNotCallOverridableMethodsInConstructors")]
        public Equipment()
        {
            this.EquipmentDetail = new HashSet<Equipment>();
            this.EquipmentActivities = new HashSet<EquipmentActivity>();
            this.EquipmentNotes = new HashSet<EquipmentNote>();
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment2.
        /// </summary>
        /// <value>
        /// The equipment2.
        /// </value>
        public virtual Equipment Equipment2 { get; set; }

        /// <summary>
        /// Gets or sets the equipment activities.
        /// </summary>
        /// <value>
        /// The equipment activities.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EquipmentActivity> EquipmentActivities { get; set; }

        /// <summary>
        /// Gets or sets the equipment detail.
        /// </summary>
        /// <value>
        /// The equipment detail.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Equipment> EquipmentDetail { get; set; }

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the equipment iso identifier.
        /// </summary>
        /// <value>
        /// The equipment iso identifier.
        /// </value>
        [Column("EquipmentSizeTypeCodeId")]
        public short EquipmentISOId { get; set; }

        /// <summary>
        /// Gets or sets the equipment notes.
        /// </summary>
        /// <value>
        /// The equipment notes.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EquipmentNote> EquipmentNotes { get; set; }

        /// <summary>
        /// Gets or sets the equipment number.
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        [Required]
        [StringLength(15)]
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the equipment size type identifier.
        /// </summary>
        /// <value>
        /// The equipment size type identifier.
        /// </value>
        public short EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has soc.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has soc; otherwise, <c>false</c>.
        /// </value>
        [Column("IsSoc")]
        public bool HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the is cancelled.
        /// </summary>
        /// <value>
        /// The is cancelled.
        /// </value>
        [Column("IsCancelled")]
        public bool? IsCanceled { get; set; }

        /// <summary>
        /// Gets or sets the parent equipment identifier.
        /// </summary>
        /// <value>
        /// The parent equipment identifier.
        /// </value>
        public long? ParentEquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the valid from.
        /// </summary>
        /// <value>
        /// The valid from.
        /// </value>
        public DateTimeOffset ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to.
        /// </summary>
        /// <value>
        /// The valid to.
        /// </value>
        public DateTimeOffset? ValidTo { get; set; }

        #endregion Properties
    }
}