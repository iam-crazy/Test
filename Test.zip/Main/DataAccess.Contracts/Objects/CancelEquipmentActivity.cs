//-----------------------------------------------------------------------
// <copyright file = "CancelEquipmentActivity.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare CancelEquipmentActivity.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare CancelEquipmentActivity.
    /// </summary>
    [Table("eme.CancelEquipmentActivity")]
    public partial class CancelEquipmentActivity
    {
        /// <summary>
        /// Gets or sets the cancel equipment activity identifier.
        /// </summary>
        /// <value>
        /// The cancel equipment activity identifier.
        /// </value>
        public int CancelEquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>          
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity cancel reason identifier.
        /// </summary>
        /// <value>
        /// The equipment activity cancel reason identifier.
        /// </value>
        public int EquipmentActivityCancelReasonId { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        [StringLength(500)]
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity.
        /// </summary>
        /// <value>
        /// The equipment activity.
        /// </value>
        public virtual EquipmentActivity EquipmentActivity { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity cancel reason.
        /// </summary>
        /// <value>
        /// The equipment activity cancel reason.
        /// </value>
        public virtual EquipmentActivityCancelReason EquipmentActivityCancelReason { get; set; }
    }
}