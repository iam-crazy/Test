//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityError.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityError.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare EquipmentActivityError.
    /// </summary>
    [Table("eme.EquipmentActivityError")]
    public partial class EquipmentActivityError
    {
        /// <summary>
        /// Gets or sets the equipment activity error identifier.
        /// </summary>
        /// <value>
        /// The equipment activity error identifier.
        /// </value> 
        public int EquipmentActivityErrorId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value> 
        public short ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity status identifier.
        /// </summary>
        /// <value>
        /// The equipment activity status identifier.
        /// </value>
        public int EquipmentActivityStatusId { get; set; }

        /// <summary>
        /// Gets or sets the error description.
        /// </summary>
        /// <value>
        /// The error description.
        /// </value>
        [StringLength(500)]
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity.
        /// </summary>
        /// <value>
        /// The equipment activity.
        /// </value>
        public virtual EquipmentActivity EquipmentActivity { get; set; }

        /// <summary>
        /// Gets or sets the validation rule.
        /// </summary>
        /// <value>
        /// The validation rule.
        /// </value>
        public virtual ValidationRule ValidationRule { get; set; }
    }
}