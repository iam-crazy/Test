//-----------------------------------------------------------------------
// <copyright file = "RequirementGroup.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementGroup.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    /// <summary>
    /// Declare RequirementGroup.
    /// </summary>
    [Table("eme.RequirementGroup")]
    public partial class RequirementGroup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementGroup"/> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "DoNotCallOverridableMethodsInConstructors")]
        public RequirementGroup()
        {
            this.RequirementFields = new HashSet<RequirementField>();
        }

        /// <summary>
        /// Gets or sets the requirement group identifier.
        /// </summary>
        /// <value>
        /// The requirement group identifier.
        /// </value>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("RequirementGroupId")]
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        [Required]
        [StringLength(10)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Required]
        [StringLength(50)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the requirement fields.
        /// </summary>
        /// <value>
        /// The requirement fields.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "ReadOnly")]
        public virtual ICollection<RequirementField> RequirementFields { get; set; }
    }
}