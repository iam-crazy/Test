//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityCancelReason.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityCancelReason.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare EquipmentActivityCancelReason.
    /// </summary>
    [Table("eme.EquipmentActivityCancelReason")]
    public partial class EquipmentActivityCancelReason
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivityCancelReason"/> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "DoNotCallOverridableMethodsInConstructors")]
        public EquipmentActivityCancelReason()
        {
            this.CancelEquipmentActivities = new HashSet<EquipmentActivity>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the cancel equipment activities.
        /// </summary>
        /// <value>
        /// The cancel equipment activities.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EquipmentActivity> CancelEquipmentActivities { get; set; }

        /// <summary>
        /// Gets or sets the Code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        [Required]
        [StringLength(10)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the CreatedOn.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentActivityCancelReasonId.
        /// </summary>
        /// <value>
        /// The equipment activity cancel reason identifier.
        /// </value>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public byte EquipmentActivityCancelReasonId { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedBy.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedOn.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        #endregion
    }
}
