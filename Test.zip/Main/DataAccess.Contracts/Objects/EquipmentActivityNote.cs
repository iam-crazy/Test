//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityNote.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>Declare EquipmentActivityNote.</summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Defines the <see cref="EquipmentActivityNote" />
    /// </summary>
    [Table("eme.EquipmentActivityNotes")]
    public partial class EquipmentActivityNote
    {
        #region Properties

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity.
        /// </summary>
        /// <value>
        /// The equipment activity.
        /// </value>
        public virtual EquipmentActivity EquipmentActivity { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [Key]
        [Column("EquipmentActivityNotesId")]
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes value.
        /// </value>
        [Required]
        [StringLength(2000)]
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        [Column("CreatedBy")]
        public int UserId { get; set; }

        #endregion
    }
}
