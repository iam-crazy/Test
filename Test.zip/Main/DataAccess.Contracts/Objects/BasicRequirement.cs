//-----------------------------------------------------------------------
// <copyright file = "BasicRequirement.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare BasicRequirement.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare BasicRequirement.
    /// </summary>
    [Table("eme.BasicRequirement")]
    public partial class BasicRequirement
    {
        /// <summary>
        /// Gets or sets the basic requirement identifier.
        /// </summary>
        /// <value>
        /// The basic requirement identifier.
        /// </value>
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int BasicRequirementId { get; set; }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the requirement field identifier.
        /// </summary>
        /// <value>
        /// The requirement field identifier.
        /// </value>
        public byte RequirementFieldId { get; set; }

        /// <summary>
        /// Gets or sets the requirement usage identifier.
        /// </summary>
        /// <value>
        /// The requirement usage identifier.
        /// </value>
        public byte RequirementUsageId { get; set; }

        /// <summary>
        /// Gets or sets the requirement field id2.
        /// </summary>
        /// <value>
        /// The requirement field id2.
        /// </value>
        [Column("RequirementFieldId2")]
        public byte? RequirementFieldIdTwo { get; set; }

        /// <summary>
        /// Gets or sets the requirement field id3.
        /// </summary>
        /// <value>
        /// The requirement field id3.
        /// </value>
        [Column("RequirementFieldId3")]
        public byte? RequirementFieldIdThree { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the activity referential.
        /// </summary>
        /// <value>
        /// The activity referential.
        /// </value>
        public virtual ActivityReferential ActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the requirement field.
        /// </summary>
        /// <value>
        /// The requirement field.
        /// </value>
        public virtual RequirementField RequirementField { get; set; }

        /// <summary>
        /// Gets or sets the requirement field two.
        /// </summary>
        /// <value>
        /// The requirement field two.
        /// </value>
        [Column("RequirementField2")]
        public virtual RequirementField RequirementFieldTwo { get; set; }

        /// <summary>
        /// Gets or sets the requirement field three.
        /// </summary>
        /// <value>
        /// The requirement field three.
        /// </value>
        [Column("RequirementField3")]
        public virtual RequirementField RequirementFieldThree { get; set; }

        /// <summary>
        /// Gets or sets the requirement usage.
        /// </summary>
        /// <value>
        /// The requirement usage.
        /// </value>
        public virtual RequirementUsage RequirementUsage { get; set; }

        /// <summary>
        /// Gets or sets the row status.
        /// </summary>
        /// <value>
        /// The row status.
        /// </value>
        [NotMapped]
        public string RowStatus { get; set; }
    }
}