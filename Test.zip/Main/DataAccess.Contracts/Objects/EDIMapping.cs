//-----------------------------------------------------------------------
// <copyright file = "EDIMapping.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EDIMapping.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare EDIMapping.
    /// </summary>
    [Table("eme.EDIMapping")]
    public partial class EDIMapping
    {
        /// <summary>
        /// Gets or sets the edi mapping identifier.
        /// </summary>
        /// <value>
        /// The edi mapping identifier.
        /// </value>
        public short EDIMappingId { get; set; }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the shipment status identifier.
        /// </summary>
        /// <value>
        /// The shipment status identifier.
        /// </value>
        public byte? ShipmentStatusId { get; set; }

        /// <summary>
        /// Gets or sets the equipment status identifier.
        /// </summary>
        /// <value>
        /// The equipment status identifier.
        /// </value>
        public byte? EquipmentStatusId { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the activity referential.
        /// </summary>
        /// <value>
        /// The activity referential.
        /// </value>
        public virtual ActivityReferential ActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the equipment status.
        /// </summary>
        /// <value>
        /// The equipment status.
        /// </value>
        public virtual EquipmentStatus EquipmentState { get; set; }

        /// <summary>
        /// Gets or sets the shipment status.
        /// </summary>
        /// <value>
        /// The shipment status.
        /// </value>
        public virtual ShipmentStatus ShipmentStatus { get; set; }
    }
}