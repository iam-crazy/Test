//-----------------------------------------------------------------------
// <copyright file = "LogicalActivity.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalActivity.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using Msc.Logistics.EME.Service.DataAccess.Contracts.Constants;

    /// <summary>
    /// Declare LogicalActivity.
    /// </summary>
    [Table("eme.LogicalActivity")]
    public partial class LogicalActivity
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalActivity"/> class.
        /// </summary>
        public LogicalActivity()
        {
        }

        #endregion Constructor

        /// <summary>
        /// Gets or sets the logical activity identifier.
        /// </summary>
        /// <value>
        /// The logical activity identifier.
        /// </value>
        public int LogicalActivityId { get; set; }

        /// <summary>
        /// Gets or sets from activity referential identifier.
        /// </summary>
        /// <value>
        /// From activity referential identifier.
        /// </value>
        [Column("ActivityReferentialIdPrevious")]
        public short FromActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets to activity referential identifier.
        /// </summary>
        /// <value>
        /// To activity referential identifier.
        /// </value>
        [Column("ActivityReferentialIdNext")]
        public short ToActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is active; otherwise, <c>false</c>.
        /// </value>
        [Column("IsActive")]
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the type of the activity.
        /// </summary>
        /// <value>
        /// The type of the activity.
        /// </value>
        [StringLength(1)]
        public string ActivityType { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        [StringLength(500)]
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment category identifier.
        /// </summary>
        /// <value>
        /// The equipment category identifier.
        /// </value>
        public int EquipmentCategoryId { get; set; }

        /// <summary>
        /// Gets or sets from activity referential.
        /// </summary>
        /// <value>
        /// From activity referential.
        /// </value>
        public virtual ActivityReferential FromActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets to activity referential.
        /// </summary>
        /// <value>
        /// To activity referential.
        /// </value>
        public virtual ActivityReferential ToActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the row status.
        /// </summary>
        /// <value>
        /// The row status.
        /// </value>
        [NotMapped]
        public string RowStatus { get; set; } = DataAccessContractsConstants.Unchanged;
    }
}