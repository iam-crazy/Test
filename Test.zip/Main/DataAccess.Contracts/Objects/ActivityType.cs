//-----------------------------------------------------------------------
// <copyright file = "ActivityType.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ActivityType.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare ActivityType.
    /// </summary>
    [Table("eme.ActivityType")]
    public partial class ActivityType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityType" /> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "Constructor")]
        public ActivityType()
        {
            ////this.ActivityReferentials = new HashSet<ActivityReferential>();
        }

        /// <summary>
        /// Gets or sets the activity type identifier.
        /// </summary>
        /// <value>
        /// The activity type identifier.
        /// </value>
        [Column("ActivityTypeId")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The activity type code.
        /// </value>
        [Required]
        [StringLength(10)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the activity referential.
        /// </summary>
        /// <value>
        /// The activity referential.
        /// </value>
        ////[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "Readonly")]
        ////public virtual ICollection<ActivityReferential> ActivityReferentials { get; set; }
    }
}