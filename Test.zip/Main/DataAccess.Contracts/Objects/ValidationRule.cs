//-----------------------------------------------------------------------
// <copyright file = "ValidationRule.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRule.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare ValidationRule.
    /// </summary>
    [Table("eme.ValidationRule")]
    public partial class ValidationRule
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRule" /> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "Constructor")]
        public ValidationRule()
        {
            this.EquipmentActivityErrors = new HashSet<EquipmentActivityError>();
            this.ReferentialValidationRules = new HashSet<ReferentialValidationRule>();
        }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>  
        public short ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the rule number.
        /// </summary>
        /// <value>
        /// The rule number.
        /// </value>
        [Required]
        [StringLength(10)]
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the validation rule group identifier.
        /// </summary>
        /// <value>
        /// The validation rule group identifier.
        /// </value> 
        public byte ValidationRuleGroupId { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Required]
        [StringLength(200)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the valid from.
        /// </summary>
        /// <value>
        /// The valid from.
        /// </value>
        public DateTime ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to.
        /// </summary>
        /// <value>
        /// The valid to.
        /// </value>
        public DateTime? ValidTo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is active; otherwise, <c>false</c>.
        /// </value>
        [Column("IsActive")]
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the reason for inactive.
        /// </summary>
        /// <value>
        /// The reason for inactive.
        /// </value>
        [StringLength(10)]
        public string ReasonForInactive { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        [StringLength(200)]
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the validation rule type identifier.
        /// </summary>
        /// <value>
        /// The validation rule type identifier.
        /// </value>    
        public byte ValidationRuleTypeId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule error result identifier.
        /// </summary>
        /// <value>
        /// The validation rule error result identifier.
        /// </value>    
        public byte ValidationRuleErrorResultId { get; set; }

        /// <summary>
        /// Gets or sets the error description.
        /// </summary>
        /// <value>
        /// The error description.
        /// </value>
        [Required]
        [StringLength(200)]
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the validation rule error result.
        /// </summary>
        /// <value>
        /// The validation rule error result.
        /// </value>
        public virtual ValidationRuleErrorResult ValidationRuleErrorResult { get; set; }

        /// <summary>
        /// Gets or sets the validation rule group.
        /// </summary>
        /// <value>
        /// The validation rule group.
        /// </value>
        public virtual ValidationRuleGroup ValidationRuleGroup { get; set; }

        /// <summary>
        /// Gets or sets the type of the validation rule.
        /// </summary>
        /// <value>
        /// The type of the validation rule.
        /// </value>
        public virtual ValidationRuleType ValidationRuleType { get; set; }

        /// <summary>
        /// Gets or sets the referential validation rules.
        /// </summary>
        /// <value>
        /// The referential validation rules.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "Readonly")]
        public virtual ICollection<ReferentialValidationRule> ReferentialValidationRules { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity errors.
        /// </summary>
        /// <value>
        /// The equipment activity errors.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "Readonly")]
        public virtual ICollection<EquipmentActivityError> EquipmentActivityErrors { get; set; }
    }
}