//-----------------------------------------------------------------------
// <copyright file = "RequirementField.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementField.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare RequirementField.
    /// </summary>
    [Table("eme.RequirementField")]
    public partial class RequirementField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementField"/> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "justification")]
        public RequirementField()
        {
            this.BasicRequirements = new HashSet<BasicRequirement>();
            this.BasicRequirementsTwo = new HashSet<BasicRequirement>();
            this.BasicRequirementsThree = new HashSet<BasicRequirement>();
        }

        /// <summary>
        /// Gets or sets the requirement field identifier.
        /// </summary>
        /// <value>
        /// The requirement field identifier.
        /// </value>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("RequirementFieldId")]
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Required]
        [StringLength(50)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        [Required]
        [StringLength(10)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the requirement group identifier.
        /// </summary>
        /// <value>
        /// The requirement group identifier.
        /// </value>
        public byte RequirementGroupId { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the basic requirements.
        /// </summary>
        /// <value>
        /// The basic requirements.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<BasicRequirement> BasicRequirements { get; set; }

        /// <summary>
        /// Gets or sets the basic requirements2.
        /// </summary>
        /// <value>
        /// The basic requirements2.
        /// </value>
        [Column("BasicRequirements2")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<BasicRequirement> BasicRequirementsTwo { get; set; }

        /// <summary>
        /// Gets or sets the basic requirements3.
        /// </summary>
        /// <value>
        /// The basic requirements3.
        /// </value>
        [Column("BasicRequirements3")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<BasicRequirement> BasicRequirementsThree { get; set; }

        /// <summary>
        /// Gets or sets the requirement group.
        /// </summary>
        /// <value>
        /// The requirement group.
        /// </value>
        public virtual RequirementGroup RequirementGroup { get; set; }
    }
}