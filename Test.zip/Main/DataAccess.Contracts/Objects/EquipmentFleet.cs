﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentFleet.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentFleet. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare EquipmentFleet.
    /// </summary>
    public class EquipmentFleet
    {
        #region Properties

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Column("EquipmentIsoId")]
        public short EquipmentISOId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The equipment code.
        /// </value>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public short EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is SOC.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is SOC; otherwise, <c>false</c>.
        /// </value>
        [Column("IsSoc")]
        public bool HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        #endregion
    }
}
