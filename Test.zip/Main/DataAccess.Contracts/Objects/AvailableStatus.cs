﻿//-----------------------------------------------------------------------
// <copyright file = "AvailableStatus.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare AvailableStatus. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare AvailableStatus.
    /// </summary>
    public class AvailableStatus
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance is sequence.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is sequence; otherwise, <c>false</c>.
        /// </value>
        public bool IsSequence { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is combination.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is combination; otherwise, <c>false</c>.
        /// </value>
        public bool IsCombination { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is logical.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is logical; otherwise, <c>false</c>.
        /// </value>
        public bool IsLogical { get; set; }
    }
}