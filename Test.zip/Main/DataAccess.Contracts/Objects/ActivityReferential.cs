//-----------------------------------------------------------------------
// <copyright file = "ActivityReferential.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ActivityReferential.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Objects
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare ActivityReferential.
    /// </summary>
    [Table("eme.ActivityReferential")]
    public partial class ActivityReferential
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityReferential" /> class.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "justification")]
        public ActivityReferential()
        {
            this.BasicRequirements = new HashSet<BasicRequirement>();
            this.EDIMappings = new HashSet<EDIMapping>();
            this.EquipmentActivities = new HashSet<EquipmentActivity>();
            this.FromLogicalActivities = new HashSet<LogicalActivity>();
            this.ToLogicalActivities = new HashSet<LogicalActivity>();
            this.ReferentialValidationRules = new HashSet<ReferentialValidationRule>();
        }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The activity referential code.
        /// </value>
        [Required]
        [StringLength(5)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [Required]
        [StringLength(240)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the business cycle identifier.
        /// </summary>
        /// <value>
        /// The business cycle identifier.
        /// </value>
        public byte? BusinessCycleId { get; set; }

        /// <summary>
        /// Gets or sets the activity type identifier.
        /// </summary>
        /// <value>
        /// The activity type identifier.
        /// </value>
        public byte ActivityTypeId { get; set; }

        /// <summary>
        /// Gets or sets the equipment status identifier.
        /// </summary>
        /// <value>
        /// The equipment status identifier.
        /// </value>
        public byte FullEmptyId { get; set; }

        /// <summary>
        /// Gets or sets the activity action identifier.
        /// </summary>
        /// <value>
        /// The activity action identifier.
        /// </value>
        public byte ActivityActionId { get; set; }

        /// <summary>
        /// Gets or sets the activity location identifier.
        /// </summary>
        /// <value>
        /// The activity location identifier.
        /// </value>
        [Column("TakePlaceAtId")]
        public byte ActivityLocationId { get; set; }

        /// <summary>
        /// Gets or sets the activity category identifier.
        /// </summary>
        /// <value>
        /// The activity category identifier.
        /// </value>
        public byte? ActivityCategoryId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> If this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is display to customer.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is display to customer; otherwise, <c>false</c>.
        /// </value>
        public bool IsDisplayToCustomer { get; set; }

        /// <summary>
        /// Gets or sets the glossary.
        /// </summary>
        /// <value>
        /// The glossary.
        /// </value>
        [StringLength(2000)]
        public string Glossary { get; set; }

        /// <summary>
        /// Gets or sets the reason for inactive.
        /// </summary>
        /// <value>
        /// The reason for inactive.
        /// </value>
        [StringLength(10)]
        public string ReasonForInactive { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        [StringLength(2000)]
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        [Column(TypeName = "datetime2")]
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the type of the activity.
        /// </summary>
        /// <value>
        /// The type of the activity.
        /// </value>
        public virtual ActivityType ActivityType { get; set; }

        /// <summary>
        /// Gets or sets the equipment status.
        /// </summary>
        /// <value>
        /// The equipment status.
        /// </value>
        public virtual FullEmpty FullEmpty { get; set; }

        /// <summary>
        /// Gets or sets the activity action.
        /// </summary>
        /// <value>
        /// The activity action.
        /// </value>
        public virtual ActivityAction ActivityAction { get; set; }

        /// <summary>
        /// Gets or sets the activity category.
        /// </summary>
        /// <value>
        /// The activity category.
        /// </value>
        public virtual ActivityCategory ActivityCategory { get; set; }

        /// <summary>
        /// Gets or sets the activity location.
        /// </summary>
        /// <value>
        /// The activity location.
        /// </value>
        public virtual TakePlaceAt ActivityLocation { get; set; }

        /// <summary>
        /// Gets or sets the basic requirements.
        /// </summary>
        /// <value>
        /// The basic requirements.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<BasicRequirement> BasicRequirements { get; set; }

        /// <summary>
        /// Gets or sets the edi mappings.
        /// </summary>
        /// <value>
        /// The edi mappings.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<EDIMapping> EDIMappings { get; set; }

        /// <summary>
        /// Gets or sets the equipment activities.
        /// </summary>
        /// <value>
        /// The equipment activities.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<EquipmentActivity> EquipmentActivities { get; set; }

        /// <summary>
        /// Gets or sets from logical activities.
        /// </summary>
        /// <value>
        /// From logical activities.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<LogicalActivity> FromLogicalActivities { get; set; }

        /// <summary>
        /// Gets or sets to logical activities.
        /// </summary>
        /// <value>
        /// To logical activities.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<LogicalActivity> ToLogicalActivities { get; set; }

        /// <summary>
        /// Gets or sets the referential validation rules.
        /// </summary>
        /// <value>
        /// The referential validation rules.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "justification")]
        public virtual ICollection<ReferentialValidationRule> ReferentialValidationRules { get; set; }

        /// <summary>
        /// Gets or sets the business cycle.
        /// </summary>
        /// <value>
        /// The business cycle.
        /// </value>
        public virtual BusinessCycle BusinessCycle { get; set; }
    }
}