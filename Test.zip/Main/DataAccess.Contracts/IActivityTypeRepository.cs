﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityTypeRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityTypeRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IActivityTypeRepository.
    /// </summary>
    public interface IActivityTypeRepository
    {
        /// <summary>
        /// Gets the ActivityType.
        /// </summary>
        /// <returns>Returns ActivityType Lists.</returns>
        Task<IList<ActivityType>> GetActivityTypes();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        void Save(ActivityType data);

        /// <summary>
        /// Deletes the specified activity type identifier.
        /// </summary>
        /// <param name="activityTypeId">The activity type identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int activityTypeId);
    }
}