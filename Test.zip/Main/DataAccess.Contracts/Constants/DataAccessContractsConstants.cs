﻿//-----------------------------------------------------------------------
// <copyright file = "DataAccessContractsConstants.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare DataAccessContractsConstants. </summary>
//---
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Constants
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare DataAccessContractsConstants.
    /// </summary>
    public static class DataAccessContractsConstants
    {
        /// <summary>
        /// The added.
        /// </summary>
        public const string Added = "A";

        /// <summary>
        /// The modified.
        /// </summary>
        public const string Modified = "U";

        /// <summary>
        /// The deleted.
        /// </summary>
        public const string Deleted = "D";

        /// <summary>
        /// The unchanged.
        /// </summary>
        public const string Unchanged = "UC";

        /// <summary>
        /// The string cancel.
        /// </summary>
        public const string Cancel = "C";
    }
}