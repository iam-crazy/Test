﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentStatusRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentStatusRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Equipment Status Repository.
    /// </summary>
    public interface IEquipmentStatusRepository
    {
        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <returns>Returns The EquipmentStatus Data.</returns>
        Task<IList<EquipmentStatus>> GetEquipmentStatus();

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentStatusData">The equipment status data.</param>
        void Save(EquipmentStatus equipmentStatusData);

        /// <summary>
        /// Deletes the specified equipment status identifier.
        /// </summary>
        /// <param name="equipmentStatusId">The equipment status identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int equipmentStatusId);
    }
}