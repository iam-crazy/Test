﻿//-----------------------------------------------------------------------
// <copyright file = "IShipmentRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IShipmentRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Shipment Repository.
    /// </summary>
    public interface IShipmentRepository
    {
        /// <summary>
        /// Gets the shipment status.
        /// </summary>
        /// <param name="shipmentCodes">The shipment codes.</param>
        /// <returns>
        /// Returns The Shipment Status.
        /// </returns>
        Task<IList<ShipmentStatus>> GetShipmentStatus(string shipmentCodes);

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="shipmentStatusData">The shipmentStatusData.</param>
        void Save(ShipmentStatus shipmentStatusData);

        /// <summary>
        /// Deletes the specified shipment status identifier.
        /// </summary>
        /// <param name="shipmentStatusId">The shipment status identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int shipmentStatusId);
    }
}