﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataSpecification.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataSpecification.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Specifications
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using Framework.Service.DataAccess;
    using Objects;

    /// <summary>
    /// Declare ReferentialDataSpecification.
    /// </summary>
    public static class ReferentialDataSpecification
    {
        /// <summary>
        /// Bies the search request.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="activities">The activities.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="fullEmpty">The full empty.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="location">The location.</param>
        /// <param name="requirementFields">The requirement fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The status.</param>
        /// <param name="isMapped">The is mapped.</param>
        /// <param name="businessCycle">The business cycle.</param>
        /// <returns>Returns Specification for Activity.</returns>
        public static IList<ISpecification<ActivityReferential>> BySearchRequest(int? action, IEnumerable<int> activities, int? activityType, IEnumerable<int> category, int? equipmentStatus, int? fullEmpty, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, int? location, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, bool? isMapped, int? businessCycle)
        {
            IList<ISpecification<ActivityReferential>> specfications = ByGetRequest(action, activities, activityType, category, equipmentStatus, fullEmpty, groupCode, isDisplayToCustomer, isValidationRuleActive, location, requirementFields, requirementUsage, shipmentStatus, validationRule, status, businessCycle);
            if (isMapped.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.EDIMappings.Any() == isMapped.Value));
            }

            return specfications;
        }

        /// <summary>
        /// Bies the search request.
        /// </summary>
        /// <returns>Returns Specification for Activity.</returns>
        public static IList<ISpecification<ActivityReferential>> BySearchRequest()
        {
            var specfications = new List<ISpecification<ActivityReferential>>();
            ////specfications.Add(new Specification<ActivityReferential>(m => m.EDIMappings.Any()));
            return specfications;
        }

        /// <summary>
        /// Bies the get request.
        /// </summary>
        /// <param name="action">The action parameter.</param>
        /// <param name="activities">The activities.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category parameter.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="fullEmpty">The full empty.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="location">The location.</param>
        /// <param name="requirementFields">The requirement fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The status parameter.</param>
        /// <param name="businessCycle">The business cycle.</param>
        /// <returns>Returns the Activity Referential.</returns>
        public static IList<ISpecification<ActivityReferential>> ByGetRequest(int? action, IEnumerable<int> activities, int? activityType, IEnumerable<int> category, int? equipmentStatus, int? fullEmpty, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, int? location, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, int? businessCycle)
        {
            var specfications = new List<ISpecification<ActivityReferential>>();

            if (action.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.ActivityActionId == action));
            }

            if (activities != null && activities.Any())
            {
                specfications.Add(new Specification<ActivityReferential>(m => activities.Any(s => s == m.ActivityReferentialId)));
            }

            if (fullEmpty.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.FullEmptyId == fullEmpty));
            }

            if (location.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.ActivityLocationId == location));
            }

            if (businessCycle.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.BusinessCycleId == businessCycle));
            }

            GetRequestStatus(activityType, category, equipmentStatus, groupCode, isDisplayToCustomer, isValidationRuleActive, requirementFields, requirementUsage, shipmentStatus, validationRule, status, specfications);

            return specfications;
        }

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="description">The description.</param>
        /// <param name="status">The referential status.</param>
        /// <returns>Returns BySearchRequest.</returns>
        public static IList<ISpecification<ActivityReferential>> BySearchRequest(string description, string status)
        {
            var specfications = new List<ISpecification<ActivityReferential>>();

            if (status != null)
            {
                bool isActive = true;
                specfications.Add(new Specification<ActivityReferential>(m => m.IsActive == isActive));
            }

            if (!string.IsNullOrEmpty(description))
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.Description.Contains(description)));
            }

            return specfications;
        }

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <returns>Returns Activity Detail.</returns>
        public static List<ISpecification<ActivityReferential>> BySearchRequest(int activityId)
        {
            var specifications = new List<ISpecification<ActivityReferential>>();
            specifications.Add(new Specification<ActivityReferential>(m => m.ActivityReferentialId == activityId));
            return specifications;
        }

        /// <summary>
        /// Bies the search validation identifier.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Return List of Referential Validation Rule.</returns>
        public static List<ISpecification<ReferentialValidationRule>> BySearchValidationId(int validationRuleId)
        {
            var specifications = new List<ISpecification<ReferentialValidationRule>>();
            specifications.Add(new Specification<ReferentialValidationRule>(m => m.ValidationRuleId == validationRuleId));
            return specifications;
        }

        /// <summary>
        /// With the header detail only.
        /// </summary>
        /// <returns>Returns Activity Detail.</returns>
        public static Expression<Func<ActivityReferential, object>>[] WithHeaderDetailOnly()
        {
            IList<Expression<Func<ActivityReferential, object>>> expressions = new List<Expression<Func<ActivityReferential, object>>>();
            CommonExpressions(expressions);
            
            expressions.Add(em => em.EDIMappings);
            return expressions.ToArray();
        }

        /// <summary>
        /// Withes the detail.
        /// </summary>
        /// <returns>Returns Activity Detail.</returns>
        public static Expression<Func<ActivityReferential, object>>[] WithDetail()
        {
            IList<Expression<Func<ActivityReferential, object>>> expressions = new List<Expression<Func<ActivityReferential, object>>>();

            CommonExpressions(expressions);

            expressions.Add(br => br.BasicRequirements);
            expressions.Add(br => br.BasicRequirements.Select(rf => rf.RequirementField.RequirementGroup));
            expressions.Add(br => br.BasicRequirements.Select(rf => rf.RequirementFieldTwo.RequirementGroup));
            expressions.Add(br => br.BasicRequirements.Select(rf => rf.RequirementFieldThree.RequirementGroup));
            expressions.Add(br => br.BasicRequirements.Select(ru => ru.RequirementUsage));

            expressions.Add(vr => vr.ReferentialValidationRules);
            expressions.Add(vr => vr.ReferentialValidationRules.Select(v => v.ValidationRule.ValidationRuleGroup));

            expressions.Add(em => em.EDIMappings);
            expressions.Add(em => em.EDIMappings.Select(es => es.EquipmentState));
            expressions.Add(em => em.EDIMappings.Select(ss => ss.ShipmentStatus));

            return expressions.ToArray();
        }

        /// <summary>
        /// Withes the only referential validation rule detail.
        /// </summary>
        /// <returns>Returns the referential.</returns>
        public static Expression<Func<ReferentialValidationRule, object>>[] WithOnlyReferentialValidationRuleDetail()
        {
            IList<Expression<Func<ReferentialValidationRule, object>>> expression = new List<Expression<Func<ReferentialValidationRule, object>>>();
            return expression.ToArray();
        }

        /// <summary>
        /// Commons the expressions.
        /// </summary>
        /// <param name="expressions">The expressions.</param>
        private static void CommonExpressions(IList<Expression<Func<ActivityReferential, object>>> expressions)
        {
            expressions.Add(at => at.ActivityType);
            expressions.Add(fe => fe.FullEmpty);
            expressions.Add(aa => aa.ActivityAction);
            expressions.Add(al => al.ActivityLocation);
            expressions.Add(ac => ac.ActivityCategory);
           expressions.Add(bc => bc.BusinessCycle);
        }

        /// <summary>
        /// Gets the request status.
        /// </summary>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="requirementFields">The requirement fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The status.</param>
        /// <param name="specfications">The specfications.</param>
        private static void GetRequestStatus(int? activityType, IEnumerable<int> category, int? equipmentStatus, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, List<ISpecification<ActivityReferential>> specfications)
        {
            if (category != null && category.Any())
            {
                specfications.Add(new Specification<ActivityReferential>(m => category.Any(s => s == m.ActivityCategoryId)));
            }

            if (activityType.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.ActivityTypeId == activityType));
            }

            if (groupCode.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.ReferentialValidationRules.Any(s => s.ValidationRule.ValidationRuleGroupId == groupCode)));
            }

            if (status.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.IsActive == status.Value));
            }

            if (validationRule.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.ReferentialValidationRules.Any(s => s.ValidationRuleId == validationRule)));
            }

            if (requirementFields != null && requirementFields.Any())
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.BasicRequirements.Any(s => requirementFields.Any(a => a == s.RequirementFieldId) || requirementFields.Any(a => a == s.RequirementFieldIdTwo) || requirementFields.Any(a => a == s.RequirementFieldIdThree))));
            }

            if (requirementUsage.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.BasicRequirements.Any(s => s.RequirementUsageId == requirementUsage)));
            }

            if (isValidationRuleActive.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.ReferentialValidationRules.Any(s => s.ValidationRule.Status == isValidationRuleActive.Value)));
            }

            if (equipmentStatus.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.EDIMappings.Any(s => s.EquipmentStatusId == equipmentStatus)));
            }

            if (shipmentStatus != null && shipmentStatus.Any())
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.EDIMappings.Any(s => shipmentStatus.Any(a => a == s.ShipmentStatusId))));
            }

            if (isDisplayToCustomer.HasValue)
            {
                specfications.Add(new Specification<ActivityReferential>(m => m.IsDisplayToCustomer == isDisplayToCustomer.Value));
            }
        }
    }
}