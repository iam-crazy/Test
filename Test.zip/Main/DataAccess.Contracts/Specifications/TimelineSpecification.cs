﻿//-----------------------------------------------------------------------
// <copyright file = "TimelineSpecification.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare TimelineSpecification.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Specifications
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using Constants;
    using Framework.Service.DataAccess;
    using Objects;

    /// <summary>
    /// Declare TimelineSpecification.
    /// </summary>
    public static class TimelineSpecification
    {
        #region Public Methods

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="equipmentIds">The identifier.</param>
        /// <param name="showCancel">The show Cancel number.</param>
        /// <returns>Returns Equipment Activity.</returns>
        public static List<ISpecification<EquipmentActivity>> BySearchRequest(IList<long> equipmentIds, bool showCancel)
        {
            var specifications = new List<ISpecification<EquipmentActivity>>();
            if (equipmentIds != null && equipmentIds.Count > 0)
            {
                specifications.Add(new Specification<EquipmentActivity>(m => equipmentIds.Any(s => s == m.EquipmentId)));
            }

            if (showCancel)
            {
                specifications.Add(new Specification<EquipmentActivity>(m => (m.EquipmentActivityState == DataAccessContractsConstants.Cancel) == showCancel));
            }

            return specifications;
        }

        /// <summary>
        /// With the detail.
        /// </summary>
        /// <returns>Returns The Data.</returns>
        public static Expression<Func<EquipmentActivity, object>>[] WithDetail()
        {
            IList<Expression<Func<EquipmentActivity, object>>> expressions = new List<Expression<Func<EquipmentActivity, object>>>();
            expressions.Add(af => af.Activity);
            expressions.Add(af => af.Activity.ActivityType);
            expressions.Add(af => af.EquipmentState);
            expressions.Add(af => af.Equipment);
            expressions.Add(ee => ee.EquipmentActivityErrors.Select(x => x.ValidationRule.ValidationRuleErrorResult));
            return expressions.ToArray();
        }

        #endregion Public Methods
    }
}