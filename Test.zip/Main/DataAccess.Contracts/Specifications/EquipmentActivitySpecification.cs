﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivitySpecification.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivitySpecification.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Specifications
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Linq.Expressions;
    using Constants;
    using Framework.Service.DataAccess;
    using Objects;

    /// <summary>
    /// Declare EquipmentActivitySpecification.
    /// </summary>
    public static class EquipmentActivitySpecification
    {
        #region Public Methods

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="equipmentActivityId">The equipment Activity Id.</param>
        /// <returns>Returns The Request.</returns>
        public static IList<ISpecification<EquipmentActivity>> BySearchRequest(EquipmentActivityFilter activityFilter, IEnumerable<long> equipmentActivityId)
        {
            return GetSpecificationFromPageRequest(activityFilter, equipmentActivityId);
        }

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns Equipment Activity.</returns>
        public static List<ISpecification<EquipmentActivity>> BySearchRequest(long id, string equipmentNumber)
        {
            var specifications = new List<ISpecification<EquipmentActivity>>();
            if (id > 0)
            {
                specifications.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityId == id));
            }

            if (!string.IsNullOrEmpty(equipmentNumber))
            {
                specifications.Add(new Specification<EquipmentActivity>(m => m.Equipment.EquipmentNumber.Contains(equipmentNumber)));
            }

            return specifications;
        }

        /// <summary>
        /// Duplicates the by search request.
        /// </summary>
        /// <param name="equipmentActivity">The equipment activity.</param>
        /// <returns>Returns Equipment Activity.</returns>
        public static List<ISpecification<EquipmentActivity>> DuplicateBySearchRequest(EquipmentActivity equipmentActivity)
        {
            var specifications = new List<ISpecification<EquipmentActivity>>();
            specifications.Add(new Specification<EquipmentActivity>(m => m.ActivityReferentialId == equipmentActivity.ActivityReferentialId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.Equipment.EquipmentNumber == equipmentActivity.Equipment.EquipmentNumber));
            specifications.Add(new Specification<EquipmentActivity>(m => DbFunctions.TruncateTime(m.ActivityDateTime) == DbFunctions.TruncateTime(equipmentActivity.ActivityDateTime)));
            specifications.Add(new Specification<EquipmentActivity>(m => m.VesselId == equipmentActivity.VesselId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.LocationId == equipmentActivity.LocationId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.VoyageId == equipmentActivity.VoyageId));
            return specifications;
        }

        /// <summary>
        /// Relevant the by search request.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="terminalId">The terminal identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="voyage">The voyage.</param>
        /// <returns>Returns List Of Equipment Activity.</returns>
        public static List<ISpecification<EquipmentActivity>> RelevantBySearchRequest(int activityId, int locationId, int terminalId, int vesselId, int voyageId, string voyage)
        {
            var specifications = new List<ISpecification<EquipmentActivity>>();
            specifications.Add(new Specification<EquipmentActivity>(m => m.ActivityReferentialId == activityId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.LocationId == locationId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.TerminalEquipmentHandlingFacilityId == terminalId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.VesselId == vesselId));
            specifications.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityState != Constants.DataAccessContractsConstants.Cancel));
            if (voyageId > 0)
            {
                specifications.Add(new Specification<EquipmentActivity>(m => m.VoyageId == voyageId));
            }

            if (!string.IsNullOrEmpty(voyage))
            {
                specifications.Add(new Specification<EquipmentActivity>(m => m.Voyage == voyage));
            }

            return specifications;
        }

        /// <summary>
        /// With the detail.
        /// </summary>
        /// <returns>Returns The Data.</returns>
        public static Expression<Func<EquipmentActivity, object>>[] WithDetail()
        {
            IList<Expression<Func<EquipmentActivity, object>>> expressions = new List<Expression<Func<EquipmentActivity, object>>>();
            expressions.Add(af => af.Activity);
            expressions.Add(af => af.Activity.ActivityType);
            expressions.Add(af => af.EquipmentState);
            expressions.Add(af => af.Equipment);
            expressions.Add(ee => ee.EquipmentActivityErrors.Select(x => x.ValidationRule.ValidationRuleErrorResult));
            return expressions.ToArray();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Advances the activity.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="equipmentActivityIds">The equipment activity ids.</param>
        /// <param name="activitySpecification">The activity specification.</param>
        private static void AdvanceActivity(EquipmentActivityFilter activityFilter, IEnumerable<long> equipmentActivityIds, List<ISpecification<EquipmentActivity>> activitySpecification)
        {
            if (equipmentActivityIds != null && equipmentActivityIds.Any())
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => equipmentActivityIds.Contains((int)m.EquipmentActivityId)));
            } 

            if (activityFilter.Activity.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ActivityReferentialId == activityFilter.Activity));
            }

            if (activityFilter.EquipmentISO.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.Equipment.EquipmentISOId == activityFilter.EquipmentISO));
            }

            if (activityFilter.EquipmentSizeType.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.Equipment.EquipmentSizeTypeId == activityFilter.EquipmentSizeType));
            }
        }

        /// <summary>
        /// Equipment the activity text filter.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="activitySpecification">The activity specification.</param>
        private static void EquipmentActivityTextFilter(EquipmentActivityFilter activityFilter, IList<ISpecification<EquipmentActivity>> activitySpecification)
        {
            if (!string.IsNullOrEmpty(activityFilter.LeasingCompanyReference))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.LeasingCompanyReference == activityFilter.LeasingCompanyReference));
            }

            if (!string.IsNullOrEmpty(activityFilter.ShippingInstructionNumber))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ShippingInstructionNumber == activityFilter.ShippingInstructionNumber));
            }

            if (!string.IsNullOrEmpty(activityFilter.BookingNumber))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.BookingNumber == activityFilter.BookingNumber));
            }

            if (activityFilter.EquipmentId.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.EquipmentId == activityFilter.EquipmentId));
            }

            if (!string.IsNullOrEmpty(activityFilter.BLNumber))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.BLNumber == activityFilter.BLNumber));
            }

            if (!string.IsNullOrEmpty(activityFilter.MSCAuthorizationReference))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.MSCAuthorizationReference == activityFilter.MSCAuthorizationReference));
            }

            if (!string.IsNullOrEmpty(activityFilter.SealNumber))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.SealNumber == activityFilter.SealNumber));
            }

            if (activityFilter.SCACCode.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.SCACCodeId == activityFilter.SCACCode));
            }

            if (!string.IsNullOrEmpty(activityFilter.PickupReference))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.PickupReference == activityFilter.PickupReference));
            }

            if (!string.IsNullOrEmpty(activityFilter.ReturnEquipmentAuthorizationNumber))
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ReturnEquipmentAuthorizationNumber == activityFilter.ReturnEquipmentAuthorizationNumber));
            }
        }

        /// <summary>
        /// Gets the specification from page request.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="equipmentActivityIds">The equipment Activity Id.</param>
        /// <returns>Returns The List.</returns>
        private static IList<ISpecification<EquipmentActivity>> GetSpecificationFromPageRequest(EquipmentActivityFilter activityFilter, IEnumerable<long> equipmentActivityIds)
        {
            var activitySpecification = new List<ISpecification<EquipmentActivity>>();
            if (equipmentActivityIds != null && equipmentActivityIds.Any())
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => equipmentActivityIds.Contains((int)m.EquipmentActivityId)));
            }
            else
            {
                LocationFilter(activityFilter, activitySpecification);
                PortFilter(activityFilter, activitySpecification);
                TerminalDepotFilter(activityFilter, activitySpecification);
                EquipmentActivityTextFilter(activityFilter, activitySpecification);
                AdvanceActivity(activityFilter, equipmentActivityIds, activitySpecification);

                if (activityFilter.FromDate.HasValue)
                {
                    activityFilter.ToDate = activityFilter.ToDate.HasValue ? activityFilter.ToDate : DateTime.Now;
                    if (!activityFilter.DateType.HasValue)
                    {
                        DateTime fromDate = activityFilter.FromDate.Value.ToUniversalTime();
                        DateTime toDate = activityFilter.ToDate.Value.ToUniversalTime();
                        activitySpecification.Add(new Specification<EquipmentActivity>(m => DbFunctions.TruncateTime(m.ActivityUTCDateTime) >= DbFunctions.TruncateTime(fromDate) && DbFunctions.TruncateTime(m.ActivityUTCDateTime) <= DbFunctions.TruncateTime(toDate)));
                    }
                    else if (activityFilter.DateType.Value)
                    {
                        activitySpecification.Add(new Specification<EquipmentActivity>(m => DbFunctions.TruncateTime(m.ActivityDateTime) >= DbFunctions.TruncateTime(activityFilter.FromDate) && DbFunctions.TruncateTime(m.ActivityDateTime) <= DbFunctions.TruncateTime(activityFilter.ToDate)));
                    }
                    else
                    {
                        activitySpecification.Add(new Specification<EquipmentActivity>(m => DbFunctions.TruncateTime(m.Equipment.CreatedOn) >= DbFunctions.TruncateTime(activityFilter.FromDate) && DbFunctions.TruncateTime(m.Equipment.CreatedOn) <= DbFunctions.TruncateTime(activityFilter.ToDate)));
                    }
                }

                if (activityFilter.HasSOC.HasValue)
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => m.Equipment.HasSOC == activityFilter.HasSOC));
                }

                if (activityFilter.Vessel.HasValue)
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => m.VesselId == activityFilter.Vessel));
                }

                if (activityFilter.Voyage.HasValue && activityFilter.Voyage > 0)
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => m.VoyageId == activityFilter.Voyage));
                }

                if (!string.IsNullOrEmpty(activityFilter.FeederVoyage))
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => m.Voyage == activityFilter.FeederVoyage));
                }

                if (activityFilter.ShowCancel.HasValue)
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => (m.EquipmentActivityState == DataAccessContractsConstants.Cancel) == activityFilter.ShowCancel.Value));
                }

                if (!string.IsNullOrEmpty(activityFilter.ActivityStatus))
                {
                    if (activityFilter.ActivityStatus != "Valid")
                    {
                        activitySpecification.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityErrors.FirstOrDefault().ValidationRule.ValidationRuleErrorResult.Description == activityFilter.ActivityStatus));
                    }
                    else
                    {
                        activitySpecification.Add(new Specification<EquipmentActivity>(m => !m.EquipmentActivityErrors.Any()));
                    }
                }

                if (!string.IsNullOrEmpty(activityFilter.ValidationRule))
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityErrors.FirstOrDefault().ValidationRule.RuleNumber == activityFilter.ValidationRule));
                }
            }

            return activitySpecification;
        }

        /// <summary>
        /// Locations the filter.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="activitySpecification">The activity specification.</param>
        private static void LocationFilter(EquipmentActivityFilter activityFilter, List<ISpecification<EquipmentActivity>> activitySpecification)
        {
            if (activityFilter.Location.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.LocationId == activityFilter.Location));
            }

            if (activityFilter.PlaceOfDelivery.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.DeliveryLocationId == activityFilter.PlaceOfDelivery));
            }

            if (activityFilter.PlaceOfFinalDestination.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.DestinationLocationId == activityFilter.PlaceOfFinalDestination));
            }

            if (activityFilter.PlaceOfReceipt.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ReceiptLocationId == activityFilter.PlaceOfReceipt));
            }

            if (activityFilter.ReturnLocation.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ReturnLocationId == activityFilter.ReturnLocation));
            }

            if (activityFilter.ReturnLocation.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ReturnLocationId == activityFilter.ReturnLocation));
            }
        }

        /// <summary>
        /// Ports the filter.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="activitySpecification">The activity specification.</param>
        private static void PortFilter(EquipmentActivityFilter activityFilter, IList<ISpecification<EquipmentActivity>> activitySpecification)
        {
            if (activityFilter.PortOfLoading.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.LoadingPortId == activityFilter.PortOfLoading));
            }

            if (activityFilter.PortOfDischarge.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.DischargePortId == activityFilter.PortOfDischarge));
            }

            if (activityFilter.TransshipmentPort.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.TransshipmentPortId == activityFilter.TransshipmentPort));
            }
        }

        /// <summary>
        /// Terminals the depot filter.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <param name="activitySpecification">The activity specification.</param>
        private static void TerminalDepotFilter(EquipmentActivityFilter activityFilter, IList<ISpecification<EquipmentActivity>> activitySpecification)
        {
            if (activityFilter.ActivityTerminal.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.TerminalEquipmentHandlingFacilityId == activityFilter.ActivityTerminal));
            }

            if (activityFilter.ActivityDepot.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.DepotEquipmentHandlingFacilityId == activityFilter.ActivityDepot));
            }

            if (activityFilter.ReturnDepot.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ReturnDepotEquipmentHandlingFacilityId == activityFilter.ReturnDepot));
            }

            if (activityFilter.ReturnTerminal.HasValue)
            {
                activitySpecification.Add(new Specification<EquipmentActivity>(m => m.ReturnTerminalEquipmentHandlingFacilityId == activityFilter.ReturnTerminal));
            }

            if (activityFilter.Valid.HasValue)
            {
                if (activityFilter.ValidationRuleId > 0)
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityErrors.FirstOrDefault().ValidationRuleId == activityFilter.ValidationRuleId));
                }
                else
                {
                    activitySpecification.Add(new Specification<EquipmentActivity>(m => !m.EquipmentActivityErrors.Any()));
                }
            }
        }

        #endregion
    }
}
