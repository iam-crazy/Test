﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleSpecification.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleSpecification.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Specifications
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using Framework.Service.DataAccess;
    using Objects;

    /// <summary>
    /// Declare ValidationRuleSpecification.
    /// </summary>
    public static class ValidationRuleSpecification
    {
        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <param name="group">The rule group.</param>
        /// <param name="description">The description.</param>
        /// <param name="type">The rule type.</param>
        /// <param name="searchValue">The search value.</param>
        /// <returns>Returns rule.</returns>
        public static List<ISpecification<ValidationRule>> BySearchRequest(int? ruleNumber, string group, string description, string type, string searchValue)
        {
            var specfications = new List<ISpecification<ValidationRule>>();
            if (ruleNumber.HasValue && ruleNumber != 0 && ruleNumber != null)
            {
                specfications.Add(new Specification<ValidationRule>(m => m.ValidationRuleId == ruleNumber));
            }

            if (!string.IsNullOrEmpty(type))
            {
                specfications.Add(new Specification<ValidationRule>(m => m.ValidationRuleType.Code.Contains(type)));
            }

            if (!string.IsNullOrEmpty(description))
            {
                specfications.Add(new Specification<ValidationRule>(m => m.Description.Contains(description)));
            }

            if (!string.IsNullOrEmpty(group))
            {
                specfications.Add(new Specification<ValidationRule>(m => m.ValidationRuleGroup.Code.Equals(group)));
            }

            if (!string.IsNullOrEmpty(searchValue))
            {
                specfications.Add(new Specification<ValidationRule>(m => m.ValidationRuleGroup.Code.Contains(group) || m.RuleNumber.Contains(Convert.ToString(ruleNumber)) || m.ValidationRuleType.Code.Contains(type) || m.Description.Contains(description)));
            }

            return specfications;
        }

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns The validation rule.</returns>
        public static List<ISpecification<ValidationRule>> BySearchRequest(int validationRuleId)
        {
            var specfications = new List<ISpecification<ValidationRule>>();
            specfications.Add(new Specification<ValidationRule>(vr => vr.ValidationRuleId == validationRuleId));
            return specfications;
        }

        /// <summary>
        /// With the detail.
        /// </summary>
        /// <returns>Returns The validation rule.</returns>
        public static Expression<Func<ValidationRule, object>>[] WithDetail()
        {
            IList<Expression<Func<ValidationRule, object>>> expressions = new List<Expression<Func<ValidationRule, object>>>();
            expressions.Add(vrg => vrg.ValidationRuleGroup);
            expressions.Add(vrt => vrt.ValidationRuleType);
            expressions.Add(vre => vre.ValidationRuleErrorResult);
            return expressions.ToArray();
        }
    }
}