﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalActivitySpecification.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalActivitySpecification.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Specifications
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using Framework.Service.DataAccess;
    using Objects;

    /// <summary>
    /// Declare LogicalActivitySpecification.
    /// </summary>
    public static class LogicalActivitySpecification
    {
        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="logicalCombinationId">The logical combination identifier.</param>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <param name="eventCodeId">The event code identifier.</param>
        /// <param name="purpose">The purpose.</param>
        /// <param name="status">If set to <c>true</c> [status].</param>
        /// <returns>Returns BySearchRequest.</returns>
        public static List<ISpecification<LogicalActivity>> BySearchRequest(int logicalCombinationId, int moveCodeId, int eventCodeId, string purpose, bool status)
        {
            var specfications = new List<ISpecification<LogicalActivity>>();
            if (logicalCombinationId != 0)
            {
                specfications.Add(new Specification<LogicalActivity>(m => m.LogicalActivityId == logicalCombinationId));
            }

            if (moveCodeId != 0)
            {
                specfications.Add(new Specification<LogicalActivity>(m => m.FromActivityReferentialId == moveCodeId));
            }

            if (eventCodeId != 0)
            {
                specfications.Add(new Specification<LogicalActivity>(m => m.ToActivityReferentialId == eventCodeId));
            }

            if (!string.IsNullOrEmpty(purpose))
            {
                specfications.Add(new Specification<LogicalActivity>(m => m.Remarks == purpose));
            }

            if (status != false)
            {
                specfications.Add(new Specification<LogicalActivity>(m => m.Status == status));
            }

            return specfications;
        }

        /// <summary>
        /// By the search request.
        /// </summary>
        /// <param name="fromActivityId">From activity identifier.</param>
        /// <param name="toActivityId">To activity identifier.</param>
        /// <param name="hasSequence">If set to <c>true</c> [is sequence].</param>
        /// <param name="hasCombination">If set to <c>true</c> [is combination].</param>
        /// <returns>Return the search request.</returns>
        public static List<ISpecification<LogicalActivity>> BySearchRequest(int fromActivityId, int toActivityId, bool hasSequence, bool hasCombination)
        {
            List<ISpecification<LogicalActivity>> specfications = new List<ISpecification<LogicalActivity>>();
            if (fromActivityId > 0)
            {
                specfications.Add(new Specification<LogicalActivity>(la => la.FromActivityReferentialId == fromActivityId));
            }

            if (toActivityId > 0)
            {
                specfications.Add(new Specification<LogicalActivity>(la => la.ToActivityReferentialId == toActivityId));
            }

            if (hasSequence)
            {
                specfications.Add(new Specification<LogicalActivity>(la => la.ActivityType == null));
            }

            if (hasCombination)
            {
                specfications.Add(new Specification<LogicalActivity>(la => la.ActivityType != null));
            }

            return specfications;
        }

        /// <summary>
        /// With the detail.
        /// </summary>
        /// <returns>Returns The Data.</returns>
        public static Expression<Func<LogicalActivity, object>>[] WithDetail()
        {
            IList<Expression<Func<LogicalActivity, object>>> expressions = new List<Expression<Func<LogicalActivity, object>>>();
            expressions.Add(fa => fa.FromActivityReferential);
            expressions.Add(ta => ta.ToActivityReferential);
            return expressions.ToArray();
        }
    }
}