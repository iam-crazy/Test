﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleGroupRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IValidationRuleGroupRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Validation Rule Group Repository.
    /// </summary>
    public interface IValidationRuleGroupRepository
    {
        /// <summary>
        /// Gets the validation rule groups.
        /// </summary>
        /// <returns>Return ValidationRuleGroup.</returns>
        Task<IList<ValidationRuleGroup>> GetValidationRuleGroups();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleGroupData">The validationRuleGroupData.</param>
        void Save(ValidationRuleGroup validationRuleGroupData);

        /// <summary>
        /// Deletes the specified validation rule group identifier.
        /// </summary>
        /// <param name="validationRuleGroupId">The validation rule group identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int validationRuleGroupId);
    }
}