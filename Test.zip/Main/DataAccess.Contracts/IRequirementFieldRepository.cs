﻿//-----------------------------------------------------------------------
// <copyright file = "IRequirementFieldRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IRequirementFieldRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Requirement Field Repository.
    /// </summary>
    public interface IRequirementFieldRepository
    {
        /// <summary>
        /// Gets the requirement fields.
        /// </summary>
        /// <returns>Return RequirementField.</returns>
        Task<IList<RequirementField>> GetRequirementFields();

        /// <summary>
        /// Saves the specified requirement field data.
        /// </summary>
        /// <param name="requirementFieldData">The requirement field data.</param>
        void Save(RequirementField requirementFieldData);

        /// <summary>
        /// Deletes the specified requirement field identifier.
        /// </summary>
        /// <param name="requirementFieldId">The requirement field identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int requirementFieldId);
    }
}