﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentStateRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentStateRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare IEquipmentStateRepository.
    /// </summary>
    public interface IEquipmentStateRepository
    {
        /// <summary>
        /// Searches the equipment states.
        /// </summary>
        /// <returns>Returns The EquipmentState Data.</returns>
        Task<IList<EquipmentState>> SearchEquipmentStates();

        /// <summary>
        /// Saves the specified equipment state data.
        /// </summary>
        /// <param name="equipmentStateData">The equipment state data.</param>
        void Save(EquipmentState equipmentStateData);

        /// <summary>
        /// Deletes the specified equipment state identifier.
        /// </summary>
        /// <param name="equipmentStateId">The equipment state identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int equipmentStateId);
    }
}