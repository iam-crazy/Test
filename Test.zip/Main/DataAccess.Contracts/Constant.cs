﻿//-----------------------------------------------------------------------
// <copyright file = "Constant.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare Constant.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare Constant.
    /// </summary>
    public static class Constant
    {
        /// <summary>
        /// The string cancel.
        /// </summary>
        public const string Cancel = "C";
    }
}