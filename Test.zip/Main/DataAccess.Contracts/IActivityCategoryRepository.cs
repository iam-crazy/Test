﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityCategoryRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityCategoryRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare ILogicalCombinationRepository.
    /// </summary>
    public interface IActivityCategoryRepository
    {
        /// <summary>
        /// Gets the ActivityCategory.
        /// </summary>
        /// <returns>Returns ActivityCategory Lists.</returns>
        Task<IList<ActivityCategory>> GetActivityCategories();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The Activity Category data.</param>
        void Save(ActivityCategory data);

        /// <summary>
        /// Deletes the specified activity category identifier.
        /// </summary>
        /// <param name="activityCategoryId">The activity category identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int activityCategoryId);
    }
}