﻿//-----------------------------------------------------------------------
// <copyright file = "IBusinessCycleRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IBusinessCycleRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare IBusinessCycleRepository.
    /// </summary>
    public interface IBusinessCycleRepository
    {
        /// <summary>
        /// Gets the business cycles.
        /// </summary>
        /// <returns>Returns BusinessCycle Lists.</returns>
        Task<IList<BusinessCycle>> GetBusinessCycles();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The save data.</param>
        void Save(BusinessCycle data);

        /// <summary>
        /// Deletes the specified business cycle identifier.
        /// </summary>
        /// <param name="businessCycleId">The business cycle identifier.</param>
        /// <param name="userId">The user identifier.</param>
        /// <returns>Retruns delete data.</returns>
        Task<int> Delete(int businessCycleId, int userId);
    }
}