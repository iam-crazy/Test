﻿//-----------------------------------------------------------------------
// <copyright file = "ILogicalCombinationRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ILogicalCombinationRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Declare ILogicalCombinationRepository.
    /// </summary>
    public interface ILogicalCombinationRepository
    {
        /// <summary>
        /// Saves the specified logical combinations.
        /// </summary>
        /// <param name="logicalCombinations">The logical combinations.</param>
        void Save(List<LogicalActivity> logicalCombinations);

        /// <summary>
        /// Gets the logical combination list.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>Returns The logical Combination List.</returns>
        Task<IList<LogicalActivity>> GetLogicalCombinationList(int moveCodeId);

        /// <summary>
        /// Gets the previous moves.
        /// </summary>
        /// <param name="nextMoveId">The next move identifier.</param>
        /// <returns>Returns The previous moves.</returns>
        Task<IList<LogicalActivity>> GetPreviousMoves(int nextMoveId);       
    }
}