﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleTypeRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IValidationRuleTypeRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Validation Rule Type Repository.
    /// </summary>
    public interface IValidationRuleTypeRepository
    {
        /// <summary>
        /// Gets the validation rule types.
        /// </summary>
        /// <returns>Return ValidationRuleType.</returns>
        Task<IList<ValidationRuleType>> GetValidationRuleTypes();

        /// <summary>
        /// Saves the specified validation rule type data.
        /// </summary>
        /// <param name="validationRuleTypeData">The validation rule type data.</param>
        void Save(ValidationRuleType validationRuleTypeData);

        /// <summary>
        /// Deletes the specified validation rule type identifier.
        /// </summary>
        /// <param name="validationRuleTypeId">The validation rule type identifier.</param>
        /// <returns>Return ValidationRuleType.</returns>
        Task<int> Delete(int validationRuleTypeId);
    }
}