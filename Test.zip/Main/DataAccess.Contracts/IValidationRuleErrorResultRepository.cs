﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleErrorResultRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IValidationRuleErrorResultRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Validation Rule Error Result Repository.
    /// </summary>
    public interface IValidationRuleErrorResultRepository
    {
        /// <summary>
        /// Gets the validation rule error results.
        /// </summary>
        /// <returns>Return ValidationRuleErrorResult.</returns>
        Task<IList<ValidationRuleErrorResult>> GetValidationRuleErrorResults();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleErrorResultData">The validationRuleErrorResultData.</param>
        void Save(ValidationRuleErrorResult validationRuleErrorResultData);

        /// <summary>
        /// Deletes the specified validation rule error result identifier.
        /// </summary>
        /// <param name="validationRuleErrorResultId">The validation rule error result identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int validationRuleErrorResultId);
    }
}