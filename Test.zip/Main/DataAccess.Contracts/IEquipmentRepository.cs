﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare IEquipmentRepository.
    /// </summary>
    public interface IEquipmentRepository
    {
        /// <summary>
        /// Gets the equipments.
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <returns>Returns The Equipment  Data.</returns>
        Task<IList<Equipment>> GetEquipment(int equipmentId);

        /// <summary>
        /// Saves the specified equipment data.
        /// </summary>
        /// <param name="equipmentData">The equipment data.</param>
        /// <returns>Returns The Equipment Data.</returns>
        Task Save(Equipment equipmentData);

        /// <summary>
        /// Determines whether [is equipment number] [the specified equipment number].
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns The Equipment Data.</returns>
        Task<bool> IsEquipmentNumber(string equipmentNumber);
    }
}