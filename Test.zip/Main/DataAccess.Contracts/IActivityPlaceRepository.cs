﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityPlaceRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityPlaceRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Activity Place Repository.
    /// </summary>
    public interface IActivityPlaceRepository
    {
        /// <summary>
        /// Gets the activity places.
        /// </summary>
        /// <returns>Return ActivityLocation.</returns>
        Task<IList<TakePlaceAt>> GetActivityPlaces();

        /// <summary>
        /// Saves the specified activity location data.
        /// </summary>
        /// <param name="activityLocationData">The activity location data.</param>
        void Save(TakePlaceAt activityLocationData);

        /// <summary>
        /// Deletes the specified activity location identifier.
        /// </summary>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int activityLocationId);
    }
}