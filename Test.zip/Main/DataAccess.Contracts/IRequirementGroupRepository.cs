﻿//-----------------------------------------------------------------------
// <copyright file = "IRequirementGroupRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IRequirementGroupRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Msc.Framework.Common.Model;
    using Msc.Logistics.EME.Service.DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare IRequirementGroupRepository.
    /// </summary>
    public interface IRequirementGroupRepository
    {
        /// <summary>
        /// Gets the requirement groups.
        /// </summary>
        /// <returns>
        /// Return GetRequirementGroups.
        /// </returns>
        Task<IList<RequirementGroup>> GetRequirementGroups();

        /// <summary>
        /// Saves the specified requirement group data.
        /// </summary>
        /// <param name="requirementGroupData">The requirement group data.</param>
        void Save(RequirementGroup requirementGroupData);

        /// <summary>
        /// Deletes the specified requirement group identifier.
        /// </summary>
        /// <param name="requirementGroupId">The requirement group identifier.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        Task<OperationOutcome> Delete(int requirementGroupId);
    }
}