﻿//-----------------------------------------------------------------------
// <copyright file = "ILogicalSequenceRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ILogicalSequenceRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare ILogicalSequenceRepository.
    /// </summary>
    public interface ILogicalSequenceRepository
    {
        /// <summary>
        /// Saves the specified logical sequence.
        /// </summary>
        /// <param name="logicalSequence">The logical sequence.</param>
        /// <returns>Returns The Save Data.</returns>
        Task<int> Save(IList<LogicalActivity> logicalSequence);

        /// <summary>
        /// Updates the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="status">If set to <c>true</c> [status].</param>
        /// <param name="remarks">The remarks.</param>
        void Update(int id, bool status, string remarks);

        /// <summary>
        /// Gets the logical sequence list.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>Returns Logical Sequence List.</returns>
        Task<IList<LogicalActivity>> GetLogicalSequenceList(int moveCodeId);

        /// <summary>
        /// Gets the previous moves.
        /// </summary>
        /// <param name="nextMoveId">The next move identifier.</param>
        /// <returns>Returns The previous moves.</returns>
        Task<IList<LogicalActivity>> GetPreviousMoves(int nextMoveId);

        /// <summary>
        /// Gets the logical activity identifier.
        /// </summary>
        /// <param name="logicalActivityId">The logical activity identifier.</param>
        /// <returns>Returns The logical activity.</returns>
        Task<LogicalActivity> GetLogicalActivityId(int logicalActivityId);
    }
}