﻿//-----------------------------------------------------------------------
// <copyright file = "IdentifierExtension.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IdentifierExtension. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts.Extension
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Declare IdentifierExtension.
    /// </summary>
    public static class IdentifierExtension
    {
        /// <summary>
        /// Gets the string separator.
        /// </summary>
        /// <param name="filterCriteria">Filter Criteria.</param>
        /// <returns>Returns the string separator.</returns>
        public static string[] GetStringSeparator(string filterCriteria)
        {
            return filterCriteria?.Trim().Split(separator: new char[] { ',' }, options: StringSplitOptions.RemoveEmptyEntries).Distinct().ToArray();
        }
    }
}