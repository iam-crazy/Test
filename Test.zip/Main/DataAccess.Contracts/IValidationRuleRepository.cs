﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleRepository.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IValidationRuleRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// IValidationRule Repository.
    /// </summary>
    public interface IValidationRuleRepository
    {
        /// <summary>
        /// Gets the validation rules.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <param name="group">The group.</param>
        /// <param name="description">The description.</param>
        /// <param name="validFrom">The valid from.</param>
        /// <param name="validTo">The valid to.</param>
        /// <param name="status">The status.</param>
        /// <param name="type">The validation rules type.</param>
        /// <param name="limit">The validation rules limit.</param>
        /// <param name="offset">The validation rules offset.</param>
        /// <param name="searchValue">The search string.</param>
        /// <returns>Return the validation rules.</returns>
        Task<IList<ValidationRule>> GetValidationRules(int? ruleNumber, string group, string description, DateTime? validFrom, DateTime? validTo, bool? status, string type, int limit, int offset, string searchValue);

        /// <summary>
        /// Gets the invalid equipment activity.
        /// </summary>
        /// <returns>Tuple Detail.</returns>
        Task<IList<Tuple<int, string, string, int>>> SearchInvalidEquipmentActivity();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        void Save(ValidationRule data);

        /// <summary>
        /// Updates the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        void Update(ValidationRule data);

        /// <summary>
        /// Gets the validation rule.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Id.</returns>
        Task<ValidationRule> GetValidationRule(int id);

        /// <summary>
        /// Gets the validation rule.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <returns>Returns The validation rule.</returns>
        Task<ValidationRule> GetValidationRule(string ruleNumber);

        /// <summary>
        /// Generates the rule number.
        /// </summary>
        /// <returns>Returns The Rule Number.</returns>
        Task<string> GenerateRuleNumber();

        /// <summary>
        /// Search the validation rules.
        /// </summary>
        /// <param name="group">The group parameter.</param>
        /// <param name="id">The id parameter.</param>
        /// <returns>Returns The Data.</returns>
        Task<List<ValidationRule>> SearchValidationRules(string group, int id);

        /// <summary>
        /// Determines whether [is rule number exist] [the specified rule number].
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <returns>Return Number rule Status.</returns>
        Task<bool> IsRuleNumberExist(string ruleNumber);
    }
}