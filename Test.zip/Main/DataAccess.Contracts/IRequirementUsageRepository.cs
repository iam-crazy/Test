﻿//-----------------------------------------------------------------------
// <copyright file = "IRequirementUsageRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IRequirementUsageRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Requirement Usage Repository.
    /// </summary>
    public interface IRequirementUsageRepository
    {
        /// <summary>
        /// Gets the requirement usages.
        /// </summary>
        /// <returns>Return RequirementUsage.</returns>
        Task<IList<RequirementUsage>> GetRequirementUsages();

        /// <summary>
        /// Saves the specified requirement usage data.
        /// </summary>
        /// <param name="requirementUsageData">The requirement usage data.</param>
        void Save(RequirementUsage requirementUsageData);

        /// <summary>
        /// Deletes the specified requirement usage identifier.
        /// </summary>
        /// <param name="requirementUsageId">The requirement usage identifier.</param>
        /// <returns>Return Delete Record.</returns>
        Task<int> Delete(int requirementUsageId);
    }
}