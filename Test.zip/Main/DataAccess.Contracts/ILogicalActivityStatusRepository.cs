﻿//-----------------------------------------------------------------------
// <copyright file = "ILogicalActivityStatusRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ILogicalActivityStatusRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Declare ILogicalActivityStatusRepository.
    /// </summary>
    public interface ILogicalActivityStatusRepository
    {
        /// <summary>
        /// Updates the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="status">If set to <c>true</c> [status].</param>
        /// <param name="remarks">The remarks.</param>
        /// <returns>Return activity status Data.</returns>
        Task<int> UpdateLogicalActivityStatus(int activityId, bool status, string remarks);

        /// <summary>
        /// Checks the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>Return activity status Data.</returns>
        Task<AvailableStatus> CheckLogicalActivityStatus(int activityId, string activityType);
    }
}