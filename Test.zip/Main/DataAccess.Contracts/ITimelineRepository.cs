﻿//-----------------------------------------------------------------------
// <copyright file = "ITimelineRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ITimelineRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Declare ITimelineRepository.
    /// </summary>
    public interface ITimelineRepository
    {
        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="equipmentId">The equipment activity identifier.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <returns>Returns the equipment activity.</returns>
        Task<IList<EquipmentActivity>> GetEquipmentActivityList(long equipmentId, bool showCancel);
    }
}