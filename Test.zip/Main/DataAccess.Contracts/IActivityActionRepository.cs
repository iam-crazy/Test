﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityActionRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityActionRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Declare ILogicalCombinationRepository.
    /// </summary>
    public interface IActivityActionRepository
    {
        /// <summary>
        /// Gets the ActivityAction.
        /// </summary>
        /// <returns>Returns ActivityAction Lists.</returns>
        Task<IList<ActivityAction>> GetActivityActions();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        void Save(ActivityAction data);

        /// <summary>
        /// Deletes the specified activity action identifier.
        /// </summary>
        /// <param name="activityActionId">The activity action identifier.</param>
        /// <returns>
        /// Return Delete Data.
        /// </returns>
        Task<int> Delete(int activityActionId);
    }
}