﻿//-----------------------------------------------------------------------
// <copyright file = "IReferentialDataRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IReferentialDataRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Referential Data Repository.
    /// </summary>
    public interface IReferentialDataRepository
    {
        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="activities">The activities.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="fullEmpty">The full empty.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="location">The location.</param>
        /// <param name="requirementFields">The requirement fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The status.</param>
        /// <param name="isMapped">The is mapped.</param>
        /// <param name="businessCycle">The businessCycle.</param>
        /// <returns>Returns the referential list.</returns>
        Task<IList<ActivityReferential>> GetReferentialList(int? action, IEnumerable<int> activities, int? activityType, IEnumerable<int> category, int? equipmentStatus, int? fullEmpty, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, int? location, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, bool? isMapped, int? businessCycle);

        /// <summary>
        /// Gets the referential data list.
        /// </summary>
        /// <param name="isMapped">Is Mapped with EDI.</param>
        /// <returns>Returns the referential list.</returns>
        Task<IList<ActivityReferential>> GetReferentialDataList(bool? isMapped);

        /// <summary>
        /// Saves the specified Referential data.
        /// </summary>
        /// <param name="data">The save data.</param>
        void Save(ActivityReferential data);

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Data Based On ID.</returns>
        Task<ActivityReferential> GetReferentialData(int id);

        /// <summary>
        /// Searches the referential data.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>Returns The Referential Data.</returns>
        Task<IList<ActivityReferential>> SearchReferentialData(string criteria);

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <returns>Return ReferentialData. </returns>
        Task<IList<RequirementField>> GetRequirementFields();

        /// <summary>
        /// Gets the Full Empty data.
        /// </summary>
        /// <returns>Return FullEmptyData. </returns>
        Task<IList<FullEmpty>> GetFullEmptyDetails();

        /// <summary>
        /// Gets the requirement usage.
        /// </summary>
        /// <returns>Returns Requirement Usage.</returns>
        Task<IList<RequirementUsage>> GetRequirementUsage();

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <returns>Get Mapped Count.</returns>
        Task<Tuple<int, int, int>> SearchQuickAccessCount();

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="activities">The activities.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="fullEmpty">The full empty.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="location">The location.</param>
        /// <param name="requirementFields">The requirement fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The status.</param>
        /// <param name="businessCycle">The businessCycle.</param>
        /// <returns>Get QuickAccess Count.</returns>
        Task<Tuple<int, int, int>> GetQuickAccessCount(int? action, IEnumerable<int> activities, int? activityType, IEnumerable<int> category, int? equipmentStatus, int? fullEmpty, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, int? location, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, int? businessCycle);

        /// <summary>
        /// Gets the referential validation rules.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Return Validation Rules.</returns>
        Task<IList<ReferentialValidationRule>> GetReferentialValidationRules(int validationRuleId);

        /// <summary>
        /// Saves the referential validation rules.
        /// </summary>
        /// <param name="data">The Referential Validation Rule data.</param>
        void SaveReferentialValidationRules(IList<ReferentialValidationRule> data);

        /// <summary>
        /// Updates the business cycle.
        /// </summary>
        /// <param name="referentialStatus">The referential status.</param>
        void UpdateBusinessCycle(ActivityReferential referentialStatus);

        /// <summary>
        /// Updates the effective to.
        /// </summary>
        /// <param name="data">The ReferentialValidationRule data.</param>
        void UpdateEffectiveTo(ReferentialValidationRule data);
    }
}