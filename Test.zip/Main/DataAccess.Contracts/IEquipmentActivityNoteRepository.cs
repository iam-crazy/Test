﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentActivityNoteRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentActivityNoteRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare IEquipmentActivityNoteRepository.
    /// </summary>
    public interface IEquipmentActivityNoteRepository
    {
        /// <summary>
        /// Gets the equipment activity note.
        /// </summary>
        /// <param name="equipmentActivityNoteId">The equipment activity note identifier.</param>
        /// <returns>Returns The EquipmentStatus Data.</returns>
        Task<IList<EquipmentActivityNote>> GetEquipmentActivityNote(int equipmentActivityNoteId);

        /// <summary>
        /// Saves the specified equipment note data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipment note data.</param>
        /// <returns>Returns The EquipmentStatus Data.</returns>
        Task Save(EquipmentActivityNote equipmentNoteData);
    }
}
