﻿//-----------------------------------------------------------------------
// <copyright file = "ILogicalActivityStatusService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ILogicalActivityStatusService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Declare ILogicalActivityStatusService.
    /// </summary>
    public interface ILogicalActivityStatusService
    {
        /// <summary>
        /// Updates the logical activity status.
        /// </summary>
        /// <param name="activity">The activity.</param>
        /// <returns>Return activity status Data.</returns>
        Task<BusinessOutcome> UpdateLogicalActivityStatus(LogicalSequenceUpdate activity);

        /// <summary>
        /// Checks the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>Return activity status Data.</returns>
        Task<AvailableStatus> CheckLogicalActivityStatus(int activityId, string activityType);
    }
}