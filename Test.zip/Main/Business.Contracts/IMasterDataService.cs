﻿//-----------------------------------------------------------------------
// <copyright file = "IMasterDataService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IMasterDataService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare IMasterDataService.
    /// </summary>
    public interface IMasterDataService
    {
        /// <summary>
        /// Searches the equipment size types.
        /// </summary>
        /// <param name="sizeTypeId">Type of the size.</param>
        /// <returns>Returns The Equipment Size Type.</returns>
        Task<EquipmentSizeType> GetEquipmentSizeType(int? sizeTypeId);

        /// <summary>
        /// Gets the equipment size types.
        /// </summary>
        /// <param name="sizeTypeIds">The size type ids.</param>
        /// <returns>Returns The Equipment Size Type.</returns>
        Task<IList<EquipmentSizeType>> GetEquipmentSizeTypes(IList<short> sizeTypeIds);

        /// <summary>
        /// Gets the equipment iso codes.
        /// </summary>
        /// <param name="equipmentISOCodes">The equipment iso codes.</param>
        /// <returns>Return EquipmentISO.</returns>
        Task<IList<EquipmentISOCode>> GetEquipmentISOCodes(IList<short> equipmentISOCodes);

        /// <summary>
        /// Gets the equipment iso code.
        /// </summary>
        /// <param name="equipmentISOCode">The equipment iso code.</param>
        /// <returns>Return EquipmentISO.</returns>
        Task<EquipmentISOCode> GetEquipmentISOCode(int? equipmentISOCode);

        /// <summary>
        /// Searches the vessel.
        /// </summary>
        /// <returns>Returns The Vessel.</returns>
        IList<VesselVoyage> SearchVoyage();

        /////// <summary>
        /////// Gets the vessel.
        /////// </summary>
        /////// <param name="vesselId">The vessel identifier.</param>
        /////// <param name="activityDate">The activity date.</param>
        /////// <returns>Return Vessel list.</returns>
        ////Task<Vessel> GetVessel(int? vesselId, DateTime activityDate);

        /// <summary>
        /// Gets the vessels.
        /// </summary>
        /// <param name="vesselIds">The vessel ids.</param>
        /// <returns>Return Vessel list.</returns>
        Task<IList<Vessel>> GetVessels(IList<int> vesselIds);

        /// <summary>
        /// Gets the ports.
        /// </summary>
        /// <param name="portIds">The port ids.</param>
        /// <returns>Return Port list.</returns>
        Task<IList<Port>> GetPorts(IList<int> portIds);

        /// <summary>
        /// Gets the terminal depots.
        /// </summary>
        /// <param name="terminalDepotIds">The terminal depot ids.</param>
        /// <returns>Return List of Terminal Depot.</returns>
        Task<IList<TerminalDepot>> GetTerminalDepots(IList<int> terminalDepotIds);

        /////// <summary>
        /////// Gets the terminal depot list.
        /////// </summary>
        /////// <param name="terminalDepotId">The terminal depot identifier.</param>
        /////// <returns>Return List of Terminal Depot.</returns>
        ////Task<IList<TerminalDepot>> GetTerminalDepotList(int? terminalDepotId);

        /// <summary>
        /// Gets the locations.
        /// </summary>
        /// <param name="locationIds">The location identifier.</param>
        /// <returns>Return Location list.</returns>
        Task<IList<Location>> GetLocations(IList<int> locationIds);

        /// <summary>
        /// Gets the equipment category.
        /// </summary>
        /// <returns>Return equipment category list.</returns>
        Task<IList<EquipmentCategory>> GetEquipmentCategories();
    }
}
