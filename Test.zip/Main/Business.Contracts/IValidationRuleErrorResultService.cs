﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleErrorResultService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IValidationRuleErrorResultService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IValidationRuleErrorResultService.
    /// </summary>
    public interface IValidationRuleErrorResultService
    {
        /// <summary>
        /// Gets the validation rule error results.
        /// </summary>
        /// <returns>Return ValidationRuleErrorResult.</returns>
        Task<IList<ValidationRuleErrorResult>> GetValidationRuleErrorResults();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleErrorResultData">The validationRuleErrorResultData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(ValidationRuleErrorResult validationRuleErrorResultData);

        /// <summary>
        /// Deletes the specified validation rule error result identifier.
        /// </summary>
        /// <param name="validationRuleErrorResultId">The validation rule error result identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int validationRuleErrorResultId, int userId);
    }
}