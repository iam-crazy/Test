﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IEquipmentService.
    /// </summary>
    public interface IEquipmentService
    {
        /// <summary>
        /// Gets the equipments.
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <returns>Returns The EquipmentStatus Data.</returns>
        Task<IList<Equipment>> GetEquipment(int equipmentId);

        /// <summary>
        /// Saves the specified equipment data.
        /// </summary>
        /// <param name="equipmentData">The equipment data.</param>
        /// <returns>Returns The EquipmentStatus Data.</returns>
        Task<BusinessOutcome> Save(Equipment equipmentData);
    }
}