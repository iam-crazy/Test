﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityTypeService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityTypeService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IActivityTypeService.
    /// </summary>
    public interface IActivityTypeService
    {
        /// <summary>
        /// Gets the ActivityType.
        /// </summary>
        /// <returns>Returns ActivityType Lists.</returns>
        Task<IList<ActivityType>> GetActivityTypes();

        /// <summary>
        /// Saves the specified ActivityType.
        /// </summary>
        /// <param name="data">The ActivityType.</param>
        /// <returns>Returns The Save Data.</returns>
        Task<BusinessOutcome> Save(ActivityType data);

        /// <summary>
        /// Deletes the specified activity type identifier.
        /// </summary>
        /// <param name="activityTypeId">The activity type identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int activityTypeId, int userId);
    }
}