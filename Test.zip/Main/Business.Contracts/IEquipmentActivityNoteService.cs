﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentActivityNoteService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentActivityNoteService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IEquipmentActivityNoteService.
    /// </summary>
    public interface IEquipmentActivityNoteService
    {
        /// <summary>
        /// Gets the equipment activity note.
        /// </summary>
        /// <param name="equipmentActivityNoteId">The equipment activity note identifier.</param>
        /// <returns>Returns equipment note.</returns>
        Task<IList<EquipmentActivityNote>> GetEquipmentActivityNote(int equipmentActivityNoteId);

        /// <summary>
        /// Saves the specified equipment note data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipment note data.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(EquipmentActivityNote equipmentNoteData);
    }
}
