﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentStatusService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IEquipmentStatusService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IEquipmentStatusService.
    /// </summary>
    public interface IEquipmentStatusService
    {
        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <returns>Returns equipment Status.</returns>
        Task<IList<EquipmentStatus>> GetEquipmentStatus();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="equipmentStatusData">The equipmentStatusData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(EquipmentStatus equipmentStatusData);

        /// <summary>
        /// Deletes the specified shipment status identifier.
        /// </summary>
        /// <param name="equipmentStatusId">The Equipment Status identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        Task<BusinessOutcome> Delete(int equipmentStatusId, int userId);
    }
}