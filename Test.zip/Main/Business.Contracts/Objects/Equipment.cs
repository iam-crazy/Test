//-----------------------------------------------------------------------
// <copyright file = "Equipment.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare Equipment. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Defines the <see cref="Equipment" />
    /// </summary>
    public partial class Equipment : UserInformation
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Equipment"/> class.
        /// </summary>
        public Equipment()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the equipment iso identifier.
        /// </summary>
        /// <value>
        /// The equipment iso identifier.
        /// </value>
        public EquipmentISOCode EquipmentISO { get; set; }

        /// <summary>
        /// Gets or sets the equipment notes.
        /// </summary>
        /// <value>
        /// The equipment notes.
        /// </value>
        public IList<EquipmentNote> EquipmentNotes { get; set; }

        /// <summary>
        /// Gets or sets the equipment number.
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the equipment size type identifier.
        /// </summary>
        /// <value>
        /// The equipment size type identifier.
        /// </value>
        public EquipmentSizeType EquipmentSizeType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has soc.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has soc; otherwise, <c>false</c>.
        /// </value>
        public bool HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the is cancelled.
        /// </summary>
        /// <value>
        /// The is cancelled.
        /// </value>
        public bool? IsCanceled { get; set; }

        /// <summary>
        /// Gets or sets the parent equipment identifier.
        /// </summary>
        /// <value>
        /// The parent equipment identifier.
        /// </value>
        public long? ParentEquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the valid from.
        /// </summary>
        /// <value>
        /// The valid from.
        /// </value>
        public DateTimeOffset ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to.
        /// </summary>
        /// <value>
        /// The valid to.
        /// </value>
        public DateTimeOffset? ValidTo { get; set; }

        #endregion
    }
}
