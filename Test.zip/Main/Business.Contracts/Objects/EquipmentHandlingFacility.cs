﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentHandlingFacility.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentHandlingFacility. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare EquipmentHandlingFacility.
    /// </summary>
    public class EquipmentHandlingFacility
    {
        #region Properties

        /// <summary>
        /// Gets or sets the equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The equipment handling facility identifier.
        /// </value>
        public int EquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is inland.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is inland; otherwise, <c>false</c>.
        /// </value>
        public bool IsInland { get; set; }

        /// <summary>
        /// Gets or sets the MSC code.
        /// </summary>
        /// <value>
        /// The MSC code.
        /// </value>
        public string MscCode { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is depot.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is depot; otherwise, <c>false</c>.
        /// </value>
        public bool IsDepot { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is terminal.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is terminal; otherwise, <c>false</c>.
        /// </value>
        public bool IsTerminal { get; set; }

        /// <summary>
        /// Gets or sets the latitude.
        /// </summary>
        /// <value>
        /// The latitude.
        /// </value>
        public double? Latitude { get; set; }

        /// <summary>
        /// Gets or sets the longitude.
        /// </summary>
        /// <value>
        /// The longitude.
        /// </value>
        public double? Longitude { get; set; }

        /// <summary>
        /// Gets or sets the deleted.
        /// </summary>
        /// <value>
        /// The deleted.
        /// </value>
        public int Deleted { get; set; }

        /// <summary>
        /// Gets or sets the last update UTC.
        /// </summary>
        /// <value>
        /// The last update UTC.
        /// </value>
        public DateTime LastUpdateUtc { get; set; }

        /// <summary>
        /// Gets or sets the Terminal Total TEU Capacity.
        /// </summary>
        /// <value>
        /// The Terminal Total TEU Capacity.
        /// </value>
        public int? TerminalTotalTEUCapacity { get; set; }

        /// <summary>
        /// Gets or sets the Terminal MSC TEU Capacity.
        /// </summary>
        /// <value>
        /// The Terminal MSC TEU Capacity.
        /// </value>
        public int? TerminalMscTEUCapacity { get; set; }

        /// <summary>
        /// Gets or sets the Terminal Total Reefer Plug Capacity.
        /// </summary>
        /// <value>
        /// The Terminal Total Reefer Plug Capacity.
        /// </value>
        public int? TerminalTotalReeferPlugCapacity { get; set; }

        /// <summary>
        /// Gets or sets the Terminal MSC Reefer Plug Capacity.
        /// </summary>
        /// <value>
        /// The Terminal MSC Reefer Plug Capacity.
        /// </value>
        public int? TerminalMscReeferPlugCapacity { get; set; }

        #endregion Properties
    }
}