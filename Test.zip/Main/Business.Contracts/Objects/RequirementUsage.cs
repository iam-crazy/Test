﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementUsage.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementUsage. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare RequirementUsage.
    /// </summary>
    public class RequirementUsage : UserInformation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementUsage"/> class.
        /// </summary>
        public RequirementUsage()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        public string Code { get; set; }

        #endregion Properties
    }
}