﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceUpdate.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequence.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare LogicalSequence update.
    /// </summary>
    public class LogicalSequenceUpdate : UserInformation
    {
        #region Properties

        /// <summary>
        /// Gets or sets the logical sequence identifier.
        /// </summary>
        /// <value>
        /// The logical sequence identifier.
        /// </value>
        public int LogicalActivityId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="LogicalSequenceDto"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        public string Remarks { get; set; }

        #endregion Properties
    }
}