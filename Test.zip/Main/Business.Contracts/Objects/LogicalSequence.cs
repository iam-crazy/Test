﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequence.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequence.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare LogicalSequence.
    /// </summary>
    public class LogicalSequence
    {
        #region Properties

        /// <summary>
        /// Gets or sets the logical sequence identifier.
        /// </summary>
        /// <value>
        /// The logical sequence identifier.
        /// </value>
        public int LogicalActivityId { get; set; }

        /// <summary>
        /// Gets or sets the current move identifier.
        /// </summary>
        /// <value>
        /// The current move identifier.
        /// </value>
        public Activity FromActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the next move identifier.
        /// </summary>
        /// <value>
        /// The next move identifier.
        /// </value>
        public Activity ToActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="LogicalSequence"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the purpose.
        /// </summary>
        /// <value>
        /// The purpose.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the row status.
        /// </summary>
        /// <value>
        /// The row status.
        /// </value>
        public string RowStatus { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the last updated by.
        /// </summary>
        /// <value>
        /// The last updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the last updated on.
        /// </summary>
        /// <value>
        /// The last updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment categories.
        /// </summary>
        /// <value>
        /// The equipment categories.
        /// </value>
        public EquipmentCategory EquipmentCategory { get; set; }

        #endregion Properties
    }
}