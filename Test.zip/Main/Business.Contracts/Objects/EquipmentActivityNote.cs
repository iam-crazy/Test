//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityNote.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityNote. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Defines the <see cref="EquipmentActivityNote" />
    /// </summary>
    public partial class EquipmentActivityNote
    {
        #region Properties

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity notes identifier.
        /// </summary>
        /// <value>
        /// The equipment activity notes identifier.
        /// </value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public int UserId { get; set; }
                
        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public UserBase UserBase { get; set; }

        #endregion
    }
}
