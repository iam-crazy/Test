//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatus.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ShipmentStatus.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare ShipmentStatus.
    /// </summary>
    public class ShipmentStatus : UserInformation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentStatus"/> class.
        /// </summary>
        public ShipmentStatus()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the shipment status identifier.
        /// </summary>
        /// <value>
        /// The shipment status identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The shipment code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        #endregion Properties
    }
}