﻿//-----------------------------------------------------------------------
// <copyright file = "PortVersion.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare PortVersion. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare PortVersion.
    /// </summary>
    public class PortVersion
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the PortVersion class.
        /// </summary>
        public PortVersion()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the port version identifier.
        /// </summary>
        /// <value>
        /// The port version identifier.
        /// </value>
        public int PortVersionId { get; set; }

        /// <summary>
        /// Gets or sets the port identifier.
        /// </summary>
        /// <value>
        /// The port identifier.
        /// </value>
        public short PortId { get; set; }

        /// <summary>
        /// Gets or sets the long name of the display.
        /// </summary>
        /// <value>
        /// The long name of the display.
        /// </value>
        public string LongDisplayName { get; set; }

        #endregion Properties
    }
}