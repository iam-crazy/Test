﻿//-----------------------------------------------------------------------
// <copyright file = "SearchLogicalSequence.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare SearchLogicalSequence.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare SearchLogicalSequence.
    /// </summary>
    public class SearchLogicalSequence
    {
        #region Properties

        /// <summary>
        /// Gets or sets the logical sequence identifier.
        /// </summary>
        /// <value>
        /// The logical sequence identifier.
        /// </value>
        public int LogicalSequenceId { get; set; }

        /// <summary>
        /// Gets or sets the current move identifier.
        /// </summary>
        /// <value>
        /// The current move identifier.
        /// </value>
        public string CurrentMove { get; set; }

        /// <summary>
        /// Gets or sets the next move identifier.
        /// </summary>
        /// <value>
        /// The next move identifier.
        /// </value>
        public string NextMove { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the inactive reason.
        /// </summary>
        /// <value>
        /// The inactive reason.
        /// </value>
        public string Remarks { get; set; }

        #endregion Properties
    }
}