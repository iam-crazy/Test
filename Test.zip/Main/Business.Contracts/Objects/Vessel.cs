﻿//-----------------------------------------------------------------------
// <copyright file = "Vessel.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare Vessel. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare Vessel.
    /// </summary>
    public class Vessel
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the Vessel class.
        /// </summary>
        public Vessel()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int? VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name value.
        /// </value>
        public string LongDisplayName { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name value.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the type of the ownership.
        /// </summary>
        /// <value>
        /// The type of the ownership.
        /// </value>
        public OwnershipType OwnershipType { get; set; }

        /// <summary>
        /// Gets or sets the vessel versions.
        /// </summary>
        /// <value>
        /// The vessel versions.
        /// </value>
        public IList<VesselVersions> VesselVersions { get; set; } = new List<VesselVersions>();

        #endregion Properties
    }
}