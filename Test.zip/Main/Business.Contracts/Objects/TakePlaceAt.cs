//-----------------------------------------------------------------------
// <copyright file = "TakePlaceAt.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare TakePlaceAt.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Delcare Take Place.
    /// </summary>
    public class TakePlaceAt : UserInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TakePlaceAt"/> class.
        /// </summary>
        public TakePlaceAt()
        {
        }

        /// <summary>
        /// Gets or sets the take place at identifier.
        /// </summary>
        /// <value>
        /// The take place at identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}