﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialData.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialData.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Declare ReferentialData.
    /// </summary>
    public class ReferentialData : UserInformation
    {
        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the business cycle identifier.
        /// </summary>
        /// <value>
        /// The business cycle identifier.
        /// </value>
        public BusinessCycle BusinessCycle { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The Referential code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The Activity type.
        /// </value>
        public ActivityType ActivityType { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the action.
        /// </summary>
        /// <value>
        /// The action.
        /// </value>
        public ActivityAction ActivityAction { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public TakePlaceAt ActivityLocation { get; set; }

        /// <summary>
        /// Gets or sets the full empty.
        /// </summary>
        /// <value>
        /// The full empty.
        /// </value>
        public FullEmpty FullEmpty { get; set; }

        /// <summary>
        /// Gets or sets the logistics status.
        /// </summary>
        /// <value>
        /// The logistics status.
        /// </value>
        public LogisticsStatus LogisticsStatus { get; set; }

        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        public ActivityCategory ActivityCategory { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [display to customer].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [display to customer]; otherwise, <c>false</c>.
        /// </value>
        public bool IsDisplayToCustomer { get; set; }

        /// <summary>
        /// Gets or sets the glossary.
        /// </summary>
        /// <value>
        /// The glossary.
        /// </value>
        public string Glossary { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> If this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the reason.
        /// </summary>
        /// <value>
        /// The reason.
        /// </value>
        public string Reason { get; set; }

        /// <summary>
        /// Gets or sets the Referential Validation Rule list.
        /// </summary>
        /// <value>
        /// The referential validation rule list.
        /// </value>
        public IList<ReferentialValidationRule> ReferentialValidationRules { get; set; }

        /// <summary>
        /// Gets or sets the basic requirements.
        /// </summary>
        /// <value>
        /// The basic requirements.
        /// </value>
        public IList<BasicRequirement> BasicRequirements { get; set; }

        /// <summary>
        /// Gets or sets the edi mapping.
        /// </summary>
        /// <value>
        /// The edi mapping.
        /// </value>
        public IList<EDIMapping> EDIMappings { get; set; }

        #endregion Properties
    }
}