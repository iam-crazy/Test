//-----------------------------------------------------------------------
// <copyright file = "EquipmentNote.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentNote.</summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Defines the <see cref="EquipmentNote" />
    /// </summary>
    public partial class EquipmentNote
    {
        #region Properties

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the equipment notes identifier.
        /// </summary>
        /// <value>
        /// The equipment notes identifier.
        /// </value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public UserBase UserBase { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public int UserId { get; set; }

        #endregion
    }
}
