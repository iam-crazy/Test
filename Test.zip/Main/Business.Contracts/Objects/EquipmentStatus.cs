//-----------------------------------------------------------------------
// <copyright file = "EquipmentStatus.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentStatus.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare EquipmentStatus.
    /// </summary>
    public class EquipmentStatus : UserInformation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the EquipmentStatus class.
        /// </summary>
        public EquipmentStatus()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the equipment status identifier.
        /// </summary>
        /// <value>
        /// The equipment status identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The equipment code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        #endregion Properties
    }
}