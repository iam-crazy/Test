﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityFilter.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityFilter.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare EquipmentActivityFilter.
    /// </summary>
    public class EquipmentActivityFilter
    {
        #region Properties

        /// <summary>
        /// Gets or sets the activity.
        /// </summary>
        /// <value>
        /// The activity.
        /// </value>
        public int? Activity { get; set; }

        /// <summary>
        /// Gets or sets the activity date time.
        /// </summary>
        /// <value>
        /// The activity date time.
        /// </value>
        public DateTime? ActivityDateTime { get; set; }

        /// <summary>
        /// Gets or sets the activity depot.
        /// </summary>
        /// <value>
        /// The activity depot.
        /// </value>
        public int? ActivityDepot { get; set; }

        /// <summary>
        /// Gets or sets the activity status.
        /// </summary>
        /// <value>
        /// The activity status.
        /// </value>
        public string ActivityStatus { get; set; }

        /// <summary>
        /// Gets or sets the activity terminal.
        /// </summary>
        /// <value>
        /// The activity terminal.
        /// </value>
        public int? ActivityTerminal { get; set; }

        /// <summary>
        /// Gets or sets the BL number.
        /// </summary>
        /// <value>
        /// The BL number.
        /// </value>
        public string BLNumber { get; set; }

        /// <summary>
        /// Gets or sets the booking number.
        /// </summary>
        /// <value>
        /// The booking number.
        /// </value>
        public string BookingNumber { get; set; }

        /// <summary>
        /// Gets or sets the type of the date.
        /// </summary>
        /// <value>
        /// The type of the date.
        /// </value>
        public bool? DateType { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public string EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment number.
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public long? EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the equipment ISO.
        /// </summary>
        /// <value>
        /// The equipment ISO.
        /// </value>
        public int? EquipmentISO { get; set; }

        /// <summary>
        /// Gets or sets the type of the equipment size.
        /// </summary>
        /// <value>
        /// The type of the equipment size.
        /// </value>
        public int? EquipmentSizeType { get; set; }

        /// <summary>
        /// Gets or sets the feeder voyage.
        /// </summary>
        /// <value>
        /// The feeder voyage.
        /// </value>
        public string FeederVoyage { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets the is SOC.
        /// </summary>
        /// <value>
        /// The is SOC.
        /// </value>
        public bool? HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the is enable.
        /// </summary>
        /// <value>
        /// The is enable.
        /// </value>
        public bool? IsEnable { get; set; }

        /// <summary>
        /// Gets or sets the leasing company reference.
        /// </summary>
        /// <value>
        /// The leasing company reference.
        /// </value>
        public string LeasingCompanyReference { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public int? Location { get; set; }

        /// <summary>
        /// Gets or sets the logged on date.
        /// </summary>
        /// <value>
        /// The logged on date.
        /// </value>
        public DateTime? LoggedOnDate { get; set; }

        /// <summary>
        /// Gets or sets the MSC authorization reference.
        /// </summary>
        /// <value>
        /// The MSC authorization reference.
        /// </value>
        public string MSCAuthorizationReference { get; set; }

        /// <summary>
        /// Gets or sets the index of the page.
        /// </summary>
        /// <value>
        /// The index of the page.
        /// </value>
        public int PageIndex { get; set; }

        /// <summary>
        /// Gets or sets the size of the page.
        /// </summary>
        /// <value>
        /// The size of the page.
        /// </value>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or sets the pick up reference.
        /// </summary>
        /// <value>
        /// The pick up reference.
        /// </value>
        public string PickupReference { get; set; }

        /// <summary>
        /// Gets or sets the place of delivery.
        /// </summary>
        /// <value>
        /// The place of delivery.
        /// </value>
        public int? PlaceOfDelivery { get; set; }

        /// <summary>
        /// Gets or sets the place of final destination.
        /// </summary>
        /// <value>
        /// The place of final destination.
        /// </value>
        public int? PlaceOfFinalDestination { get; set; }

        /// <summary>
        /// Gets or sets the place of receipt.
        /// </summary>
        /// <value>
        /// The place of receipt.
        /// </value>
        public int? PlaceOfReceipt { get; set; }

        /// <summary>
        /// Gets or sets the port of discharge.
        /// </summary>
        /// <value>
        /// The port of discharge.
        /// </value>
        public int? PortOfDischarge { get; set; }

        /// <summary>
        /// Gets or sets the port of loading.
        /// </summary>
        /// <value>
        /// The port of loading.
        /// </value>
        public int? PortOfLoading { get; set; }

        /// <summary>
        /// Gets or sets the return depot.
        /// </summary>
        /// <value>
        /// The return depot.
        /// </value>
        public int? ReturnDepot { get; set; }

        /// <summary>
        /// Gets or sets the return equipment authorization number.
        /// </summary>
        /// <value>
        /// The return equipment authorization number.
        /// </value>
        public string ReturnEquipmentAuthorizationNumber { get; set; }

        /// <summary>
        /// Gets or sets the return location.
        /// </summary>
        /// <value>
        /// The return location.
        /// </value>
        public int? ReturnLocation { get; set; }

        /// <summary>
        /// Gets or sets the return terminal.
        /// </summary>
        /// <value>
        /// The return terminal.
        /// </value>
        public int? ReturnTerminal { get; set; }

        /// <summary>
        /// Gets or sets the SCAC code.
        /// </summary>
        /// <value>
        /// The SCAC code.
        /// </value>
        public int? SCACCode { get; set; }

        /// <summary>
        /// Gets or sets the seal number.
        /// </summary>
        /// <value>
        /// The seal number.
        /// </value>
        public string SealNumber { get; set; }

        /// <summary>
        /// Gets or sets the shipping instruction number.
        /// </summary>
        /// <value>
        /// The shipping instruction number.
        /// </value>
        public string ShippingInstructionNumber { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [show cancel].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [show cancel]; otherwise, <c>false</c>.
        /// </value>
        public bool? ShowCancel { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date Time.
        /// </value>
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Gets or sets the transshipment port.
        /// </summary>
        /// <value>
        /// The transshipment port.
        /// </value>
        public int? TransshipmentPort { get; set; }

        /// <summary>
        /// Gets or sets the valid.
        /// </summary>
        /// <value>
        /// The valid value.
        /// </value>
        public bool? Valid { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>
        public string ValidationRule { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>
        public int? ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the vessel.
        /// </summary>
        /// <value>
        /// The vessel.
        /// </value>
        public int? Vessel { get; set; }

        /// <summary>
        /// Gets or sets the voyage.
        /// </summary>
        /// <value>
        /// The voyage.
        /// </value>
        public int? Voyage { get; set; }

        #endregion
    }
}
