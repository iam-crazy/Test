﻿//-----------------------------------------------------------------------
// <copyright file = "EDIMapping.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EDIMapping. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare EDIMapping.
    /// </summary>
    public class EDIMapping : UserInformation
    {
        #region Properties

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the edi mapping identifier.
        /// </summary>
        /// <value>
        /// The edi mapping identifier.
        /// </value>
        public short EDIMappingId { get; set; }        

        /// <summary>
        /// Gets or sets the equipment status.
        /// </summary>
        /// <value>
        /// The equipment status.
        /// </value>
        public EquipmentStatus EquipmentStatus { get; set; }

        /// <summary>
        /// Gets or sets the shipment status.
        /// </summary>
        /// <value>
        /// The shipment status.
        /// </value>
        public ShipmentStatus ShipmentStatus { get; set; }

        #endregion Properties
    }
}