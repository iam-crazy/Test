﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentSizeType.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentSizeType. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare EquipmentSizeType.
    /// </summary>
    public class EquipmentSizeType
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the EquipmentSizeType class.
        /// </summary>
        public EquipmentSizeType()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the size of the equipment.
        /// </summary>
        /// <value>
        /// The size of the equipment.
        /// </value>
        public string EquipmentSize { get; set; }

        /// <summary>
        /// Gets or sets the size type identifier.
        /// </summary>
        /// <value>
        /// The size type identifier.
        /// </value>
        public short EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets the type of the equipment.
        /// </summary>
        /// <value>
        /// The type of the equipment.
        /// </value>
        public string EquipmentType { get; set; }

        /// <summary>
        /// Gets or sets the type of the size.
        /// </summary>
        /// <value>
        /// The type of the size.
        /// </value>
        public string SizeType { get; set; }

        #endregion
    }
}
