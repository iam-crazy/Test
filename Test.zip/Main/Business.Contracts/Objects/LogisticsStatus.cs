﻿//-----------------------------------------------------------------------
// <copyright file = "LogisticsStatus.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogisticsStatus.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare LogisticsStatus.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.Objects.GeneralCode" />
    public class LogisticsStatus : GeneralCode
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LogisticsStatus"/> class.
        /// </summary>
        public LogisticsStatus()
        {
        }

        /// <summary>
        /// Gets or sets the is mapped.
        /// </summary>
        /// <value>
        /// The is mapped.
        /// </value>
        public bool? IsGateIn { get; set; }
    }
}