﻿//-----------------------------------------------------------------------
// <copyright file = "VesselVersions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare VesselVersions. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare VesselVersions.
    /// </summary>
    public class VesselVersions
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="VesselVersions"/> class.
        /// </summary>
        public VesselVersions()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the vessel code.
        /// </summary>
        /// <value>
        /// The vessel code.
        /// </value>
        public int VesselVersionId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int? VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name value.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string LongDisplayName { get; set; }

        /// <summary>
        /// Gets or sets the valid from UTC.
        /// </summary>
        /// <value>
        /// The valid from UTC.
        /// </value>
        public DateTime ValidFromUtc { get; set; }

        /// <summary>
        /// Gets or sets the valid to UTC.
        /// </summary>
        /// <value>
        /// The valid to UTC.
        /// </value>
        public DateTime? ValidToUtc { get; set; }

        /// <summary>
        /// Gets or sets the type of the ownership.
        /// </summary>
        /// <value>
        /// The type of the ownership.
        /// </value>
        public OwnershipType OwnershipType { get; set; }

        #endregion Properties
    }
}