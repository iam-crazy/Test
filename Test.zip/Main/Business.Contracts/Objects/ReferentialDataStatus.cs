﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataStatus.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ReferentialDataStatus. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare ReferentialDataStatus.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.Objects.UserInformation" />
    public class ReferentialDataStatus : UserInformation
    {
        /// <summary>
        /// Gets or sets the is mapped.
        /// </summary>
        /// <value>
        /// The is mapped.
        /// </value>
        public bool? IsGateIn { get; set; }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public int ActivityReferentialId { get; set; }
    }
}