﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentISOCode.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentISOCode. </summary>
//-----------------------------------------------------------------------       
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare Equipment ISO Code.
    /// </summary>
    public class EquipmentISOCode
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentISOCode"/> class.
        /// </summary>
        public EquipmentISOCode()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the ISO code identifier.
        /// </summary>
        /// <value>
        /// The ISO code identifier.
        /// </value>
        public int EquipmentSizeTypeCodeId { get; set; }

        /// <summary>
        /// Gets or sets the equipment type identifier.
        /// </summary>
        /// <value>
        /// The equipment type identifier.
        /// </value>
        public short EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets the ISO code.
        /// </summary>
        /// <value>
        /// The ISO code.
        /// </value>
        public string MscCode { get; set; }

        #endregion Properties
    }
}