﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataFilter.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataFilter.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare ReferentialDataFilter.
    /// </summary>
    public class ReferentialDataFilter
    {
        #region Properties

        /// <summary>
        /// Gets or sets the action.
        /// </summary>
        /// <value>
        /// The action.
        /// </value>
        public int? Action { get; set; }

        /// <summary>
        /// Gets or sets the activities.
        /// </summary>
        /// <value>
        /// The activities.
        /// </value>
        public IEnumerable<int> Activities { get; set; }

        /// <summary>
        /// Gets or sets the type of the activity.
        /// </summary>
        /// <value>
        /// The type of the activity.
        /// </value>
        public int? ActivityType { get; set; }

        /// <summary>
        /// Gets or sets the categories.
        /// </summary>
        /// <value>
        /// The categories.
        /// </value>
        public IEnumerable<int> Categories { get; set; }

        /// <summary>
        /// Gets or sets the equipment status.
        /// </summary>
        /// <value>
        /// The equipment status.
        /// </value>
        public int? EquipmentStatus { get; set; }

        /// <summary>
        /// Gets or sets the full empty.
        /// </summary>
        /// <value>
        /// The full empty.
        /// </value>
        public int? FullEmpty { get; set; }

        /// <summary>
        /// Gets or sets the group code.
        /// </summary>
        /// <value>
        /// The group code.
        /// </value>
        public int? GroupCode { get; set; }

        /// <summary>
        /// Gets or sets the is display to customer.
        /// </summary>
        /// <value>
        /// The is display to customer.
        /// </value>
        public bool? IsDisplayToCustomer { get; set; }

        /// <summary>
        /// Gets or sets the is mapped.
        /// </summary>
        /// <value>
        /// The is mapped.
        /// </value>
        public bool? IsMapped { get; set; }

        /// <summary>
        /// Gets or sets the is validation rule active.
        /// </summary>
        /// <value>
        /// The is validation rule active.
        /// </value>
        public bool? IsValidationRuleActive { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public int? Location { get; set; }

        /// <summary>
        /// Gets or sets the requirement fields.
        /// </summary>
        /// <value>
        /// The requirement fields.
        /// </value>
        public IEnumerable<int> RequirementFields { get; set; }

        /// <summary>
        /// Gets or sets the requirement usage.
        /// </summary>
        /// <value>
        /// The requirement usage.
        /// </value>
        public int? RequirementUsage { get; set; }

        /// <summary>
        /// Gets or sets the shipment status.
        /// </summary>
        /// <value>
        /// The shipment status.
        /// </value>
        public IEnumerable<int> ShipmentStatus { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public bool? Status { get; set; }

        /// <summary>
        /// Gets or sets the validation rule.
        /// </summary>
        /// <value>
        /// The validation rule.
        /// </value>
        public int? ValidationRule { get; set; }

        /// <summary>
        /// Gets or sets the business cycle.
        /// </summary>
        /// <value>
        /// The business cycle.
        /// </value>
        public int? BusinessCycle { get; set; }

        #endregion Properties
    }
}