﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRule.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRule. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare ValidationRule.
    /// </summary>
    public class ValidationRule : ValidationRuleBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ValidationRule"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [activity code change status].
        /// </summary>
        /// <value>
        /// <c>true</c> if [activity code change status]; otherwise, <c>false</c>.
        /// </value>
        public bool ActivityCodeChangeStatus { get; set; }

        /// <summary>
        /// Gets or sets the Remarks.
        /// </summary>
        /// <value>
        /// The Remarks.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the Type.
        /// </summary>
        /// <value>
        /// The Activity Type.
        /// </value>
        public ValidationRuleType ValidationRuleType { get; set; }

        /// <summary>
        /// Gets or sets the valid error result.
        /// </summary>
        /// <value>
        /// The valid error result.
        /// </value>
        public ValidationRuleErrorResult ValidationRuleErrorResult { get; set; }

        /// <summary>
        /// Gets or sets the error description.
        /// </summary>
        /// <value>
        /// The invalid error description.
        /// </value>
        public string ErrorDescription { get; set; }        

        #endregion Properties
    }
}