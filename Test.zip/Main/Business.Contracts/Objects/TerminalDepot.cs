﻿//-----------------------------------------------------------------------
// <copyright file = "TerminalDepot.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare TerminalDepot. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare TerminalDepot.
    /// </summary>
    public class TerminalDepot
    {
        #region Properties

        /// <summary>
        /// Gets or sets the equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The equipment handling facility identifier.
        /// </value>
        public int EquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int TerminalDepotId { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string LongDisplayName { get; set; }

        #endregion Properties
    }
}