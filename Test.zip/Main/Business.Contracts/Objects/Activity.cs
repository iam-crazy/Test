﻿//-----------------------------------------------------------------------
// <copyright file = "Activity.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare Activity. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare Activity.
    /// </summary>
    public class Activity
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the Activity class.
        /// </summary>
        public Activity()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public short ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The Activity code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The activity type.
        /// </value>
        public ActivityType ActivityType { get; set; }

        #endregion Properties
    }
}