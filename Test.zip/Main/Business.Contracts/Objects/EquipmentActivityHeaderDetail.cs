﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityHeaderDetail.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityHeaderDetail. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare EquipmentActivityHeaderDetail.
    /// </summary>
    public class EquipmentActivityHeaderDetail
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Count.
        /// </summary>
        /// <value>
        /// The count.
        /// </value>
        public long Count { get; set; }

        /// <summary>
        /// Gets or sets the ErrorDescription.
        /// </summary>
        /// <value>
        /// The error description.
        /// </value>
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Gets or sets the RuleNumber.
        /// </summary>
        /// <value>
        /// The rule number.
        /// </value>
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the ValidationId.
        /// </summary>
        /// <value>
        /// The validation identifier.
        /// </value>
        public int? ValidationId { get; set; }

        #endregion
    }
}
