﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentCategory.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentCategory.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare EquipmentCategory.
    /// </summary>
    public class EquipmentCategory
    {
        /// <summary>
        /// Gets or sets the equipment category identifier.
        /// </summary>
        /// <value>
        /// The equipment category identifier.
        /// </value>
        public int EquipmentCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}
