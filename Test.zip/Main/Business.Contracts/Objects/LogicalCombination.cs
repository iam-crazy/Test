﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombination.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare LogicalCombination. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare LogicalCombination.
    /// </summary>
    public class LogicalCombination : UserInformation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the LogicalCombination class.
        /// </summary>
        public LogicalCombination()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the logical combination identifier.
        /// </summary>
        /// <value>
        /// The logical combination identifier.
        /// </value>
        public int LogicalActivityId { get; set; }

        /// <summary>
        /// Gets or sets the event identifier.
        /// </summary>
        /// <value>
        /// The event identifier.
        /// </value>
        public Activity FromActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the move identifier.
        /// </summary>
        /// <value>
        /// The move identifier.
        /// </value>
        public Activity ToActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>
        /// The position.
        /// </value>
        public string ActivityType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="LogicalCombination"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the purpose.
        /// </summary>
        /// <value>
        /// The purpose.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the row status.
        /// </summary>
        /// <value>
        /// The row status.
        /// </value>
        public string RowStatus { get; set; }

        #endregion Properties
    }
}