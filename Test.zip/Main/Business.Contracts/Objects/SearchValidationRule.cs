﻿//-----------------------------------------------------------------------
// <copyright file = "SearchValidationRule.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare SearchValidationRule. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare SearchValidationRule.
    /// </summary>
    public class SearchValidationRule
    {
        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the rule number.
        /// </summary>
        /// <value>
        /// The rule number.
        /// </value>
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public string Group { get; set; }

        /// <summary>
        /// Gets or sets the short Description.
        /// </summary>
        /// <value>
        /// The short Description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the valid from date.
        /// </summary>
        /// <value>
        /// The valid from date.
        /// </value>
        public DateTime ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to date.
        /// </summary>
        /// <value>
        /// The valid to date.
        /// </value>
        public DateTime? ValidTo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="SearchValidationRule"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the Type.
        /// </summary>
        /// <value>
        /// The Activity Type.
        /// </value>
        public string ActivityType { get; set; }

        #endregion Properties
    }
}