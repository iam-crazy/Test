﻿//-----------------------------------------------------------------------
// <copyright file = "SearchReferentialData.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare SearchReferentialData. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare SearchReferentialData.
    /// </summary>
    public class SearchReferentialData
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the SearchReferentialData class.
        /// </summary>
        public SearchReferentialData()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The Referential code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the type of the activity.
        /// </summary>
        /// <value>
        /// The type of the activity.
        /// </value>
        public TakePlaceAt ActivityType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>
        ///   <c>true</c> If this instance is active; otherwise, <c>false</c>.
        /// </value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the action.
        /// </summary>
        /// <value>
        /// The action.
        /// </value>
        public ActivityAction ActivityAction { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public TakePlaceAt ActivityLocation { get; set; }

        /// <summary>
        /// Gets or sets the glossary.
        /// </summary>
        /// <value>
        /// The glossary.
        /// </value>
        public string Glossary { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the full empty.
        /// </summary>
        /// <value>
        /// The full empty.
        /// </value>
        public GeneralCode FullEmpty { get; set; }

        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        public ActivityCategory ActivityCategory { get; set; }

        /// <summary>
        /// Gets or sets the business cycle.
        /// </summary>
        /// <value>
        /// The business cycle.
        /// </value>
        public BusinessCycle BusinessCycle { get; set; }

        #endregion Properties
    }
}