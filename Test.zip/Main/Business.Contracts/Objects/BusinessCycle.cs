//-----------------------------------------------------------------------
// <copyright file = "BusinessCycle.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare BusinessCycle.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare BusinessCycle.
    /// </summary>
    public class BusinessCycle : UserInformation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessCycle"/> class.
        /// </summary>
        public BusinessCycle()
        {
        }

        /// <summary>
        /// Gets or sets the business cycle identifier.
        /// </summary>
        /// <value>
        /// The business cycle identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}