﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityError.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityError. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare EquipmentActivityError.
    /// </summary>
    public class EquipmentActivityError
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the EquipmentActivityError class.
        /// </summary>
        public EquipmentActivityError()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /////// <summary>
        /////// Gets or sets the validation rule identifier.
        /////// </summary>
        /////// <value>
        /////// The validation rule identifier.
        /////// </value>
        ////public int ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>
        public ValidationRule ValidationRule { get; set; } = new ValidationRule();

        /// <summary>
        /// Gets or sets the error description.
        /// </summary>
        /// <value>
        /// The error description.
        /// </value>
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Gets or sets the rule.
        /// </summary>
        /// <value>
        /// The error rule.
        /// </value>
        public string Rule { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the updated by.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the updated on.
        /// </summary>
        /// <value>
        /// The updated on.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        #endregion Properties
    }
}