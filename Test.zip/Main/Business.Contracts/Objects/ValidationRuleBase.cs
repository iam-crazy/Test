﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleBase.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleBase. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare ValidationRule.
    /// </summary>
    public class ValidationRuleBase : UserInformation
    {
        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public short ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the rule number.
        /// </summary>
        /// <value>
        /// The rule number.
        /// </value>
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the short Description.
        /// </summary>
        /// <value>
        /// The short Description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public ValidationRuleGroup ValidationRuleGroup { get; set; }

        /// <summary>
        /// Gets or sets the valid from date.
        /// </summary>
        /// <value>
        /// The valid from date.
        /// </value>
        public DateTime ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to date.
        /// </summary>
        /// <value>
        /// The valid to date.
        /// </value>
        public DateTime? ValidTo { get; set; }

        #endregion Properties
    }
}