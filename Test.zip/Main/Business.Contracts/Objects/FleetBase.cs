﻿//-----------------------------------------------------------------------
// <copyright file = "FleetBase.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare FleetBase. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Defines the <see cref="FleetBase" />
    /// </summary>
    public class FleetBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the equipment iso identifier.
        /// </summary>
        /// <value>
        /// The equipment iso identifier.
        /// </value>
        public int EquipmentISOId { get; set; }

        /// <summary>
        /// Gets or sets the equipment number.
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the equipment size type identifier.
        /// </summary>
        /// <value>
        /// The equipment size type identifier.
        /// </value>
        public int EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has soc.
        /// </summary>
        /// <value>
        ///   <c>true</c> If this instance has soc; otherwise, <c>false</c>.
        /// </value>
        public bool HasSOC { get; set; }

        #endregion Properties
    }
}