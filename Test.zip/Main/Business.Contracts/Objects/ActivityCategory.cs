﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityCategory.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityCategory. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare ActivityCategory.
    /// </summary>
    public class ActivityCategory : UserInformation
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ActivityCategory class.
        /// </summary>
        public ActivityCategory()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The General code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        #endregion Properties
    }
}