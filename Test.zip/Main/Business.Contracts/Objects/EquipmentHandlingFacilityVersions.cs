﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentHandlingFacilityVersions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentHandlingFacilityVersions. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare EquipmentHandlingFacilityVersions.
    /// </summary>
    public class EquipmentHandlingFacilityVersions
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the EquipmentHandlingFacilityVersions class.
        /// </summary>
        public EquipmentHandlingFacilityVersions()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the equipment handling facility identifier.
        /// </summary>
        /// <value>
        /// The equipment handling facility identifier.
        /// </value>
        public int EquipmentHandlingFacilityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment handling facility version identifier.
        /// </summary>
        /// <value>
        /// The equipment handling facility version identifier.
        /// </value>
        public int EquipmentHandlingFacilityVersionId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The Equipment handling name.
        /// </value>
        public string Name { get; set; }

        #endregion Properties
    }
}