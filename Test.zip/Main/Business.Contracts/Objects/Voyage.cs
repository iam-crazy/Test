﻿//-----------------------------------------------------------------------
// <copyright file = "Voyage.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare Voyage. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare Voyage.
    /// </summary>
    public class Voyage
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the Voyage class.
        /// </summary>
        public Voyage()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the voyage identifier.
        /// </summary>
        /// <value>
        /// The voyage identifier.
        /// </value>
        public int VoyageId { get; set; }

        /// <summary>
        /// Gets or sets the name of the voyage.
        /// </summary>
        /// <value>
        /// The name of the voyage.
        /// </value>
        public string VoyageName { get; set; }

        #endregion Properties
    }
}