﻿//-----------------------------------------------------------------------
// <copyright file = "Port.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare Port. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare Port.
    /// </summary>
    public class Port
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the Port class.
        /// </summary>
        public Port()
        {
        }

        #endregion Constructor

        #region Properties      

        /// <summary>
        /// Gets or sets the port identifier.
        /// </summary>
        /// <value>
        /// The port identifier.
        /// </value>
        public short PortId { get; set; }       

        /// <summary>
        /// Gets or sets the long name of the display.
        /// </summary>
        /// <value>
        /// The long name of the display.
        /// </value>
        public string LongDisplayName { get; set; }       

        #endregion Properties
    }
}