﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentFleet.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentFleet. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    /// <summary>
    /// Declare EquipmentFleet.
    /// </summary>
    public class EquipmentFleet
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the EquipmentFleet class.
        /// </summary>
        public EquipmentFleet()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public EquipmentISOCode EquipmentISO { get; set; } = new EquipmentISOCode();

        /// <summary>
        /// Gets or sets the equipment iso identifier.
        /// </summary>
        /// <value>
        /// The equipment iso identifier.
        /// </value>
        public short EquipmentISOId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The equipment code.
        /// </value>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public EquipmentSizeType EquipmentSizeType { get; set; } = new EquipmentSizeType();

        /// <summary>
        /// Gets or sets the equipment size type identifier.
        /// </summary>
        /// <value>
        /// The equipment size type identifier.
        /// </value>
        public short EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is SOC.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is SOC; otherwise, <c>false</c>.
        /// </value>
        public bool HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public long Id { get; set; }

        #endregion
    }
}
