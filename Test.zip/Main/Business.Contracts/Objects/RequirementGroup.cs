//-----------------------------------------------------------------------
// <copyright file = "RequirementGroup.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementGroup.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare RequirementGroup.
    /// </summary>
    public class RequirementGroup : UserInformation
    {
        /// <summary>
        /// Gets or sets the requirement group identifier.
        /// </summary>
        /// <value>
        /// The requirement group identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}