﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialValidationRule.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialValidationRule.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare ReferentialValidationRule.
    /// </summary>
    public class ReferentialValidationRule : UserInformation
    { 
        #region Constructor             

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferentialValidationRule"/> class.
        /// </summary>
        public ReferentialValidationRule()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public short ReferentialValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the referential data identifier.
        /// </summary>
        /// <value>
        /// The referential data identifier.
        /// </value>
        public short ReferentialDataId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>
        public short ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule effective as of date.
        /// </summary>
        /// <value>
        /// The validation rule effective as of date.
        /// </value>
        public DateTime EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets the validation rule disabled as of date.
        /// </summary>
        /// <value>
        /// The validation rule disabled as of date.
        /// </value>
        public DateTime? EffectiveTo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ReferentialValidationRule"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }        

        /// <summary>
        /// Gets or sets the referential data.
        /// </summary>
        /// <value>
        /// The referential data.
        /// </value>
        public ReferentialData ReferentialData { get; set; }

        /// <summary>
        /// Gets or sets the validation rule.
        /// </summary>
        /// <value>
        /// The validation rule.
        /// </value>
        public ValidationRule ValidationRule { get; set; } = new ValidationRule();

        #endregion Properties
    }
}