﻿//-----------------------------------------------------------------------
// <copyright file = "BasicRequirement.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare BasicRequirement. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts.Objects
{
    using System;

    /// <summary>
    /// Declare BasicRequirement.
    /// </summary>
    public class BasicRequirement : UserInformation
    {
        #region Properties

        /// <summary>
        /// Gets or sets the basic status.
        /// </summary>
        /// <value>
        /// The basic status.
        /// </value>
        public string BasicStatus { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int BasicRequirementId { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementField RequirementField { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementField RequirementFieldTwo { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementField RequirementFieldThree { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementUsage RequirementUsage { get; set; }

        #endregion Properties
    }
}