﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentNoteService.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IEquipmentNoteService.</summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Msc.Framework.Common.Model;
    using Msc.Logistics.EME.Service.Business.Contracts.Objects;

    /// <summary>
    /// Defines the <see cref="IEquipmentNoteService" />
    /// </summary>
    public interface IEquipmentNoteService
    {
        /// <summary>
        /// Gets the equipment note.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns equipment note.</returns>
        Task<IList<EquipmentNote>> GetEquipmentNote(int equipmentNote);

        /// <summary>
        /// Saves the specified equipment note data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipment note data.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(EquipmentNote equipmentNoteData);
    }
}
