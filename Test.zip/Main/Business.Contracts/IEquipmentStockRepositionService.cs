﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentStockRepositionService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IEquipmentStockRepositionService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Threading.Tasks;
    using Msc.Logistics.EME.Service.Business.Contracts.Objects;

    /// <summary>
    /// Declare IEquipmentStockRepositionService.
    /// </summary>
    public interface IEquipmentStockRepositionService
    {
        /// <summary>
        /// Gets the logistics status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <returns>Returns the logistic status.</returns>
        Task<LogisticsStatus> GetLogisticsStatus(int activityId);
    }
}