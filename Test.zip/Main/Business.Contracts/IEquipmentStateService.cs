﻿//-----------------------------------------------------------------------
// <copyright file = "IEquipmentStateService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IEquipmentStateService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IEquipmentStateService.
    /// </summary>
    public interface IEquipmentStateService
    {
        /// <summary>
        /// Searches the equipment states.
        /// </summary>
        /// <returns>Returns equipment states.</returns>
        Task<IList<EquipmentState>> SearchEquipmentStates();

        /// <summary>
        /// Saves the specified equipment state data.
        /// </summary>
        /// <param name="equipmentStateData">The equipment state data.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(EquipmentState equipmentStateData);

        /// <summary>
        /// Deletes the specified equipment state identifier.
        /// </summary>
        /// <param name="equipmentStateId">The equipment state identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        Task<BusinessOutcome> Delete(int equipmentStateId, int userId);
    }
}