﻿//-----------------------------------------------------------------------
// <copyright file = "IRequirementFieldService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IRequirementFieldService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IRequirementFieldService.
    /// </summary>
    public interface IRequirementFieldService
    {
        /// <summary>
        /// Gets the requirement fields.
        /// </summary>
        /// <returns>Return RequirementField.</returns>
        Task<IList<RequirementField>> GetRequirementFields();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="requirementFieldData">The requirementFieldData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(RequirementField requirementFieldData);

        /// <summary>
        /// Deletes the specified requirement field identifier.
        /// </summary>
        /// <param name="requirementFieldId">The requirement field identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int requirementFieldId, int userId);
    }
}