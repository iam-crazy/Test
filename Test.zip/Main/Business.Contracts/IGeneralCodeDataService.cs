﻿//-----------------------------------------------------------------------
// <copyright file = "IGeneralCodeDataService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IGeneralCodeDataService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using Objects;

    /// <summary>
    /// Declare IGeneralCodeDataService.
    /// </summary>
    public interface IGeneralCodeDataService
    {
        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="code">The general code.</param>
        /// <param name="description">The description.</param>
        /// <param name="referenceName">Name of the reference.</param>
        /// <param name="limit">The limit.</param>
        /// <param name="offset">The offset.</param>
        /// <param name="searchValue">The search value.</param>
        /// <returns>Return the general codes.</returns>
        IList<GeneralCode> GetGeneralCodes(string code, string description, string referenceName, int limit, int offset, string searchValue);
    }
}