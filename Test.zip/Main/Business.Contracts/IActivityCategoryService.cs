﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityCategoryService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityCategoryService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IActivityCategoryService.
    /// </summary>
    public interface IActivityCategoryService
    {
        /// <summary>
        /// Gets the ActivityCategory.
        /// </summary>
        /// <returns>Returns ActivityCategory Lists.</returns>
        Task<IList<ActivityCategory>> GetActivityCategories();

        /// <summary>
        /// Saves the specified ActivityCategory.
        /// </summary>
        /// <param name="data">The ActivityCategory.</param>
        /// <returns>Returns The Save Data.</returns>
        Task<BusinessOutcome> Save(ActivityCategory data);

        /// <summary>
        /// Deletes the specified activity category identifier.
        /// </summary>
        /// <param name="activityCategoryId">The activity category identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int activityCategoryId, int userId);
    }
}