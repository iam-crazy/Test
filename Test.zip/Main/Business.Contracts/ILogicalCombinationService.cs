﻿//-----------------------------------------------------------------------
// <copyright file = "ILogicalCombinationService.cs" company = "MSC">
//   Mediterranean Shipping Company SA - OneVision Project.
// </copyright>
// <summary>
//   Declare ILogicalCombinationService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Framework.Common.Model.Pagination;
    using Objects;

    /// <summary>
    ///  Declare ILogicalCombinationService.
    /// </summary>
    public interface ILogicalCombinationService
    {
        /// <summary>
        /// Saves the specified logical combination.
        /// </summary>
        /// <param name="logicalCombination">The logical combination.</param>
        /// <returns>Returns The logical Data.</returns>
        Task<BusinessOutcome> Save(IList<LogicalCombination> logicalCombination);

        /// <summary>
        /// Gets the logical combination list.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>Returns Logical Combination List.</returns>
        Task<IList<LogicalCombination>> GetLogicalCombinationList(int moveCodeId);      
    }
}