﻿//-----------------------------------------------------------------------
// <copyright file = "IRequirementUsageService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IRequirementUsageService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IRequirementUsageService.
    /// </summary>
    public interface IRequirementUsageService
    {
        /// <summary>
        /// Gets the requirement usages.
        /// </summary>
        /// <returns>Return RequirementUsage.</returns>
        Task<IList<RequirementUsage>> GetRequirementUsages();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="requirementUsageData">The requirementUsageData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(RequirementUsage requirementUsageData);

        /// <summary>
        /// Deletes the specified requirement usage identifier.
        /// </summary>
        /// <param name="requirementUsageId">The requirement usage identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int requirementUsageId, int userId);
    }
}