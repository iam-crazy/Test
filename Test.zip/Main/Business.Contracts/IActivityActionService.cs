﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityActionService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IActivityActionService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    ///  Declare IActivityActionService.
    /// </summary>
    public interface IActivityActionService
    {
        /// <summary>
        /// Gets the ActivityAction.
        /// </summary>
        /// <returns>
        /// Returns ActivityAction Lists.
        /// </returns>
        Task<IList<ActivityAction>> GetActivityActions();

        /// <summary>
        /// Saves the specified ActivityAction.
        /// </summary>
        /// <param name="data">The ActivityAction.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        Task<BusinessOutcome> Save(ActivityAction data);

        /// <summary>
        /// Deletes the specified activity action identifier.
        /// </summary>
        /// <param name="activityActionId">The activity action identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Data.
        /// </returns>
        Task<BusinessOutcome> Delete(int activityActionId, int userId);
    }
}