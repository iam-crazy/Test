﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IValidationRuleService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IValidationRuleService.
    /// </summary>
    public interface IValidationRuleService
    {
        /// <summary>
        /// Gets the validation rules.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <param name="group">The group.</param>
        /// <param name="description">The description.</param>
        /// <param name="validFrom">The valid from.</param>
        /// <param name="validTo">The valid to.</param>
        /// <param name="status">The rule status.</param>
        /// <param name="type">The rule type.</param>
        /// <param name="limit">The rule limit.</param>
        /// <param name="offset">The offset.</param>
        /// <param name="searchValue">The search string.</param>
        /// <returns>Return the validation rules.</returns>
        Task<IList<ValidationRule>> GetValidationRules(int? ruleNumber, string group, string description, DateTime? validFrom, DateTime? validTo, bool? status, string type, int limit, int offset, string searchValue);

        /// <summary>
        /// Saves the specified validation rule.
        /// </summary>
        /// <param name="validationRule">The validation rule.</param>
        /// <returns>Returns The Save Data.</returns>
        Task<BusinessOutcome> Save(ValidationRule validationRule);

        /// <summary>
        /// Gets the validation rule.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Id.</returns>
        Task<ValidationRule> GetValidationRule(int id);

        /// <summary>
        /// Gets the rule number.
        /// </summary>
        /// <returns>Returns Rule Number.</returns>
        Task<string> GenerateRuleNumber();

        /// <summary>
        /// Searches the validation rules.
        /// </summary>
        /// <param name="group">The group parameter.</param>
        /// <param name="id">The id parameter.</param>
        /// <returns>Returns List of validation Rules.</returns>
        Task<IList<ValidationRuleBase>> SearchValidationRules(string group, int id);
    }
}