﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleTypeService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IValidationRuleTypeService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IValidationRuleTypeService.
    /// </summary>
    public interface IValidationRuleTypeService
    {
        /// <summary>
        /// Gets the validation rule types.
        /// </summary>
        /// <returns>Return ValidationRuleType.</returns>
        Task<IList<ValidationRuleType>> GetValidationRuleTypes();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleTypeData">The validationRuleTypeData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(ValidationRuleType validationRuleTypeData);

        /// <summary>
        /// Deletes the specified validation rule type identifier.
        /// </summary>
        /// <param name="validationRuleTypeId">The validation rule type identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int validationRuleTypeId, int userId);
    }
}