﻿//-----------------------------------------------------------------------
// <copyright file = "ITimelineService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ITimelineService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;   
    using Objects;

    /// <summary>
    ///  Declare ITimelineService.
    /// </summary>
    public interface ITimelineService
    {
        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <returns>Returns the equipment activity.</returns>
        Task<IList<EquipmentActivity>> GetEquipmentActivityList(long equipmentActivityId, bool showCancel);        
    }
}