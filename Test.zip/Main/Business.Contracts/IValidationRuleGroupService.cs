﻿//-----------------------------------------------------------------------
// <copyright file = "IValidationRuleGroupService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IValidationRuleGroupService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IValidationRuleGroupService.
    /// </summary>
    public interface IValidationRuleGroupService
    {
        /// <summary>
        /// Gets the validation rule groups.
        /// </summary>
        /// <returns>Return ValidationRuleGroup.</returns>
        Task<IList<ValidationRuleGroup>> GetValidationRuleGroups();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleGroupData">The validationRuleGroupData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(ValidationRuleGroup validationRuleGroupData);

        /// <summary>
        /// Deletes the specified validation rule group identifier.
        /// </summary>
        /// <param name="validationRuleGroupId">The validation rule group identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int validationRuleGroupId, int userId);
    }
}