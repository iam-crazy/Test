﻿//-----------------------------------------------------------------------
// <copyright file = "IReferentialDataService.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IReferentialDataService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Framework.Common.Model.Pagination;
    using Objects;

    /// <summary>
    /// Referential Data Service.
    /// </summary>
    public interface IReferentialDataService
    {
        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>Return the referential list.</returns>
        Task<IList<SearchReferentialData>> GetReferentialList(ReferentialDataFilter referentialData);

        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="isMapped">The is mapped.</param>
        /// <returns>Return the referential list.</returns>
        Task<IList<SearchReferentialData>> GetReferentialList(bool? isMapped);

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Data Based On ID.</returns>
        Task<ReferentialData> GetReferentialData(int id);

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The Referential data.</param>
        /// <returns>Save The Referential Data.</returns>
        Task<BusinessOutcome> Save(ReferentialData data);

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <returns>Return ReferentialData. </returns>
        Task<IList<RequirementField>> GetReferentialFields();

        /// <summary>
        /// Gets the Full Empty Details.
        /// </summary>
        /// <returns>Return FullEmptyDetails. </returns>
        Task<IList<FullEmpty>> GetFullEmptyDetails();

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <returns>Return ReferentialData. </returns>
        Task<IList<RequirementUsage>> GetReferentialUsage();

        /// <summary>
        /// Gets the activity referential list.
        /// </summary>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>Returns The Type Of Activity.</returns>
        Task<IList<Activity>> GetActivityReferentialList(string activityType);

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <returns>Get Mapped Count.</returns>
        Task<Tuple<int, int, int>> SearchQuickAccessCount();

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>Get Mapped Count.</returns>
        Task<Tuple<int, int, int>> GetQuickAccessCount(ReferentialDataFilter referentialData);

        /// <summary>
        /// Gets the referential validation rules.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns the validation rule.</returns>
        Task<IList<ReferentialValidationRule>> GetReferentialValidationRules(int validationRuleId);

        /// <summary>
        /// Updates the business cycle.
        /// </summary>
        /// <param name="referentialStatus">The referential status.</param>
        /// <returns>Returns the updated cycle.</returns>
        Task<BusinessOutcome> UpdateBusinessCycle(ReferentialDataStatus referentialStatus);
    }
}