﻿//-----------------------------------------------------------------------
// <copyright file = "IBusinessCycleService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IBusinessCycleService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Business.Contracts.Objects;
    using Framework.Common.Model;

    /// <summary>
    /// Declare IBusinessCycleService.
    /// </summary>
    public interface IBusinessCycleService
    {
        /// <summary>
        /// Gets the business cycles.
        /// </summary>
        /// <returns>Returns BusinessCycle list.</returns>
        Task<IList<BusinessCycle>> GetBusinessCycles();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <returns>Returns The Save Data.</returns>
        Task<BusinessOutcome> Save(BusinessCycle data);

        /// <summary>
        /// Deletes the specified business cycle identifier.
        /// </summary>
        /// <param name="businessCycleId">The business cycle identifier.</param>
        /// <param name="userId">The user identifier.</param>
        /// <returns>Returns the delete data.</returns>
        Task<BusinessOutcome> Delete(int businessCycleId, int userId);
    }
}