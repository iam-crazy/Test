﻿//-----------------------------------------------------------------------
// <copyright file = "IShipmentStatusService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare IShipmentStatusService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IShipmentStatusService.
    /// </summary>
    public interface IShipmentStatusService
    {
        /// <summary>
        /// Gets the shipment status.
        /// </summary>
        /// <param name="shipmentStatusCodes">The shipment status codes.</param>
        /// <returns>
        /// Returns Shipment status.
        /// </returns>
        Task<IList<ShipmentStatus>> GetShipmentStatus(string shipmentStatusCodes);

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="shipmentStatusData">The shipmentStatusData.</param>
        /// <returns>Return OperationOutcome.</returns>
        Task<BusinessOutcome> Save(ShipmentStatus shipmentStatusData);

        /// <summary>
        /// Deletes the specified shipment status identifier.
        /// </summary>
        /// <param name="shipmentStatusId">The shipment status identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        Task<BusinessOutcome> Delete(int shipmentStatusId, int userId);
    }
}