﻿//-----------------------------------------------------------------------
// <copyright file = "IActivityPlaceService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare IActivityPlaceService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare IActivityPlaceService.
    /// </summary>
    public interface IActivityPlaceService
    {
        /// <summary>
        /// Gets the activity places.
        /// </summary>
        /// <returns>Return ActivityPlace.</returns>
        Task<IList<TakePlaceAt>> GetActivityPlaces();

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="activityLocationData">The activityLocationData.</param>
        /// <returns>Return Operation Outcome.</returns>
        Task<BusinessOutcome> Save(TakePlaceAt activityLocationData);

        /// <summary>
        /// Deletes the specified activity location identifier.
        /// </summary>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Record.</returns>
        Task<BusinessOutcome> Delete(int activityLocationId, int userId);
    }
}