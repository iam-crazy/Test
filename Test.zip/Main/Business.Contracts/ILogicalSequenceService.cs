﻿//-----------------------------------------------------------------------
// <copyright file = "ILogicalSequenceService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ILogicalSequenceService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Framework.Common.Model;
    using Objects;

    /// <summary>
    /// Declare ILogicalSequenceService.
    /// </summary>
    public interface ILogicalSequenceService
    {
        /// <summary>
        /// Saves the specified logical sequence.
        /// </summary>
        /// <param name="logicalSequence">The logical sequence.</param>
        /// <returns>Returns The Save Data.</returns>
        Task<BusinessOutcome> Save(IList<LogicalSequence> logicalSequence);

        /// <summary>
        /// Updates the specified sequence.
        /// </summary>
        /// <param name="sequence">The sequence.</param>
        /// <returns>
        /// Returns the Saved data.
        /// </returns>
        Task<BusinessOutcome> Update(LogicalSequenceUpdate sequence);

        /// <summary>
        /// Gets the logical sequence list.
        /// </summary>
        /// <param name="currentMoveId">The current move identifier.</param>
        /// <returns>Returns Current Move Identifier.</returns>
        Task<IList<LogicalSequence>> GetLogicalSequenceList(int currentMoveId);

        /// <summary>
        /// Gets the logical activity identifier.
        /// </summary>
        /// <param name="logicalActivityId">The logical activity identifier.</param>
        /// <returns>Return the LogicalSequence List.</returns>
        Task<LogicalSequence> GetLogicalActivityId(int logicalActivityId);
    }
}