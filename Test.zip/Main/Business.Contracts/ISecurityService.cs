﻿//-----------------------------------------------------------------------
// <copyright file = "ISecurityService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ISecurityService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Objects;

    /// <summary>
    /// Declare ISecurityService.
    /// </summary>
    public interface ISecurityService
    {
        /// <summary>
        /// Searches the users.
        /// </summary>
        /// <returns>Returns List of users.</returns>
        Task<IList<UserBase>> SearchUsers();

        /// <summary>
        /// Gets the user by identifier.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>Return user Object.</returns>
        Task<UserBase> GetUserById(int userId);
    }
}
