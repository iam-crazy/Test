﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityTypeServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityTypeServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    ///  Declare ActivityTypeServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IActivityActionService}" />
    [TestClass]
    public class ActivityTypeServiceTest : BaseTest<IActivityTypeService>
    {
        /// <summary>
        /// Saves the activity type_ activity type_ expected success status.
        /// </summary>
        /// <returns>Return the activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveActivityType_ActivityType_ExpectedSuccessStatus()
        {
            ////Arrange
            ActivityType activityType = new ActivityType();
            activityType.Code = "GIN";
            activityType.Description = "Gate In";
            activityType.CreatedBy = BusinessTestConstants.UserId;
            activityType.CreatedOn = DateTime.Now;
            activityType.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(activityType);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the activity type_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ActivityTypeList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<ActivityType> result = await Service.GetActivityTypes();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the activity type_ activity type i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteActivityType_ActivityTypeId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userid = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userid);
            int recordId = Convert.ToInt16(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityTypeService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var activityTypeService = new ActivityTypeService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityTypeService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var activityTypeService = new ActivityTypeService(null, new ActivityTypeRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}