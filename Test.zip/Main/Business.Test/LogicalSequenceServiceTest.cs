﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare LogicalSequenceServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare General Code DataService Test.
    /// </summary>
    [TestClass]
    public class LogicalSequenceServiceTest : BaseTest<ILogicalSequenceService>
    {
        /// <summary>
        /// Saves the logical sequence_ logical sequence_ expected success status.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public void SaveLogicalSequence_LogicalSequence_ExpectedSuccessStatus()
        {
            BusinessOutcome output = Service.Save(this.SaveLogicalSequence_LogicalSequence_Object()).Result;
            Assert.IsTrue(output.IdentityValue != "0");
        }

        /// <summary>
        /// Gets the logical sequence.
        /// </summary>
        /// <returns>Returns The identifier.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task LogicalSequenceList_NoParameter_LogicalSequenceList()
        {
            int moveCodeId = 1;
            var logicalSequence = await Service.GetLogicalSequenceList(moveCodeId);
            if (logicalSequence.Count > 0)
            {
                Assert.IsTrue(logicalSequence.Count > 0);
                Assert.IsNotNull(logicalSequence);
            }
        }

        /// <summary>
        /// Updates the logical sequence_ logical sequence_ expected success status.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public void UpdateLogicalSequence_LogicalSequence_ExpectedSuccessStatus()
        {
            var logicalsequence = new LogicalSequenceUpdate()
            {
                LogicalActivityId = 1,
                Remarks = "Export Loaded on Rail",
                Status = true,
                UpdatedBy = -1,
                CreatedBy = -1,
                CreatedOn = DateTime.Now,
                UpdatedOn = DateTime.Now,
                UserName = string.Empty
            };

            BusinessOutcome output = Service.Update(logicalsequence).Result;
            Assert.IsTrue(output.IdentityValue != "0");
        }

        /// <summary>
        /// Logical the sequence_ logical sequence id_ expected valid list.
        /// </summary>
        /// <returns>Returns The identifier.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task LogicalSequence_LogicalSequenceId_ExpectedValidList()
        {
            ////Act
            LogicalSequence result = await Service.GetLogicalActivityId(1);
            ////Assert
            int recordId = Convert.ToInt32(result.LogicalActivityId);
            Assert.IsTrue(recordId != 0);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "shipmentDataService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var shipmentDataService = new LogicalSequenceService(new DbContextScopeFactory(), null, null, null, null, null);
        }

        /////// <summary>
        /////// Tests the record for exception.
        /////// </summary>
        ////[TestMethod]
        ////[ExpectedException(typeof(ArgumentNullException))]
        ////public void GetArgumentNullErrorForRepository()
        ////{
        ////    var shipmentDataService = new LogicalSequenceService(new DbContextScopeFactory(), null, null, null);
        ////}

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "shipmentDataService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var shipmentDataService = new LogicalSequenceService(null, new LogicalSequenceRepository(new AmbientDbContextLocator()), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "logicalSequenceService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentMapperAndMasterData_NoParameter_NullException()
        {
            var logicalSequenceService = new LogicalSequenceService(new DbContextScopeFactory(), new LogicalSequenceRepository(new AmbientDbContextLocator()), null, null, null, null);
        }

        /// <summary>
        /// Logical the sequence save.
        /// </summary>
        /// <returns>Returns The Logical Sequence.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        private List<LogicalSequence> SaveLogicalSequence_LogicalSequence_Object()
        {
            return new List<LogicalSequence>() { new LogicalSequence() { FromActivityReferential = new Activity { ActivityReferentialId = 1, Code = "ELR", Description = "Export Loaded on Rail" }, ToActivityReferential = new Activity { ActivityReferentialId = 1, Code = "OHD", Description = "On Hold" }, Status = true, RowStatus = "A", CreatedBy = 1, CreatedOn = DateTime.Now, EquipmentCategory = new EquipmentCategory { EquipmentCategoryId = 1, Description = "Container" } } };
        }
    }
}