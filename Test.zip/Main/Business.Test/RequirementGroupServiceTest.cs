﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementGroupServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementGroupServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Msc.Framework.Common.Model;
    using Msc.Logistics.EME.Service.Business.Contracts;
    using Msc.Logistics.EME.Service.Business.Contracts.Objects;
    using Msc.Logistics.EME.Service.Business.Test.Constants;

    /// <summary>
    /// Declare RequirementGroupServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IRequirementGroupService}" />
    [TestClass]
    public class RequirementGroupServiceTest : BaseTest<IRequirementGroupService>
    {
        /// <summary>
        /// Saves the requirement group_ requirement group_ expected success status.
        /// </summary>
        /// <returns>Return the requirement group.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveRequirementGroup_RequirementGroup_ExpectedSuccessStatus()
        {
            ////Arrange
            RequirementGroup requirementGroup = new RequirementGroup();
            requirementGroup.Code = "GIN";
            requirementGroup.Description = "Gate In";
            requirementGroup.CreatedBy = BusinessTestConstants.UserId;
            requirementGroup.CreatedOn = DateTime.Now;
            requirementGroup.UserName = string.Empty;

            ////Act
            OperationOutcome result = await Service.Save(requirementGroup);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the requirement group_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the requirement group.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task RequirementGroupList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<RequirementGroup> result = await Service.GetRequirementGroups();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the requirement group_ requirement group i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the requirement group.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteRequirementGroup_RequirementGroupId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            OperationOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "requirementGroupService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var requirementGroupService = new RequirementGroupService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "requirementGroupService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var requirementGroupService = new RequirementGroupService(null, new RequirementGroupRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}