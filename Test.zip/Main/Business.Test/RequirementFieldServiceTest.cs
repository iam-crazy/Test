﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementFieldServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementFieldServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare RequirementFieldServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IRequirementFieldService}" />
    [TestClass]
    public class RequirementFieldServiceTest : BaseTest<IRequirementFieldService>
    {
        /// <summary>
        /// Saves the requirement field_ requirement field_ expected success status.
        /// </summary>
        /// <returns>Return the requirement field.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveRequirementField_RequirementField_ExpectedSuccessStatus()
        {
            ////Arrange
            RequirementField requirementField = new RequirementField();
            requirementField.Code = "GIN";
            requirementField.Description = "Gate In";
            requirementField.CreatedBy = BusinessTestConstants.UserId;
            requirementField.CreatedOn = DateTime.Now;
            requirementField.UserName = string.Empty;
            requirementField.RequirementGroup = new RequirementGroup { Id = 1, Code = "GIN" };

            ////Act
            BusinessOutcome result = await Service.Save(requirementField);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            ////Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the requirement field_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the requirement field.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task RequirementFieldList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<RequirementField> result = await Service.GetRequirementFields();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the requirement field_ requirement field i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the requirement field.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteRequirementField_RequirementFieldId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "requirementFieldService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var requirementFieldService = new RequirementFieldService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "requirementFieldService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var requirementFieldService = new RequirementFieldService(null, new RequirementFieldRepository(new AmbientDbContextLocator()), null, null, null);
        }

        /// <summary>
        /// Saves the requirement field_ requirement field_ expected success status.
        /// </summary>
        /// <returns>Return the requirement field.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public async Task SaveRequirementField_NullValue_ExpectedSuccessStatus()
        {
            BusinessOutcome result = await Service.Save(null);
        }
    }
}