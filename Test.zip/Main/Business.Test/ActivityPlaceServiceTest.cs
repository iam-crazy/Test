﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityPlaceServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityPlaceServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare EquipmentActivityTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IActivityPlaceService}" />
    [TestClass]
    public class ActivityPlaceServiceTest : BaseTest<IActivityPlaceService>
    {
        /// <summary>
        /// Saves the activity place_ activity place_ expected success status.
        /// </summary>
        /// <returns>Return the activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveActivityPlace_ActivityPlace_ExpectedSuccessStatus()
        {
            ////Arrange
            TakePlaceAt activityPlace = new TakePlaceAt();
            activityPlace.Code = "GIN";
            activityPlace.Description = "Gate In";
            activityPlace.CreatedBy = BusinessTestConstants.UserId;
            activityPlace.CreatedOn = DateTime.Now;
            activityPlace.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(activityPlace);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the activity place_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ActivityPlaceList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<TakePlaceAt> result = await Service.GetActivityPlaces();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the activity place_ activity place i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the activity.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteActivityPlace_ActivityPlaceId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userid = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userid);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityPlaceService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var activityPlaceService = new ActivityPlaceService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityPlaceService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var activityPlaceService = new ActivityPlaceService(null, new ActivityPlaceRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}