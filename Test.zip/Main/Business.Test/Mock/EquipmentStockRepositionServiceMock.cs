﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStockRepositionServiceMock.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStockRepositionServiceMock. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System.Net.Http;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using Framework.UI.Rest;

    /// <summary>
    /// Declare EquipmentStockRepositionServiceMock.
    /// </summary>
    public class EquipmentStockRepositionServiceMock : IEquipmentStockRepositionService
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStockRepositionServiceMock"/> class.
        /// </summary>
        /// <param name="httpClient">The HTTP client.</param>
        public EquipmentStockRepositionServiceMock()
        {
        }

        #endregion Constructor

        /// <summary>
        /// Gets the logistics status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <returns>Returns the logistic status list.</returns>
        public Task<LogisticsStatus> GetLogisticsStatus(int activityId)
        {
            return Task.Run(() => new LogisticsStatus() { Code = "LOGISTIC", Id = 93, Description = "Logistic" });
        }
    }
}