﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityCategoryServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityCategoryServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare ActivityCategoryServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IActivityCategoryService}" />
    [TestClass]
    public class ActivityCategoryServiceTest : BaseTest<IActivityCategoryService>
    {
        /// <summary>
        /// Saves the activity category_ activity category_ expected success status.
        /// </summary>
        /// <returns>Returns the activity category list.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveActivityCategory_ActivityCategory_ExpectedSuccessStatus()
        {
            ////Arrange
            ActivityCategory activityCategory = new ActivityCategory();
            activityCategory.Code = "GIN";
            activityCategory.Description = "Gate In";
            activityCategory.CreatedBy = BusinessTestConstants.UserId;
            activityCategory.CreatedOn = DateTime.Now;
            activityCategory.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(activityCategory);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the activity category_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Returns the activity category list.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ActivityCategoryList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<ActivityCategory> result = await Service.GetActivityCategories();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the activity category_ activity category id_ expect deleted object.
        /// </summary>
        /// <returns>Returns the activity category list.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteActivityCategory_ActivityCategoryId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userid = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userid);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityCategoryService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var activityCategoryService = new ActivityCategoryService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityCategoryService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var activityCategoryService = new ActivityCategoryService(null, new ActivityCategoryRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}