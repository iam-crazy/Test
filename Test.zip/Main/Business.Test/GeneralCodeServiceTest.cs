﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare GeneralCodeServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare GeneralCodeServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IGeneralCodeDataService}" />
    [TestClass]
    public class GeneralCodeServiceTest : BaseTest<IGeneralCodeDataService>
    {
        /// <summary>
        /// Generals the status list_ no parameter_ expected valid list.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public void GeneralStatusList_NoParameter_ExpectedValidList()
        {
            ////Arrange
            GeneralCode generalCode = new GeneralCode();
            generalCode.Code = "GIN";
            generalCode.Description = "Gate In";
            generalCode.CreatedBy = BusinessTestConstants.UserId;
            generalCode.CreatedOn = DateTime.Now;
            generalCode.ReferenceName = "Type";
            generalCode.Value = "MOV";

            ////Act
            IList<GeneralCode> result = Service.GetGeneralCodes(null, "Move", "Type", 4, 1, "MOV");

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>        
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "generalCodeDataService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetMapperContext_NoParameter_NullException()
        {
            var generalCodeDataService = new GeneralCodeDataService(null);
        }        
    }
}