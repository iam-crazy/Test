﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleErrorResultServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//  Declare ValidationRuleErrorResultServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    ///  Declare ValidationRuleErrorResultServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IValidationRuleErrorResultService}" />
    [TestClass]
    public class ValidationRuleErrorResultServiceTest : BaseTest<IValidationRuleErrorResultService>
    {
        /// <summary>
        /// Saves the validation rule error result_ validation rule error result_ expected success status.
        /// </summary>
        /// <returns>Return the validation rule error result.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRuleErrorResult_ValidationRuleErrorResult_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRuleErrorResult validationRuleErrorResult = new ValidationRuleErrorResult();
            validationRuleErrorResult.Code = "GIN";
            validationRuleErrorResult.Description = "Gate In";
            validationRuleErrorResult.CreatedBy = BusinessTestConstants.UserId;
            validationRuleErrorResult.CreatedOn = DateTime.Now;
            validationRuleErrorResult.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(validationRuleErrorResult);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            ////Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the validation rule error result_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the validation rule error result.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ValidationRuleErrorResultList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<ValidationRuleErrorResult> result = await Service.GetValidationRuleErrorResults();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the validation rule error result_ validation rule error result i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the validation rule error result.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteValidationRuleErrorResult_ValidationRuleErrorResultId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleErrorResultService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var validationRuleErrorResultService = new ValidationRuleErrorResultService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleErrorResultService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var validationRuleErrorResultService = new ValidationRuleErrorResultService(null, new ValidationRuleErrorResultRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}