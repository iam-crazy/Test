﻿//-----------------------------------------------------------------------
// <copyright file = "BaseTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare BaseTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System.CodeDom.Compiler;
    using System.Configuration;
    using AutoMapper;
    using ChangeLog.Service;
    using Contracts;
    using DataAccess;
    using DataAccess.Contracts;
    using LightInject;
    using Locking.Service.Api.Contracts;
    using Mapping;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare BaseTest.
    /// </summary>
    /// <typeparam name="T">Type Parameter.</typeparam>
    [GeneratedCodeAttribute("Framework", "3.1")]
    public class BaseTest<T>
    {
        /// <summary>
        /// The this.container.
        /// </summary>
        private readonly ServiceContainer containers = ConfiguredContainer.Current;

        /// <summary>
        /// The master data API address.
        /// </summary>
        private string masterDataApiAddress = ConfigurationManager.AppSettings.Get("masterDataApiAddress");

        /// <summary>
        /// The ESR data API address.
        /// </summary>
        private string esrDataApiAddress = ConfigurationManager.AppSettings.Get("esrDataApiAddress");

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseTest{T}"/> class.
        /// </summary>
        public BaseTest()
        {
            this.containers.Register<IGeneralCodeDataService, GeneralCodeDataService>();
            this.containers.Register<IMasterDataService, MasterDataService>();
            this.containers.Register<IEquipmentStockRepositionService, EquipmentStockRepositionServiceMock>();
            this.containers.Register<IReferentialDataService, ReferentialDataService>();
            this.containers.Register<IReferentialDataRepository, ReferentialDataRepository>();
            this.containers.Register<IValidationRuleService, ValidationRuleService>();
            this.containers.Register<IValidationRuleRepository, ValidationRuleRepository>();
            this.containers.Register<IEquipmentActivityService, EquipmentActivityService>();
            this.containers.Register<IEquipmentActivityRepository, EquipmentActivityRepository>();
            this.containers.Register<ILogicalSequenceService, LogicalSequenceService>();
            this.containers.Register<ILogicalSequenceRepository, LogicalSequenceRepository>();
            this.containers.Register<ILogicalCombinationService, LogicalCombinationService>();
            this.containers.Register<ILogicalCombinationRepository, LogicalCombinationRepository>();
            this.containers.Register<IActivityCategoryService, ActivityCategoryService>();
            this.containers.Register<IActivityCategoryRepository, ActivityCategoryRepository>();
            this.containers.Register<IActivityPlaceService, ActivityPlaceService>();
            this.containers.Register<IActivityPlaceRepository, ActivityPlaceRepository>();

            this.containers.Register<IValidationRuleErrorResultService, ValidationRuleErrorResultService>();
            this.containers.Register<IValidationRuleErrorResultRepository, ValidationRuleErrorResultRepository>();
            this.containers.Register<IValidationRuleGroupService, ValidationRuleGroupService>();
            this.containers.Register<IValidationRuleGroupRepository, ValidationRuleGroupRepository>();
            this.containers.Register<IValidationRuleTypeService, ValidationRuleTypeService>();
            this.containers.Register<IValidationRuleTypeRepository, ValidationRuleTypeRepository>();
            this.containers.Register<IActivityActionService, ActivityActionService>();
            this.containers.Register<IActivityActionRepository, ActivityActionRepository>();
            this.containers.Register<IEquipmentStatusService, EquipmentStatusService>();
            this.containers.Register<IEquipmentStatusRepository, EquipmentStatusRepository>();
            this.containers.Register<IShipmentStatusService, ShipmentStatusService>();
            this.containers.Register<IShipmentRepository, ShipmentStatusRepository>();
            this.containers.Register<IActivityTypeService, ActivityTypeService>();
            this.containers.Register<IActivityTypeRepository, ActivityTypeRepository>();
            this.containers.Register<IRequirementUsageService, RequirementUsageService>();
            this.containers.Register<IRequirementUsageRepository, RequirementUsageRepository>();
            this.containers.Register<IRequirementFieldService, RequirementFieldService>();
            this.containers.Register<IRequirementFieldRepository, RequirementFieldRepository>();
            this.containers.Register<IRequirementGroupService, RequirementGroupService>();
            this.containers.Register<IRequirementGroupRepository, RequirementGroupRepository>();
            this.containers.Register<IEquipmentStateService, EquipmentStateService>();
            this.containers.Register<IEquipmentStateRepository, EquipmentStateRepository>();
            this.containers.Register<ITimelineService, TimelineService>();
            this.containers.Register<ITimelineRepository, TimelineRepository>();
            this.containers.Register(factory => new MasterDataHttpClient(this.masterDataApiAddress, "1"), new PerContainerLifetime());
            this.containers.Register(factory => new ESRDataHttpClient(this.esrDataApiAddress, "1"), new PerContainerLifetime());
           //// this.containers.Register<IChangeLog, ChangeLog>();
            this.containers.Register<IChangeLog>(c => null);
            this.containers.RegisterInstance(new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<AutoMapperProfile>();
            }));

            // Locking
            string lockApiBaseAddress = ConfigurationManager.AppSettings.Get("LockApiAddress");
            this.containers.Register(factory => new LockHttpClient(lockApiBaseAddress));
            this.containers.Register<ILockService, LockService>();

            this.containers.Register(sf => sf.GetInstance<MapperConfiguration>().CreateMapper(), new PerContainerLifetime());
            ////ConfiguredContainer.SetChangeLogAttributes();
            this.Service = this.containers.GetInstance<T>();
        }

        /// <summary>
        /// Gets the service.
        /// </summary>
        /// <value>
        /// The service.
        /// </value>
        protected T Service { get; }

        /// <summary>
        /// Classes the initialize.
        /// </summary>
        /// <param name="context">The context.</param>
        [ClassInitialize]
        public void ClassInitialize(TestContext context)
        {
            Effort.Provider.EffortProviderConfiguration.RegisterProvider();
        }
    }
}