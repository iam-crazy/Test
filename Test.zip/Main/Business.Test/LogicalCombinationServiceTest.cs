﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombinationServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare LogicalCombinationTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.QualityTools.Testing.Fakes;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare Logical Combination Service Test.
    /// </summary>
    [TestClass]
    public class LogicalCombinationServiceTest : BaseTest<ILogicalCombinationService>
    {
        /// <summary>
        /// Save_s the row status active_ expected success.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public void Save_RowStatusActive_ExpectedSuccess()
        {
            BusinessOutcome output = Service.Save(this.SaveLogicalCombination_Combination_ExpectedSuccessStatus()).Result;
            Assert.IsTrue(output.IdentityValue != "0");
        }

        /// <summary>
        /// Save_s the row status inactive_ expected success.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void Save_RowStatusInactive_ExpectedSuccess()
        {
            BusinessOutcome output = Service.Save(this.LogicalCombinationSaveUpdate()).Result;
            Assert.IsTrue(output.IdentityValue != "0");
        }

        /// <summary>
        /// Save_s the row status delete_ expect deleted object.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "result")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void Save_RowStatusDelete_ExpectDeletedObject()
        {
            BusinessOutcome result = Service.Save(this.LogicalCombinationDelete()).Result;
        }

        /// <summary>
        /// Duplicates the check logical combination.
        /// </summary>
        /// <returns>Returns Logical Combination.</returns>
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        public async Task SaveLogicalCombination_DuplicateCheck_ExpectedSuccessStatus()
        {
            List<LogicalCombination> logicalActivities = new List<LogicalCombination>();
            LogicalCombination logicalActivity = new LogicalCombination();
            logicalActivity.FromActivityReferential = new Activity { ActivityReferentialId = 1, Code = "ELR", Description = "Export Loaded on Rail" };
            logicalActivity.ToActivityReferential = new Activity { ActivityReferentialId = 1, Code = "OHD", Description = "On Hold" };
            logicalActivity.RowStatus = "A";
            logicalActivity.CreatedBy = 1;
            logicalActivity.CreatedOn = DateTime.Now;
            logicalActivity.UpdatedBy = -1;
            logicalActivity.UpdatedOn = DateTime.Now;
            logicalActivity.ActivityType = "A";
            BusinessOutcome output = new BusinessOutcome();
            logicalActivities.Add(logicalActivity);
            ////Act
            var result = await Service.Save(logicalActivities);
        }

        /// <summary>
        /// Gets the logical sequence.
        /// </summary>
        /// <returns>Returns The identifier.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task LogicalCombinationList_NoParameter_LogicalCombinationList()
        {
            int moveCodeId = 2;
            ////int logicalCombinationId = 0;
            ////int eventCodeId = 0;
            ////string position = null;
            ////string purpose = null;
            ////bool status = false;
            var logicalCombination = await Service.GetLogicalCombinationList(moveCodeId);
            if (logicalCombination.Count > 0)
            {
                Assert.IsTrue(logicalCombination.Count > 0);
                Assert.IsNotNull(logicalCombination);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "logicalCombinationService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var logicalCombinationService = new LogicalCombinationService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "logicalCombinationService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContextAndMapper_NoParameter_NullException()
        {
            var logicalCombinationService = new LogicalCombinationService(null, new LogicalCombinationRepository(new AmbientDbContextLocator()), null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "logicalCombinationService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentMapper_NoParameter_NullException()
        {
            var logicalCombinationService = new LogicalCombinationService(new DbContextScopeFactory(), new LogicalCombinationRepository(new AmbientDbContextLocator()), null, null, null);
        }

        /// <summary>
        /// Tests all records.
        /// </summary>
        /// <returns>Its asserts with all possible filter parameters.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "AvoidUncalledPrivateCode")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        private List<LogicalCombination> SaveLogicalCombination_Combination_ExpectedSuccessStatus()
        {
            return new List<LogicalCombination>() { new LogicalCombination() { FromActivityReferential = new Activity { ActivityReferentialId = 2, Code = "ELR", Description = "Export Loaded on Rail" }, ToActivityReferential = new Activity { ActivityReferentialId = 3, Code = "OHD", Description = "On Hold" }, Status = "A", RowStatus = "A", CreatedBy = 1, CreatedOn = DateTime.Now, ActivityType = "A", UpdatedBy = -1, UpdatedOn = DateTime.Now, UserName = string.Empty } };
        }

        /// <summary>
        /// Logical the combination save update.
        /// </summary>
        /// <returns>Its asserts with all possible filter parameters.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "AvoidUncalledPrivateCode")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        private List<LogicalCombination> LogicalCombinationSaveUpdate()
        {
            return new List<LogicalCombination>() { new LogicalCombination() { LogicalActivityId = 1, FromActivityReferential = new Activity { ActivityReferentialId = 2, Code = "ELR", Description = "Export Loaded on Rail" }, ToActivityReferential = new Activity { ActivityReferentialId = 1, Code = "OHD", Description = "On Hold" }, RowStatus = "U", UpdatedBy = -1, UpdatedOn = DateTime.Now, ActivityType = "O", UserName = string.Empty } };
        }

        /// <summary>
        /// Logicals the combination delete.
        /// </summary>
        /// <returns>Its asserts with all possible filter parameters.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "AvoidUncalledPrivateCode")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        private List<LogicalCombination> LogicalCombinationDelete()
        {
            return new List<LogicalCombination>() { new LogicalCombination() { LogicalActivityId = 2, FromActivityReferential = new Activity { ActivityReferentialId = 2, Code = "ELR", Description = "Export Loaded on Rail" }, ToActivityReferential = new Activity { ActivityReferentialId = 1, Code = "OHD", Description = "On Hold" }, RowStatus = "D", UpdatedBy = -1, UpdatedOn = DateTime.Now, ActivityType = "O", UserName = string.Empty } };
        }
    }
}