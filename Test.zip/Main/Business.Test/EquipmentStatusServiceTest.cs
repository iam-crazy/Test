﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStatusServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStatusServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare EquipmentStatusServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IEquipmentStatusService}" />
    [TestClass]
    public class EquipmentStatusServiceTest : BaseTest<IEquipmentStatusService>
    {
        /// <summary>
        /// Saves the equipment status_ equipment status_ expected success status.
        /// </summary>
        /// <returns>Return the equipment status.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveEquipmentStatus_EquipmentStatus_ExpectedSuccessStatus()
        {
            ////Arrange
            EquipmentStatus equipmentStatus = new EquipmentStatus();
            equipmentStatus.Code = "GIN";
            equipmentStatus.Description = "Gate In";
            equipmentStatus.CreatedBy = BusinessTestConstants.UserId;
            equipmentStatus.CreatedOn = DateTime.Now;
            equipmentStatus.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(equipmentStatus);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the equipment status_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the equipment status.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task EquipmentStatusList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<EquipmentStatus> result = await Service.GetEquipmentStatus();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the equipment status_ equipment status i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the equipment status.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteEquipmentStatus_EquipmentStatusId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "equipmentStatusService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var equipmentStatusService = new EquipmentStatusService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "equipmentStatusService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var equipmentStatusService = new EquipmentStatusService(null, new EquipmentStatusRepository(new AmbientDbContextLocator()), null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "equipmentStatusService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentMapper_NoParameter_NullException()
        {
            var equipmentStatusService = new EquipmentStatusService(new DbContextScopeFactory(), new EquipmentStatusRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}