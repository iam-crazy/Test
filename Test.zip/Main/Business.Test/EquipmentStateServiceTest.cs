﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStateServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStateServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare EquipmentStateServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IEquipmentStateService}" />
    [TestClass]
    public class EquipmentStateServiceTest : BaseTest<IEquipmentStateService>
    {
        /// <summary>
        /// Saves the equipment state_ equipment state_ expected success status.
        /// </summary>
        /// <returns>Return the equipment state.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveEquipmentState_EquipmentState_ExpectedSuccessStatus()
        {
            ////Arrange
            EquipmentState equipmentState = new EquipmentState();
            equipmentState.Code = "NEW";
            equipmentState.Description = "New";
            equipmentState.CreatedBy = BusinessTestConstants.UserId;
            equipmentState.CreatedOn = DateTime.Now;
            equipmentState.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(equipmentState);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the equipment state_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the equipment state.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task EquipmentStateList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<EquipmentState> result = await Service.SearchEquipmentStates();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the equipment state_ equipment state i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the equipment state.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteEquipmentState_EquipmentStateId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userid = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userid);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "equipmentStateService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var equipmentStateService = new EquipmentStateService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "equipmentStateService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var equipmentStateService = new EquipmentStateService(null, new EquipmentStateRepository(new AmbientDbContextLocator()), null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "equipmentStateService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentMapper_NoParameter_NullException()
        {
            var equipmentStateService = new EquipmentStateService(new DbContextScopeFactory(), new EquipmentStateRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}