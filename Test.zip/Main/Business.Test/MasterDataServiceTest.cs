﻿//-----------------------------------------------------------------------
// <copyright file = "MasterDataServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare MasterDataServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using Contracts;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare MasterDataServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IMasterDataService}" />
    [TestClass]
    public class MasterDataServiceTest : BaseTest<IMasterDataService>
    {
    }
}