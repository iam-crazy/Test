﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using AutoMapper.Configuration;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare ReferentialDataServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IReferentialDataService}" />
    [TestClass]
    public class ReferentialDataServiceTest : BaseTest<IReferentialDataService>
    {
        /// <summary>
        /// Saves the activity referential.
        /// </summary>
        /// <returns> Return the activity referential.</returns>
        ////[TestMethod]
        public async Task SaveActivityReferential()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();

            ////Act
            BusinessOutcome output = await Service.Save(referentialData);

            ////Assert
            Assert.IsTrue(Convert.ToInt16(output.IdentityValue) > 0);
        }

        /// <summary>
        /// Saves the activity referential.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        ////[TestMethod]
        public async Task UpdateActivityReferential()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();
            referentialData.ActivityReferentialId = 1;
            referentialData.UpdatedBy = -1;
            referentialData.UpdatedOn = DateTime.Now;
            referentialData.UserName = string.Empty;
            referentialData.ReferentialValidationRules.Add(new Contracts.Objects.ReferentialValidationRule
            {
                ValidationRuleId = 1,
                ReferentialValidationRuleId = 1,
                EffectiveDate = DateTime.Now,
                EffectiveTo = null,
                Status = true,
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
            });
            referentialData.EDIMappings.Add(new Contracts.Objects.EDIMapping
            {
                EquipmentStatus = null,
                ShipmentStatus = null,
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
                EDIMappingId = 1
            });
            ////Act
            BusinessOutcome output = await Service.Save(referentialData);

            ////Assert
            Assert.IsTrue(Convert.ToInt16(output.IdentityValue) > 0);
        }

        /// <summary>
        /// Saves the activity referential.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [TestMethod]
        public async Task GetReferentialList()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();

            ////Act
            var output = await Service.GetReferentialList(new ReferentialDataFilter() { Action = 1, IsMapped = null });
        }

        /// <summary>
        /// Saves the activity referential.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [TestMethod]
        public async Task GetAllReferentialList()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();

            ////Act
            var output = await Service.GetReferentialList(isMapped: null);
        }

        /// <summary>
        /// Saves the activity referential.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [TestMethod]
        public async Task SearchQuickAccessCount()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();

            ////Act
            var output = await Service.GetQuickAccessCount(new ReferentialDataFilter() { Action = 1, IsMapped = null });
        }

        /// <summary>
        /// Saves the activity referential.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [TestMethod]
        public async Task SearchAllQuickAccessCount()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();

            ////Act
            var output = await Service.SearchQuickAccessCount();
        }

        /// <summary>
        /// Saves the activity referential_ null parameter_ expected rejection status.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveActivityReferential_NullParameter_ExpectedRejectionStatus()
        {
            ////Arrange
            ReferentialData referentialData = this.ActivityReferentialMockData();
            referentialData.Code = "$#D";

            ////Act
            BusinessOutcome output = await Service.Save(referentialData);

            ////Assert
            Assert.IsTrue(output.ConvertToOperationOutcome().Status == OperationOutcomeStatus.Rejection);
        }

        /////// <summary>
        /////// Gets the activity referential_ null parameter_ expected valid list.
        /////// </summary>
        /////// <returns>Return the referential.</returns>
        ////[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        ////[TestMethod]
        ////public void ActivityReferentialList_NullParameter_ExpectedValidList()
        ////{
        ////    ////Arrange
        ////    string code = null;
        ////    string description = null;
        ////    string activityType = null;
        ////    string status = null;
        ////    string action = null;
        ////    string location = null;
        ////    string glossary = null;
        ////    string remarks = null;
        ////    string fullEmpty = null;
        ////    bool? isMapped = null;

        ////    //TODO Krishna
        ////    ////Act
        ////    //  IList<SearchReferentialData> output = await Service.GetReferentialList(code, description, activityType, status, action, location, glossary, remarks, fullEmpty, isMapped);

        ////    ////Assert
        ////    // Assert.IsTrue(output != null);
        ////    //  Assert.IsTrue(output.Count > 0);
        ////}

        /// <summary>
        /// Gets the activity referential_ id_ expected valid object.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "UsePropertiesWhereAppropriate")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GetActivityReferential_Id_ExpectedValidObject()
        {
            ////Arrange
            int id = 1;

            ////Act
            ReferentialData output = await Service.GetReferentialData(id);

            ////Assert
            Assert.IsTrue(output != null);
        }

        /// <summary>
        /// Gets the activity referential_ null id_ expected null object.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "UsePropertiesWhereAppropriate")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GetActivityReferential_NullId_ExpectedNullObject()
        {
            ////Arrange
            int id = 0;

            ////Act
            ReferentialData output = await Service.GetReferentialData(id);

            ////Assert
            Assert.IsTrue(output == null);
        }

        /// <summary>
        /// Gets the activity_ null parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ActivityList_NullParameter_ExpectedValidList()
        {
            ////Arrange
            string activityType = null;

            ////Act
            IList<Activity> output = await Service.GetActivityReferentialList(activityType);

            ////Assert
            Assert.IsTrue(output.Count == 0);
        }

        /// <summary>
        /// Gets the requirement field_ null parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task RequirementFieldList_NullParameter_ExpectedValidList()
        {
            ////Act
            IList<RequirementField> output = await Service.GetReferentialFields();

            ////Assert
            Assert.IsTrue(output != null);
            Assert.IsTrue(output.Count > 0);
        }

        /// <summary>
        /// Gets the requirement usage_ null parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task RequirementUsageList_NullParameter_ExpectedValidList()
        {
            ////Act
            IList<RequirementUsage> output = await Service.GetReferentialUsage();

            ////Assert
            Assert.IsTrue(output != null);
            Assert.IsTrue(output.Count > 0);
        }

        /// <summary>
        /// Gets the requirement usage_ null parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task FullEmptyDetails_NullParameter_ExpectedValidList()
        {
            ////Act
            IList<FullEmpty> output = await Service.GetFullEmptyDetails();

            ////Assert
            Assert.IsTrue(output != null);
            Assert.IsTrue(output.Count > 0);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "referentialDataService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var referentialDataService = new ReferentialDataService(new DbContextScopeFactory(), null, null, null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "referentialDataService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var configuration = new MapperConfigurationExpression();
            var mapperConfig = new MapperConfiguration(configuration);
            IMapper mapper = new Mapper(mapperConfig);
            var referentialDataService = new ReferentialDataService(null, new ReferentialDataRepository(new AmbientDbContextLocator()), null, mapper, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "referentialDataService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentMapper_NoParameter_NullException()
        {
            var referentialDataService = new ReferentialDataService(new DbContextScopeFactory(), new ReferentialDataRepository(new AmbientDbContextLocator()), null, null, null, null, null);
        }

        /// <summary>
        /// Activities the referential mock data.
        /// </summary>
        /// <returns>Return the activity referential.</returns>
        private ReferentialData ActivityReferentialMockData()
        {
            return new ReferentialData()
            {
                Code = "ECY",
                ActivityAction = new ActivityAction { Id = 1 },
                ActivityType = new ActivityType { Id = 1 },
                ActivityCategory = new ActivityCategory { Id = 1 },
                ActivityLocation = new TakePlaceAt { Id = 1 },
                FullEmpty = new FullEmpty { Id = 1 },
                BusinessCycle = new BusinessCycle { Id = 1 },
                Description = "Description",
                Glossary = "Glossary",
                Reason = "Reason ",
                IsDisplayToCustomer = true,
                Remarks = "Remarks",
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
                UserName = string.Empty,
                ReferentialValidationRules = this.ReferentialValidationRule(),
                BasicRequirements = this.BasicRequirement(),
                EDIMappings = this.EDIMapping(),
            };
        }

        /// <summary>
        /// Referential the validation rule.
        /// </summary>
        /// <returns>Returns Validation Rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        private List<ReferentialValidationRule> ReferentialValidationRule()
        {
            List<ReferentialValidationRule> referentialValidationList = new List<ReferentialValidationRule>();
            referentialValidationList.Add(new Contracts.Objects.ReferentialValidationRule
            {
                ValidationRuleId = 1,
                EffectiveDate = DateTime.Now,
                EffectiveTo = null,
                Status = true,
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
            });

            return referentialValidationList;
        }

        /// <summary>
        /// Basics the requirement.
        /// </summary>
        /// <returns>Returns Basic Requirement.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        private List<BasicRequirement> BasicRequirement()
        {
            List<BasicRequirement> basicRequirementList = new List<BasicRequirement>();
            basicRequirementList.Add(new Contracts.Objects.BasicRequirement
            {
                BasicStatus = "A",
                RequirementField = new RequirementField { Id = 1 },
                RequirementUsage = new RequirementUsage { Id = 1 },
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
            });
            basicRequirementList.Add(new Contracts.Objects.BasicRequirement
            {
                BasicStatus = "A",
                RequirementField = new RequirementField { Id = 1 },
                RequirementFieldTwo = new RequirementField { Id = 1 },
                RequirementFieldThree = new RequirementField { Id = 1 },
                RequirementUsage = new RequirementUsage { Id = 1 },
                BasicRequirementId = 1,
                UpdatedBy = 1,
                UpdatedOn = DateTime.Now,
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
            });

            return basicRequirementList;
        }

        /// <summary>
        /// Edi the mapping.
        /// </summary>
        /// <returns>Returns EDI Mapping.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Justification = "MarkMembersAsStatic")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "ediMapping")]
        private List<EDIMapping> EDIMapping()
        {
            EDIMapping ediMapping = new EDIMapping();
            List<EDIMapping> ediMappingList = new List<EDIMapping>();
            ediMappingList.Add(new Contracts.Objects.EDIMapping
            {
                EquipmentStatus = new EquipmentStatus { Id = 1 },
                ShipmentStatus = new ShipmentStatus { Id = 1 },
                CreatedBy = BusinessTestConstants.UserId,
                CreatedOn = DateTime.Now,
            });

            return ediMappingList;
        }
    }
}