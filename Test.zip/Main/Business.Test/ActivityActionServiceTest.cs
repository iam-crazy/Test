﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityActionServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityActionServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    ///  Declare ActivityActionServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IActivityActionService}" />
    [TestClass]
    public class ActivityActionServiceTest : BaseTest<IActivityActionService>
    {
        /// <summary>
        /// Saves the activity action_ activity action_ expected success status.
        /// </summary>
        /// <returns>Returns the activity save value.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveActivityAction_ActivityAction_ExpectedSuccessStatus()
        {
            ////Arrange
            ActivityAction activityAction = new ActivityAction();
            activityAction.Code = "GIN";
            activityAction.Description = "Gate In";
            activityAction.CreatedBy = BusinessTestConstants.UserId;
            activityAction.CreatedOn = DateTime.Now;
            activityAction.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(activityAction);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the activity action_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Returns the activity list.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ActivityActionList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<ActivityAction> result = await Service.GetActivityActions();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the activity action_ activity action i d_ expect deleted object.
        /// </summary>
        /// <returns>Returns the activity list.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteActivityAction_ActivityActionId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userid = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userid);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityActionService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var activityActionService = new ActivityActionService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "activityActionService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var activityActionService = new ActivityActionService(null, new ActivityActionRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}