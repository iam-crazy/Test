﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleGroupServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleGroupServiceTest. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare ValidationRuleGroupServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IValidationRuleGroupService}" />
    [TestClass]
    public class ValidationRuleGroupServiceTest : BaseTest<IValidationRuleGroupService>
    {
        /// <summary>
        /// Saves the validation rule group_ validation rule group_ expected success status.
        /// </summary>
        /// <returns>Return the validation rule group.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRuleGroup_ValidationRuleGroup_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRuleGroup validationRuleGroup = new ValidationRuleGroup();
            validationRuleGroup.Code = "GIN";
            validationRuleGroup.Description = "Gate In";
            validationRuleGroup.CreatedBy = BusinessTestConstants.UserId;
            validationRuleGroup.CreatedOn = DateTime.Now;
            validationRuleGroup.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(validationRuleGroup);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            ////Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the validation rule group_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the validation rule group.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ValidationRuleGroupList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<ValidationRuleGroup> result = await Service.GetValidationRuleGroups();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the validation rule group_ validation rule group i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the validation rule group.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteValidationRuleGroup_ValidationRuleGroupId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleGroupService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var validationRuleGroupService = new ValidationRuleGroupService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleGroupService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var validationRuleGroupService = new ValidationRuleGroupService(null, new ValidationRuleGroupRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}