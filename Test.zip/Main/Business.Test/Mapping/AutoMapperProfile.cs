﻿//-----------------------------------------------------------------------
// <copyright file = "AutoMapperProfile.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare AutoMapperProfile.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test.Mapping
{
    using System.CodeDom.Compiler;
    using AutoMapper;
    using Business = Contracts.Objects;
    using DataAccess = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare AutoMapperProfile.
    /// </summary>
    [GeneratedCode("AutoMapperProfile", "1.0.0")]
    public class AutoMapperProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
        /// </summary>
        public AutoMapperProfile()
        {
            this.CreateMissingTypeMaps = false;
            this.ForAllMaps((typeMap, mapConfig) => mapConfig.PreserveReferences());
            ////------- DataAccess To Business--------   
            this.CreateMap<DataAccess.ActivityAction, Business.ActivityAction>()
                .ConstructUsing(dest => new Business.ActivityAction()).ReverseMap();

            this.CreateMap<DataAccess.ActivityCategory, Business.ActivityCategory>()
                .ConstructUsing(dest => new Business.ActivityCategory()).ReverseMap();

            this.CreateMap<DataAccess.ActivityReferential, Business.ReferentialData>()
                .ConstructUsing(dest => new Business.ReferentialData()).ReverseMap();

            this.CreateMap<DataAccess.ActivityReferential, Business.SearchReferentialData>()
              .ConstructUsing(dest => new Business.SearchReferentialData()).ReverseMap();

            this.CreateMap<DataAccess.ActivityType, Business.ActivityType>()
                .ConstructUsing(dest => new Business.ActivityType()).ReverseMap();

            this.CreateMap<DataAccess.ActivityType, Business.TakePlaceAt>()
                .ConstructUsing(dest => new Business.TakePlaceAt()).ReverseMap();        
            
            this.CreateMap<DataAccess.BasicRequirement, Business.BasicRequirement>()
                .ConstructUsing(dest => new Business.BasicRequirement()).ReverseMap();

            this.CreateMap<DataAccess.CancelEquipmentActivity, Business.CancelEquipmentActivity>()
                .ConstructUsing(dest => new Business.CancelEquipmentActivity()).ReverseMap();

            this.CreateMap<DataAccess.EDIMapping, Business.EDIMapping>()
                .ConstructUsing(dest => new Business.EDIMapping()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivity, Business.EquipmentActivity>()
                .ConstructUsing(dest => new Business.EquipmentActivity()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivity, Business.EquipmentFleet>()
                .ConstructUsing(dest => new Business.EquipmentFleet()).ReverseMap();

            this.CreateMap<DataAccess.ActivityReferential, Business.Activity>()
               .ConstructUsing(dest => new Business.Activity()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivityError, Business.EquipmentActivityError>()
                .ConstructUsing(dest => new Business.EquipmentActivityError()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivityFilter, Business.EquipmentActivityFilter>()
                .ConstructUsing(dest => new Business.EquipmentActivityFilter()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentFleet, Business.EquipmentFleet>()
                .ConstructUsing(dest => new Business.EquipmentFleet()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentFleet, Business.EquipmentActivity>()
               .ConstructUsing(dest => new Business.EquipmentActivity()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentStatus, Business.EquipmentStatus>()
                .ConstructUsing(dest => new Business.EquipmentStatus()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentState, Business.EquipmentState>()
              .ConstructUsing(dest => new Business.EquipmentState()).ReverseMap();

            this.CreateMap<DataAccess.FullEmpty, Business.FullEmpty>()
                .ConstructUsing(dest => new Business.FullEmpty()).ReverseMap();

            this.CreateMap<DataAccess.FullEmpty, Business.GeneralCode>()
              .ConstructUsing(dest => new Business.GeneralCode()).ReverseMap();

            this.CreateMap<DataAccess.LogicalActivity, Business.LogicalSequence>()
                .ConstructUsing(dest => new Business.LogicalSequence()).ReverseMap();
            this.CreateMap<DataAccess.LogicalActivity, Business.LogicalSequenceUpdate>()
              .ConstructUsing(dest => new Business.LogicalSequenceUpdate()).ReverseMap();

            this.CreateMap<DataAccess.LogicalActivity, Business.LogicalCombination>()
                .ConstructUsing(dest => new Business.LogicalCombination()).ReverseMap();

            this.CreateMap<DataAccess.ReferentialValidationRule, Business.ReferentialValidationRule>()
                .ConstructUsing(dest => new Business.ReferentialValidationRule()).ReverseMap();

            this.CreateMap<DataAccess.RequirementField, Business.RequirementField>()
                .ConstructUsing(dest => new Business.RequirementField()).ReverseMap();

            this.CreateMap<DataAccess.RequirementGroup, Business.RequirementGroup>()
                .ConstructUsing(dest => new Business.RequirementGroup()).ReverseMap();

            this.CreateMap<DataAccess.RequirementUsage, Business.RequirementUsage>()
                .ConstructUsing(dest => new Business.RequirementUsage()).ReverseMap();

            this.CreateMap<DataAccess.ShipmentStatus, Business.ShipmentStatus>()
                .ConstructUsing(dest => new Business.ShipmentStatus()).ReverseMap();

            this.CreateMap<DataAccess.TakePlaceAt, Business.TakePlaceAt>()
                .ConstructUsing(dest => new Business.TakePlaceAt()).ReverseMap();

            this.CreateMap<DataAccess.ValidateEquipment, Business.ValidateEquipment>()
                .ConstructUsing(dest => new Business.ValidateEquipment()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRule, Business.ValidationRule>()
                .ConstructUsing(dest => new Business.ValidationRule()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRule, Business.ValidationRuleBase>()
                            .ConstructUsing(dest => new Business.ValidationRuleBase()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRuleErrorResult, Business.ValidationRuleErrorResult>()
                .ConstructUsing(dest => new Business.ValidationRuleErrorResult()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRuleGroup, Business.ValidationRuleGroup>()
                .ConstructUsing(dest => new Business.ValidationRuleGroup()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRuleType, Business.ValidationRuleType>()
                .ConstructUsing(dest => new Business.ValidationRuleType()).ReverseMap();

            ////------- DataAccess To DataAccess--------

            this.CreateMap<DataAccess.EquipmentActivity, DataAccess.EquipmentFleet>()
               .ConstructUsing(dest => new DataAccess.EquipmentFleet()).ReverseMap();
        }
    }
}