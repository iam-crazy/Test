﻿//-----------------------------------------------------------------------
// <copyright file = "BusinessTestConstants.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare BusinessTestConstants. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test.Constants
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare BusinessTestConstants.
    /// </summary>
    public static class BusinessTestConstants
    {
        /// <summary>
        /// The user identifier.
        /// </summary>
        public const int UserId = 1;
    }
}