﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleTypeServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
// Declare ValidationRuleTypeServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare ValidationRuleTypeServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IValidationRuleTypeService}" />
    [TestClass]
    public class ValidationRuleTypeServiceTest : BaseTest<IValidationRuleTypeService>
    {
        /// <summary>
        /// Saves the validation rule type_ validation rule type_ expected success status.
        /// </summary>
        /// <returns>Return the validation rule type.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRuleType_ValidationRuleType_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRuleType validationRuleType = new ValidationRuleType();
            validationRuleType.Code = "GIN";
            validationRuleType.Description = "Gate In";
            validationRuleType.CreatedBy = BusinessTestConstants.UserId;
            validationRuleType.CreatedOn = DateTime.Now;
            validationRuleType.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(validationRuleType);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            ////Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the validation rule type_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the validation rule type.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ValidationRuleTypeList_NoParameter_ExpectedValidList()
        {
            ////Act
            IList<ValidationRuleType> result = await Service.GetValidationRuleTypes();

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the validation rule type_ validation rule error result i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the validation rule type.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteValidationRuleType_ValidationRuleErrorResultId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleGroupService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var validationRuleGroupService = new ValidationRuleTypeService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleGroupService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var validationRuleGroupService = new ValidationRuleTypeService(null, new ValidationRuleTypeRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}