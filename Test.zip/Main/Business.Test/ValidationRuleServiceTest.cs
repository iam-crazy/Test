﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using AutoMapper.Configuration;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Declare ValidationRuleServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IValidationRuleService}" />
    [TestClass]
    public class ValidationRuleServiceTest : BaseTest<IValidationRuleService>
    {
        /// <summary>
        /// Tests all records.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRule_ValidationRule_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME004";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = null;
            validationRule.Status = true;
            validationRule.Remarks = "No";
            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = BusinessTestConstants.UserId;
            validationRule.UpdatedOn = DateTime.Now;
            validationRule.UserName = string.Empty;
            ////Act
            BusinessOutcome result = await Service.Save(validationRule);

            ////Assert
            int recordId = Convert.ToInt32(result.IdentityValue);
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Tests all records.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task UpdateValidationRule_ValidationRule_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME004";
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidationRuleId = 2;
            validationRule.ValidTo = null;
            validationRule.Status = false;
            validationRule.Remarks = "No";
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = BusinessTestConstants.UserId;
            validationRule.UpdatedOn = DateTime.Now;
            ////Act
            BusinessOutcome result = await Service.Save(validationRule);

            ////Assert
            short recordId = Convert.ToInt16(result.IdentityValue);
        }

        /// <summary>
        /// Tests all records.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task UpdateValidationRule_ValidationRule_WithoutRuleStatus()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME004";
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidationRuleId = 2;
            validationRule.ValidTo = null;
            validationRule.Status = false;
            validationRule.Remarks = string.Empty;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = BusinessTestConstants.UserId;
            validationRule.UpdatedOn = DateTime.Now;
            ////Act
            BusinessOutcome result = await Service.Save(validationRule);

            ////Assert
            short recordId = Convert.ToInt16(result.IdentityValue);
        }

        /// <summary>
        /// Updates the validation rule_ statusand validation rule_ expected success status.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task UpdateValidationRule_Status_And_ValidationRule_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME004";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = null;
            validationRule.Status = false;
            validationRule.ValidationRuleId = 1;
            validationRule.Remarks = "No";
            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = -1;
            validationRule.UpdatedOn = DateTime.Now;
            ////Act
            BusinessOutcome result = await Service.Save(validationRule);

            ////Assert
            int recordId = Convert.ToInt32(result.IdentityValue);
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Updates the validation rule_ statusand validation rule_ expected success status.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task UpdateValidationRule_FalseStatusAndRemarksValidationRule_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME004";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = null;
            validationRule.Status = true;
            validationRule.ActivityCodeChangeStatus = false;
            validationRule.ValidationRuleId = 1;
            validationRule.Remarks = "No";
            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = -1;
            validationRule.UpdatedOn = DateTime.Now;
            validationRule.UserName = string.Empty;
            ////Act
            BusinessOutcome result = await Service.Save(validationRule);

            ////Assert
            int recordId = Convert.ToInt32(result.IdentityValue);
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Updates the validation rule_ statusand validation rule_ expected success status.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task UpdateValidationRule_TrueStatusAndRemarksValidationRule_ExpectedSuccessStatus()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME004";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = null;
            validationRule.Status = true;
            validationRule.ActivityCodeChangeStatus = true;
            validationRule.ValidationRuleId = 1;
            validationRule.Remarks = "No";

            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = -1;
            validationRule.UpdatedOn = DateTime.Now;
            validationRule.UserName = string.Empty;
            ////Act
            BusinessOutcome result = await Service.Save(validationRule);

            ////Assert
            int recordId = Convert.ToInt32(result.IdentityValue);
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the validation rules not null list.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "UsePropertiesWhereAppropriate")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GetValidationRules_RuleNumber_ExpectedValidList()
        {
            ////Act
            IList<ValidationRule> result = await Service.GetValidationRules(0, string.Empty, string.Empty, null, null, false, string.Empty, 0, 0, string.Empty);
            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Gets the validation rule identifier not null.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "UsePropertiesWhereAppropriate")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GetValidationRule_ValidationRuleId_ExpectedValidList()
        {
            ////Act
            ValidationRule result = await Service.GetValidationRule(1);
            ////Assert
            int recordId = Convert.ToInt32(result.ValidationRuleId);
            Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Tests all records.
        /// </summary>
        /// <returns>
        /// Its asserts with all possible filter parameters.
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(System.ArgumentNullException))]
        public async Task SaveValidationRule_NullValidationRule_NullError()
        {
            ////Act
            ValidationRule validationRule = null;
            ////Assert
            var result = await Service.Save(validationRule);
        }

        /// <summary>
        /// Gets the search validation rule group not null.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "UsePropertiesWhereAppropriate")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GetSearchValidationRule_NullGroup_ExpectedValidList()
        {
            ////Act
            var result = await Service.SearchValidationRules(null, 0);
        }

        /// <summary>
        /// Searches the validation rule group not null.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Justification = "UsePropertiesWhereAppropriate")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GetSearchValidationRule_ValidationRuleGroupCode_ExpectedValidList()
        {
            ////Act
            ValidationRule validationRule = new ValidationRule();
            validationRule.ValidationRuleId = 1;
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I" };
            var result = await Service.SearchValidationRules(validationRule.ValidationRuleGroup.Code, validationRule.ValidationRuleId);
            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Gets the rule number test not null.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task GenerateRuleNumberList_NoParameter_ExpectedValidObject()
        {
            var result = await Service.GenerateRuleNumber();

            Assert.IsNotNull(result);
        }

        /// <summary>
        /// Saves the validation rule_ null rule number.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRule_NullRuleNumber_NullObject()
        {
            ////Act
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = string.Empty;
            validationRule.ValidFrom = default(DateTime);
            validationRule.ValidTo = null;
            validationRule.ValidationRuleGroup = null;
            validationRule.Description = null;
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Id = 0 };
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Id = 0 };
            validationRule.ValidationRuleType = new ValidationRuleType { Id = 0 };
            validationRule.ErrorDescription = null;
            var result = await Service.Save(validationRule);

            Assert.IsNull(result.IdentityValue);
            Assert.IsTrue(result.Messages.Any());
        }

        /// <summary>
        /// Saves the validation rule_ valid from_ null object.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRule_ValidFrom_NullObject()
        {
            ValidationRule validationRule = new ValidationRule();
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = validationRule.ValidFrom.AddDays(-1);
            var result = await Service.Save(validationRule);
            Assert.IsNull(result.IdentityValue);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentRepository_NoParameter_NullException()
        {
            var configuration = new MapperConfigurationExpression();
            var mapperConfig = new MapperConfiguration(configuration);
            IMapper mapper = new Mapper(mapperConfig);
            var validationRuleService = new ValidationRuleService(new DbContextScopeFactory(), null, mapper, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_NullException()
        {
            var configuration = new MapperConfigurationExpression();
            var mapperConfig = new MapperConfiguration(configuration);
            IMapper mapper = new Mapper(mapperConfig);
            var validationRuleService = new ValidationRuleService(null, new ValidationRuleRepository(new AmbientDbContextLocator()), mapper, new ReferentialDataRepository(new AmbientDbContextLocator()), null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "validationRuleService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentMapper_NoParameter_NullException()
        {
            var validationRuleService = new ValidationRuleService(new DbContextScopeFactory(), new ValidationRuleRepository(new AmbientDbContextLocator()), null, new ReferentialDataRepository(new AmbientDbContextLocator()), null, null);
        }

        /// <summary>
        /// Saves the validation rule_ rule number_ null objet.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRule_RuleNumber_NullObjet()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME026";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = DateTime.Now;
            validationRule.Status = true;
            validationRule.Remarks = "No";
            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = BusinessTestConstants.UserId;
            validationRule.UpdatedOn = DateTime.Now;
            validationRule.UserName = string.Empty;
            BusinessOutcome result = await Service.Save(validationRule);
            ////Act
            Assert.IsFalse(result.Messages.Any());
        }

        /// <summary>
        /// Save ValidationRule Inactivate.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRule_Inactivate()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME026";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = DateTime.Now;
            validationRule.Status = false;
            validationRule.Remarks = "No";
            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = BusinessTestConstants.UserId;
            validationRule.UpdatedOn = DateTime.Now;
            BusinessOutcome result = await Service.Save(validationRule);
            ////Act
            Assert.IsFalse(result.Messages.Any());
        }

        /// <summary>
        /// Save ValidationRule REactivate.
        /// </summary>
        /// <returns>Return the validation rule.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveValidationRule_REActivate()
        {
            ////Arrange
            ValidationRule validationRule = new ValidationRule();
            validationRule.RuleNumber = "EME026";
            validationRule.ValidationRuleGroup = new ValidationRuleGroup { Code = "I", Description = "Empty", Id = 1 };
            validationRule.Description = "Test Description";
            validationRule.ValidFrom = DateTime.Now;
            validationRule.ValidTo = DateTime.Now;
            validationRule.Status = true;
            validationRule.Remarks = "No";
            validationRule.ValidationRuleType = new ValidationRuleType { Code = "COM", Description = "Empty", Id = 1 };
            validationRule.ErrorDescription = "ErrorDescription";
            validationRule.ValidationRuleErrorResult = new ValidationRuleErrorResult { Code = "IV", Description = "Empty", Id = 1 };
            validationRule.CreatedBy = BusinessTestConstants.UserId;
            validationRule.CreatedOn = DateTime.Now;
            validationRule.UpdatedBy = BusinessTestConstants.UserId;
            validationRule.UpdatedOn = DateTime.Now;
            BusinessOutcome result = await Service.Save(validationRule);
            ////Act
            Assert.IsFalse(result.Messages.Any());
        }
    }
}