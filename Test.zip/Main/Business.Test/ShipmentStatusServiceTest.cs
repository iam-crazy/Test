﻿//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatusServiceTest.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ShipmentStatusServiceTest.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess;
    using EntityFramework.DbContextScope;
    using Framework.Common.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    ///   Declare ShipmentStatusServiceTest.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Test.BaseTest{Msc.Logistics.EME.Service.Business.Contracts.IShipmentStatusService}" />
    [TestClass]
    public class ShipmentStatusServiceTest : BaseTest<IShipmentStatusService>
    {
        /// <summary>
        /// Saves the shipment status_ shipment status_ expected success status.
        /// </summary>
        /// <returns>Return the shipment status.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task SaveShipmentStatus_ShipmentStatus_ExpectedSuccessStatus()
        {
            ////Arrange
            ShipmentStatus shipmentStatus = new ShipmentStatus();
            shipmentStatus.Code = "GIN";
            shipmentStatus.Description = "Gate In";
            shipmentStatus.CreatedBy = BusinessTestConstants.UserId;
            shipmentStatus.CreatedOn = DateTime.Now;
            shipmentStatus.UserName = string.Empty;

            ////Act
            BusinessOutcome result = await Service.Save(shipmentStatus);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            ////Assert.IsTrue(recordId > 0);
        }

        /// <summary>
        /// Gets the shipment status_ no parameter_ expected valid list.
        /// </summary>
        /// <returns>Return the shipment status.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task ShipmentStatusList_NoParameter_ExpectedValidList()
        {
            //// var shipmentCodes = "ship";
            var shipmentCodes = "AM";
            ////Act
            IList<ShipmentStatus> result = await Service.GetShipmentStatus(shipmentCodes);

            ////Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Any());
        }

        /// <summary>
        /// Deletes the shipment status_ shipment status i d_ expect deleted object.
        /// </summary>
        /// <returns>Return the shipment status.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        public async Task DeleteShipmentStatus_ShipmentStatusId_ExpectDeletedObject()
        {
            ////Arrange
            int id = 1;
            int userId = -1;
            ////Act
            BusinessOutcome result = await Service.Delete(id, userId);
            int recordId = Convert.ToInt32(result.IdentityValue);

            ////Assert
            if (recordId > 0)
            {
                Assert.IsTrue(recordId > 0);
            }
            else
            {
                Assert.IsTrue(recordId == 0);
            }
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "shipmentStatusService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentContext_NoParameter_Exception()
        {
            var shipmentStatusService = new ShipmentStatusService(new DbContextScopeFactory(), null, null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "shipmentStatusService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetArgumentExceptRepository_NoParameter_NullException()
        {
            var shipmentStatusService = new ShipmentStatusService(null, new ShipmentStatusRepository(new AmbientDbContextLocator()), null, null, null);
        }

        /// <summary>
        /// Tests the record for exception.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Justification = "RemoveUnusedLocals", MessageId = "shipmentStatusService")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores", Justification = "IdentifiersShouldNotContainUnderscores")]
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetMapperExceptRepository_NoParameter_NullException()
        {
            var shipmentStatusService = new ShipmentStatusService(new DbContextScopeFactory(), new ShipmentStatusRepository(new AmbientDbContextLocator()), null, null, null);
        }
    }
}