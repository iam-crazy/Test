﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStateDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentStateDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare EquipmentState.
    /// </summary>
    public class EquipmentStateDto : UserInformationDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStateDto"/> class.
        /// </summary>
        public EquipmentStateDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the equipment status identifier.
        /// </summary>
        /// <value>
        /// The equipment status identifier.
        /// </value>
        public int EquipmentStateId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The equipment code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        #endregion Fields
    }
}