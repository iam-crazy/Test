﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialValidationRuleDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ReferentialValidationRuleDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare Referential Validation Rule.
    /// </summary>
    public class ReferentialValidationRuleDto : UserInformationDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int ReferentialValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the referential data identifier.
        /// </summary>
        /// <value>
        /// The referential data identifier.
        /// </value>
        public int ReferentialDataId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule identifier.
        /// </summary>
        /// <value>
        /// The validation rule identifier.
        /// </value>
        public int ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the validation rule effective as of date.
        /// </summary>
        /// <value>
        /// The validation rule effective as of date.
        /// </value>
        public DateTime EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets the validation rule disabled as of date.
        /// </summary>
        /// <value>
        /// The validation rule disabled as of date.
        /// </value>
        public DateTime? EffectiveTo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ReferentialValidationRuleDto"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the referential data.
        /// </summary>
        /// <value>
        /// The referential data.
        /// </value>
        public virtual ReferentialDataDto ReferentialData { get; set; }

        /// <summary>
        /// Gets or sets the validation rule.
        /// </summary>
        /// <value>
        /// The validation rule.
        /// </value>
        public virtual ValidationRuleDto ValidationRule { get; set; }

        #endregion Fields
    }
}