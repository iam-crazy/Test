﻿//-----------------------------------------------------------------------
// <copyright file = "PortDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare PortDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare Port.
    /// </summary>
    public class PortDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int PortId { get; set; }      

        /// <summary>
        /// Gets or sets the long name of the display.
        /// </summary>
        /// <value>
        /// The long name of the display.
        /// </value>
        public string LongDisplayName { get; set; }

        #endregion Properties
    }
}