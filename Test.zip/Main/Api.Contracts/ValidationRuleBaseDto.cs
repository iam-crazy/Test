﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleBaseDto.cs" company = "MSC">
//   Mediterranean Shipping Company SA . OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleBaseDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using Business.Contracts.Objects;

    /// <summary>
    /// Declare ValidationRule.
    /// </summary>
    public class ValidationRuleBaseDto : UserInformationDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public long ValidationRuleId { get; set; }

        /// <summary>
        /// Gets or sets the rule number.
        /// </summary>
        /// <value>
        /// The rule number.
        /// </value>
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the short Description.
        /// </summary>
        /// <value>
        /// The short Description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public ValidationRuleGroup ValidationRuleGroup { get; set; }

        /// <summary>
        /// Gets or sets the valid from date.
        /// </summary>
        /// <value>
        /// The valid from date.
        /// </value>
        public DateTime ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to date.
        /// </summary>
        /// <value>
        /// The valid to date.
        /// </value>
        public DateTime? ValidTo { get; set; }

        #endregion Properties
    }
}