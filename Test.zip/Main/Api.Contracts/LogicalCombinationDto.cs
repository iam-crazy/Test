﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombinationDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare LogicalCombinationDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare EquipmentActivity.
    /// </summary>
    public class LogicalCombinationDto : UserInformationDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalCombinationDto"/> class.
        /// </summary>
        public LogicalCombinationDto()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the logical combination identifier.
        /// </summary>
        /// <value>
        /// The logical combination identifier.
        /// </value>
        public int LogicalActivityId { get; set; }

        /// <summary>
        /// Gets or sets the event identifier.
        /// </summary>
        /// <value>
        /// The event identifier.
        /// </value>
        public ActivityDto FromActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the move identifier.
        /// </summary>
        /// <value>
        /// The move identifier.
        /// </value>
        public ActivityDto ToActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>
        /// The position.
        /// </value>
        public string ActivityType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="LogicalCombination"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the purpose.
        /// </summary>
        /// <value>
        /// The purpose.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the row status.
        /// </summary>
        /// <value>
        /// The row status.
        /// </value>
        public string RowStatus { get; set; }

        #endregion Properties
    }
}