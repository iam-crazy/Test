﻿//-----------------------------------------------------------------------
// <copyright file = "VesselVoyageDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare VesselVoyageDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare VesselVoyage DTO.
    /// </summary>
    public class VesselVoyageDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the vessel.
        /// </summary>
        /// <value>
        /// The vessel.
        /// </value>
        public string Vessel { get; set; }

        /// <summary>
        /// Gets or sets the voyage.
        /// </summary>
        /// <value>
        /// The voyage.
        /// </value>
        public string Voyage { get; set; }

        /////// <summary>
        /////// Gets or sets the port.
        /////// </summary>
        /////// <value>
        /////// The voyage port.
        /////// </value>
        ////public string Port { get; set; }

        /// <summary>
        /// Gets or sets the arrival.
        /// </summary>
        /// <value>
        /// The arrival.
        /// </value>
        public DateTime Arrival { get; set; }

        /// <summary>
        /// Gets or sets the departure.
        /// </summary>
        /// <value>
        /// The departure.
        /// </value>
        public DateTime Departure { get; set; }

        /// <summary>
        /// Gets or sets the service.
        /// </summary>
        /// <value>
        /// The service.
        /// </value>
        public string Service { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int? Id { get; set; }

        #endregion Fields
    }
}