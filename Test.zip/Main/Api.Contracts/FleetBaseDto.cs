﻿//-----------------------------------------------------------------------
// <copyright file = "FleetBaseDto.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Defines the <see cref="FleetBaseDto" />
    /// </summary>
    public class FleetBaseDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the EquipmentId
        /// </summary>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentIsoId
        /// </summary>
        public int EquipmentISOId { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentNumber
        /// </summary>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentSizeTypeId
        /// </summary>
        public int EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsSoc
        /// </summary>
        public bool HasSOC { get; set; }

        #endregion Properties
    }
}