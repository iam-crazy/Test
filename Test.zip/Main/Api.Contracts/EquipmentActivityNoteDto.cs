//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityNoteDto.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Defines the <see cref="EquipmentActivityNoteDto" />
    /// </summary>
    public partial class EquipmentActivityNoteDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity.
        /// </summary>
        /// <value>
        /// The equipment activity.
        /// </value>
        public EquipmentActivityDto EquipmentActivity { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity identifier.
        /// </summary>
        /// <value>
        /// The equipment activity identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity notes identifier.
        /// </summary>
        /// <value>
        /// The equipment activity notes identifier.
        /// </value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public UserBaseDto UserBase { get; set; }

        #endregion
    }
}
