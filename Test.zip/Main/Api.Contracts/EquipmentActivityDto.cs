﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivity.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivity. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Declare EquipmentActivity.
    /// </summary>
    public class EquipmentActivityDto : UserInformationDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the activity.
        /// </summary>
        /// <value>
        /// The activity.
        /// </value>
        public ActivityDto Activity { get; set; }

        /// <summary>
        /// Gets or sets the activity date time.
        /// </summary>
        /// <value>
        /// The activity date time.
        /// </value>
        public DateTime ActivityDateTime { get; set; }

        /// <summary>
        /// Gets or sets the activity UTC date time.
        /// </summary>
        /// <value>
        /// The activity UTC date time.
        /// </value>
        public DateTimeOffset ActivityUTCDateTime { get; set; }

        /// <summary>
        /// Gets or sets the BL number.
        /// </summary>
        /// <value>
        /// The BL number.
        /// </value>
        public string BLNumber { get; set; }

        /// <summary>
        /// Gets or sets the booking number.
        /// </summary>
        /// <value>
        /// The booking number.
        /// </value>
        public string BookingNumber { get; set; }

        /// <summary>
        /// Gets or sets the cancel equipment activities.
        /// </summary>
        /// <value>
        /// The cancel equipment activities.
        /// </value>
        public IList<CancelEquipmentActivityDto> CancelEquipmentActivities { get; set; }

        /// <summary>
        /// Gets or sets the delivery location.
        /// </summary>
        /// <value>
        /// The delivery location.
        /// </value>
        public LocationDto DeliveryLocation { get; set; }

        /// <summary>
        /// Gets or sets the depot equipment handling facility.
        /// </summary>
        /// <value>
        /// The depot equipment handling facility.
        /// </value>
        public TerminalDepotDto DepotEquipmentHandlingFacility { get; set; }

        /// <summary>
        /// Gets or sets the destination location.
        /// </summary>
        /// <value>
        /// The destination location.
        /// </value>
        public LocationDto DestinationLocation { get; set; }

        /// <summary>
        /// Gets or sets the Equipment
        /// </summary>
        public EquipmentDto Equipment { get; set; }

        /// <summary>
        /// Gets or sets the equipment activity errors.
        /// </summary>
        /// <value>
        /// The equipment activity errors.
        /// </value>
        public IList<EquipmentActivityErrorDto> EquipmentActivityErrors { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public long EquipmentActivityId { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentActivityNotes
        /// </summary>
        public IList<EquipmentActivityNoteDto> EquipmentActivityNotes { get; set; }

        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>
        /// The state.
        /// </value>
        public string EquipmentActivityState { get; set; }

        /// <summary>
        /// Gets or sets the state of the equipment.
        /// </summary>
        /// <value>
        /// The state of the equipment.
        /// </value>
        public EquipmentStateDto EquipmentState { get; set; }

        /// <summary>
        /// Gets or sets the equipment state identifier.
        /// </summary>
        /// <value>
        /// The equipment state identifier.
        /// </value>
        public byte? EquipmentStateId { get; set; }

        /// <summary>
        /// Gets or sets the leasing company reference.
        /// </summary>
        /// <value>
        /// The leasing company reference.
        /// </value>
        public string LeasingCompanyReference { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public PortDto Location { get; set; }

        /// <summary>
        /// Gets or sets the logistics status identifier.
        /// </summary>
        /// <value>
        /// The logistics status identifier.
        /// </value>
        public byte? LogisticsStatusId { get; set; }

        /// <summary>
        /// Gets or sets the MSC authorization reference.
        /// </summary>
        /// <value>
        /// The MSC authorization reference.
        /// </value>
        public string MSCAuthorizationReference { get; set; }

        /// <summary>
        /// Gets or sets the pick up reference.
        /// </summary>
        /// <value>
        /// The pick up reference.
        /// </value>
        public string PickupReference { get; set; }

        /// <summary>
        /// Gets or sets the port of discharge.
        /// </summary>
        /// <value>
        /// The port of discharge.
        /// </value>
        public PortDto PortOfDischarge { get; set; }

        /// <summary>
        /// Gets or sets the port of load.
        /// </summary>
        /// <value>
        /// The port of load.
        /// </value>
        public PortDto PortOfLoad { get; set; }

        /// <summary>
        /// Gets or sets the receipt location.
        /// </summary>
        /// <value>
        /// The receipt location.
        /// </value>
        public LocationDto ReceiptLocation { get; set; }

        /// <summary>
        /// Gets or sets the return depot equipment handling facility.
        /// </summary>
        /// <value>
        /// The return depot equipment handling facility.
        /// </value>
        public TerminalDepotDto ReturnDepotEquipmentHandlingFacility { get; set; }

        /// <summary>
        /// Gets or sets the return equipment authorization number.
        /// </summary>
        /// <value>
        /// The return equipment authorization number.
        /// </value>
        public string ReturnEquipmentAuthorizationNumber { get; set; }

        /// <summary>
        /// Gets or sets the return location.
        /// </summary>
        /// <value>
        /// The return location.
        /// </value>
        public LocationDto ReturnLocation { get; set; }

        /// <summary>
        /// Gets or sets the return terminal equipment handling facility.
        /// </summary>
        /// <value>
        /// The return terminal equipment handling facility.
        /// </value>
        public TerminalDepotDto ReturnTerminalEquipmentHandlingFacility { get; set; }

        /// <summary>
        /// Gets or sets the SCAC code identifier.
        /// </summary>
        /// <value>
        /// The SCAC code identifier.
        /// </value>
        public int? SCACCodeId { get; set; }

        /// <summary>
        /// Gets or sets the seal number.
        /// </summary>
        /// <value>
        /// The seal number.
        /// </value>
        public string SealNumber { get; set; }

        /// <summary>
        /// Gets or sets the shipping instruction number.
        /// </summary>
        /// <value>
        /// The shipping instruction number.
        /// </value>
        public string ShippingInstructionNumber { get; set; }

        /// <summary>
        /// Gets or sets the terminal equipment handling facility.
        /// </summary>
        /// <value>
        /// The terminal equipment handling facility.
        /// </value>
        public TerminalDepotDto TerminalEquipmentHandlingFacility { get; set; }

        /// <summary>
        /// Gets or sets the transshipment port.
        /// </summary>
        /// <value>
        /// The transshipment port.
        /// </value>
        public PortDto TransshipmentPort { get; set; }

        /// <summary>
        /// Gets or sets the vessel.
        /// </summary>
        /// <value>
        /// The vessel.
        /// </value>
        public VesselDto Vessel { get; set; }

        /// <summary>
        /// Gets or sets the voyage.
        /// </summary>
        /// <value>
        /// The voyage.
        /// </value>
        public VesselVoyageDto VesselVoyage { get; set; }

        /// <summary>
        /// Gets or sets the voyage.
        /// </summary>
        /// <value>
        /// The voyage.
        /// </value>
        public string Voyage { get; set; }

        /// <summary>
        /// Gets or sets the voyage eta.
        /// </summary>
        /// <value>
        /// The voyage eta.
        /// </value>
        public DateTime? VoyageETA { get; set; }

        /// <summary>
        /// Gets or sets the voyage ETD.
        /// </summary>
        /// <value>
        /// The voyage ETD.
        /// </value>
        public DateTime? VoyageETD { get; set; }

        #endregion
    }
}
