﻿//-----------------------------------------------------------------------
// <copyright file = "ValidateEquipmentDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidateEquipment. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare ValidateEquipment.
    /// </summary>
    public class ValidateEquipmentDto
    {
        /// <summary>
        /// Gets or sets the available equipment.
        /// </summary>
        /// <value>
        /// The available equipment.
        /// </value>
        public IList<EquipmentFleetDto> AvailableEquipment { get; set; }

        /// <summary>
        /// Gets or sets the duplicate equipment.
        /// </summary>
        /// <value>
        /// The duplicate equipment.
        /// </value>
        public IList<string> DuplicateEquipment { get; set; }

        /// <summary>
        /// Gets or sets the missing equipment.
        /// </summary>
        /// <value>
        /// The missing equipment.
        /// </value>
        public IList<string> MissingEquipment { get; set; }
    }
}