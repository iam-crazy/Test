﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataFilterDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataFilterDto.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare ReferentialDataFilterDto.
    /// </summary>
    public class ReferentialDataFilterDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Action
        /// </summary>
        public int? Action { get; set; }

        /// <summary>
        /// Gets or sets the Activities
        /// </summary>
        public IEnumerable<int> Activities { get; set; }

        /// <summary>
        /// Gets or sets the ActivityType
        /// </summary>
        public int? ActivityType { get; set; }

        /// <summary>
        /// Gets or sets the Category
        /// </summary>
        public IEnumerable<int> Categories { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentStatus
        /// </summary>
        public int? EquipmentStatus { get; set; }

        /// <summary>
        /// Gets or sets the FullEmpty
        /// </summary>
        public int? FullEmpty { get; set; }

        /// <summary>
        /// Gets or sets the GroupCode
        /// </summary>
        public int? GroupCode { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsDisplayToCustomer
        /// </summary>
        public bool? IsDisplayToCustomer { get; set; }

        /// <summary>
        /// Gets or sets the is mapped.
        /// </summary>
        /// <value>
        /// The is mapped.
        /// </value>
        public bool? IsMapped { get; set; }

        /// <summary>
        /// Gets or sets the IsValidationRuleActive
        /// </summary>
        public bool? IsValidationRuleActive { get; set; }

        /// <summary>
        /// Gets or sets the Location
        /// </summary>
        public int? Location { get; set; }

        /// <summary>
        /// Gets or sets the RequirementFieldOne
        /// </summary>
        public IEnumerable<int> RequirementFields { get; set; }

        /// <summary>
        /// Gets or sets the RequirementUsage
        /// </summary>
        public int? RequirementUsage { get; set; }

        /// <summary>
        /// Gets or sets the ShipmentStatus
        /// </summary>
        public IEnumerable<int> ShipmentStatus { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public bool? Status { get; set; }

        /// <summary>
        /// Gets or sets the ValidationRule
        /// </summary>
        public int? ValidationRule { get; set; }

        /// <summary>
        /// Gets or sets the business cycle.
        /// </summary>
        /// <value>
        /// The business cycle.
        /// </value>
        public int? BusinessCycle { get; set; }

        #endregion Properties
    }
}