﻿//-----------------------------------------------------------------------
// <copyright file = "VesselVersionsDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare VesselVersionsDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare VesselVersions.
    /// </summary>
    public class VesselVersionsDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="VesselVersionsDto"/> class.
        /// </summary>
        public VesselVersionsDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int? VesselVersionId { get; set; }

        /// <summary>
        /// Gets or sets the vessel code.
        /// </summary>
        /// <value>
        /// The vessel code.
        /// </value>
        public int? VesselId { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string LongDisplayName { get; set; }

        /// <summary>
        /// Gets or sets the name of the vessel.
        /// </summary>
        /// <value>
        /// The name of the vessel.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the type of the ownership.
        /// </summary>
        /// <value>
        /// The type of the ownership.
        /// </value>
        public OwnershipType OwnershipType { get; set; }

        #endregion Fields
    }
}