﻿//-----------------------------------------------------------------------
// <copyright file = "PortVersionDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare PortDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System.Collections.Generic;

    /// <summary>
    /// Declare Port.
    /// </summary>
    public class PortVersionDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="PortVersionDto"/> class.
        /// </summary>
        public PortVersionDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int PortId { get; set; }

        /// <summary>
        /// Gets or sets the long name of the display.
        /// </summary>
        /// <value>
        /// The long name of the display.
        /// </value>
        public string LongDisplayName { get; set; }

        /// <summary>
        /// Gets or sets the port versions.
        /// </summary>
        /// <value>
        /// The port versions.
        /// </value>
        public IList<PortVersionDto> PortVersions { get; set; }

        #endregion Fields
    }
}