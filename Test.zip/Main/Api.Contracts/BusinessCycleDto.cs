//-----------------------------------------------------------------------
// <copyright file = "BusinessCycleDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare BusinessCycleDto.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    /// <summary>
    /// Declare BusinessCycleDto.
    /// </summary>
    public class BusinessCycleDto : UserInformationDto
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessCycleDto"/> class.
        /// </summary>
        public BusinessCycleDto()
        {
        }

        /// <summary>
        /// Gets or sets the business cycle identifier.
        /// </summary>
        /// <value>
        /// The business cycle identifier.
        /// </value>
        public byte Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}