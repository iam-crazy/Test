﻿//-----------------------------------------------------------------------
// <copyright file = "BasicRequirementDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare BasicRequirementDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare BasicRequirement.
    /// </summary>
    public class BasicRequirementDto : UserInformationDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the basic status.
        /// </summary>
        /// <value>
        /// The basic status.
        /// </value>
        public string BasicStatus { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int BasicRequirementId { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementFieldDto RequirementField { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementFieldDto RequirementFieldTwo { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementFieldDto RequirementFieldThree { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public RequirementBasicUsageDto RequirementUsage { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ReferentialValidationRule"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        #endregion Fields
    }
}