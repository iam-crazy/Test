﻿//-----------------------------------------------------------------------
// <copyright file = "SearchValidationRuleDto.cs" company = "MSC">
//   Mediterranean Shipping Company SA . OneVision Project.
// </copyright>
// <summary>
//   Declare SearchValidationRuleDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare SearchValidationRule.
    /// </summary>
    public class SearchValidationRuleDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the rule number.
        /// </summary>
        /// <value>
        /// The rule number.
        /// </value>
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the Group.
        /// </summary>
        /// <value>
        /// The Group.
        /// </value>
        public string Group { get; set; }

        /// <summary>
        /// Gets or sets the short Description.
        /// </summary>
        /// <value>
        /// The short Description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the valid from date.
        /// </summary>
        /// <value>
        /// The valid from date.
        /// </value>
        public DateTime ValidFrom { get; set; }

        /// <summary>
        /// Gets or sets the valid to date.
        /// </summary>
        /// <value>
        /// The valid to date.
        /// </value>
        public DateTime? ValidTo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="SearchValidationRuleDto"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the Type.
        /// </summary>
        /// <value>
        /// The Activity Type.
        /// </value>
        public string ActivityType { get; set; }

        #endregion Fields
    }
}