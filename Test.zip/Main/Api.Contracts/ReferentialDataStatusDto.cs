﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataStatusDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ReferentialDataStatusDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare ReferentialDataStatusDto.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Api.Contracts.UserInformationDto" />
    public class ReferentialDataStatusDto : UserInformationDto
    {
        /// <summary>
        /// Gets or sets the is mapped.
        /// </summary>
        /// <value>
        /// The is mapped.
        /// </value>
        public bool? IsGateIn { get; set; }

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public int ActivityReferentialId { get; set; }
    }
}