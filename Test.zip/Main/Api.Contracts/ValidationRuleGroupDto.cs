﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleGroupDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleGroupDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare ValidationRuleGroupDto.
    /// </summary>
    public class ValidationRuleGroupDto : UserInformationDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleGroupDto"/> class.
        /// </summary>
        public ValidationRuleGroupDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The General code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        #endregion Fields
    }
}