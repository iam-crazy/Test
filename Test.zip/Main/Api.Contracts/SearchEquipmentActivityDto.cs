﻿//-----------------------------------------------------------------------
// <copyright file = "SearchEquipmentActivityDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare SearchEquipmentActivity. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare SearchEquipmentActivity.
    /// </summary>
    public class SearchEquipmentActivityDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="SearchEquipmentActivityDto"/> class.
        /// </summary>
        public SearchEquipmentActivityDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the equipment number.
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the type of the equipment size.
        /// </summary>
        /// <value>
        /// The type of the equipment size.
        /// </value>
        public string EquipmentSizeType { get; set; }

        /// <summary>
        /// Gets or sets the equipment ISO code.
        /// </summary>
        /// <value>
        /// The equipment ISO code.
        /// </value>
        public string EquipmentISOCode { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="SearchEquipmentActivityDto"/> is SOC.
        /// </summary>
        /// <value>
        ///   <c>true</c> if SOC; otherwise, <c>false</c>.
        /// </value>
        public bool HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the activity code.
        /// </summary>
        /// <value>
        /// The activity code.
        /// </value>
        public string ActivityCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets the activity date time.
        /// </summary>
        /// <value>
        /// The activity date time.
        /// </value>
        public DateTime ActivityDateTime { get; set; }

        /// <summary>
        /// Gets or sets the activity location.
        /// </summary>
        /// <value>
        /// The activity location.
        /// </value>
        public string ActivityLocation { get; set; }

        /// <summary>
        /// Gets or sets the activity terminal depot.
        /// </summary>
        /// <value>
        /// The activity terminal depot.
        /// </value>
        public string ActivityTerminalDepot { get; set; }

        /// <summary>
        /// Gets or sets the activity state.
        /// </summary>
        /// <value>
        /// The activity state.
        /// </value>
        public string ActivityState { get; set; }

        /// <summary>
        /// Gets or sets the Activity DateTime.
        /// </summary>
        /// <value>
        /// The Activity DateTime.
        /// </value>
        public DateTime ActivityUTCDateTime { get; set; }

        /// <summary>
        /// Gets or sets the activity code.
        /// </summary>
        /// <value>
        /// The activity code.
        /// </value>
        public string ActivityCode { get; set; }

        /// <summary>
        /// Gets or sets the activity status.
        /// </summary>
        /// <value>
        /// The activity status.
        /// </value>
        public string ActivityStatus { get; set; }

        /// <summary>
        /// Gets or sets the activity error description.
        /// </summary>
        /// <value>
        /// The activity error description.
        /// </value>
        public string ActivityErrorDescription { get; set; }

        /// <summary>
        /// Gets or sets the port of load.
        /// </summary>
        /// <value>
        /// The port of load.
        /// </value>
        public string PortOfLoad { get; set; }

        /// <summary>
        /// Gets or sets the port of discharge.
        /// </summary>
        /// <value>
        /// The port of discharge.
        /// </value>
        public string PortOfDischarge { get; set; }

        /// <summary>
        /// Gets or sets the transshipment port.
        /// </summary>
        /// <value>
        /// The transshipment port.
        /// </value>
        public string TransshipmentPort { get; set; }

        /// <summary>
        /// Gets or sets the vessel.
        /// </summary>
        /// <value>
        /// The vessel.
        /// </value>
        public string Vessel { get; set; }

        /// <summary>
        /// Gets or sets the voyage.
        /// </summary>
        /// <value>
        /// The voyage.
        /// </value>
        public string Voyage { get; set; }

        /// <summary>
        /// Gets or sets the logged date.
        /// </summary>
        /// <value>
        /// The logged date.
        /// </value>
        public DateTime LoggedDate { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public string Location { get; set; }

        #endregion Fields
    }
}