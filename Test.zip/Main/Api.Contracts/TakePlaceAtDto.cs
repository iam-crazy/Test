namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;

    public class TakePlaceAtDto : UserInformationDto
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TakePlaceAt"/> class.
        /// </summary>
        public TakePlaceAtDto()
        {
        }

        /// <summary>
        /// Gets or sets the take place at identifier.
        /// </summary>
        /// <value>
        /// The take place at identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}