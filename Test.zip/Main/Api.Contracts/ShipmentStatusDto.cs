﻿//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatusDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ShipmentStatusDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare ShipmentStatusDto.
    /// </summary>
    public class ShipmentStatusDto : UserInformationDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentStatusDto"/> class.
        /// </summary>
        public ShipmentStatusDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the shipment status identifier.
        /// </summary>
        /// <value>
        /// The shipment status identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The shipment code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        #endregion Fields
    }
}