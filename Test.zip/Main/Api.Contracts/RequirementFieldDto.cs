﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementFieldDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementFieldDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare RequirementFields.
    /// </summary>
    public class RequirementFieldDto : UserInformationDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementFieldDto"/> class.
        /// </summary>
        public RequirementFieldDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        public string Code { get; set; }

        public RequirementGroupDto RequirementGroup { get; set; }

        #endregion Fields
    }
}