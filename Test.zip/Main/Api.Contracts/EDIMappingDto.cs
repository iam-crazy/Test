﻿//-----------------------------------------------------------------------
// <copyright file = "EDIMappingDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EDIMappingDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare EDIMapping.
    /// </summary>
    public class EDIMappingDto : UserInformationDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the activity referential identifier.
        /// </summary>
        /// <value>
        /// The activity referential identifier.
        /// </value>
        public int ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the edi mapping identifier.
        /// </summary>
        /// <value>
        /// The edi mapping identifier.
        /// </value>
        public int EDIMappingId { get; set; }

        /// <summary>
        /// Gets or sets the equipment status.
        /// </summary>
        /// <value>
        /// The equipment status.
        /// </value>
        public EquipmentStatusDto EquipmentStatus { get; set; }

        /// <summary>
        /// Gets or sets the shipment status.
        /// </summary>
        /// <value>
        /// The shipment status.
        /// </value>
        public ShipmentStatusDto ShipmentStatus { get; set; }

        #endregion Fields
    }
}