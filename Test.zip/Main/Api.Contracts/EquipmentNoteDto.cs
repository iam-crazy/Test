//-----------------------------------------------------------------------
// <copyright file = "EquipmentNoteDto.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Defines the <see cref="EquipmentNoteDto" />
    /// </summary>
    public partial class EquipmentNoteDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>
        /// The created on.
        /// </value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the equipment identifier.
        /// </summary>
        /// <value>
        /// The equipment identifier.
        /// </value>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the equipment notes identifier.
        /// </summary>
        /// <value>
        /// The equipment notes identifier.
        /// </value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public UserBaseDto UserBase { get; set; }

        #endregion
    }
}
