﻿//-----------------------------------------------------------------------
// <copyright file = "SearchLogicalSequenceDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare SearchLogicalSequenceDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare SearchLogicalSequence.
    /// </summary>
    public class SearchLogicalSequenceDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the logical sequence identifier.
        /// </summary>
        /// <value>
        /// The logical sequence identifier.
        /// </value>
        public int LogicalSequenceId { get; set; }

        /// <summary>
        /// Gets or sets the current move identifier.
        /// </summary>
        /// <value>
        /// The current move identifier.
        /// </value>
        public string CurrentMove { get; set; }

        /// <summary>
        /// Gets or sets the next move identifier.
        /// </summary>
        /// <value>
        /// The next move identifier.
        /// </value>
        public string NextMove { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the inactive reason.
        /// </summary>
        /// <value>
        /// The inactive reason.
        /// </value>
        public string Remarks { get; set; }

        #endregion Fields
    }
}