﻿//-----------------------------------------------------------------------
// <copyright file = "LogisticsStatusDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogisticsStatusDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare LogisticsStatusDto.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Api.Contracts.GeneralCodeDto" />
    public class LogisticsStatusDto : GeneralCodeDto
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LogisticsStatusDto"/> class.
        /// </summary>
        public LogisticsStatusDto()
        {
        }

        /// <summary>
        /// Gets or sets the is mapped.
        /// </summary>
        /// <value>
        /// The is mapped.
        /// </value>
        public bool? IsGateIn { get; set; }
    }
}