﻿//-----------------------------------------------------------------------
// <copyright file = "VoyageDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare VoyageDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare Voyage.
    /// </summary>
    public class VoyageDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="VoyageDto"/> class.
        /// </summary>
        public VoyageDto()
        {
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        /// Gets or sets the voyage identifier.
        /// </summary>
        /// <value>
        /// The voyage identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the voyage.
        /// </summary>
        /// <value>
        /// The name of the voyage.
        /// </value>
        public string VoyageName { get; set; }

        #endregion Fields
    }
}