﻿//-----------------------------------------------------------------------
// <copyright file = "ValidateEquipmentActivityDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidateEquipmentActivityDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare ValidateEquipmentActivityDto.
    /// </summary>
    public class ValidateEquipmentActivityDto
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance is duplicate.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is duplicate; otherwise, <c>false</c>.
        /// </value>
        public bool IsDuplicate { get; set; }

        /// <summary>
        /// Returns true if ... is valid.
        /// </summary>
        /// <value>
        ///  <c>true</c> if this instance is valid; otherwise, <c>false</c>.
        /// </value>
        public bool IsValid { get; set; }
    }
}