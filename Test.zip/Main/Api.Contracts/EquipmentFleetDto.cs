﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentFleetDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentFleet. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare EquipmentFleet.
    /// </summary>
    public class EquipmentFleetDto : UserInformationDto
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentFleetDto"/> class.
        /// </summary>
        public EquipmentFleetDto()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the EquipmentId
        /// </summary>
        public long EquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public EquipmentISOCodeDto EquipmentISO { get; set; } = new EquipmentISOCodeDto();

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code value.
        /// </value>
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public EquipmentSizeTypeDto EquipmentSizeType { get; set; } = new EquipmentSizeTypeDto();

        /// <summary>
        /// Gets or sets a value indicating whether this instance is SOC.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is SOC; otherwise, <c>false</c>.
        /// </value>
        public bool HasSOC { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        #endregion
    }
}
