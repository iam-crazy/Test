﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityHeaderDetailDto.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityHeaderDetailDto.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare EquipmentActivityHeaderDetailDto.
    /// </summary>
    public class EquipmentActivityHeaderDetailDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Count
        /// </summary>
        public long Count { get; set; }

        /// <summary>
        /// Gets or sets the ErrorDescription
        /// </summary>
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Gets or sets the RuleNumber
        /// </summary>
        public string RuleNumber { get; set; }

        /// <summary>
        /// Gets or sets the ValidationId
        /// </summary>
        public int? ValidationId { get; set; }

        #endregion
    }
}
