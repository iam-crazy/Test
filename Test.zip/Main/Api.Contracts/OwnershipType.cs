﻿//-----------------------------------------------------------------------
// <copyright file = "OwnershipType.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare OwnershipType. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare OwnershipType.
    /// </summary>
    public class OwnershipType
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the OwnershipType class.
        /// </summary>
        public OwnershipType()
        {
        }

        #endregion Constructor

        /// <summary>
        /// Gets or sets the ownership type identifier.
        /// </summary>
        /// <value>
        /// The ownership type identifier.
        /// </value>
        public int OwnershipTypeId { get; set; }

        /// <summary>
        /// Gets or sets the MSC code.
        /// </summary>
        /// <value>
        /// The MSC code.
        /// </value>
        public string MscCode { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }
    }
}