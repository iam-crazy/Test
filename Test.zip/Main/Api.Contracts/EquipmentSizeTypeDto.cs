﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentSizeTypeDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentSizeTypeDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare Equipment Size Type.
    /// </summary>
    public class EquipmentSizeTypeDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the size type identifier.
        /// </summary>
        /// <value>
        /// The size type identifier.
        /// </value>
        public int EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets the type of the size.
        /// </summary>
        /// <value>
        /// The type of the size.
        /// </value>
        public string SizeType { get; set; }

        #endregion Properties
    }
}