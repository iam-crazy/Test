﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialQuickAccessCount.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialQuickAccessCount.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare ReferentialQuickAccessCount.
    /// </summary>
    public class ReferentialQuickAccessCountDto
    {
        /// <summary>
        /// All count.
        /// </summary>
        public long AllCount { get; set; }

        /// <summary>
        /// The mapped count.
        /// </summary>
        public long MappedCount { get; set; }

        /// <summary>
        /// The un mapped count.
        /// </summary>
        public long UnmappedCount { get; set; }
    }
}