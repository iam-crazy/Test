﻿//-----------------------------------------------------------------------
// <copyright file = "SearchReferentialDataDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare SearchReferentialDataDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare SearchReferentialData.
    /// </summary>
    public class SearchReferentialDataDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="SearchReferentialDataDto"/> class.
        /// </summary>
        public SearchReferentialDataDto()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The Referential code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the type of the activity.
        /// </summary>
        /// <value>
        /// The type of the activity.
        /// </value>
        public ActivityTypeDto ActivityType { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the action.
        /// </summary>
        /// <value>
        /// The action.
        /// </value>
        public ActivityActionDto ActivityAction { get; set; }

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        public TakePlaceAtDto ActivityLocation { get; set; }

        /// <summary>
        /// Gets or sets the glossary.
        /// </summary>
        /// <value>
        /// The glossary.
        /// </value>
        public string Glossary { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the full empty.
        /// </summary>
        /// <value>
        /// The full empty.
        /// </value>
        public GeneralCodeDto FullEmpty { get; set; }

        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        public ActivityCategoryDto ActivityCategory { get; set; }

        /// <summary>
        /// Gets or sets the business cycle.
        /// </summary>
        /// <value>
        /// The business cycle.
        /// </value>
        public BusinessCycleDto BusinessCycle { get; set; }

        #endregion Properties
    }
}