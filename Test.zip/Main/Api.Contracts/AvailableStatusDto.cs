﻿//-----------------------------------------------------------------------
// <copyright file = "AvailableStatusDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare AvailableStatusDto. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare AvailableStatusDto.
    /// </summary>
    public class AvailableStatusDto
    {
        /// <summary>
        /// Gets or sets the available equipment.
        /// </summary>
        /// <value>
        /// The available equipment.
        /// </value>
        public bool IsSequence { get; set; }

        /// <summary>
        /// Gets or sets the duplicate equipment.
        /// </summary>
        /// <value>
        /// The duplicate equipment.
        /// </value>
        public bool IsCombination { get; set; }

        /// <summary>
        /// Gets or sets the missing equipment.
        /// </summary>
        /// <value>
        /// The missing equipment.
        /// </value>
        public bool IsLogical { get; set; }
    }
}