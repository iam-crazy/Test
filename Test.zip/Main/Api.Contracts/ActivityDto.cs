﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare Activity. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    /// <summary>
    /// Declare Activity.
    /// </summary>
    public class ActivityDto
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityDto"/> class.
        /// </summary>
        public ActivityDto()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int ActivityReferentialId { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The Activity code.
        /// </value>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The activity type.
        /// </value>
        public ActivityTypeDto ActivityType { get; set; }

        #endregion Properties
    }
}