﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequenceDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare LogicalSequence.
    /// </summary>
    public class LogicalSequenceDto : UserInformationDto
    {
        #region Properties

        /// <summary>
        /// Gets or sets the logical sequence identifier.
        /// </summary>
        /// <value>
        /// The logical sequence identifier.
        /// </value>
        public int LogicalActivityId { get; set; }

        /// <summary>
        /// Gets or sets the current move identifier.
        /// </summary>
        /// <value>
        /// The current move identifier.
        /// </value>
        public ActivityDto FromActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets the next move identifier.
        /// </summary>
        /// <value>
        /// The next move identifier.
        /// </value>
        public ActivityDto ToActivityReferential { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="LogicalSequenceDto"/> is status.
        /// </summary>
        /// <value>
        ///   <c>true</c> if status; otherwise, <c>false</c>.
        /// </value>
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets the remarks.
        /// </summary>
        /// <value>
        /// The remarks.
        /// </value>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets or sets the row status.
        /// </summary>
        /// <value>
        /// The row status.
        /// </value>
        public string RowStatus { get; set; }

        /// <summary>
        /// Gets or sets the equipment categories.
        /// </summary>
        /// <value>
        /// The equipment categories.
        /// </value>
        public EquipmentCategoryDto EquipmentCategory { get; set; }

        #endregion Properties
    }
}