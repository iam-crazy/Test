﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentISOCodeDto.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentISOCodeDto.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Contracts
{
    using System;

    /// <summary>
    /// Declare Equipment ISO Type.
    /// </summary>
    public class EquipmentISOCodeDto
    {
        #region Fields

        /// <summary>
        /// Gets or sets the ISO code identifier.
        /// </summary>
        /// <value>
        /// The ISO code identifier.
        /// </value>
        public int EquipmentSizeTypeCodeId { get; set; }

        /// <summary>
        /// Gets or sets the equipment type identifier.
        /// </summary>
        /// <value>
        /// The equipment type identifier.
        /// </value>
        public short EquipmentSizeTypeId { get; set; }

        /// <summary>
        /// Gets or sets the ISO code.
        /// </summary>
        /// <value>
        /// The ISO code.
        /// </value>
        public string MscCode { get; set; }

        #endregion Fields
    }
}