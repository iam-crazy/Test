﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityExtension.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityExtension.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Extension
{
    using System;
    using Business.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityExtension.
    /// </summary>
    public static class EquipmentActivityExtension
    {
        #region Public Methods

        /// <summary>
        /// Gets the equipment activity filter.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentSizeType">Type of the equipment size.</param>
        /// <param name="equipmentISOCode">The equipment iso code.</param>
        /// <param name="shipperOwnedContainer">The shipper owned container.</param>
        /// <param name="activityCode">The activity code.</param>
        /// <param name="activityTerminalId">The activity terminal identifier.</param>
        /// <param name="dateType">Type of the date.</param>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="activityTerminalDepotId">The activity terminal depot identifier.</param>
        /// <param name="activityStatus">The activity status.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="portOfLoad">The port of load.</param>
        /// <param name="portOfDischarge">The port of discharge.</param>
        /// <param name="shippingInstructionNumber">The shipping instruction number.</param>
        /// <param name="placeOfDeliveryLocationId">The place of delivery location identifier.</param>
        /// <param name="placeOfFinalDestinationLocationId">The place of final destination location identifier.</param>
        /// <param name="scacCode">The scac code.</param>
        /// <param name="voyage">The voyage.</param>
        /// <param name="fromDate">From date value.</param>
        /// <param name="toDate">To date value.</param>
        /// <param name="transshipmentPort">The transshipment port.</param>
        /// <param name="receiptLocationId">The receipt location identifier.</param>
        /// <param name="returnLocation">The return location.</param>
        /// <param name="returnTerminalEquipment">The return terminal equipment.</param>
        /// <param name="returnDepotEquipment">The return depot equipment.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="sealNumber">The seal number.</param>
        /// <param name="bookingNumber">The booking number.</param>
        /// <param name="billOfLadingNumber">The bill of lading number.</param>
        /// <param name="leasingCompanyReference">The leasing company reference.</param>
        /// <param name="pickupReference">The pickup reference.</param>
        /// <param name="mscAuthorizationReference">The MSC authorization reference.</param>
        /// <param name="returnEquipmentAuthorizationNumber">The return equipment authorization number.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <param name="valid">The valid.</param>
        /// <returns>Returns Validation rule.</returns>
        public static EquipmentActivityFilter GetEquipmentActivityFilter(string equipmentActivityId, int? equipmentSizeType, int? equipmentISOCode, bool? shipperOwnedContainer, int? activityCode, int? activityTerminalId, bool? dateType, int? activityLocationId, int? activityTerminalDepotId, string activityStatus, long? equipmentNumber, int? portOfLoad, int? portOfDischarge, string shippingInstructionNumber, int? placeOfDeliveryLocationId, int? placeOfFinalDestinationLocationId, int? scacCode, int? voyage, DateTime? fromDate, DateTime? toDate, int? transshipmentPort, int? receiptLocationId, int? returnLocation, int? returnTerminalEquipment, int? returnDepotEquipment, int? vesselId, string sealNumber, string bookingNumber, string billOfLadingNumber, string leasingCompanyReference, string pickupReference, string mscAuthorizationReference, string returnEquipmentAuthorizationNumber, bool? showCancel, string validationRule, string feederVoyage, int pageIndex, int pageSize, int? validationRuleId, bool? valid)
        {
            var activityFilter = new EquipmentActivityFilter();
            activityFilter.EquipmentActivityId = equipmentActivityId;
            activityFilter.EquipmentSizeType = equipmentSizeType;
            activityFilter.EquipmentISO = equipmentISOCode;
            activityFilter.HasSOC = shipperOwnedContainer;
            activityFilter.Activity = activityCode;
            activityFilter.Location = activityLocationId;
            activityFilter.ActivityTerminal = activityTerminalId;
            activityFilter.ActivityDepot = activityTerminalDepotId;
            activityFilter.EquipmentId = equipmentNumber;
            activityFilter.PortOfLoading = portOfLoad;
            activityFilter.PortOfDischarge = portOfDischarge;
            activityFilter.TransshipmentPort = transshipmentPort;
            activityFilter.ShippingInstructionNumber = shippingInstructionNumber;
            activityFilter.PlaceOfDelivery = placeOfDeliveryLocationId;
            activityFilter.PlaceOfFinalDestination = placeOfFinalDestinationLocationId;
            activityFilter.SCACCode = scacCode;
            activityFilter.Voyage = voyage;
            activityFilter.FeederVoyage = feederVoyage;
            activityFilter.PlaceOfReceipt = receiptLocationId;
            activityFilter.ReturnLocation = returnLocation;
            activityFilter.ReturnTerminal = returnTerminalEquipment;
            activityFilter.ReturnDepot = returnDepotEquipment;
            activityFilter.Vessel = vesselId;
            activityFilter.DateType = dateType;
            activityFilter.SealNumber = sealNumber;
            activityFilter.BLNumber = billOfLadingNumber;
            activityFilter.ShowCancel = showCancel;
            activityFilter.ActivityStatus = activityStatus;
            activityFilter.ValidationRule = validationRule;
            activityFilter.FromDate = fromDate;
            activityFilter.ToDate = toDate;
            activityFilter.BookingNumber = bookingNumber;
            activityFilter.LeasingCompanyReference = leasingCompanyReference;
            activityFilter.PickupReference = pickupReference;
            activityFilter.MSCAuthorizationReference = mscAuthorizationReference;
            activityFilter.ReturnEquipmentAuthorizationNumber = returnEquipmentAuthorizationNumber;
            activityFilter.PageIndex = pageIndex;
            activityFilter.PageSize = pageSize;
            activityFilter.ValidationRuleId = validationRuleId;
            activityFilter.Valid = valid;
            return activityFilter;
        }

        #endregion
    }
}
