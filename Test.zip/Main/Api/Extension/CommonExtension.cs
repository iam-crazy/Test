﻿//-----------------------------------------------------------------------
// <copyright file = "CommonExtension.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare CommonExtension.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Extension
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;

    /// <summary>
    /// Declare CommonExtension.
    /// </summary>
    public static class CommonExtension
    {
        /////// <summary>
        /////// Creates the read only response.
        /////// </summary>
        /////// <typeparam name="TSource">The type of the source.</typeparam>
        /////// <typeparam name="TDestination">The type of the destination.</typeparam>
        /////// <param name="item">The response item.</param>
        /////// <param name="controller">The controller.</param>
        /////// <param name="mapper">The response mapper.</param>
        /////// <returns>Returns The Response.</returns>
        /////// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /////// </exception>
        ////public static HttpResponseMessage CreateReadOnlyResponse<TSource, TDestination>(this TSource item, ApiController controller, IMapper mapper)
        ////{
        ////    if (controller == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(controller));
        ////    }

        ////    if (mapper == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(mapper));
        ////    }

        ////    HttpStatusCode statusCode = HttpStatusCode.OK;
        ////    TDestination resultData = default(TDestination);
        ////    if (item == null)
        ////    {
        ////        statusCode = HttpStatusCode.NotFound;
        ////        return controller.Request.CreateResponse(statusCode, Resource.ValidationMessage.LBL_NoRecordFound);
        ////    }
        ////    else
        ////    {
        ////        resultData = mapper.Map<TDestination>(item);
        ////    }

        ////    return controller.Request.CreateResponse(statusCode, resultData);
        ////}

        /// <summary>
        /// Creates the read only response.
        /// </summary>
        /// <typeparam name="TSource">The type of the source.</typeparam>
        /// <param name="controller">The controller.</param>
        /// <param name="item">The response item.</param>
        /// <returns>Returns The Response.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public static HttpResponseMessage CreateReadOnlyResponse<TSource>(this ApiController controller, TSource item)
        {
            if (controller == null)
            {
                throw new ArgumentNullException(nameof(controller));
            }

            HttpStatusCode statusCode = HttpStatusCode.OK;
            if (item == null)
            {
                statusCode = HttpStatusCode.NotFound;
                return controller.Request.CreateResponse(statusCode, Resource.ValidationMessage.LBL_NoRecordFound);
            }

            return controller.Request.CreateResponse(statusCode, item);
        }
    }
}