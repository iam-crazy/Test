﻿//-----------------------------------------------------------------------
// <copyright file = "TimelineController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare TimelineController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;
    using Framework.Common.Model.Pagination;

    /// <summary>
    /// Timeline Data Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/timelines")]
    public class TimelineController : ApiController
    {
        #region Member

        /// <summary>
        /// The time line data service.
        /// </summary>
        private readonly ITimelineService timelineService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="TimelineController"/> class.
        /// </summary>
        /// <param name="timelineService">The timeline service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public TimelineController(ITimelineService timelineService, IMapper mapper)
        {
            if (timelineService == null)
            {
                throw new ArgumentNullException(nameof(timelineService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.timelineService = timelineService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="showCancel">If set to <c>true</c> [show cancel].</param>
        /// <returns>Returns the equipment list.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentActivityList(long equipmentActivityId, bool showCancel)
        {             
            if (equipmentActivityId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<EquipmentActivity> data = await this.timelineService.GetEquipmentActivityList(equipmentActivityId, showCancel);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentActivityDto>>(data));           
        } 
        #endregion Public Methods
    }
}