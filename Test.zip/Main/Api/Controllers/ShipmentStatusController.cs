﻿//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatusController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ShipmentStatusController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Shipment Status Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/shipmentStatus")]
    public class ShipmentStatusController : ApiController
    {
        #region Member

        /// <summary>
        /// The shipment status service.
        /// </summary>
        private readonly IShipmentStatusService shipmentStatusService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentStatusController"/> class.
        /// </summary>
        /// <param name="shipmentStatusService">The shipment Status Service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ShipmentStatusController(IShipmentStatusService shipmentStatusService, IMapper mapper)
        {
            if (shipmentStatusService == null)
            {
                throw new ArgumentNullException(nameof(shipmentStatusService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.shipmentStatusService = shipmentStatusService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the shipment status.
        /// </summary>
        /// <param name="shipmentStatusCodes">The shipment status codes.</param>
        /// <returns>
        /// Returns Shipment Status.
        /// </returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetShipmentStatus(string shipmentStatusCodes = null)
        {
            IList<ShipmentStatus> data = await this.shipmentStatusService.GetShipmentStatus(shipmentStatusCodes);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ShipmentStatusDto>>(data));
        }

        /// <summary>
        /// Saves the specified shipment status data.
        /// </summary>
        /// <param name="shipmentStatusData">The shipment status data.</param>
        /// <returns>Return Save Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ShipmentStatusDto shipmentStatusData)
        {
            var result = this.mapper.Map<ShipmentStatus>(shipmentStatusData);
            BusinessOutcome output = await this.shipmentStatusService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified shipment status data identifier.
        /// </summary>
        /// <param name="shipmentStatusDataId">The shipment status data identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int shipmentStatusDataId, int userId)
        {
            if (shipmentStatusDataId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.shipmentStatusService.Delete(shipmentStatusDataId, userId));
        }

        #endregion Public Methods
    }
}