﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityActionController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ActivityActionController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Referential Data Controller..
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/activityActions")]
    public class ActivityActionController : ApiController
    {
        #region Member

        /// <summary>
        /// The referential data service.
        /// </summary>
        private readonly IActivityActionService activityActionService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityActionController"/> class.
        /// </summary>
        /// <param name="activityActionService">The activity action service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ActivityActionController(IActivityActionService activityActionService, IMapper mapper)
        {
            if (activityActionService == null)
            {
                throw new ArgumentNullException(nameof(activityActionService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.activityActionService = activityActionService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the requirement field list.
        /// </summary>
        /// <returns>
        /// Returns requirement field list.
        /// </returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetActivityActions()
        {
            IList<ActivityAction> data = await this.activityActionService.GetActivityActions();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ActivityActionDto>>(data));
            ////return data.CreateReadOnlyResponse<IList<ActivityAction>, IList<ActivityActionDto>>(this, this.mapper);
        }

        /// <summary>
        /// Save Referential Data.
        /// </summary>
        /// <param name="activityActionData">The activity action data.</param>
        /// <returns>
        /// Return the Response of save.
        /// </returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ActivityAction activityActionData)
        {
            var result = this.mapper.Map<ActivityAction>(activityActionData);
            BusinessOutcome outcome = await this.activityActionService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, outcome.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified activity action identifier.
        /// </summary>
        /// <param name="activityActionId">The activity action identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int activityActionId, int userId)
        {
            if (activityActionId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.activityActionService.Delete(activityActionId, userId));
        }

        #endregion Public Methods
    }
}