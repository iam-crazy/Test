﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleGroupController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleGroupController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare ValidationRuleGroupController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/validationRuleGroup")]
    public class ValidationRuleGroupController : ApiController
    {
        #region Members

        /// <summary>
        /// The validation rule group service.
        /// </summary>
        private readonly IValidationRuleGroupService validationRuleGroupService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleGroupController"/> class.
        /// </summary>
        /// <param name="validationRuleGroupService">The validation rule group service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleGroupController(IValidationRuleGroupService validationRuleGroupService, IMapper mapper)
        {
            if (validationRuleGroupService == null)
            {
                throw new ArgumentNullException(nameof(validationRuleGroupService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.validationRuleGroupService = validationRuleGroupService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rule group list.
        /// </summary>
        /// <returns>Returns validation RuleGroup list.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetValidationRuleGroupList()
        {
            IList<ValidationRuleGroup> data = await this.validationRuleGroupService.GetValidationRuleGroups();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ValidationRuleGroupDto>>(data));
        }

        /// <summary>
        /// Saves the specified validation rule group data.
        /// </summary>
        /// <param name="validationRuleGroupData">The validation rule group data.</param>
        /// <returns>Returns Save data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ValidationRuleGroupDto validationRuleGroupData)
        {
            var mapped = this.mapper.Map<ValidationRuleGroup>(validationRuleGroupData);
            BusinessOutcome output = await this.validationRuleGroupService.Save(mapped);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Delete the specified validation rule group identifier.
        /// </summary>
        /// <param name="validationRuleGroupId">The validation rule group identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Returns Delete data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int validationRuleGroupId, int userId)
        {
            if (validationRuleGroupId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.validationRuleGroupService.Delete(validationRuleGroupId, userId));
        }

        #endregion Public Methods
    }
}