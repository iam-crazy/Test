﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Validation Rule Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/validationRules")]
    public class ValidationRuleController : ApiController
    {
        #region Members

        /// <summary>
        /// The port term repository.
        /// </summary>
        private readonly IValidationRuleService validationruleService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleController"/> class.
        /// </summary>
        /// <param name="validationRuleService">The validation rule service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ValidationRuleController(IValidationRuleService validationRuleService, IMapper mapper)
        {
            if (validationRuleService == null)
            {
                throw new ArgumentNullException(nameof(validationRuleService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.validationruleService = validationRuleService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rule list.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <param name="group">The validation group.</param>
        /// <param name="description">The description.</param>
        /// <param name="validFrom">The valid from.</param>
        /// <param name="validTo">The valid to.</param>
        /// <param name="status">The validation status.</param>
        /// <param name="type">The validation type.</param>
        /// <param name="limit">The validation limit.</param>
        /// <param name="offset">The validation offset.</param>
        /// <param name="searchValue">The search string.</param>
        /// <returns>Returns the validation rule list.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetValidationRules(int? ruleNumber = null, string group = null, string description = null, DateTime? validFrom = null, DateTime? validTo = null, bool? status = true, string type = null, int limit = 0, int offset = 0, string searchValue = null)
        {
            IList<ValidationRule> data = await this.validationruleService.GetValidationRules(ruleNumber, group, description, validFrom, validTo, status, type, limit, offset, searchValue);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ValidationRuleDto>>(data));
        }

        /// <summary>
        /// Searches the validation rules.
        /// </summary>
        /// <param name="group">The rule group.</param>
        /// <param name="id">The validation id.</param>
        /// <returns>Returns Validation Rules.</returns>
        [Route("SearchValidationRules")]
        [HttpGet]
        public async Task<HttpResponseMessage> SearchValidationRules(string group, int id)
        {
            if (group == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<ValidationRuleBase> data = await this.validationruleService.SearchValidationRules(group, id);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<List<ValidationRuleBaseDto>>(data));
        }

        /// <summary>
        /// Save the specified validation rule.
        /// </summary>
        /// <param name="validationRule">The validation rule.</param>
        /// <returns>Returns The Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ValidationRuleDto validationRule)
        {
            var result = this.mapper.Map<ValidationRule>(validationRule);
            BusinessOutcome output = await this.validationruleService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Updates the specified validation rule.
        /// </summary>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Specified Data.</returns>
        [Route("{id}")]
        [HttpPut]
        public async Task<HttpResponseMessage> Update([FromBody]ValidationRuleDto validationRule, int id = 0)
        {
            if (id == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var result = this.mapper.Map<ValidationRule>(validationRule);
            BusinessOutcome output = await this.validationruleService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Gets the validation rule.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns The data.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("{validationRuleId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetValidationRule(int validationRuleId)
        {
            if (validationRuleId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var data = await this.validationruleService.GetValidationRule(validationRuleId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<ValidationRuleDto>(data));
        }

        #endregion Public Methods
    }
}