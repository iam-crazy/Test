﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityNoteController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityNoteController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Framework.Common.Model;

    /// <summary>
    /// Declare EquipmentActivityNoteController.
    /// </summary>
    [RoutePrefix("v1/equipmentActivityNote")]
    public class EquipmentActivityNoteController : ApiController
    {
        #region Fields

        /// <summary>
        /// Defines the equipmentNoteService.
        /// </summary>
        private readonly IEquipmentActivityNoteService equipmentNoteService;

        /// <summary>
        /// Defines the mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivityNoteController"/> class.
        /// </summary>
        /// <param name="equipmentNoteService">The <see cref="IEquipmentActivityNoteService"/></param>
        /// <param name="mapper">The <see cref="IMapper"/></param>
        public EquipmentActivityNoteController(IEquipmentActivityNoteService equipmentNoteService, IMapper mapper)
        {
            if (equipmentNoteService == null)
            {
                throw new ArgumentNullException(nameof(equipmentNoteService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.equipmentNoteService = equipmentNoteService;
            this.mapper = mapper;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the equipment activity note.
        /// </summary>
        /// <param name="equipmentActivityNoteId">The equipment activity note identifier.</param>
        /// <returns>Returns the equipment note.</returns>
        [Route("{equipmentActivityNoteId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentActivityNote(int equipmentActivityNoteId)
        {
            IList<EquipmentActivityNote> data = await this.equipmentNoteService.GetEquipmentActivityNote(equipmentActivityNoteId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentActivityNoteDto>>(data));
        }

        /// <summary>
        /// Saves the specified equipment note.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns the equipment note.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(EquipmentActivityNoteDto equipmentNote)
        {
            var result = this.mapper.Map<EquipmentActivityNote>(equipmentNote);
            BusinessOutcome output = await this.equipmentNoteService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        #endregion
    }
}
