﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleErrorResultController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleErrorResultController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare ValidationRuleErrorResultController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/validationRuleErrorResults")]
    public class ValidationRuleErrorResultController : ApiController
    {
        #region Members

        /// <summary>
        /// The validation rule error result service.
        /// </summary>
        private readonly IValidationRuleErrorResultService validationRuleErrorResultService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleErrorResultController"/> class.
        /// </summary>
        /// <param name="validationRuleErrorResultService">The validation rule error result service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleErrorResultController(IValidationRuleErrorResultService validationRuleErrorResultService, IMapper mapper)
        {
            if (validationRuleErrorResultService == null)
            {
                throw new ArgumentNullException(nameof(validationRuleErrorResultService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.validationRuleErrorResultService = validationRuleErrorResultService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rule error results.
        /// </summary>
        /// <returns>Returns the Validation Rule Error results.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetValidationRuleErrorResults()
        {
            IList<ValidationRuleErrorResult> data = await this.validationRuleErrorResultService.GetValidationRuleErrorResults();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ValidationRuleErrorResultDto>>(data));
        }

        /// <summary>
        /// Saves the specified validation rule error result data.
        /// </summary>
        /// <param name="validationRuleErrorResultData">The validation rule error result data.</param>
        /// <returns>Returns the save data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ValidationRuleErrorResultDto validationRuleErrorResultData)
        {
            var mapped = this.mapper.Map<ValidationRuleErrorResult>(validationRuleErrorResultData);
            BusinessOutcome output = await this.validationRuleErrorResultService.Save(mapped);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Delete the specified validation rule error result identifier.
        /// </summary>
        /// <param name="validationRuleErrorResultId">The validation rule error result identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Returns the delete data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int validationRuleErrorResultId, int userId)
        {
            if (validationRuleErrorResultId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.validationRuleErrorResultService.Delete(validationRuleErrorResultId, userId));
        }

        #endregion Public Methods
    }
}