﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStatusController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentStatusController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Equipment Status Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/equipmentStatus")]
    public class EquipmentStatusController : ApiController
    {
        #region Member

        /// <summary>
        /// The equipment status service.
        /// </summary>
        private readonly IEquipmentStatusService equipmentStatusService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStatusController"/> class.
        /// </summary>
        /// <param name="equipmentStatusService">The equipment Status Service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public EquipmentStatusController(IEquipmentStatusService equipmentStatusService, IMapper mapper)
        {
            if (equipmentStatusService == null)
            {
                throw new ArgumentNullException(nameof(equipmentStatusService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.equipmentStatusService = equipmentStatusService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <returns>Returns equipment status.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentStatus()
        {
            IList<EquipmentStatus> data = await this.equipmentStatusService.GetEquipmentStatus();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentStatusDto>>(data));
        }

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentStatusData">The equipment status data.</param>
        /// <returns>Return Save Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(EquipmentStatusDto equipmentStatusData)
        {
            var result = this.mapper.Map<EquipmentStatus>(equipmentStatusData);
            BusinessOutcome output = await this.equipmentStatusService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified equipment status data identifier.
        /// </summary>
        /// <param name="equipmentStatusDataId">The equipment status data identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int equipmentStatusDataId, int userId)
        {
            if (equipmentStatusDataId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.equipmentStatusService.Delete(equipmentStatusDataId, userId));
        }

        #endregion Public Methods
    }
}