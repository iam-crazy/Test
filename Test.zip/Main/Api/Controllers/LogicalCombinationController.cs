﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombinationController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalCombinationController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare EquipmentActivityController.
    /// </summary>
    [RoutePrefix("v1/logicalCombinations")]
    public class LogicalCombinationController : ApiController
    {
        #region Member

        /// <summary>
        /// The logical combination service.
        /// </summary>
        private readonly ILogicalCombinationService logicalCombinationService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalCombinationController"/> class.
        /// </summary>
        /// <param name="logicalCombinationService">The logical combination service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public LogicalCombinationController(ILogicalCombinationService logicalCombinationService, IMapper mapper)
        {
            if (logicalCombinationService == null)
            {
                throw new ArgumentNullException(nameof(logicalCombinationService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.logicalCombinationService = logicalCombinationService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The specified data.</param>
        /// <returns>Returns The Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save([FromBody] IList<LogicalCombinationDto> data)
        {
            if (data == null)
            {
                return this.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new ArgumentNullException(nameof(data)));
            }

            var result = this.mapper.Map<IList<LogicalCombination>>(data);
            BusinessOutcome output = await this.logicalCombinationService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Updates the specified data.
        /// </summary>
        /// <param name="data">The specified data.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Specified Data.</returns>
        [Route("{id}")]
        [HttpPut]
        public async Task<HttpResponseMessage> Update([FromBody] IList<LogicalCombinationDto> data, int id = 0)
        {
            if (id == 0)
            {
                return this.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new ArgumentNullException(nameof(data)));
            }

            var result = this.mapper.Map<IList<LogicalCombination>>(data);
            BusinessOutcome output = await this.logicalCombinationService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Gets the logical combinations.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>Returns Logical Combination List.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetLogicalCombinations(int moveCodeId = 0)
        {
            IList<LogicalCombination> data = await this.logicalCombinationService.GetLogicalCombinationList(moveCodeId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<LogicalCombinationDto>>(data));
        }         

        #endregion Public Methods
    }
}