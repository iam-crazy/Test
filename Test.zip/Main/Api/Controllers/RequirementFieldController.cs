﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementFieldController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementFieldController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare Requirement Field Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/requirementField")]
    public class RequirementFieldController : ApiController
    {
        #region Members

        /// <summary>
        /// The requirement field service.
        /// </summary>
        private readonly IRequirementFieldService requirementFieldService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementFieldController"/> class.
        /// </summary>
        /// <param name="requirementFieldService">The requirement field service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public RequirementFieldController(IRequirementFieldService requirementFieldService, IMapper mapper)
        {
            if (requirementFieldService == null)
            {
                throw new ArgumentNullException(nameof(requirementFieldService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.requirementFieldService = requirementFieldService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the requirement fields.
        /// </summary>
        /// <returns>The requirement fields.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetRequirementFields()
        {
            IList<RequirementField> data = await this.requirementFieldService.GetRequirementFields();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<RequirementFieldDto>>(data));
        }

        /// <summary>
        /// Saves the specified requirement field data.
        /// </summary>
        /// <param name="requirementFieldData">The requirement field data.</param>
        /// <returns>The saved data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(RequirementFieldDto requirementFieldData)
        {
            var result = this.mapper.Map<RequirementField>(requirementFieldData);
            BusinessOutcome output = await this.requirementFieldService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified requirement field identifier.
        /// </summary>
        /// <param name="requirementFieldId">The requirement field identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Delete the record.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int requirementFieldId, int userId)
        {
            if (requirementFieldId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.requirementFieldService.Delete(requirementFieldId, userId));
        }

        #endregion Public Methods
    }
}