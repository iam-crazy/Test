//-----------------------------------------------------------------------
// <copyright file = "ErrorController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ErrorController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    /// <summary>
    /// Error Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    public class ErrorController : ApiController
    {
        /// <summary>
        /// Handle404s this instance.
        /// </summary>
        /// <returns>Returns The Message.</returns>
        [HttpGet, HttpPost, HttpPut, HttpDelete, HttpHead, HttpOptions, AcceptVerbs("PATCH")]
        public HttpResponseMessage Handle404()
        {
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, Resource.ValidationMessage.LBL_RequestResourceNotFound);
        }
    }
}