﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Framework.Common.Model;
    using Msc.Logistics.EME.Service.Api.Extension;

    /// <summary>
    /// Referential Data Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/referentialData")]
    public class ReferentialDataController : ApiController
    {
        #region Fields

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The referential data service.
        /// </summary>
        private readonly IReferentialDataService referentialDataService;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferentialDataController" /> class.
        /// </summary>
        /// <param name="referentialDataService">The referential data service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ReferentialDataController(IReferentialDataService referentialDataService, IMapper mapper)
        {
            if (referentialDataService == null)
            {
                throw new ArgumentNullException(nameof(referentialDataService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.referentialDataService = referentialDataService;
            this.mapper = mapper;
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Gets the activity referential list.
        /// </summary>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>Returns The Type Of Activity.</returns>
        [Route("GetActivityCodes")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetActivityReferentialList(string activityType = null)
        {
            IList<Activity> data = await this.referentialDataService.GetActivityReferentialList(activityType);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ActivityDto>>(data));
        }

        /// <summary>
        /// Gets the Full Empty field list.
        /// </summary>
        /// <returns>Returns Full Empty list.</returns>
        [Route("GetFullEmpty")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetFullEmpty()
        {
            IList<FullEmpty> data = await this.referentialDataService.GetFullEmptyDetails();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<FullEmptyDto>>(data));
        }

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <param name="referentialDataId">The referential data identifier.</param>
        /// <returns>Returns The Id.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("{referentialDataId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetReferentialData(int referentialDataId)
        {
            if (referentialDataId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var data = await this.referentialDataService.GetReferentialData(referentialDataId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<ReferentialDataDto>(data));
        }

        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>Returns The List.</returns>
        [Route("ReferentialList")]
        [HttpPost]
        public async Task<HttpResponseMessage> GetReferentialList(ReferentialDataFilterDto referentialData)
        {
            IList<SearchReferentialData> data = await this.referentialDataService.GetReferentialList(this.mapper.Map<ReferentialDataFilter>(referentialData));
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<SearchReferentialDataDto>>(data));
        }

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>Returns The Referentail Count.</returns>
        [Route("GetQuickAccessCount")]
        [HttpPost]
        public async Task<HttpResponseMessage> GetQuickAccessCount(ReferentialDataFilterDto referentialData)
        {
            Tuple<int, int, int> data = await this.referentialDataService.GetQuickAccessCount(this.mapper.Map<ReferentialDataFilter>(referentialData));
            return this.CreateReadOnlyResponse(new ReferentialQuickAccessCountDto() { AllCount = data.Item1, MappedCount = data.Item2, UnmappedCount = data.Item3 });
        }

        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="isMapped">Is Mapped with EDI.</param>
        /// <returns>Returns The List.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetReferentialList(bool? isMapped = null)
        {
            IList<SearchReferentialData> data = await this.referentialDataService.GetReferentialList(isMapped);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<SearchReferentialDataDto>>(data));
        }

        /// <summary>
        /// Gets the requirement field list.
        /// </summary>
        /// <returns>Returns requirement field list.</returns>
        [Route("GetRequirementFieldList")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetRequirementFieldList()
        {
            IList<RequirementField> data = await this.referentialDataService.GetReferentialFields();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<RequirementFieldDto>>(data));
        }

        /// <summary>
        /// Gets the requirement usage list.
        /// </summary>
        /// <returns>Returns Requirement Usage List.</returns>
        [Route("GetRequirementUsageList")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetRequirementUsageList()
        {
            var data = await this.referentialDataService.GetReferentialUsage();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<RequirementBasicUsageDto>>(data));
        }

        /// <summary>
        /// Save Referential Data.
        /// </summary>
        /// <param name="referentialData">Referential data.</param>
        /// <returns>
        /// Return the Response of save.
        /// </returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ReferentialDataDto referentialData)
        {
            if (referentialData == null)
            {
                throw new ArgumentException(nameof(referentialData));
            }

            var result = this.mapper.Map<ReferentialData>(referentialData);
            BusinessOutcome output = await this.referentialDataService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <returns>Returns The Referentail Count.</returns>
        [Route("GetQuickAccessCount")]
        [HttpGet]
        public async Task<HttpResponseMessage> SearchQuickAccessCount()
        {
            Tuple<int, int, int> data = await this.referentialDataService.SearchQuickAccessCount();
            return this.CreateReadOnlyResponse(new ReferentialQuickAccessCountDto() { AllCount = data.Item1, MappedCount = data.Item2, UnmappedCount = data.Item3 });
        }

        /// <summary>
        /// Updates the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>Returns Referential Data.</returns>
        [Route("{id}")]
        [HttpPut]
        public async Task<HttpResponseMessage> Update(int id, [FromBody]ReferentialDataDto referentialData)
        {
            if (id == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var result = this.mapper.Map<ReferentialData>(referentialData);
            BusinessOutcome output = await this.referentialDataService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        ///  Gets the Referential Validation rules associated with the given validation rule id.
        /// </summary>
        /// <param name="validationRuleId">Selected validationrule.</param>
        /// <returns>Referential Validation rules.</returns>
        [Route("GetReferentialValidationRules")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetReferentialValidationRules(int validationRuleId)
        {
            if (validationRuleId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<ReferentialValidationRule> data = await this.referentialDataService.GetReferentialValidationRules(validationRuleId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ReferentialValidationRuleDto>>(data));
        }

        /// <summary>
        /// Updates the logistics status.
        /// </summary>
        /// <param name="referentialStatus">The referentialStatus.</param>
        /// <returns>Returns saved data.</returns>
        [Route("UpdateBusinessCycle")]
        [HttpPut]
        public async Task<HttpResponseMessage> UpdateBusinessCycle([FromBody]ReferentialDataStatusDto referentialStatus)
        {
            var result = this.mapper.Map<ReferentialDataStatus>(referentialStatus);
            BusinessOutcome output = await this.referentialDataService.UpdateBusinessCycle(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        #endregion Public Methods
    }
}