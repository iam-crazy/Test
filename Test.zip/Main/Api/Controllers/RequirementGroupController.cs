﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementGroupController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementGroupController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Framework.Common.Model;

    /// <summary>
    /// Declare Requirement Field Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/requirementGroup")]
    public class RequirementGroupController : ApiController
    {
        #region Members

        /// <summary>
        /// The requirement group service.
        /// </summary>
        private readonly IRequirementGroupService requirementGroupService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementGroupController"/> class.
        /// </summary>
        /// <param name="requirementGroupService">The requirement group service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">The Argument Null Exception.
        /// </exception>
        public RequirementGroupController(IRequirementGroupService requirementGroupService, IMapper mapper)
        {
            if (requirementGroupService == null)
            {
                throw new ArgumentNullException(nameof(requirementGroupService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.requirementGroupService = requirementGroupService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the requirement Groups.
        /// </summary>
        /// <returns>Return the Requirement Group.</returns>
        [Route("")]
        [HttpGet]
        public async Task<IList<RequirementGroupDto>> GetRequirementGroup()
        {
            var data = await this.requirementGroupService.GetRequirementGroups();
            var items = this.mapper.Map<List<RequirementGroupDto>>(data);
            return items;
        }

        /// <summary>
        /// Saves the specified requirement group data.
        /// </summary>
        /// <param name="requirementGroupData">The requirement group data.</param>
        /// <returns>Returns the Save Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<OperationOutcome> Save(RequirementGroupDto requirementGroupData)
        {
            OperationOutcome output = null;
            var result = this.mapper.Map<RequirementGroup>(requirementGroupData);
            output = await this.requirementGroupService.Save(result);
            return output;
        }

        /// <summary>
        /// Deletes the specified requirement group identifier.
        /// </summary>
        /// <param name="requirementGroupId">The requirement group identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Returns the Delete Record.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<OperationOutcome> Delete(int requirementGroupId, int userId)
        {
            OperationOutcome output = null;
            output = await this.requirementGroupService.Delete(requirementGroupId, userId);
            return output;
        }

        #endregion Public Methods
    }
}