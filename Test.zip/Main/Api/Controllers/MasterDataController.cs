﻿//-----------------------------------------------------------------------
// <copyright file = "MasterDataController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare MasterDataController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;

    /// <summary>
    /// Declare MasterDataController.
    /// </summary>
    [RoutePrefix("v1/masterData")]
    public class MasterDataController : ApiController
    {
        #region Members

        /// <summary>
        /// The general code data service.
        /// </summary>
        private readonly IMasterDataService masterDataService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="MasterDataController"/> class.
        /// </summary>
        /// <param name="masterDataService">The master data service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public MasterDataController(IMasterDataService masterDataService, IMapper mapper)
        {
            if (masterDataService == null)
            {
                throw new ArgumentNullException(nameof(masterDataService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.masterDataService = masterDataService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Searches the voyage.
        /// </summary>
        /// <returns>Returns voyage.</returns>
        [HttpGet]
        [Route("SearchVoyage")]
        public IList<VesselVoyage> SearchVoyage()
        {
            var data = this.masterDataService.SearchVoyage();
            return this.mapper.Map<List<VesselVoyage>>(data);
        }

        #endregion Public Methods
    }
}