﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStateController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentStateController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Framework.Common.Model;
    using Msc.Logistics.EME.Service.Api.Contracts;
    using Msc.Logistics.EME.Service.Api.Extension;
    using Msc.Logistics.EME.Service.Business.Contracts;
    using Msc.Logistics.EME.Service.Business.Contracts.Objects;

    /// <summary>
    /// Equipment State Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/equipmentStates")]
    public class EquipmentStateController : ApiController
    {
        #region Member

        /// <summary>
        /// The equipment state service.
        /// </summary>
        private readonly IEquipmentStateService equipmentStateService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStateController"/> class.
        /// </summary>
        /// <param name="equipmentStateService">The equipment state service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public EquipmentStateController(IEquipmentStateService equipmentStateService, IMapper mapper)
        {
            if (equipmentStateService == null)
            {
                throw new ArgumentNullException(nameof(equipmentStateService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.equipmentStateService = equipmentStateService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <returns>Returns equipment status.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> SearchEquipmentStates()
        {
            IList<EquipmentState> data = await this.equipmentStateService.SearchEquipmentStates();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentStateDto>>(data));
        }

        /// <summary>
        /// Saves the specified equipment state data.
        /// </summary>
        /// <param name="equipmentStateData">The equipment state data.</param>
        /// <returns>Return Save Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(EquipmentStatusDto equipmentStateData)
        {
            var result = this.mapper.Map<EquipmentState>(equipmentStateData);
            BusinessOutcome output = await this.equipmentStateService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified equipment state data identifier.
        /// </summary>
        /// <param name="equipmentStateDataId">The equipment state data identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int equipmentStateDataId, int userId)
        {
            if (equipmentStateDataId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.equipmentStateService.Delete(equipmentStateDataId, userId));
        }

        #endregion Public Methods
    }
}