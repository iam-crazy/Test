﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalActivityStatusController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalActivityStatusController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// LogicalActivityStatus Controller..
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/logicalActivityStatus")]
    public class LogicalActivityStatusController : ApiController
    {
        #region Member

        /// <summary>
        /// The logicalActivityStatus Service.
        /// </summary>
        private readonly ILogicalActivityStatusService logicalActivityStatusService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalActivityStatusController"/> class.
        /// </summary>
        /// <param name="logicalActivityStatusService">The logicalActivityStatus service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public LogicalActivityStatusController(ILogicalActivityStatusService logicalActivityStatusService, IMapper mapper)
        {
            if (logicalActivityStatusService == null)
            {
                throw new ArgumentNullException(nameof(logicalActivityStatusService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.logicalActivityStatusService = logicalActivityStatusService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods   

        /// <summary>
        /// Updates the logical activity status.
        /// </summary>
        /// <param name="activity">The activity.</param>
        /// <returns>Returns the logical activity data.</returns>
        [Route("")]
        [HttpPut]
        public async Task<HttpResponseMessage> UpdateLogicalActivityStatus(LogicalSequenceUpdateDto activity)
        {
            if (activity == null || activity.LogicalActivityId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var result = this.mapper.Map<LogicalSequenceUpdate>(activity);
            BusinessOutcome output = await this.logicalActivityStatusService.UpdateLogicalActivityStatus(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());             
        }       

        /// <summary>
        /// Checks the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>Returns the logical activity data.</returns>
        [Route("CheckLogicalActivityStatus")]
        [HttpGet]
        public async Task<HttpResponseMessage> CheckLogicalActivityStatus(int activityId, string activityType)
        {
            if (activityId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }          

            var data = await this.logicalActivityStatusService.CheckLogicalActivityStatus(activityId, activityType);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<AvailableStatusDto>(data));  
        }

        #endregion Public Methods
    }
}