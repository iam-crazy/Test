﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleTypeController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ValidationRuleTypeController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare ValidationRuleTypeController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/validationRuleTypes")]
    public class ValidationRuleTypeController : ApiController
    {
        #region Members

        /// <summary>
        /// The validation rule type service.
        /// </summary>
        private readonly IValidationRuleTypeService validationRuleTypeService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleTypeController"/> class.
        /// </summary>
        /// <param name="validationRuleTypeService">The validation rule type service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleTypeController(IValidationRuleTypeService validationRuleTypeService, IMapper mapper)
        {
            if (validationRuleTypeService == null)
            {
                throw new ArgumentNullException(nameof(validationRuleTypeService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.validationRuleTypeService = validationRuleTypeService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rule group list.
        /// </summary>
        /// <returns>Returns ValidationRule Group list.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetValidationRuleGroupList()
        {
            IList<ValidationRuleType> data = await this.validationRuleTypeService.GetValidationRuleTypes();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ValidationRuleTypeDto>>(data));
        }

        /// <summary>
        /// Saves the specified validation rule type data.
        /// </summary>
        /// <param name="validationRuleTypeData">The validation rule type data.</param>
        /// <returns>Returns Save data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ValidationRuleTypeDto validationRuleTypeData)
        {
            var mapped = this.mapper.Map<ValidationRuleType>(validationRuleTypeData);
            BusinessOutcome output = await this.validationRuleTypeService.Save(mapped);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Delete the specified validation rule type identifier.
        /// </summary>
        /// <param name="validationRuleTypeId">The validation rule type identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Returns Delete data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int validationRuleTypeId, int userId)
        {
            if (validationRuleTypeId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.validationRuleTypeService.Delete(validationRuleTypeId, userId));
        }

        #endregion Public Methods
    }
}