﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentNoteController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentNoteController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Framework.Common.Model;

    /// <summary>
    /// Declare EquipmentNoteController.
    /// </summary>
    [RoutePrefix("v1/equipmentNote")]
    public class EquipmentNoteController : ApiController
    {
        #region Fields

        /// <summary>
        /// Defines the equipmentNoteService.
        /// </summary>
        private readonly IEquipmentNoteService equipmentNoteService;

        /// <summary>
        /// Defines the mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentNoteController"/> class.
        /// </summary>
        /// <param name="equipmentNoteService">The <see cref="IEquipmentNoteService"/></param>
        /// <param name="mapper">The <see cref="IMapper"/></param>
        public EquipmentNoteController(IEquipmentNoteService equipmentNoteService, IMapper mapper)
        {
            if (equipmentNoteService == null)
            {
                throw new ArgumentNullException(nameof(equipmentNoteService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.equipmentNoteService = equipmentNoteService;
            this.mapper = mapper;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the equipment note.
        /// </summary>
        /// <param name="equipmentNoteId">The equipment note identifier.</param>
        /// <returns>Returns equipment note.</returns>
        [Route("{equipmentNoteId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentNote(int equipmentNoteId)
        {
            IList<EquipmentNote> data = await this.equipmentNoteService.GetEquipmentNote(equipmentNoteId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentNoteDto>>(data));
        }

        /// <summary>
        /// Saves the specified equipment note.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns the equipment value.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(EquipmentNoteDto equipmentNote)
        {
            if (equipmentNote == null)
            {
                return this.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new ArgumentNullException(nameof(equipmentNote)));
            }

            var result = this.mapper.Map<EquipmentNote>(equipmentNote);
            BusinessOutcome output = await this.equipmentNoteService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        #endregion
    }
}
