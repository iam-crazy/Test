﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityCategoryController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ActivityCategoryController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare ActivityCategoryController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/activityCategories")]
    public class ActivityCategoryController : ApiController
    {
        #region Member

        /// <summary>
        /// The activity category service.
        /// </summary>
        private readonly IActivityCategoryService activityCategoryService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityCategoryController"/> class.
        /// </summary>
        /// <param name="activityCategoryService">The activity category service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ActivityCategoryController(IActivityCategoryService activityCategoryService, IMapper mapper)
        {
            if (activityCategoryService == null)
            {
                throw new ArgumentNullException(nameof(activityCategoryService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.activityCategoryService = activityCategoryService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the activity category.
        /// </summary>
        /// <returns>Return the activity category list.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetActivityCategories()
        {
            IList<ActivityCategory> data = await this.activityCategoryService.GetActivityCategories();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<ActivityCategoryDto>>(data));
            //// return data.CreateReadOnlyResponse<IList<ActivityCategory>, IList<ActivityCategoryDto>>(this, this.mapper);
        }

        /// <summary>
        /// Saves the specified activity category data.
        /// </summary>
        /// <param name="activityCategoryData">The activity category data.</param>
        /// <returns>The saved data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(ActivityCategoryDto activityCategoryData)
        {
            var result = this.mapper.Map<ActivityCategory>(activityCategoryData);
            BusinessOutcome outcome = await this.activityCategoryService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, outcome.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified activity category identifier.
        /// </summary>
        /// <param name="activityCategoryId">The activity action identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Delete the record.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int activityCategoryId, int userId)
        {
            if (activityCategoryId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.activityCategoryService.Delete(activityCategoryId, userId));
        }

        #endregion Public Methods
    }
}