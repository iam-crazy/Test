﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare GeneralCodeController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;

    /// <summary>
    /// Declare GeneralCodeController.
    /// </summary>
    [RoutePrefix("v1/generalCodes")]
    public class GeneralCodeController : ApiController
    {
        #region Member

        /// <summary>
        /// The general code data service.
        /// </summary>
        private readonly IGeneralCodeDataService generalCodeDataService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="GeneralCodeController"/> class.
        /// </summary>
        /// <param name="generalCodeDataService">The general code data service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public GeneralCodeController(IGeneralCodeDataService generalCodeDataService, IMapper mapper)
        {
            if (generalCodeDataService == null)
            {
                throw new ArgumentNullException(nameof(generalCodeDataService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.generalCodeDataService = generalCodeDataService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="code">The general code.</param>
        /// <param name="description">The description.</param>
        /// <param name="referenceName">Name of the reference.</param>
        /// <param name="limit">The general limit.</param>
        /// <param name="offset">The general offset.</param>
        /// <param name="searchValue">The search string.</param>
        /// <returns>Returns The GeneralCode.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetGeneralCodes(string code = null, string description = null, string referenceName = null, int limit = 0, int offset = 0, string searchValue = null)
        {
            IList<GeneralCode> data = this.generalCodeDataService.GetGeneralCodes(code, description, referenceName, limit, offset, searchValue);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<GeneralCodeDto>>(data));
        }

        #endregion Public Methods
    }
}