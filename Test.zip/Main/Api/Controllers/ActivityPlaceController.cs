﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityPlaceController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ActivityPlaceController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare Activity Place Controller.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/activityPlaces")]
    public class ActivityPlaceController : ApiController
    {
        #region Member

        /// <summary>
        /// The activity place service.
        /// </summary>
        private readonly IActivityPlaceService activityPlaceService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityPlaceController"/> class.
        /// </summary>
        /// <param name="activityPlaceService">The activity place service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ActivityPlaceController(IActivityPlaceService activityPlaceService, IMapper mapper)
        {
            if (activityPlaceService == null)
            {
                throw new ArgumentNullException(nameof(activityPlaceService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.activityPlaceService = activityPlaceService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the activity place.
        /// </summary>
        /// <returns>Return the activity place list.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetActivityPlace()
        {
            IList<TakePlaceAt> data = await this.activityPlaceService.GetActivityPlaces();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<TakePlaceAtDto>>(data));
        }

        /// <summary>
        /// Saves the specified activity place data.
        /// </summary>
        /// <param name="activityPlaceData">The activity place data.</param>
        /// <returns>The saved data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(TakePlaceAtDto activityPlaceData)
        {
            var result = this.mapper.Map<TakePlaceAt>(activityPlaceData);
            BusinessOutcome output = await this.activityPlaceService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified activity place identifier.
        /// </summary>
        /// <param name="activityPlaceId">The activity place identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Delete the record.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int activityPlaceId, int userId)
        {
            if (activityPlaceId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.activityPlaceService.Delete(activityPlaceId, userId));
        }

        #endregion Public Methods
    }
}