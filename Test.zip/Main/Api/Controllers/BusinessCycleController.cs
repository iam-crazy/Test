﻿//-----------------------------------------------------------------------
// <copyright file = "BusinessCycleController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare BusinessCycleController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Msc.Framework.Common.Model;
    using Msc.Logistics.EME.Service.Api.Contracts;
    using Msc.Logistics.EME.Service.Business.Contracts;
    using Msc.Logistics.EME.Service.Business.Contracts.Objects;

    /// <summary>
    /// Declare BusinessCycleController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/businessCycle")]
    public class BusinessCycleController : ApiController
    {
        /// <summary>
        /// The business cycle service.
        /// </summary>
        private readonly IBusinessCycleService businessCycleService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessCycleController" /> class.
        /// </summary>
        /// <param name="businessCycleService">The business cycle service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Throws Exception.</exception>
        public BusinessCycleController(IBusinessCycleService businessCycleService, IMapper mapper)
        {
            if (businessCycleService == null)
            {
                throw new ArgumentNullException(nameof(businessCycleService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.businessCycleService = businessCycleService;
            this.mapper = mapper;
        }

        /// <summary>
        /// Gets the requirement field list.
        /// </summary>
        /// <returns>
        /// Returns requirement field list.
        /// </returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetBusinessCycles()
        {
            IList<BusinessCycle> data = await this.businessCycleService.GetBusinessCycles();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<BusinessCycleDto>>(data));
        }

        /// <summary>
        /// Saves the specified business cycle data.
        /// </summary>
        /// <param name="businessCycleData">The business cycle data.</param>
        /// <returns>
        /// Return the Response of save.
        /// </returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(BusinessCycle businessCycleData)
        {
            var result = this.mapper.Map<BusinessCycle>(businessCycleData);
            BusinessOutcome outcome = await this.businessCycleService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, outcome.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified business cycle identifier.
        /// </summary>
        /// <param name="businessCycleId">The business cycle identifier.</param>
        /// <param name="userId">The user identifier.</param>
        /// <returns>Returns Delete Data.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int businessCycleId, int userId)
        {
            if (businessCycleId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.businessCycleService.Delete(businessCycleId, userId));
        }
    }
}