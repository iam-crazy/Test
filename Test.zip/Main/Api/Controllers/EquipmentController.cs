﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Framework.Common.Model;

    /// <summary>
    /// Declare EquipmentController.
    /// </summary>
    [RoutePrefix("v1/equipments")]
    public class EquipmentController : ApiController
    {
        #region Fields

        /// <summary>
        /// Defines the equipmentService.
        /// </summary>
        private readonly IEquipmentService equipmentService;

        /// <summary>
        /// Defines the mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentController"/> class.
        /// </summary>
        /// <param name="equipmentService">The <see cref="IEquipmentService"/></param>
        /// <param name="mapper">The <see cref="IMapper"/></param>
        public EquipmentController(IEquipmentService equipmentService, IMapper mapper)
        {
            if (equipmentService == null)
            {
                throw new ArgumentNullException(nameof(equipmentService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.equipmentService = equipmentService;
            this.mapper = mapper;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the equipment.
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <returns>Returns the equipment.</returns>
        [Route("{equipmentId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipment(int equipmentId)
        {
            IList<Equipment> data = await this.equipmentService.GetEquipment(equipmentId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentDto>>(data));
        }

        /// <summary>
        /// Saves the specified equipment note.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns the equipment note.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(EquipmentDto equipmentNote)
        {
            if (equipmentNote == null)
            {
                return this.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new ArgumentNullException(nameof(equipmentNote)));
            }

            Equipment result = this.mapper.Map<Equipment>(equipmentNote);
            BusinessOutcome output = await this.equipmentService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        #endregion
    }
}
