﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityController.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;
    using Framework.Common.Model.Pagination;

    /// <summary>
    /// Declare EquipmentActivityController.
    /// </summary>
    [RoutePrefix("v1/equipmentActivities")]
    public class EquipmentActivityController : ApiController
    {
        #region Fields

        /// <summary>
        /// The equipment activity service.
        /// </summary>
        private readonly IEquipmentActivityService equipmentActivityService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivityController"/> class.
        /// </summary>
        /// <param name="equipmentActivityService">The equipment activity service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public EquipmentActivityController(IEquipmentActivityService equipmentActivityService, IMapper mapper)
        {
            if (equipmentActivityService == null)
            {
                throw new ArgumentNullException(nameof(equipmentActivityService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.equipmentActivityService = equipmentActivityService;
            this.mapper = mapper;
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The activity data.</param>
        /// <returns>Returns The Data.</returns>
        [Route("Cancel")]
        [HttpPut]
        public async Task<HttpResponseMessage> Cancel(IList<CancelEquipmentActivityDto> data)
        {
            var result = this.mapper.Map<List<CancelEquipmentActivity>>(data);
            BusinessOutcome output = await this.equipmentActivityService.Cancel(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Checks the equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="voyage">The voyage.</param>
        /// <returns>Returns Validation rule.</returns>
        [Route("CheckEquipments")]
        [HttpGet]
        public async Task<HttpResponseMessage> CheckEquipment(string equipmentActivityId, string equipmentNumber, int activityReferentialId, DateTime activityDateTime, int locationId, int vesselId, int voyageId, string voyage)
        {
            var data = await this.equipmentActivityService.CheckEquipment(equipmentActivityId, equipmentNumber, activityReferentialId, activityDateTime, locationId, vesselId, voyageId, voyage);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<ValidateEquipmentDto>(data));
        }

        /// <summary>
        /// Checks the equipment activity.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentSizeType">Type of the equipment size.</param>
        /// <param name="equipmentISOCode">The equipment ISO code.</param>
        /// <param name="shipperOwnedContainer">The shipper owned container.</param>
        /// <param name="activityCode">The activity code.</param>
        /// <param name="activityTerminalId">The activity terminal identifier.</param>
        /// <param name="dateType">Type of the date.</param>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="activityTerminalDepotId">The activity terminal depot identifier.</param>
        /// <param name="activityStatus">The activity status.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="portOfLoad">The port of load.</param>
        /// <param name="portOfDischarge">The port of discharge.</param>
        /// <param name="shippingInstructionNumber">The shipping instruction number.</param>
        /// <param name="placeOfDeliveryLocationId">The place of delivery location identifier.</param>
        /// <param name="placeOfFinalDestinationLocationId">The place of final destination location identifier.</param>
        /// <param name="scacCode">The SCAC code.</param>
        /// <param name="voyage">The voyage.</param>
        /// <param name="fromDate">The From date.</param>
        /// <param name="toDate">The To date.</param>
        /// <param name="transshipmentPort">The transshipment port.</param>
        /// <param name="receiptLocationId">The receipt location identifier.</param>
        /// <param name="returnLocation">The return location.</param>
        /// <param name="returnTerminalEquipment">The return terminal equipment.</param>
        /// <param name="returnDepotEquipment">The return depot equipment.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="sealNumber">The seal number.</param>
        /// <param name="bookingNumber">The booking number.</param>
        /// <param name="billOfLadingNumber">The bill of lading number.</param>
        /// <param name="leasingCompanyReference">The leasing company reference.</param>
        /// <param name="pickupReference">The pickup reference.</param>
        /// <param name="mscAuthorizationReference">The MSC authorization reference.</param>
        /// <param name="returnEquipmentAuthorizationNumber">The return equipment authorization number.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <param name="valid">The Equipment valid.</param>
        /// <returns>Returns Check Equipment Activity.</returns>
        [Route("CheckEquipmentActivity")]
        [HttpGet]
        public async Task<HttpResponseMessage> CheckEquipmentActivity(string equipmentActivityId = null, int? equipmentSizeType = null, int? equipmentISOCode = null, bool? shipperOwnedContainer = null, int? activityCode = null, int? activityTerminalId = null, bool? dateType = null, int? activityLocationId = null, int? activityTerminalDepotId = null, string activityStatus = null, long? equipmentNumber = null, int? portOfLoad = null, int? portOfDischarge = null, string shippingInstructionNumber = null, int? placeOfDeliveryLocationId = null, int? placeOfFinalDestinationLocationId = null, int? scacCode = null, int? voyage = null, DateTime? fromDate = null, DateTime? toDate = null, int? transshipmentPort = null, int? receiptLocationId = null, int? returnLocation = null, int? returnTerminalEquipment = null, int? returnDepotEquipment = null, int? vesselId = null, string sealNumber = null, string bookingNumber = null, string billOfLadingNumber = null, string leasingCompanyReference = null, string pickupReference = null, string mscAuthorizationReference = null, string returnEquipmentAuthorizationNumber = null, bool? showCancel = null, string validationRule = null, string feederVoyage = null, int? validationRuleId = 0, bool? valid = null)
        {
            EquipmentActivityFilter activityFilter = EquipmentActivityExtension.GetEquipmentActivityFilter(equipmentActivityId, equipmentSizeType, equipmentISOCode, shipperOwnedContainer, activityCode, activityTerminalId, dateType, activityLocationId, activityTerminalDepotId, activityStatus, equipmentNumber, portOfLoad, portOfDischarge, shippingInstructionNumber, placeOfDeliveryLocationId, placeOfFinalDestinationLocationId, scacCode, voyage, fromDate, toDate, transshipmentPort, receiptLocationId, returnLocation, returnTerminalEquipment, returnDepotEquipment, vesselId, sealNumber, bookingNumber, billOfLadingNumber, leasingCompanyReference, pickupReference, mscAuthorizationReference, returnEquipmentAuthorizationNumber, showCancel, validationRule, feederVoyage, 0, 0, validationRuleId, valid);
            if (activityFilter == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            bool data = await this.equipmentActivityService.CheckEquipmentActivity(validationRuleId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<bool>(data));
        }

        /// <summary>
        /// Gets the equipment activity.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <returns>Returns The Id.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("{equipmentActivityId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentActivity(int equipmentActivityId)
        {
            if (equipmentActivityId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var data = await this.equipmentActivityService.GetEquipmentActivity(equipmentActivityId, string.Empty);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<EquipmentActivityDto>(data));
        }

        /// <summary>
        /// Gets the equipment activity ids.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentSizeType">Type of the equipment size.</param>
        /// <param name="equipmentISOCode">The equipment ISO code.</param>
        /// <param name="shipperOwnedContainer">The shipper owned container.</param>
        /// <param name="activityCode">The activity code.</param>
        /// <param name="activityTerminalId">The activity terminal identifier.</param>
        /// <param name="dateType">Type of the date.</param>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="activityTerminalDepotId">The activity terminal depot identifier.</param>
        /// <param name="activityStatus">The activity status.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="portOfLoad">The port of load.</param>
        /// <param name="portOfDischarge">The port of discharge.</param>
        /// <param name="shippingInstructionNumber">The shipping instruction number.</param>
        /// <param name="placeOfDeliveryLocationId">The place of delivery location identifier.</param>
        /// <param name="placeOfFinalDestinationLocationId">The place of final destination location identifier.</param>
        /// <param name="scacCode">The SCAC code.</param>
        /// <param name="voyage">The voyage.</param>
        /// <param name="fromDate">The From date.</param>
        /// <param name="toDate">The To date.</param>
        /// <param name="transshipmentPort">The transshipment port.</param>
        /// <param name="receiptLocationId">The receipt location identifier.</param>
        /// <param name="returnLocation">The return location.</param>
        /// <param name="returnTerminalEquipment">The return terminal equipment.</param>
        /// <param name="returnDepotEquipment">The return depot equipment.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="sealNumber">The seal number.</param>
        /// <param name="bookingNumber">The booking number.</param>
        /// <param name="billOfLadingNumber">The bill of lading number.</param>
        /// <param name="leasingCompanyReference">The leasing company reference.</param>
        /// <param name="pickupReference">The pickup reference.</param>
        /// <param name="mscAuthorizationReference">The MSC authorization reference.</param>
        /// <param name="returnEquipmentAuthorizationNumber">The return equipment authorization number.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <param name="valid">The Equipment valid.</param>
        /// <returns>Returns Equipment Activity Ids.</returns>
        [Route("GetEquipmentActivityIds")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentActivityIds(string equipmentActivityId = null, int? equipmentSizeType = null, int? equipmentISOCode = null, bool? shipperOwnedContainer = null, int? activityCode = null, int? activityTerminalId = null, bool? dateType = null, int? activityLocationId = null, int? activityTerminalDepotId = null, string activityStatus = null, long? equipmentNumber = null, int? portOfLoad = null, int? portOfDischarge = null, string shippingInstructionNumber = null, int? placeOfDeliveryLocationId = null, int? placeOfFinalDestinationLocationId = null, int? scacCode = null, int? voyage = null, DateTime? fromDate = null, DateTime? toDate = null, int? transshipmentPort = null, int? receiptLocationId = null, int? returnLocation = null, int? returnTerminalEquipment = null, int? returnDepotEquipment = null, int? vesselId = null, string sealNumber = null, string bookingNumber = null, string billOfLadingNumber = null, string leasingCompanyReference = null, string pickupReference = null, string mscAuthorizationReference = null, string returnEquipmentAuthorizationNumber = null, bool? showCancel = null, string validationRule = null, string feederVoyage = null, int? validationRuleId = 0, bool? valid = null)
        {
            EquipmentActivityFilter activityFilter = EquipmentActivityExtension.GetEquipmentActivityFilter(equipmentActivityId, equipmentSizeType, equipmentISOCode, shipperOwnedContainer, activityCode, activityTerminalId, dateType, activityLocationId, activityTerminalDepotId, activityStatus, equipmentNumber, portOfLoad, portOfDischarge, shippingInstructionNumber, placeOfDeliveryLocationId, placeOfFinalDestinationLocationId, scacCode, voyage, fromDate, toDate, transshipmentPort, receiptLocationId, returnLocation, returnTerminalEquipment, returnDepotEquipment, vesselId, sealNumber, bookingNumber, billOfLadingNumber, leasingCompanyReference, pickupReference, mscAuthorizationReference, returnEquipmentAuthorizationNumber, showCancel, validationRule, feederVoyage, 0, 0, validationRuleId, valid);
            if (activityFilter == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<long> data = await this.equipmentActivityService.GetEquipmentActivityIds(validationRuleId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<long>>(data));
        }

        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentSizeType">Type of the equipment size.</param>
        /// <param name="equipmentISOCode">The equipment iso code.</param>
        /// <param name="shipperOwnedContainer">The shipper owned container.</param>
        /// <param name="activityCode">The activity code.</param>
        /// <param name="activityTerminalId">The activity terminal identifier.</param>
        /// <param name="dateType">Type of the date.</param>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="activityTerminalDepotId">The activity terminal depot identifier.</param>
        /// <param name="activityStatus">The activity status.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="portOfLoad">The port of load.</param>
        /// <param name="portOfDischarge">The port of discharge.</param>
        /// <param name="shippingInstructionNumber">The shipping instruction number.</param>
        /// <param name="placeOfDeliveryLocationId">The place of delivery location identifier.</param>
        /// <param name="placeOfFinalDestinationLocationId">The place of final destination location identifier.</param>
        /// <param name="scacCode">The scac code.</param>
        /// <param name="voyage">The voyage  value.</param>
        /// <param name="fromDate">From date value.</param>
        /// <param name="toDate">To date value.</param>
        /// <param name="transshipmentPort">The transshipment port.</param>
        /// <param name="receiptLocationId">The receipt location identifier.</param>
        /// <param name="returnLocation">The return location.</param>
        /// <param name="returnTerminalEquipment">The return terminal equipment.</param>
        /// <param name="returnDepotEquipment">The return depot equipment.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="sealNumber">The seal number.</param>
        /// <param name="bookingNumber">The booking number.</param>
        /// <param name="billOfLadingNumber">The bill of lading number.</param>
        /// <param name="leasingCompanyReference">The leasing company reference.</param>
        /// <param name="pickupReference">The pickup reference.</param>
        /// <param name="mscAuthorizationReference">The MSC authorization reference.</param>
        /// <param name="returnEquipmentAuthorizationNumber">The return equipment authorization number.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <param name="valid">The valid rule identifier.</param>
        /// <returns>Returns Validation rule.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentActivityList(string equipmentActivityId = null, int? equipmentSizeType = null, int? equipmentISOCode = null, bool? shipperOwnedContainer = null, int? activityCode = null, int? activityTerminalId = null, bool? dateType = null, int? activityLocationId = null, int? activityTerminalDepotId = null, string activityStatus = null, long? equipmentNumber = null, int? portOfLoad = null, int? portOfDischarge = null, string shippingInstructionNumber = null, int? placeOfDeliveryLocationId = null, int? placeOfFinalDestinationLocationId = null, int? scacCode = null, int? voyage = null, DateTime? fromDate = null, DateTime? toDate = null, int? transshipmentPort = null, int? receiptLocationId = null, int? returnLocation = null, int? returnTerminalEquipment = null, int? returnDepotEquipment = null, int? vesselId = null, string sealNumber = null, string bookingNumber = null, string billOfLadingNumber = null, string leasingCompanyReference = null, string pickupReference = null, string mscAuthorizationReference = null, string returnEquipmentAuthorizationNumber = null, bool? showCancel = null, string validationRule = null, string feederVoyage = null, int pageIndex = 0, int pageSize = 0, int validationRuleId = 0, bool? valid = null)
        {
            EquipmentActivityFilter activityFilter = EquipmentActivityExtension.GetEquipmentActivityFilter(equipmentActivityId, equipmentSizeType, equipmentISOCode, shipperOwnedContainer, activityCode, activityTerminalId, dateType, activityLocationId, activityTerminalDepotId, activityStatus, equipmentNumber, portOfLoad, portOfDischarge, shippingInstructionNumber, placeOfDeliveryLocationId, placeOfFinalDestinationLocationId, scacCode, voyage, fromDate, toDate, transshipmentPort, receiptLocationId, returnLocation, returnTerminalEquipment, returnDepotEquipment, vesselId, sealNumber, bookingNumber, billOfLadingNumber, leasingCompanyReference, pickupReference, mscAuthorizationReference, returnEquipmentAuthorizationNumber, showCancel, validationRule, feederVoyage, pageIndex, pageSize, validationRuleId, valid);
            if (activityFilter == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            PageResponse<EquipmentActivity> data = await this.equipmentActivityService.GetEquipmentActivityList(activityFilter);
            return Request.CreateResponse(HttpStatusCode.OK, new PageResponse<EquipmentActivityDto>() { Items = this.mapper.Map<List<EquipmentActivityDto>>(data?.Items), TotalCount = data?.TotalCount });
        }

        /// <summary>
        /// Gets the equipment fleet.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns Equipment Number.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("GetEquipmentFleet")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentFleet(string equipmentNumber)
        {
            if (string.IsNullOrEmpty(equipmentNumber))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var data = await this.equipmentActivityService.GetEquipmentByFleet(equipmentNumber);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<EquipmentFleetDto>(data));
        }

        /// <summary>
        /// Gets the equipment fleet list.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns the equipmentNumber.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("GetEquipmentFleetList")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetEquipmentFleetList(string equipmentNumber)
        {
            if (string.IsNullOrEmpty(equipmentNumber))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<FleetBase> data = await this.equipmentActivityService.SearchEquipmentActivity(equipmentNumber);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<FleetBaseDto>>(data));
        }

        /// <summary>
        /// Gets the relevant equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <returns>Returns the equipment activity list.</returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        [Route("GetRelevantEquipment")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetRelevantEquipment(int equipmentActivityId)
        {
            if (equipmentActivityId <= 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<EquipmentActivity> data = await this.equipmentActivityService.GetRelevantEquipment(equipmentActivityId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<EquipmentActivityDto>>(data));
        }

        /// <summary>
        /// Gets the valid equipment activity.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentSizeType">Type of the equipment size.</param>
        /// <param name="equipmentISOCode">The equipment iso code.</param>
        /// <param name="shipperOwnedContainer">The shipper owned container.</param>
        /// <param name="activityCode">The activity code.</param>
        /// <param name="activityTerminalId">The activity terminal identifier.</param>
        /// <param name="dateType">Type of the date.</param>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="activityTerminalDepotId">The activity terminal depot identifier.</param>
        /// <param name="activityStatus">The activity status.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="portOfLoad">The port of load.</param>
        /// <param name="portOfDischarge">The port of discharge.</param>
        /// <param name="shippingInstructionNumber">The shipping instruction number.</param>
        /// <param name="placeOfDeliveryLocationId">The place of delivery location identifier.</param>
        /// <param name="placeOfFinalDestinationLocationId">The place of final destination location identifier.</param>
        /// <param name="scacCode">The scac code.</param>
        /// <param name="voyage">The voyage.</param>
        /// <param name="fromDate">From date value.</param>
        /// <param name="toDate">To date value.</param>
        /// <param name="transshipmentPort">The transshipment port.</param>
        /// <param name="receiptLocationId">The receipt location identifier.</param>
        /// <param name="returnLocation">The return location.</param>
        /// <param name="returnTerminalEquipment">The return terminal equipment.</param>
        /// <param name="returnDepotEquipment">The return depot equipment.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="sealNumber">The seal number.</param>
        /// <param name="bookingNumber">The booking number.</param>
        /// <param name="billOfLadingNumber">The bill of lading number.</param>
        /// <param name="leasingCompanyReference">The leasing company reference.</param>
        /// <param name="pickupReference">The pickup reference.</param>
        /// <param name="mscAuthorizationReference">The MSC authorization reference.</param>
        /// <param name="returnEquipmentAuthorizationNumber">The return equipment authorization number.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <param name="valid">The valid.</param>
        /// <returns>Returns Valid Equipment Activity.</returns>
        [Route("GetValidEquipmentActivity")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetValidEquipmentActivity(string equipmentActivityId = null, int? equipmentSizeType = null, int? equipmentISOCode = null, bool? shipperOwnedContainer = null, int? activityCode = null, int? activityTerminalId = null, bool? dateType = null, int? activityLocationId = null, int? activityTerminalDepotId = null, string activityStatus = null, long? equipmentNumber = null, int? portOfLoad = null, int? portOfDischarge = null, string shippingInstructionNumber = null, int? placeOfDeliveryLocationId = null, int? placeOfFinalDestinationLocationId = null, int? scacCode = null, int? voyage = null, DateTime? fromDate = null, DateTime? toDate = null, int? transshipmentPort = null, int? receiptLocationId = null, int? returnLocation = null, int? returnTerminalEquipment = null, int? returnDepotEquipment = null, int? vesselId = null, string sealNumber = null, string bookingNumber = null, string billOfLadingNumber = null, string leasingCompanyReference = null, string pickupReference = null, string mscAuthorizationReference = null, string returnEquipmentAuthorizationNumber = null, bool? showCancel = null, string validationRule = null, string feederVoyage = null, int validationRuleId = 0, bool? valid = null)
        {
            EquipmentActivityFilter activityFilter = EquipmentActivityExtension.GetEquipmentActivityFilter(equipmentActivityId, equipmentSizeType, equipmentISOCode, shipperOwnedContainer, activityCode, activityTerminalId, dateType, activityLocationId, activityTerminalDepotId, activityStatus, equipmentNumber, portOfLoad, portOfDischarge, shippingInstructionNumber, placeOfDeliveryLocationId, placeOfFinalDestinationLocationId, scacCode, voyage, fromDate, toDate, transshipmentPort, receiptLocationId, returnLocation, returnTerminalEquipment, returnDepotEquipment, vesselId, sealNumber, bookingNumber, billOfLadingNumber, leasingCompanyReference, pickupReference, mscAuthorizationReference, returnEquipmentAuthorizationNumber, showCancel, validationRule, feederVoyage, 0, 0, validationRuleId, valid);
            if (activityFilter == null)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            IList<EquipmentActivityHeaderDetail> data = await this.equipmentActivityService.GetValidEquipmentActivity(activityFilter);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<List<EquipmentActivityHeaderDetailDto>>(data));
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The activity data.</param>
        /// <returns>Returns The Data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save([FromBody]IList<EquipmentActivityDto> data)
        {
            var result = this.mapper.Map<List<EquipmentActivity>>(data);
            BusinessOutcome output = await this.equipmentActivityService.Save(result);

            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Updates the specified data.
        /// </summary>
        /// <param name="data">The specified data.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns The Specified Data.</returns>
        [Route("{id}")]
        [HttpPut]
        public async Task<HttpResponseMessage> Update([FromBody] IList<EquipmentActivityDto> data, int id = 0)
        {
            if (id == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var result = this.mapper.Map<List<EquipmentActivity>>(data);
            BusinessOutcome output = await this.equipmentActivityService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Determines whether [has equipment activity duplicate] [the specified equipment activity identifier].
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <returns>Returns Equipment Duplicate.</returns>
        [Route("HasEquipmentActivityDuplicate")]
        [HttpGet]
        public async Task<HttpResponseMessage> HasEquipmentActivityDuplicate(long equipmentActivityId, long equipmentId, int activityReferentialId, string activityDate, int locationId, int vesselId, int voyageId, string feederVoyage)
        {
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<bool>(await this.equipmentActivityService.HasEquipmentActivityDuplicate(equipmentActivityId, equipmentId, activityReferentialId, activityDate, locationId, vesselId, voyageId, feederVoyage)));
        }

        /// <summary>
        /// Determines whether [has equipment activity valid] [the specified equipment identifier].
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <returns>Returns Equipment valid.</returns>
        [Route("HasEquipmentActivityValid")]
        [HttpGet]
        public async Task<HttpResponseMessage> HasEquipmentActivityValid(long equipmentId, string activityDate)
        {
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<bool>(await this.equipmentActivityService.HasEquipmentActivityValid(equipmentId, activityDate)));
        }

        #endregion Public Methods
    }
}