﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceController.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequenceController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare LogicalSequenceController.
    /// </summary>
    [RoutePrefix("v1/logicalSequences")]
    public class LogicalSequenceController : ApiController
    {
        #region Members

        /// <summary>
        /// The logical sequence service.
        /// </summary>
        private readonly ILogicalSequenceService logicalSequenceService;

        /// <summary>
        /// The sequence mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalSequenceController"/> class.
        /// </summary>
        /// <param name="logicalSequenceService">The logical sequence service.</param>
        /// <param name="mapper">The logical mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public LogicalSequenceController(ILogicalSequenceService logicalSequenceService, IMapper mapper)
        {
            if (logicalSequenceService == null)
            {
                throw new ArgumentNullException(nameof(logicalSequenceService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.logicalSequenceService = logicalSequenceService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Saves the specified logical sequence data.
        /// </summary>
        /// <param name="logicalSequenceData">The logical sequence data.</param>
        /// <returns>Returns logical sequence data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save([FromBody]IList<LogicalSequenceDto> logicalSequenceData)
        {
            if (logicalSequenceData == null)
            {
                return this.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new ArgumentNullException(nameof(logicalSequenceData)));
            }

            var result = this.mapper.Map<IList<LogicalSequence>>(logicalSequenceData);
            BusinessOutcome output = await this.logicalSequenceService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Updates the specified sequence.
        /// </summary>
        /// <param name="sequence">The sequence.</param>
        /// <returns>Returns the update data.</returns>
        [Route("")]
        [HttpPut]
        public async Task<HttpResponseMessage> Update(LogicalSequenceUpdateDto sequence)
        {
            if (sequence == null || sequence.LogicalActivityId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            var result = this.mapper.Map<LogicalSequenceUpdate>(sequence);
            BusinessOutcome output = await this.logicalSequenceService.Update(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Gets the logical sequence list.
        /// </summary>
        /// <param name="logicalActivityId">The logical activity identifier.</param>
        /// <returns>Returns GetLogicalSequenceList.</returns>
        [Route("{logicalActivityId}")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetLogicalSequenceId(int logicalActivityId)
        {
            var data = await this.logicalSequenceService.GetLogicalActivityId(logicalActivityId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<LogicalSequenceDto>(data));
        }

        /// <summary>
        /// Gets the logical sequence list.
        /// </summary>
        /// <param name="currentMoveId">The current move identifier.</param>
        /// <returns>Returns Logical Sequence List.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetLogicalSequenceList(int currentMoveId = 0)
        {
            IList<LogicalSequence> data = await this.logicalSequenceService.GetLogicalSequenceList(currentMoveId);
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<LogicalSequenceDto>>(data));
        }

        #endregion Public Methods
    }
}