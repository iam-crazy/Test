﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementBasicUsageController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementBasicUsageController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using AutoMapper;
    using Business.Contracts;
    using Business.Contracts.Objects;
    using Contracts;
    using Extension;
    using Framework.Common.Model;

    /// <summary>
    /// Declare  Requirement BasicUsage Controller.
    /// </summary>
    /// <seealso cref="ApiController" />
    [RoutePrefix("v1/requirementBasicUsage")]
    public class RequirementBasicUsageController : ApiController
    {
        #region Members

        /// <summary>
        /// The requirement basic usage service.
        /// </summary>
        private readonly IRequirementUsageService requirementBasicUsageService;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementBasicUsageController"/> class.
        /// </summary>
        /// <param name="requirementBasicUsageService">The requirement basic usage service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public RequirementBasicUsageController(IRequirementUsageService requirementBasicUsageService, IMapper mapper)
        {
            if (requirementBasicUsageService == null)
            {
                throw new ArgumentNullException(nameof(requirementBasicUsageService));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.requirementBasicUsageService = requirementBasicUsageService;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the requirement usages.
        /// </summary>
        /// <returns>The Requirement Usage List.</returns>
        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetRequirementUsages()
        {
            IList<RequirementUsage> data = await this.requirementBasicUsageService.GetRequirementUsages();
            return Request.CreateResponse(HttpStatusCode.OK, this.mapper.Map<IList<RequirementBasicUsageDto>>(data));
        }

        /// <summary>
        /// Saves the specified requirement basic usage DTO.
        /// </summary>
        /// <param name="requirementBasicUsageDto">The requirement basic usage DTO.</param>
        /// <returns>The saved data.</returns>
        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Save(RequirementBasicUsageDto requirementBasicUsageDto)
        {
            var result = this.mapper.Map<RequirementUsage>(requirementBasicUsageDto);
            BusinessOutcome output = await this.requirementBasicUsageService.Save(result);
            return Request.CreateResponse(HttpStatusCode.OK, output.ConvertToOperationOutcome());
        }

        /// <summary>
        /// Deletes the specified requirement basic usage identifier.
        /// </summary>
        /// <param name="requirementBasicUsageId">The requirement basic usage identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Delete the record.</returns>
        [Route("")]
        [HttpDelete]
        public async Task<HttpResponseMessage> Delete(int requirementBasicUsageId, int userId)
        {
            if (requirementBasicUsageId == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, Resource.ValidationMessage.LBL_InvalidId);
            }

            return Request.CreateResponse(HttpStatusCode.OK, await this.requirementBasicUsageService.Delete(requirementBasicUsageId, userId));
        }

        #endregion Public Methods
    }
}