﻿//-----------------------------------------------------------------------
// <copyright file = "HealthCheckController.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare HealthCheckController.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api.Controllers
{
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    /// <summary>
    /// Declare HealthCheckController. Allow integration services to be called.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    [RoutePrefix("v1/alives")]
    public class HealthCheckController : ApiController
    {
        /// <summary>
        /// Pings this instance.
        /// </summary>
        /// <returns>Returns the http status.</returns>
        [Route("")]
        [HttpGet]
        public HttpResponseMessage Ping()
        {
            return Request.CreateResponse(HttpStatusCode.OK, "v1");
        }
    }
}