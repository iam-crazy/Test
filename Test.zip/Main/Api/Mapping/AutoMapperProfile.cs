﻿//-----------------------------------------------------------------------
// <copyright file = "AutoMapperProfile.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare AutoMapperProfile.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Mapping
{
    using System.CodeDom.Compiler;
    using AutoMapper;
    using Api = Msc.Logistics.EME.Service.Api.Contracts;
    using Business = Business.Contracts.Objects;
    using DataAccess = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare AutoMapperProfile.
    /// </summary>
    [GeneratedCode("AutoMapperProfile", "1.0.0")]
    public class AutoMapperProfile : Profile
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
        /// </summary>
        public AutoMapperProfile()
        {
            this.CreateMissingTypeMaps = false;
            this.ForAllMaps((typeMap, mapConfig) => mapConfig.PreserveReferences());

            ////-------Business To API---------

            this.CreateMap<Business.Activity, Api.ActivityDto>()
                .ConstructUsing(dest => new Api.ActivityDto()).ReverseMap();

            this.CreateMap<Business.AvailableStatus, Api.AvailableStatusDto>()
               .ConstructUsing(dest => new Api.AvailableStatusDto()).ReverseMap();

            this.CreateMap<Business.ActivityAction, Api.ActivityActionDto>()
                .ConstructUsing(dest => new Api.ActivityActionDto()).ReverseMap();

            this.CreateMap<Business.ActivityCategory, Api.ActivityCategoryDto>()
                .ConstructUsing(dest => new Api.ActivityCategoryDto()).ReverseMap();

            this.CreateMap<Business.ActivityType, Api.ActivityTypeDto>()
                .ConstructUsing(dest => new Api.ActivityTypeDto()).ReverseMap();

            this.CreateMap<Business.BasicRequirement, Api.BasicRequirementDto>()
                .ConstructUsing(dest => new Api.BasicRequirementDto()).ReverseMap();

            this.CreateMap<Business.CancelEquipmentActivity, Api.CancelEquipmentActivityDto>()
                .ConstructUsing(dest => new Api.CancelEquipmentActivityDto()).ReverseMap();

            this.CreateMap<Business.EDIMapping, Api.EDIMappingDto>()
                .ConstructUsing(dest => new Api.EDIMappingDto()).ReverseMap();

            this.CreateMap<Business.EquipmentActivity, Api.EquipmentActivityDto>()
                .ConstructUsing(dest => new Api.EquipmentActivityDto()).ReverseMap();
            this.CreateMap<Business.EquipmentActivityHeaderDetail, Api.EquipmentActivityHeaderDetailDto>()
              .ConstructUsing(dest => new Api.EquipmentActivityHeaderDetailDto()).ReverseMap();

            this.CreateMap<Business.EquipmentActivity, Api.EquipmentFleetDto>()
                .ConstructUsing(dest => new Api.EquipmentFleetDto()).ReverseMap();

            this.CreateMap<Business.Equipment, Api.EquipmentDto>()
               .ConstructUsing(dest => new Api.EquipmentDto()).ReverseMap();

            this.CreateMap<Business.EquipmentActivityHeaderDetail, Api.EquipmentActivityHeaderDetailDto>()
               .ConstructUsing(dest => new Api.EquipmentActivityHeaderDetailDto()).ReverseMap();
            this.CreateMap<Business.EquipmentActivityError, Api.EquipmentActivityErrorDto>()
                .ConstructUsing(dest => new Api.EquipmentActivityErrorDto()).ReverseMap();

            this.CreateMap<Business.EquipmentActivityFilter, Api.EquipmentActivityDto>()
                .ConstructUsing(dest => new Api.EquipmentActivityDto()).ReverseMap();

            this.CreateMap<Business.EquipmentCategory, Api.EquipmentCategoryDto>()
                .ConstructUsing(dest => new Api.EquipmentCategoryDto()).ReverseMap();

            this.CreateMap<Business.EquipmentFleet, Api.EquipmentFleetDto>()
                .ConstructUsing(dest => new Api.EquipmentFleetDto()).ReverseMap();

            this.CreateMap<Business.EquipmentFleet, Api.EquipmentActivityDto>()
               .ConstructUsing(dest => new Api.EquipmentActivityDto()).ReverseMap();

            this.CreateMap<Business.EquipmentISOCode, Api.EquipmentISOCodeDto>()
                .ConstructUsing(dest => new Api.EquipmentISOCodeDto()).ReverseMap();

            this.CreateMap<Business.EquipmentSizeType, Api.EquipmentSizeTypeDto>()
                .ConstructUsing(dest => new Api.EquipmentSizeTypeDto()).ReverseMap();

            this.CreateMap<Business.EquipmentStatus, Api.EquipmentStatusDto>()
                .ConstructUsing(dest => new Api.EquipmentStatusDto()).ReverseMap();

            this.CreateMap<Business.EquipmentState, Api.EquipmentStateDto>()
             .ConstructUsing(dest => new Api.EquipmentStateDto()).ReverseMap();

            this.CreateMap<Business.FullEmpty, Api.FullEmptyDto>()
                .ConstructUsing(dest => new Api.FullEmptyDto()).ReverseMap();

            this.CreateMap<Business.GeneralCode, Api.GeneralCodeDto>()
                .ConstructUsing(dest => new Api.GeneralCodeDto()).ReverseMap();

            this.CreateMap<Business.Location, Api.LocationDto>()
                .ConstructUsing(dest => new Api.LocationDto()).ReverseMap();

            this.CreateMap<Business.LogicalCombination, Api.LogicalCombinationDto>()
                .ConstructUsing(dest => new Api.LogicalCombinationDto()).ReverseMap();

            this.CreateMap<Business.LogicalSequence, Api.LogicalSequenceDto>()
                .ConstructUsing(dest => new Api.LogicalSequenceDto()).ReverseMap();

            this.CreateMap<Business.LogicalSequenceUpdate, Api.LogicalSequenceUpdateDto>()
              .ConstructUsing(dest => new Api.LogicalSequenceUpdateDto()).ReverseMap();

            this.CreateMap<Business.OwnershipType, Api.OwnershipType>()
                .ConstructUsing(dest => new Api.OwnershipType()).ReverseMap();

            this.CreateMap<Business.Port, Api.PortDto>()
                .ConstructUsing(dest => new Api.PortDto()).ReverseMap();

            this.CreateMap<Business.PortVersion, Api.PortVersionDto>()
                .ConstructUsing(dest => new Api.PortVersionDto()).ReverseMap();

            this.CreateMap<Business.ReferentialData, Api.ReferentialDataDto>()
                .ConstructUsing(dest => new Api.ReferentialDataDto()).ReverseMap();

            this.CreateMap<Business.ReferentialDataFilter, Api.ReferentialDataFilterDto>()
                .ConstructUsing(dest => new Api.ReferentialDataFilterDto()).ReverseMap();

            this.CreateMap<Business.ReferentialValidationRule, Api.ReferentialValidationRuleDto>()
                .ConstructUsing(dest => new Api.ReferentialValidationRuleDto()).ReverseMap();

            this.CreateMap<Business.RequirementField, Api.RequirementFieldDto>()
                 .ConstructUsing(dest => new Api.RequirementFieldDto()).ReverseMap();

            this.CreateMap<Business.RequirementGroup, Api.RequirementGroupDto>()
               .ConstructUsing(dest => new Api.RequirementGroupDto()).ReverseMap();

            this.CreateMap<Business.RequirementUsage, Api.RequirementBasicUsageDto>()
                .ConstructUsing(dest => new Api.RequirementBasicUsageDto()).ReverseMap();

            this.CreateMap<Business.SearchEquipmentActivity, Api.SearchEquipmentActivityDto>()
                .ConstructUsing(dest => new Api.SearchEquipmentActivityDto()).ReverseMap();

            this.CreateMap<Business.SearchLogicalSequence, Api.SearchLogicalSequenceDto>()
                .ConstructUsing(dest => new Api.SearchLogicalSequenceDto()).ReverseMap();

            this.CreateMap<Business.SearchReferentialData, Api.SearchReferentialDataDto>()
                .ConstructUsing(dest => new Api.SearchReferentialDataDto()).ReverseMap();

            this.CreateMap<Business.SearchValidationRule, Api.SearchValidationRuleDto>()
                .ConstructUsing(dest => new Api.SearchValidationRuleDto()).ReverseMap();

            this.CreateMap<Business.ShipmentStatus, Api.ShipmentStatusDto>()
                .ConstructUsing(dest => new Api.ShipmentStatusDto()).ReverseMap();

            this.CreateMap<Business.TakePlaceAt, Api.TakePlaceAtDto>()
                .ConstructUsing(dest => new Api.TakePlaceAtDto()).ReverseMap();

            this.CreateMap<Business.TakePlaceAt, Api.ActivityTypeDto>()
               .ConstructUsing(dest => new Api.ActivityTypeDto()).ReverseMap();

            this.CreateMap<Business.TerminalDepot, Api.TerminalDepotDto>()
                .ConstructUsing(dest => new Api.TerminalDepotDto()).ReverseMap();

            this.CreateMap<Business.ValidateEquipment, Api.ValidateEquipmentDto>()
                .ConstructUsing(dest => new Api.ValidateEquipmentDto()).ReverseMap();

            this.CreateMap<Business.ValidationRule, Api.ValidationRuleDto>()
                .ConstructUsing(dest => new Api.ValidationRuleDto()).ReverseMap();

            this.CreateMap<Business.ValidationRuleBase, Api.ValidationRuleBaseDto>()
                .ConstructUsing(dest => new Api.ValidationRuleBaseDto()).ReverseMap();

            this.CreateMap<Business.ValidationRuleErrorResult, Api.ValidationRuleErrorResultDto>()
                .ConstructUsing(dest => new Api.ValidationRuleErrorResultDto()).ReverseMap();

            this.CreateMap<Business.ValidationRuleGroup, Api.ValidationRuleGroupDto>()
                .ConstructUsing(dest => new Api.ValidationRuleGroupDto()).ReverseMap();

            this.CreateMap<Business.ValidationRuleType, Api.ValidationRuleTypeDto>()
                .ConstructUsing(dest => new Api.ValidationRuleTypeDto()).ReverseMap();

            this.CreateMap<Business.Vessel, Api.VesselDto>()
                .ConstructUsing(dest => new Api.VesselDto()).ReverseMap();

            this.CreateMap<Business.VesselVersions, Api.VesselVersionsDto>()
                .ConstructUsing(dest => new Api.VesselVersionsDto()).ReverseMap();

            this.CreateMap<Business.VesselVoyage, Api.VesselVoyageDto>()
                .ConstructUsing(dest => new Api.VesselVoyageDto()).ReverseMap();

            this.CreateMap<Business.Voyage, Api.VoyageDto>()
                .ConstructUsing(dest => new Api.VoyageDto()).ReverseMap();

            this.CreateMap<Business.BusinessCycle, Api.BusinessCycleDto>()
                .ConstructUsing(dest => new Api.BusinessCycleDto()).ReverseMap();

            this.CreateMap<Business.EquipmentActivityNote, Api.EquipmentActivityNoteDto>()
              .ConstructUsing(dest => new Api.EquipmentActivityNoteDto()).ReverseMap();

            this.CreateMap<Business.EquipmentNote, Api.EquipmentNoteDto>()
              .ConstructUsing(dest => new Api.EquipmentNoteDto()).ReverseMap();

            this.CreateMap<Business.UserBase, Api.UserBaseDto>()
            .ConstructUsing(dest => new Api.UserBaseDto()).ReverseMap();

            this.CreateMap<Business.FleetBase, Api.FleetBaseDto>()
            .ConstructUsing(dest => new Api.FleetBaseDto()).ReverseMap();

            this.CreateMap<Business.ValidateEquipmentActivity, Api.ValidateEquipmentActivityDto>()
               .ConstructUsing(dest => new Api.ValidateEquipmentActivityDto()).ReverseMap();

            ////------- DataAccess To Business--------

            this.CreateMap<DataAccess.ActivityAction, Business.ActivityAction>()
                .ConstructUsing(dest => new Business.ActivityAction()).ReverseMap();

            this.CreateMap<DataAccess.AvailableStatus, Business.AvailableStatus>()
               .ConstructUsing(dest => new Business.AvailableStatus()).ReverseMap();

            this.CreateMap<DataAccess.ActivityCategory, Business.ActivityCategory>()
                .ConstructUsing(dest => new Business.ActivityCategory()).ReverseMap();

            this.CreateMap<DataAccess.ActivityReferential, Business.ReferentialData>()
                .ConstructUsing(dest => new Business.ReferentialData()).ReverseMap();

            this.CreateMap<DataAccess.ActivityReferential, Business.SearchReferentialData>()
              .ConstructUsing(dest => new Business.SearchReferentialData()).ReverseMap();

            this.CreateMap<DataAccess.ActivityType, Business.ActivityType>()
                .ConstructUsing(dest => new Business.ActivityType()).ReverseMap();

            this.CreateMap<DataAccess.ActivityType, Business.TakePlaceAt>()
                .ConstructUsing(dest => new Business.TakePlaceAt()).ReverseMap();

            this.CreateMap<DataAccess.Equipment, Business.EquipmentFleet>()
            .ConstructUsing(dest => new Business.EquipmentFleet()).ReverseMap();

            this.CreateMap<DataAccess.BasicRequirement, Business.BasicRequirement>()
                .ConstructUsing(dest => new Business.BasicRequirement()).ReverseMap();

            this.CreateMap<DataAccess.CancelEquipmentActivity, Business.CancelEquipmentActivity>()
                .ConstructUsing(dest => new Business.CancelEquipmentActivity()).ReverseMap();

            this.CreateMap<DataAccess.EDIMapping, Business.EDIMapping>()
                .ConstructUsing(dest => new Business.EDIMapping()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivity, Business.EquipmentActivity>()
                .ConstructUsing(dest => new Business.EquipmentActivity()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivity, Business.EquipmentFleet>()
                .ConstructUsing(dest => new Business.EquipmentFleet()).ReverseMap();

            this.CreateMap<DataAccess.Equipment, Business.Equipment>()
             .ConstructUsing(dest => new Business.Equipment()).ReverseMap();

            this.CreateMap<DataAccess.ActivityReferential, Business.Activity>()
               .ConstructUsing(dest => new Business.Activity()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivityError, Business.EquipmentActivityError>()
                .ConstructUsing(dest => new Business.EquipmentActivityError()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivityFilter, Business.EquipmentActivityFilter>()
                .ConstructUsing(dest => new Business.EquipmentActivityFilter()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentFleet, Business.EquipmentFleet>()
                .ConstructUsing(dest => new Business.EquipmentFleet()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentFleet, Business.EquipmentActivity>()
               .ConstructUsing(dest => new Business.EquipmentActivity()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentStatus, Business.EquipmentStatus>()
                .ConstructUsing(dest => new Business.EquipmentStatus()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentState, Business.EquipmentState>()
              .ConstructUsing(dest => new Business.EquipmentState()).ReverseMap();

            this.CreateMap<DataAccess.FullEmpty, Business.FullEmpty>()
                .ConstructUsing(dest => new Business.FullEmpty()).ReverseMap();

            this.CreateMap<DataAccess.FullEmpty, Business.GeneralCode>()
              .ConstructUsing(dest => new Business.GeneralCode()).ReverseMap();

            this.CreateMap<DataAccess.LogicalActivity, Business.LogicalSequence>()
                .ConstructUsing(dest => new Business.LogicalSequence()).ReverseMap();

            this.CreateMap<DataAccess.LogicalActivity, Business.LogicalCombination>()
                .ConstructUsing(dest => new Business.LogicalCombination()).ReverseMap();

            this.CreateMap<DataAccess.ReferentialValidationRule, Business.ReferentialValidationRule>()
                .ConstructUsing(dest => new Business.ReferentialValidationRule()).ReverseMap();

            this.CreateMap<DataAccess.RequirementField, Business.RequirementField>()
                .ConstructUsing(dest => new Business.RequirementField()).ReverseMap();

            this.CreateMap<DataAccess.RequirementGroup, Business.RequirementGroup>()
                .ConstructUsing(dest => new Business.RequirementGroup()).ReverseMap();

            this.CreateMap<DataAccess.RequirementUsage, Business.RequirementUsage>()
                .ConstructUsing(dest => new Business.RequirementUsage()).ReverseMap();

            this.CreateMap<DataAccess.ShipmentStatus, Business.ShipmentStatus>()
                .ConstructUsing(dest => new Business.ShipmentStatus()).ReverseMap();

            this.CreateMap<DataAccess.TakePlaceAt, Business.TakePlaceAt>()
                .ConstructUsing(dest => new Business.TakePlaceAt()).ReverseMap();

            this.CreateMap<DataAccess.ValidateEquipment, Business.ValidateEquipment>()
                .ConstructUsing(dest => new Business.ValidateEquipment()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRule, Business.ValidationRule>()
                .ConstructUsing(dest => new Business.ValidationRule()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRule, Business.ValidationRuleBase>()
                            .ConstructUsing(dest => new Business.ValidationRuleBase()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRuleErrorResult, Business.ValidationRuleErrorResult>()
                .ConstructUsing(dest => new Business.ValidationRuleErrorResult()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRuleGroup, Business.ValidationRuleGroup>()
                .ConstructUsing(dest => new Business.ValidationRuleGroup()).ReverseMap();

            this.CreateMap<DataAccess.ValidationRuleType, Business.ValidationRuleType>()
                .ConstructUsing(dest => new Business.ValidationRuleType()).ReverseMap();

            this.CreateMap<DataAccess.LogicalActivity, Business.LogicalSequenceUpdate>()
              .ConstructUsing(dest => new Business.LogicalSequenceUpdate()).ReverseMap();

            this.CreateMap<DataAccess.BusinessCycle, Business.BusinessCycle>()
             .ConstructUsing(dest => new Business.BusinessCycle()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentNote, Business.EquipmentNote>()
              .ConstructUsing(dest => new Business.EquipmentNote()).ReverseMap();

            this.CreateMap<DataAccess.EquipmentActivityNote, Business.EquipmentActivityNote>()
              .ConstructUsing(dest => new Business.EquipmentActivityNote()).ReverseMap();

            this.CreateMap<DataAccess.Equipment, Business.FleetBase>()
              .ConstructUsing(dest => new Business.FleetBase()).ReverseMap();

            this.CreateMap<DataAccess.ValidateEquipmentActivity, Business.ValidateEquipmentActivity>()
              .ConstructUsing(dest => new Business.ValidateEquipmentActivity()).ReverseMap();

            ////------- DataAccess To DataAccess--------

            this.CreateMap<DataAccess.EquipmentActivity, DataAccess.EquipmentFleet>()
               .ConstructUsing(dest => new DataAccess.EquipmentFleet()).ReverseMap();

            this.CreateMap<Api.GeneralCodeDto, Api.LogisticsStatusDto>()
                .ConstructUsing(dest => new Api.LogisticsStatusDto()).ReverseMap();

            this.CreateMap<Business.LogisticsStatus, Api.LogisticsStatusDto>()
              .ConstructUsing(dest => new Api.LogisticsStatusDto()).ReverseMap();
        }

        #endregion
    }
}
