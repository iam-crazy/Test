﻿//-----------------------------------------------------------------------
// <copyright file = "Constants.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare Constants.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Api.Constant
{
    /// <summary>
    /// Declare Constants.
    /// </summary>
    public static class Constants
    {
        #region Constants

        /// <summary>
        /// The ESR data API.
        /// </summary>
        public const string ESRDataApi = "esrDataApiAddress";

        /// <summary>
        /// The master data API.
        /// </summary>
        public const string MasterDataApi = "masterDataApiAddress";

        /// <summary>
        /// The ESR data API.
        /// </summary>
        public const string SecurityDataApi = "securityDataApiAddress";

        /// <summary>
        /// The number one.
        /// </summary>
        public const string UserId = "1";

        #endregion
    }
}
