//-----------------------------------------------------------------------
// <copyright file = "Global.asax.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare Global Configuration.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Api
{
    using System.Web.Http;

    /// <summary>
    /// Declare global application.
    /// </summary>
    public class WebApiApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// Start the api application.
        /// </summary>
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            ContainerConfig.SetChangeLogAttributes();
        }
    }
}
