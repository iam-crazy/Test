﻿//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatusRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ShipmentStatusRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Extension;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Declare ShipmentStatusRepository.
    /// </summary>
    public class ShipmentStatusRepository : RepositoryBase<EMEDataContext, ShipmentStatus>, IShipmentRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentStatusRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ShipmentStatusRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the shipment status.
        /// </summary>
        /// <param name="shipmentCodes">The shipment codes.</param>
        /// <returns>
        /// Returns The Shipment Status.
        /// </returns>
        public async Task<IList<ShipmentStatus>> GetShipmentStatus(string shipmentCodes)
        {
            var specfications = new List<ISpecification<ShipmentStatus>>();
            if (shipmentCodes?.Length > 0)
            {
                var shipmentStatusCodes = IdentifierExtension.GetStringSeparator(shipmentCodes).ToArray();
                specfications.Add(new Specification<ShipmentStatus>(m => shipmentStatusCodes.Contains(m.Code)));
            }

            var query = DbContext.BuildQuery(specfications);
            return await query.ToListAsync();
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="shipmentStatusData">The shipmentStatusData.</param>
        public void Save(ShipmentStatus shipmentStatusData)
        {
            if (shipmentStatusData?.Id > 0)
            {
                this.UpdateShipmentStatus(shipmentStatusData);
            }
            else
            {
                DbContext.Entry(shipmentStatusData).State = EntityState.Added;
            }
        }

        /// <summary>
        /// Deletes the specified shipment status identifier.
        /// </summary>
        /// <param name="shipmentStatusId">The shipment status identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int shipmentStatusId)
        {
            int responseValue = 0;
            if (shipmentStatusId > 0)
            {
                var duplicate = DbContext.EDIMappings.Where(a => a.ShipmentStatusId == shipmentStatusId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ShipmentStatus.FirstOrDefault(a => a.Id == shipmentStatusId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return shipmentStatusId;
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the shipment status.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateShipmentStatus(ShipmentStatus data)
        {
            ShipmentStatus existShipmentStatus = DbContext.ShipmentStatus.FirstOrDefault(x => x.Id == data.Id);
            if (existShipmentStatus == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existShipmentStatus.Code = data.Code;
            existShipmentStatus.Description = data.Description;
            existShipmentStatus.UpdatedBy = data.UpdatedBy;
            existShipmentStatus.UpdatedOn = data.UpdatedOn;
        }

        #endregion Private Methods
    }
}