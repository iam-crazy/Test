﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentNoteRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentNoteRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess
{
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare EquipmentNoteRepository.
    /// </summary>
    public class EquipmentNoteRepository : RepositoryBase<EMEDataContext, EquipmentNote>, IEquipmentNoteRepository
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentNoteRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The <see cref="IAmbientDbContextLocator"/></param>
        public EquipmentNoteRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the equipment note.
        /// </summary>
        /// <param name="equipmentNoteId">The equipment note identifier.</param>
        /// <returns>
        /// Returns The Equipment note Data.
        /// </returns>
        public async Task<IList<EquipmentNote>> GetEquipmentNote(int equipmentNoteId)
        {
            return await DbContext.EquipmentNotes.ToListAsync();
        }

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipmentNoteData.</param>
        /// <returns>Returns the equipment note.</returns>
        public async Task Save(EquipmentNote equipmentNoteData)
        {
            DbContext.EquipmentNotes.Add(equipmentNoteData);
            await DbContext.SaveChangesAsync();
        }

        #endregion
    }
}
