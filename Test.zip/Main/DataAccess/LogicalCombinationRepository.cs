﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombinationRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalCombinationRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Constant;
    using Contracts;
    using Contracts.Extension;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Declare EquipmentActivityRepository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.Logistics.EME.Service.DataAccess.Contracts.EMEDataContext, Msc.Logistics.EME.Service.DataAccess.Contracts.LogicalCombination}" />
    /// <seealso cref="Msc.Logistics.EME.Service.DataAccess.Contracts.ILogicalCombinationRepository" />
    public class LogicalCombinationRepository : RepositoryBase<EMEDataContext, LogicalActivity>, ILogicalCombinationRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalCombinationRepository" /> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public LogicalCombinationRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Saves the specified logical combinations.
        /// </summary>
        /// <param name="logicalCombinations">The logical combinations.</param>
        /// <exception cref="System.ArgumentException">Given Move and Event is Already Exists.</exception>
        public void Save(List<LogicalActivity> logicalCombinations)
        {
            if (logicalCombinations != null && logicalCombinations.Any())
            {
                foreach (LogicalActivity logicalCombination in logicalCombinations)
                {
                    if (logicalCombinations != null && logicalCombinations.Any())
                    {
                        if (logicalCombination.RowStatus == DataAccessConstant.Active)
                        {
                            var duplicate = DbContext.LogicalActivities.Where(a => a.FromActivityReferentialId == logicalCombination.FromActivityReferentialId && a.ToActivityReferentialId == logicalCombination.ToActivityReferentialId);
                            if (duplicate != null && duplicate.Any())
                            {
                                throw new ArgumentException("Given Move and Event is Already Exists");
                            }

                            DbContext.LogicalActivities.Add(logicalCombination);
                            DbContext.SaveChangesAsync();
                        }
                        else if (logicalCombination.RowStatus == DataAccessConstant.Update)
                        {
                            logicalCombination.Status = true;
                            DbContext.Entry(logicalCombination).State = EntityState.Modified;
                            ////DbContext.SaveChangesAsync();
                        }
                        else if (logicalCombination.RowStatus == DataAccessConstant.Delete)
                        {
                            logicalCombination.Status = false;
                            DbContext.Entry(logicalCombination).State = EntityState.Modified;
                            ////DbContext.SaveChangesAsync();
                        }
                        else
                        {
                            DbContext.Entry(logicalCombination).State = EntityState.Modified;
                            ////DbContext.SaveChangesAsync();
                        }
                    }

                    ////DbContext.SaveChangesAsync();
                }
            }
        }

        /// <summary>
        /// Gets the previous moves.
        /// </summary>
        /// <param name="nextMoveId">The next move identifier.</param>
        /// <returns>Returns the previous moves.</returns>
        public async Task<IList<LogicalActivity>> GetPreviousMoves(int nextMoveId)
        {
            var query = DbContext.BuildQuery(LogicalActivitySpecification.BySearchRequest(0, nextMoveId, false, true), LogicalActivitySpecification.WithDetail());
            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets the logical combination list.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>
        /// Returns The logical Combination List.
        /// </returns>
        public async Task<IList<LogicalActivity>> GetLogicalCombinationList(int moveCodeId)
        {
            var query = DbContext.BuildQuery(LogicalActivitySpecification.BySearchRequest(moveCodeId, 0, false, true), LogicalActivitySpecification.WithDetail());
            var data = await query.ToListAsync();
            var logicalCombinationList = data.OrderBy(m => m.FromActivityReferential.Code);
            return logicalCombinationList.Any() ? logicalCombinationList.ToList() : new List<LogicalActivity>();
        }      

        #endregion Public Methods
    }
}