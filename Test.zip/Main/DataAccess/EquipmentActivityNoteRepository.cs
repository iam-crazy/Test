﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityNoteRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityNoteRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Threading.Tasks;
    using AutoMapper;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare EquipmentActivityNoteRepository.
    /// </summary>
    public class EquipmentActivityNoteRepository : RepositoryBase<EMEDataContext, EquipmentActivityNote>, IEquipmentActivityNoteRepository
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivityNoteRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The <see cref="IAmbientDbContextLocator"/></param>
        /// <param name="mapper">The <see cref="IMapper"/></param>
        public EquipmentActivityNoteRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Gets the equipment activity note.
        /// </summary>
        /// <param name="equipmentActivityNoteId">The equipment activity note identifier.</param>
        /// <returns>
        /// Returns The EquipmentStatus Data.
        /// </returns>
        public async Task<IList<EquipmentActivityNote>> GetEquipmentActivityNote(int equipmentActivityNoteId)
        {
            return await DbContext.EquipmentActivityNotes.ToListAsync();
        }

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipmentNoteData.</param>
        /// <returns>Returns equipment Note Data.</returns>
        public async Task Save(EquipmentActivityNote equipmentNoteData)
        {
            DbContext.EquipmentActivityNotes.Add(equipmentNoteData);
            await DbContext.SaveChangesAsync();
        }

        #endregion Public Methods
    }
}