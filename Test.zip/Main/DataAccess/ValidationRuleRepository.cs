﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare Validation Rule Repository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Validation Rule Repository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.EquipmentMovesEvents.Service.DataAccess.Contracts.EquipmentMovesEventsContext, Msc.EquipmentMovesEvents.Service.DataAccess.Contracts.ReferentialData}" />
    /// <seealso cref="Msc.EquipmentMovesEvents.Service.DataAccess.Contracts.IValidationRuleRepository" />
    public class ValidationRuleRepository : RepositoryBase<EMEDataContext, ValidationRule>, IValidationRuleRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ValidationRuleRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rules.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <param name="group">The group.</param>
        /// <param name="description">The description.</param>
        /// <param name="validFrom">The valid from.</param>
        /// <param name="validTo">The valid to.</param>
        /// <param name="status">The status.</param>
        /// <param name="type">The rule type.</param>
        /// <param name="limit">The rule limit.</param>
        /// <param name="offset">The rule offset.</param>
        /// <param name="searchValue">The search Value.</param>
        /// <returns>Returns Validation rules.</returns>
        public async Task<IList<ValidationRule>> GetValidationRules(int? ruleNumber, string group, string description, DateTime? validFrom, DateTime? validTo, bool? status, string type, int limit, int offset, string searchValue)
        {
            IQueryable<ValidationRule> query = default(IQueryable<ValidationRule>);
            {
                query = DbContext.BuildQuery(ValidationRuleSpecification.BySearchRequest(ruleNumber, group, description, type, searchValue), ValidationRuleSpecification.WithDetail());
            }

            var rules = await query.ToListAsync();
            return rules.OrderBy(m => m.RuleNumber).ToList();
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        public void Save(ValidationRule data)
        {
            DbContext.ValidationRules.Add(data);
        }

        /// <summary>
        /// Updates the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        public void Update(ValidationRule data)
        {
            var validationRule = DbContext.ValidationRules.FirstOrDefault(x => x.ValidationRuleId == data.ValidationRuleId);
            validationRule.ValidationRuleId = data.ValidationRuleId;
            validationRule.RuleNumber = data.RuleNumber;
            validationRule.Description = data.Description;
            validationRule.ValidationRuleGroupId = data.ValidationRuleGroupId;
            validationRule.ValidFrom = data.ValidFrom;
            validationRule.ValidTo = data.ValidTo;
            validationRule.Status = data.Status;
            validationRule.ValidationRuleTypeId = data.ValidationRuleTypeId;
            validationRule.ValidationRuleErrorResultId = data.ValidationRuleErrorResultId;
            validationRule.ErrorDescription = data.ErrorDescription;
            validationRule.ReasonForInactive = data.ReasonForInactive;
            validationRule.Remarks = data.Remarks;            
            validationRule.UpdatedBy = data.UpdatedBy;
            validationRule.UpdatedOn = data.UpdatedOn;
        }

        /// <summary>
        /// Gets the validation rule by ID.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Returns The List Based On ID.
        /// </returns>
        public async Task<ValidationRule> GetValidationRule(int id)
        {
            IQueryable<ValidationRule> query = default(IQueryable<ValidationRule>);
            {
                query = DbContext.BuildQuery(ValidationRuleSpecification.BySearchRequest(id), ValidationRuleSpecification.WithDetail());
            }

            return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// Gets the rule number.
        /// </summary>
        /// <returns>
        /// Returns RuleNumber.
        /// </returns>
        public async Task<string> GenerateRuleNumber()
        {
            var autoId = 0;
            if (DbContext.ValidationRules.Any())
            {
                autoId = await DbContext.ValidationRules.MaxAsync(a => a.ValidationRuleId) + 1;
            }
            else
            {
                autoId = 1;
            }

            return Convert.ToString(autoId);
        }

        /// <summary>
        /// Gets the validation rule.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <returns>Returns the validation rule.</returns>
        public async Task<ValidationRule> GetValidationRule(string ruleNumber)
        {
            var query = DbContext.ValidationRules.Where(p => p.RuleNumber == ruleNumber);
            return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// Determines whether /[is rule number exist] [the specified rule number].
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <returns>Already Exist.</returns>
        public async Task<bool> IsRuleNumberExist(string ruleNumber)
        {
            return await DbContext.ValidationRules.AnyAsync(p => p.RuleNumber == ruleNumber);
        }

        /// <summary>
        /// Search the validation rules.
        /// </summary>
        /// <param name="group">The group parameter.</param>
        /// <param name="id">The id parameter.</param>
        /// <returns>
        /// Returns The Data.
        /// </returns>
        public async Task<List<ValidationRule>> SearchValidationRules(string group, int id)
        {
            IQueryable<ValidationRule> query;
            if (id > 0)
            {
                query = DbContext.ValidationRules.Where(p => p.ValidationRuleGroup.Code == group && p.ValidationRuleType.Code == Constant.DataAccessConstant.SpecificationCode);
            }
            else
            {
                query = DbContext.ValidationRules.Where(p => p.ValidationRuleGroup.Code == group && p.ValidationRuleType.Code == Constant.DataAccessConstant.SpecificationCode && p.Status);
            }

            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets the valid equipment activity.
        /// </summary>
        /// <returns>Returns Valid Equipment Activity.</returns>
        public async Task<IList<Tuple<int, string, string, int>>> SearchInvalidEquipmentActivity()
        {
            var query = await DbContext.ValidationRules.Include(s => s.EquipmentActivityErrors).Where(s => s.EquipmentActivityErrors.Any()).Select(s => new { s.ValidationRuleId, s.RuleNumber, s.ErrorDescription, Count = s.EquipmentActivityErrors.Count }).ToListAsync();
            return query.Select(s => new Tuple<int, string, string, int>(s.ValidationRuleId, s.RuleNumber, s.ErrorDescription, s.Count)).ToList();
        }

        #endregion Public Methods
    }
}