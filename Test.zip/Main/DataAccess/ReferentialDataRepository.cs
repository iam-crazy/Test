﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Constant;
    using Contracts;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Referential Data Repository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.EquipmentMovesEvents.Service.DataAccess.Contracts.EquipmentMovesEventsContext, Msc.EquipmentMovesEvents.Service.DataAccess.Contracts.ReferentialData}" />
    /// <seealso cref="Msc.EquipmentMovesEvents.Service.DataAccess.Contracts.IReferentialDataRepository" />
    public class ReferentialDataRepository : RepositoryBase<EMEDataContext, ActivityReferential>, IReferentialDataRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferentialDataRepository" /> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Referential Data Repository.</exception>
        public ReferentialDataRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Saves the specified Referential data.
        /// </summary>
        /// <param name="data">The save data.</param>
        public void Save(ActivityReferential data)
        {
            if (data != null && data.ActivityReferentialId == 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.Code == data.Code);
                if (duplicate != null && !duplicate.Any())
                {
                    DbContext.ActivityReferentials.Add(data);
                }
            }
            else
            {
                this.UpdateActivityReferential(data);
                if (data.ReferentialValidationRules != null && data.ReferentialValidationRules.Any())
                {
                    foreach (ReferentialValidationRule item in data.ReferentialValidationRules)
                    {
                        if (item.ReferentialValidationRuleId > 0)
                        {
                            this.UpdateReferentialValidationRule(item);
                        }
                        else
                        {
                            DbContext.Entry(item).State = EntityState.Added;
                        }
                    }
                }

                if (data.BasicRequirements != null && data.BasicRequirements.Any())
                {
                    foreach (BasicRequirement item in data.BasicRequirements.ToList())
                    {
                        if (item.RowStatus == DataAccessConstant.Active)
                        {
                            DbContext.Entry(item).State = EntityState.Added;
                        }
                        else if (item.BasicRequirementId > 0 && item.RowStatus != DataAccessConstant.Delete)
                        {
                            this.UpdateBasicRequirement(item);
                        }
                        else if (item.BasicRequirementId > 0 && item.RowStatus == DataAccessConstant.Delete)
                        {
                            DbContext.Entry(item).State = EntityState.Deleted;
                        }
                    }
                }

                if (data.EDIMappings != null && data.EDIMappings.Any())
                {
                    foreach (EDIMapping item in data.EDIMappings)
                    {
                        if (item.EDIMappingId > 0)
                        {
                            this.UpdateEdiMapping(item);
                        }
                        else
                        {
                            DbContext.Entry(item).State = EntityState.Added;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets the referential data By ID.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Returns The List Based On ID.
        /// </returns>
        public async Task<ActivityReferential> GetReferentialData(int id)
        {
            var query = DbContext.BuildQuery(ReferentialDataSpecification.BySearchRequest(id), ReferentialDataSpecification.WithDetail());
            return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="activities">The activities.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="fullEmpty">The full empty.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="location">The location.</param>
        /// <param name="requirementFields">The requirement Fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The is status.</param>
        /// <param name="isMapped">The is mapped.</param>
        /// <param name="businessCycle">The businessCycle.</param>
        /// <returns>
        /// Returns the referential list.
        /// </returns>
        public async Task<IList<ActivityReferential>> GetReferentialList(int? action, IEnumerable<int> activities, int? activityType, IEnumerable<int> category, int? equipmentStatus, int? fullEmpty, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, int? location, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, bool? isMapped, int? businessCycle)
        {
            var data = await DbContext.BuildQuery(ReferentialDataSpecification.BySearchRequest(action, activities, activityType, category, equipmentStatus, fullEmpty, groupCode, isDisplayToCustomer, isValidationRuleActive, location, requirementFields, requirementUsage, shipmentStatus, validationRule, status, isMapped, businessCycle).ToList(), ReferentialDataSpecification.WithHeaderDetailOnly()).OrderBy(m => m.Code).ToListAsync();
            if (isMapped.HasValue)
            {
                if (isMapped.Value)
                {
                    data = data.Where(s => s.EDIMappings.Any() && s.EDIMappings.Any(a => a.EquipmentStatusId.HasValue)).ToList();
                }
                else
                {
                    data = data.Where(s => !s.EDIMappings.Any() || s.EDIMappings.Any(a => !a.EquipmentStatusId.HasValue)).ToList();
                }
            }

            return data;
        }

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <param name="action">The action parameter.</param>
        /// <param name="activities">The activities.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <param name="category">The category parameter.</param>
        /// <param name="equipmentStatus">The equipment status.</param>
        /// <param name="fullEmpty">The full empty.</param>
        /// <param name="groupCode">The group code.</param>
        /// <param name="isDisplayToCustomer">The is display to customer.</param>
        /// <param name="isValidationRuleActive">The is validation rule active.</param>
        /// <param name="location">The location.</param>
        /// <param name="requirementFields">The requirement fields.</param>
        /// <param name="requirementUsage">The requirement usage.</param>
        /// <param name="shipmentStatus">The shipment status.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="status">The status parameter.</param>
        /// <param name="businessCycle">The businessCycle.</param>
        /// <returns>
        /// Get QuickAccess Count.
        /// </returns>
        public async Task<Tuple<int, int, int>> GetQuickAccessCount(int? action, IEnumerable<int> activities, int? activityType, IEnumerable<int> category, int? equipmentStatus, int? fullEmpty, int? groupCode, bool? isDisplayToCustomer, bool? isValidationRuleActive, int? location, IEnumerable<int> requirementFields, int? requirementUsage, IEnumerable<int> shipmentStatus, int? validationRule, bool? status, int? businessCycle)
        {
            var query = await DbContext.BuildQuery(ReferentialDataSpecification.ByGetRequest(action, activities, activityType, category, equipmentStatus, fullEmpty, groupCode, isDisplayToCustomer, isValidationRuleActive, location, requirementFields, requirementUsage, shipmentStatus, validationRule, status, businessCycle).ToList(), ReferentialDataSpecification.WithHeaderDetailOnly()).ToListAsync();
            IList<bool> mappingDetail = query.Select(s => s.EDIMappings.Any(a => a.EquipmentStatusId.HasValue && a.ShipmentStatusId.HasValue)).ToList();
            return new Tuple<int, int, int>(mappingDetail.Count(), mappingDetail.Count(s => s), mappingDetail.Count(s => !s));
        }

        /// <summary>
        /// Gets the referential data list.
        /// </summary>
        /// <param name="isMapped">Is Mapped with EDI.</param>
        /// <returns>Returns Referential List.</returns>
        public async Task<IList<ActivityReferential>> GetReferentialDataList(bool? isMapped)
        {
            var data = await DbContext.BuildQuery(ReferentialDataSpecification.BySearchRequest().ToList(), ReferentialDataSpecification.WithHeaderDetailOnly()).ToListAsync();
            if (isMapped.HasValue)
            {
                if (isMapped.Value)
                {
                    data = data.Where(s => s.EDIMappings.Any() && s.EDIMappings.Any(a => a.EquipmentStatusId.HasValue)).ToList();
                }
                else
                {
                    data = data.Where(s => !s.EDIMappings.Any() || s.EDIMappings.Any(a => !a.EquipmentStatusId.HasValue && !a.ShipmentStatusId.HasValue)).ToList();
                }
            }

            return data;
        }

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <returns>Get Mapped Count.</returns>
        public async Task<Tuple<int, int, int>> SearchQuickAccessCount()
        {
            var mappingDetails = await DbContext.ActivityReferentials.Include(s => s.EDIMappings).Select(s => s.EDIMappings).ToListAsync();
            IList<bool> mappingDetail = mappingDetails.Select(s => s.Any() && s.Any(a => a.EquipmentStatusId.HasValue && a.ShipmentStatusId.HasValue)).ToList();
            return new Tuple<int, int, int>(mappingDetail.Count(), mappingDetail.Count(s => s), mappingDetail.Count(s => !s));
        }

        /// <summary>
        /// Searches the referential data.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>Returns The Search Data.</returns>
        public async Task<IList<ActivityReferential>> SearchReferentialData(string criteria)
        {
            var query = DbContext.BuildQuery(ReferentialDataSpecification.BySearchRequest(criteria, DataAccessConstant.Active).ToList(), ReferentialDataSpecification.WithHeaderDetailOnly());
            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <returns>
        /// Return ReferentialData.
        /// </returns>
        public async Task<IList<RequirementField>> GetRequirementFields()
        {
            var data = await DbContext.RequirementFields.ToListAsync();
            return data;
        }

        /// <summary>
        /// Gets the Full Empty data.
        /// </summary>
        /// <returns>
        /// Return Full Empty Data.
        /// </returns>
        public async Task<IList<FullEmpty>> GetFullEmptyDetails()
        {
            var data = await DbContext.FullEmpties.ToListAsync();
            return data;
        }

        /// <summary>
        /// Gets the requirement usage.
        /// </summary>
        /// <returns>
        /// Returns Requirement Usage.
        /// </returns>
        public async Task<IList<RequirementUsage>> GetRequirementUsage()
        {
            var data = await DbContext.RequirementUsages.ToListAsync();
            return data;
        }

        /// <summary>
        /// Gets the Referential Validation rules associated with the given validation rule id.
        /// </summary>
        /// <param name="validationRuleId">The validation Rule Id.</param>
        /// <returns>
        /// Referential Validation rules.
        /// </returns>
        public async Task<IList<ReferentialValidationRule>> GetReferentialValidationRules(int validationRuleId)
        {
            var query = DbContext.BuildQuery(ReferentialDataSpecification.BySearchValidationId(validationRuleId), ReferentialDataSpecification.WithOnlyReferentialValidationRuleDetail());
            return await query.ToListAsync();
        }

        /// <summary>
        /// Saves the referential validation rules.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        public void SaveReferentialValidationRules(IList<ReferentialValidationRule> data)
        {
            if (data != null && data.Any())
            {
                foreach (var item in data)
                {
                    this.UpdateEffectiveTo(item);
                }
            }
        }

        /// <summary>
        /// Updates the business cycle.
        /// </summary>
        /// <param name="referentialStatus">The referential status.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public void UpdateBusinessCycle(ActivityReferential referentialStatus)
        {
            var referential = DbContext.ActivityReferentials.FirstOrDefault(x => x.ActivityReferentialId == referentialStatus.ActivityReferentialId);
            if (referential == null)
            {
                throw new ArgumentNullException("referentialStatus");
            }

            referential.ActivityReferentialId = referentialStatus.ActivityReferentialId;
            referential.BusinessCycleId = referentialStatus.BusinessCycleId;
            referential.UpdatedBy = referentialStatus.UpdatedBy;
            referential.UpdatedOn = referentialStatus.UpdatedOn;
        }

        /// <summary>
        /// Updates the effective to.
        /// </summary>
        /// <param name="data">The ReferentialValidationRule data.</param>
        /// <exception cref="System.ArgumentNullException">The ArgumentNullException data.</exception>
        public void UpdateEffectiveTo(ReferentialValidationRule data)
        {
            var referential = DbContext.ReferentialValidationRules.FirstOrDefault(x => x.ActivityReferentialId == data.ActivityReferentialId);
            if (referential == null)
            {
                throw new ArgumentNullException("data");
            }

            referential.EffectiveTo = data.EffectiveTo;
            referential.EffectiveDate = data.EffectiveDate;
            referential.UpdatedBy = data.UpdatedBy;
            referential.UpdatedOn = data.UpdatedOn;
        }

        /// <summary>
        /// Updates the activity referential.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateActivityReferential(ActivityReferential data)
        {
            ActivityReferential existActivityReferential = DbContext.ActivityReferentials.FirstOrDefault(x => x.ActivityReferentialId == data.ActivityReferentialId);
            if (existActivityReferential == null)
            {
                throw new ArgumentNullException("data");
            }

            DbContext.Entry<ActivityReferential>(existActivityReferential).CurrentValues.SetValues(data);
            ////DbContext.SaveChanges();
        }

        /// <summary>
        /// Updates the referential validation rule.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        private void UpdateReferentialValidationRule(ReferentialValidationRule data)
        {
            ReferentialValidationRule existReferentialValidationRule = DbContext.ReferentialValidationRules.FirstOrDefault(x => x.ReferentialValidationRuleId == data.ReferentialValidationRuleId);
            if (existReferentialValidationRule == null)
            {
                throw new ArgumentNullException("data");
            }

            DbContext.Entry<ReferentialValidationRule>(existReferentialValidationRule).CurrentValues.SetValues(data);
        }

        /// <summary>
        /// Updates the basic requirement.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateBasicRequirement(BasicRequirement data)
        {
            BasicRequirement existBasicRequirement = DbContext.BasicRequirements.FirstOrDefault(x => x.BasicRequirementId == data.BasicRequirementId);
            if (existBasicRequirement == null)
            {
                throw new ArgumentNullException("data");
            }

            DbContext.Entry<BasicRequirement>(existBasicRequirement).CurrentValues.SetValues(data);
        }

        /// <summary>
        /// Updates the edi mapping.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateEdiMapping(EDIMapping data)
        {
            EDIMapping existEDIMapping = DbContext.EDIMappings.FirstOrDefault(x => x.EDIMappingId == data.EDIMappingId);
            if (existEDIMapping == null)
            {
                throw new ArgumentNullException("data");
            }

            DbContext.Entry<EDIMapping>(existEDIMapping).CurrentValues.SetValues(data);
        }

        #endregion Public Methods
    }
}