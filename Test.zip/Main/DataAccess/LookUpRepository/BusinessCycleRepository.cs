﻿//-----------------------------------------------------------------------
// <copyright file = "BusinessCycleRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare BusinessCycleRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare BusinessCycleRepository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.Logistics.EME.Service.DataAccess.Contracts.EMEDataContext, Msc.Logistics.EME.Service.DataAccess.Contracts.Objects.BusinessCycle}" />
    /// <seealso cref="Msc.Logistics.EME.Service.DataAccess.Contracts.IBusinessCycleRepository" />
    public class BusinessCycleRepository : RepositoryBase<EMEDataContext, BusinessCycle>, IBusinessCycleRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessCycleRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public BusinessCycleRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified business cyle identifier.
        /// </summary>
        /// <param name="businessCycleId">The business cycle identifier.</param>
        /// <param name="userId">The UserId.</param>
        /// <returns>
        /// Retruns delete data.
        /// </returns>
        public async Task<int> Delete(int businessCycleId, int userId)
        {
            int responseValue = 0;
            if (businessCycleId > 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.BusinessCycleId == businessCycleId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.BusinessCycles.SingleOrDefault(a => a.Id == businessCycleId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return businessCycleId;
        }

        /// <summary>
        /// Gets the business cycles.
        /// </summary>
        /// <returns>
        /// Returns BusinessCycle Lists.
        /// </returns>
        public async Task<IList<BusinessCycle>> GetBusinessCycles()
        {
            var data = await DbContext.BusinessCycles.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        public void Save(BusinessCycle data)
        {
            if (data != null && data.Id > 0)
            {
                this.UpdateBusinessCycle(data);
            }
            else
            {
                DbContext.BusinessCycles.Add(data);
            }

            ////await DbContext.SaveChangesAsync();
            ////return data.Id;
        }

        /// <summary>
        /// Updates the business cycle.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateBusinessCycle(BusinessCycle data)
        {
            BusinessCycle existBusinessCycle = DbContext.BusinessCycles.FirstOrDefault(x => x.Id == data.Id);
            if (existBusinessCycle == null)
            {
                throw new ArgumentNullException("data");
            }

            existBusinessCycle.Code = data.Code;
            existBusinessCycle.Description = data.Description;
            existBusinessCycle.UpdatedBy = data.UpdatedBy;
            existBusinessCycle.UpdatedOn = data.UpdatedOn;
        }

        #endregion Public Methods
    }
}