﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityActionRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityActionRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare ActivityActionRepository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, ActivityAction}" />
    /// <seealso cref="IActivityActionRepository" />
    public class ActivityActionRepository : RepositoryBase<EMEDataContext, ActivityAction>, IActivityActionRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ActivityActionRepository class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ActivityActionRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified activity action identifier.
        /// </summary>
        /// <param name="activityActionId">The activity action identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int activityActionId)
        {
            int responseValue = 0;
            if (activityActionId > 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.ActivityActionId == activityActionId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ActivityActions.SingleOrDefault(a => a.Id == activityActionId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return activityActionId;
        }

        /// <summary>
        /// Gets the ActivityAction.
        /// </summary>
        /// <returns>
        /// Returns ActivityAction Lists.
        /// </returns>
        public async Task<IList<ActivityAction>> GetActivityActions()
        {
            var data = await DbContext.ActivityActions.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        public void Save(ActivityAction data)
        {
            if (data != null)
            {
                if (data.Id > 0)
                {
                    this.UpdateActivityAction(data);
                }
                else
                {
                    DbContext.Entry(data).State = EntityState.Added;
                }
            }

            ////await DbContext.SaveChangesAsync();
            ////return data.Id;
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the activity action.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateActivityAction(ActivityAction data)
        {
            ActivityAction existActivityAction = DbContext.ActivityActions.FirstOrDefault(x => x.Id == data.Id);
            if (existActivityAction == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existActivityAction.Code = data.Code;
            existActivityAction.Description = data.Description;
            existActivityAction.UpdatedBy = data.UpdatedBy;
            existActivityAction.UpdatedOn = data.UpdatedOn;
            ////DbContext.Entry(existActivityAction).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}