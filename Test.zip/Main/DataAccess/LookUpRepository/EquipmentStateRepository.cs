﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStateRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStateRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare EquipmentStateRepository.
    /// </summary>
    public class EquipmentStateRepository : RepositoryBase<EMEDataContext, EquipmentState>, IEquipmentStateRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStateRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public EquipmentStateRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the equipment state.
        /// </summary>
        /// <returns>
        /// Returns The EquipmentState Data.
        /// </returns>
        public async Task<IList<EquipmentState>> SearchEquipmentStates()
        {
            return await DbContext.EquipmentStates.ToListAsync();
        }

        /// <summary>
        /// Saves the specified equipment state data.
        /// </summary>
        /// <param name="equipmentStateData">The equipment state data.</param>
        public void Save(EquipmentState equipmentStateData)
        {
            if (equipmentStateData?.EquipmentStateId > 0)
            {
                this.UpdateEquipmentState(equipmentStateData);
            }
            else
            {
                DbContext.Entry(equipmentStateData).State = EntityState.Added;
            }
        }

        /// <summary>
        /// Deletes the specified equipment state identifier.
        /// </summary>
        /// <param name="equipmentStateId">The equipment state identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int equipmentStateId)
        {
            int responseValue = 0;
            if (equipmentStateId > 0)
            {
                var duplicate = DbContext.EquipmentActivities.Where(a => a.EquipmentStateId == equipmentStateId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.EquipmentStates.FirstOrDefault(a => a.EquipmentStateId == equipmentStateId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return equipmentStateId;
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the state of the equipment.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateEquipmentState(EquipmentState data)
        {
            EquipmentState existEquipmentState = DbContext.EquipmentStates.FirstOrDefault(x => x.EquipmentStateId == data.EquipmentStateId);
            if (existEquipmentState == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existEquipmentState.Code = data.Code;
            existEquipmentState.Description = data.Description;
            existEquipmentState.UpdatedBy = data.UpdatedBy;
            existEquipmentState.UpdatedOn = data.UpdatedOn;
            ////DbContext.Entry(existEquipmentState).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}