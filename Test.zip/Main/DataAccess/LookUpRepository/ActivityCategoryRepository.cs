﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityCategoryRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityCategoryRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare ActivityCategoryRepository.
    /// </summary>
    public class ActivityCategoryRepository : RepositoryBase<EMEDataContext, ActivityCategory>, IActivityCategoryRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ActivityCategoryRepository class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ActivityCategoryRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified activity category identifier.
        /// </summary>
        /// <param name="activityCategoryId">The activity category identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int activityCategoryId)
        {
            int responseValue = 0;
            if (activityCategoryId > 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.ActivityCategoryId == activityCategoryId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ActivityCategories.SingleOrDefault(a => a.Id == activityCategoryId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return activityCategoryId;
        }

        /// <summary>
        /// Gets the ActivityCategory.
        /// </summary>
        /// <returns>
        /// Returns ActivityCategory Lists.
        /// </returns>
        public async Task<IList<ActivityCategory>> GetActivityCategories()
        {
            var data = await DbContext.ActivityCategories.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The Activity Category data.</param>
        public void Save(ActivityCategory data)
        {
            if (data != null && data.Id > 0)
            {
                this.UpdateActionCategory(data);
            }
            else
            {
                DbContext.Entry(data).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the action category.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateActionCategory(ActivityCategory data)
        {
            ActivityCategory existActivityCategory = DbContext.ActivityCategories.FirstOrDefault(x => x.Id == data.Id);
            if (existActivityCategory == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existActivityCategory.Code = data.Code;
            existActivityCategory.Description = data.Description;
            existActivityCategory.UpdatedBy = data.UpdatedBy;
            existActivityCategory.UpdatedOn = data.UpdatedOn;
            ////  DbContext.Entry(existActivityCategory).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}