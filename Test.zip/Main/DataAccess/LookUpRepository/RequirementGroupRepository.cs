﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementGroupRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementGroupRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using EntityFramework.DbContextScope.Interfaces;
    using Msc.Framework.Common.Model;
    using Msc.Framework.Service.DataAccess.SQLServer;
    using Msc.Logistics.EME.Service.DataAccess.Contracts;
    using Msc.Logistics.EME.Service.DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare RequirementGroupRepository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.Logistics.EME.Service.DataAccess.Contracts.EMEDataContext, Msc.Logistics.EME.Service.DataAccess.Contracts.Objects.RequirementField}" />
    /// <seealso cref="Msc.Logistics.EME.Service.DataAccess.Contracts.IRequirementGroupRepository" />
    public class RequirementGroupRepository : RepositoryBase<EMEDataContext, RequirementField>, IRequirementGroupRepository
    {
        #region constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementGroupRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">The ArgumentNullException.</exception>
        public RequirementGroupRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion constructor

        /// <summary>
        /// Deletes the specified requirement group identifier.
        /// </summary>
        /// <param name="requirementGroupId">The requirement group identifier.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<OperationOutcome> Delete(int requirementGroupId)
        {
            OperationOutcome output = new OperationOutcome();
            long result;
            if (DbContext.RequirementFields.Any(a => a.RequirementGroupId == requirementGroupId))
            {
                output.Status = OperationOutcomeStatus.Failure;
                output.Messages.Add(new OperationOutcomeMessage { Message = "The Selected records already exist in table" });
                return output;
            }

            var deleteRecord = DbContext.RequirementGroups.Where(a => a.Id == requirementGroupId).FirstOrDefault<RequirementGroup>();
            DbContext.Entry(deleteRecord).State = EntityState.Deleted;
            result = await DbContext.SaveChangesAsync();
            output.IdentityValue = Convert.ToString(result);
            output.Status = OperationOutcomeStatus.Success;
            return output;
        }

        /// <summary>
        /// Gets the requirement fields.
        /// </summary>
        /// <returns>
        /// Return RequirementField.
        /// </returns>
        public async Task<IList<RequirementGroup>> GetRequirementGroups()
        {
            var data = await DbContext.RequirementGroups.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified requirement group data.
        /// </summary>
        /// <param name="requirementGroupData">The requirement group data.</param>
        public void Save(RequirementGroup requirementGroupData)
        {
            if (requirementGroupData?.Id > 0)
            {
                this.UpdateRequirementGroup(requirementGroupData);
            }
            else
            {
                DbContext.Entry(requirementGroupData).State = EntityState.Added;
            }
        }

        #region Private Methods

        /// <summary>
        /// Updates the requirement group.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateRequirementGroup(RequirementGroup data)
        {
            RequirementGroup existRequirementGroup = DbContext.RequirementGroups.FirstOrDefault(x => x.Id == data.Id);
            if (existRequirementGroup == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existRequirementGroup.Code = data.Code;
            existRequirementGroup.Description = data.Description;
            existRequirementGroup.UpdatedBy = data.UpdatedBy;
            existRequirementGroup.UpdatedOn = data.UpdatedOn;
            ////DbContext.Entry(existRequirementGroup).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}