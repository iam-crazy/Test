﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityTypeRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityTypeRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare ActivityTypeRepository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, ActivityType}" />
    /// <seealso cref="IActivityTypeRepository" />
    public class ActivityTypeRepository : RepositoryBase<EMEDataContext, ActivityType>, IActivityTypeRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ActivityTypeRepository class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ActivityTypeRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified activity type identifier.
        /// </summary>
        /// <param name="activityTypeId">The activity type identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int activityTypeId)
        {
            int responseValue = 0;
            if (activityTypeId > 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.ActivityTypeId == activityTypeId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ActivityTypes.SingleOrDefault(a => a.Id == activityTypeId);
                DbContext.Entry(deleteRecord).State = System.Data.Entity.EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return activityTypeId;
        }

        /// <summary>
        /// Gets the ActivityType.
        /// </summary>
        /// <returns>
        /// Returns ActivityType Lists.
        /// </returns>
        public async Task<IList<ActivityType>> GetActivityTypes()
        {
            var data = await DbContext.ActivityTypes.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        public void Save(ActivityType data)
        {
            if (data?.Id > 0)
            {
                this.UpdateTakePlaceAt(data);
            }
            else
            {
                DbContext.Entry(data).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the take place at.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateTakePlaceAt(ActivityType data)
        {
            ActivityType existActivityType = DbContext.ActivityTypes.FirstOrDefault(x => x.Id == data.Id);
            if (existActivityType == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existActivityType.Code = data.Code;
            existActivityType.Description = data.Description;
            existActivityType.UpdatedBy = data.UpdatedBy;
            existActivityType.UpdatedOn = data.UpdatedOn;
           //// DbContext.Entry(existActivityType).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}