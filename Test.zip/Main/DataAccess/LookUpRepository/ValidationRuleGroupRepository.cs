﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleGroupRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleGroupRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare ValidationRuleGroupRepository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, ValidationRuleGroup}" />
    /// <seealso cref="IValidationRuleGroupRepository" />
    public class ValidationRuleGroupRepository : RepositoryBase<EMEDataContext, ValidationRuleGroup>, IValidationRuleGroupRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ValidationRuleGroupRepository class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Return Argument Null exception.</exception>
        public ValidationRuleGroupRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified validation rule group identifier.
        /// </summary>
        /// <param name="validationRuleGroupId">The validation rule group identifier.</param>
        /// <returns>Return Delete Record.</returns>
        public async Task<int> Delete(int validationRuleGroupId)
        {
            int responseValue = 0;
            if (validationRuleGroupId > 0)
            {
                var duplicate = DbContext.ValidationRules.Where(a => a.ValidationRuleGroupId == validationRuleGroupId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ValidationRuleGroups.SingleOrDefault(a => a.Id == validationRuleGroupId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return validationRuleGroupId;
        }

        /// <summary>
        /// Gets the validation rule groups.
        /// </summary>
        /// <returns>
        /// Return ValidationRuleGroup.
        /// </returns>
        public async Task<IList<ValidationRuleGroup>> GetValidationRuleGroups()
        {
            var data = await DbContext.ValidationRuleGroups.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleGroupData">The validationRuleGroupData.</param>
        public void Save(ValidationRuleGroup validationRuleGroupData)
        {
            if (validationRuleGroupData?.Id > 0)
            {
                this.UpdateValidationRuleType(validationRuleGroupData);
            }
            else
            {
                DbContext.Entry(validationRuleGroupData).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the type of the validation rule.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateValidationRuleType(ValidationRuleGroup data)
        {
            ValidationRuleGroup existValidationRuleGroup = DbContext.ValidationRuleGroups.FirstOrDefault(x => x.Id == data.Id);
            if (existValidationRuleGroup == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existValidationRuleGroup.Code = data.Code;
            existValidationRuleGroup.Description = data.Description;
            existValidationRuleGroup.UpdatedBy = data.UpdatedBy;
            existValidationRuleGroup.UpdatedOn = data.UpdatedOn;
          ////  DbContext.Entry(existValidationRuleGroup).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}