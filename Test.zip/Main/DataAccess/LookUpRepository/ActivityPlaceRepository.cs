﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityPlaceRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityPlaceRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare ActivityPlaceRepository.
    /// </summary>
    public class ActivityPlaceRepository : RepositoryBase<EMEDataContext, TakePlaceAt>, IActivityPlaceRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ActivityPlaceRepository class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public ActivityPlaceRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified activity location identifier.
        /// </summary>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int activityLocationId)
        {
            int responseValue = 0;
            if (activityLocationId > 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.ActivityLocationId == activityLocationId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ActivityLocations.SingleOrDefault(a => a.Id == activityLocationId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return activityLocationId;
        }

        /// <summary>
        /// Gets the activity places.
        /// </summary>
        /// <returns>
        /// Return ActivityLocation.
        /// </returns>
        public async Task<IList<TakePlaceAt>> GetActivityPlaces()
        {
            var data = await DbContext.ActivityLocations.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified activity location data.
        /// </summary>
        /// <param name="activityLocationData">The activity location data.</param>
        public void Save(TakePlaceAt activityLocationData)
        {
            if (activityLocationData?.Id > 0)
            {
                this.UpdateTakePlaceAt(activityLocationData);
            }
            else
            {
                DbContext.Entry(activityLocationData).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the take place at.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateTakePlaceAt(TakePlaceAt data)
        {
            TakePlaceAt existTakePlaceAt = DbContext.ActivityLocations.FirstOrDefault(x => x.Id == data.Id);
            if (existTakePlaceAt == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existTakePlaceAt.Code = data.Code;
            existTakePlaceAt.Description = data.Description;
            existTakePlaceAt.UpdatedBy = data.UpdatedBy;
            existTakePlaceAt.UpdatedOn = data.UpdatedOn;
         ////   DbContext.Entry(existTakePlaceAt).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}