﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementFieldRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementFieldRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare RequirementFieldRepository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, RequirementField}" />
    /// <seealso cref="IRequirementFieldRepository" />
    public class RequirementFieldRepository : RepositoryBase<EMEDataContext, RequirementField>, IRequirementFieldRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementFieldRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public RequirementFieldRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified requirement field identifier.
        /// </summary>
        /// <param name="requirementFieldId">The requirement field identifier.</param>
        /// <returns>Return Delete Record.</returns>
        public async Task<int> Delete(int requirementFieldId)
        {
            int responseValue = 0;
            if (requirementFieldId > 0)
            {
                var duplicate = DbContext.BasicRequirements.Where(a => a.RequirementFieldId == requirementFieldId || a.RequirementFieldIdTwo == requirementFieldId || a.RequirementFieldIdThree == requirementFieldId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.RequirementFields.SingleOrDefault(a => a.Id == requirementFieldId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return requirementFieldId;
        }

        /// <summary>
        /// Gets the requirement fields.
        /// </summary>
        /// <returns>
        /// Return RequirementField.
        /// </returns>
        public async Task<IList<RequirementField>> GetRequirementFields()
        {
            var data = await DbContext.RequirementFields.Include(rg => rg.RequirementGroup).ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified requirement field data.
        /// </summary>
        /// <param name="requirementFieldData">The requirement field data.</param>
        public void Save(RequirementField requirementFieldData)
        {
            if (requirementFieldData?.Id > 0)
            {
                this.UpdateRequirementField(requirementFieldData);
            }
            else
            {
                DbContext.Entry(requirementFieldData).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the requirement field.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateRequirementField(RequirementField data)
        {
            RequirementField existRequirementField = DbContext.RequirementFields.FirstOrDefault(x => x.Id == data.Id);
            if (existRequirementField == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existRequirementField.Code = data.Code;
            existRequirementField.Description = data.Description;
            existRequirementField.UpdatedBy = data.UpdatedBy;
            existRequirementField.UpdatedOn = data.UpdatedOn;
            existRequirementField.RequirementGroupId = data.RequirementGroupId;
            ////DbContext.Entry(existRequirementField).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}