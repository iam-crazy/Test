﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementUsageRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementUsageRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare RequirementUsage Repository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, RequirementField}" />
    /// <seealso cref="IRequirementUsageRepository" />
    public class RequirementUsageRepository : RepositoryBase<EMEDataContext, RequirementField>, IRequirementUsageRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementUsageRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Return Argument Null exception.</exception>
        public RequirementUsageRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified requirement usage identifier.
        /// </summary>
        /// <param name="requirementUsageId">The requirement usage identifier.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<int> Delete(int requirementUsageId)
        {
            int responseValue = 0;
            if (requirementUsageId > 0)
            {
                var duplicate = DbContext.BasicRequirements.Where(a => a.RequirementUsageId == requirementUsageId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.RequirementUsages.SingleOrDefault(a => a.Id == requirementUsageId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return requirementUsageId;
        }

        /// <summary>
        /// Gets the requirement usages.
        /// </summary>
        /// <returns>
        /// Return RequirementUsage.
        /// </returns>
        public async Task<IList<RequirementUsage>> GetRequirementUsages()
        {
            var data = await DbContext.RequirementUsages.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified requirement usage data.
        /// </summary>
        /// <param name="requirementUsageData">The requirement usage data.</param>
        public void Save(RequirementUsage requirementUsageData)
        {
            if (requirementUsageData?.Id > 0)
            {
                this.UpdateValidationRuleType(requirementUsageData);
            }
            else
            {
                DbContext.Entry(requirementUsageData).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the type of the validation rule.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateValidationRuleType(RequirementUsage data)
        {
            RequirementUsage existRequirementUsage = DbContext.RequirementUsages.FirstOrDefault(x => x.Id == data.Id);
            if (existRequirementUsage == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existRequirementUsage.Code = data.Code;
            existRequirementUsage.Description = data.Description;
            existRequirementUsage.UpdatedBy = data.UpdatedBy;
            existRequirementUsage.UpdatedOn = data.UpdatedOn;
            ////DbContext.Entry(existRequirementUsage).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}