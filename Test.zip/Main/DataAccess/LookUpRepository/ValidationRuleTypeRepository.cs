﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleTypeRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleTypeRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare ValidationRuleTypeRepository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, ValidationRuleType}" />
    /// <seealso cref="IValidationRuleTypeRepository" />
    public class ValidationRuleTypeRepository : RepositoryBase<EMEDataContext, ValidationRuleType>, IValidationRuleTypeRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleTypeRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Return Argument Null exception.</exception>
        public ValidationRuleTypeRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified validation rule type identifier.
        /// </summary>
        /// <param name="validationRuleTypeId">The validation rule type identifier.</param>
        /// <returns>Return Delete Record.</returns>
        public async Task<int> Delete(int validationRuleTypeId)
        {
            int responseValue = 0;
            if (validationRuleTypeId > 0)
            {
                var duplicate = DbContext.ValidationRules.Where(a => a.ValidationRuleTypeId == validationRuleTypeId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ValidationRuleTypes.SingleOrDefault(a => a.Id == validationRuleTypeId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return validationRuleTypeId;
        }

        /// <summary>
        /// Gets the validation rule types.
        /// </summary>
        /// <returns>
        /// Return ValidationRuleType.
        /// </returns>
        public async Task<IList<ValidationRuleType>> GetValidationRuleTypes()
        {
            var data = await DbContext.ValidationRuleTypes.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified validation rule type data.
        /// </summary>
        /// <param name="validationRuleTypeData">The validation rule type data.</param>
        public void Save(ValidationRuleType validationRuleTypeData)
        {
            if (validationRuleTypeData?.Id > 0)
            {
                this.UpdateValidationRuleType(validationRuleTypeData);               
            }
            else
            {
                DbContext.Entry(validationRuleTypeData).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the type of the validation rule.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateValidationRuleType(ValidationRuleType data)
        {
            ValidationRuleType existValidationRuleType = DbContext.ValidationRuleTypes.FirstOrDefault(x => x.Id == data.Id);
            if (existValidationRuleType == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existValidationRuleType.Code = data.Code;
            existValidationRuleType.Description = data.Description;
            existValidationRuleType.UpdatedBy = data.UpdatedBy;
            existValidationRuleType.UpdatedOn = data.UpdatedOn;
           //// DbContext.Entry(existValidationRuleType).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}