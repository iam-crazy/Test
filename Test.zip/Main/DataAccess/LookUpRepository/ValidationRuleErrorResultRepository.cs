﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleErrorResultRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleErrorResultRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare Validation Rule Error Result Repository.
    /// </summary>
    /// <seealso cref="Framework.Service.DataAccess.SQLServer.RepositoryBase{EMEDataContext, RequirementField}" />
    /// <seealso cref="IValidationRuleErrorResultRepository" />
    public class ValidationRuleErrorResultRepository : RepositoryBase<EMEDataContext, RequirementField>, IValidationRuleErrorResultRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleErrorResultRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Return Argument Null exception.</exception>
        public ValidationRuleErrorResultRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified validation rule error result identifier.
        /// </summary>
        /// <param name="validationRuleErrorResultId">The validation rule error result identifier.</param>
        /// <returns>Return Delete Record.</returns>
        public async Task<int> Delete(int validationRuleErrorResultId)
        {
            int responseValue = 0;
            if (validationRuleErrorResultId > 0)
            {
                var duplicate = DbContext.ValidationRules.Where(a => a.ValidationRuleErrorResultId == validationRuleErrorResultId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.ValidationRuleErrorResults.SingleOrDefault(a => a.Id == validationRuleErrorResultId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return validationRuleErrorResultId;
        }

        /// <summary>
        /// Gets the validation rule error results.
        /// </summary>
        /// <returns>
        /// Return ValidationRuleErrorResult.
        /// </returns>
        public async Task<IList<ValidationRuleErrorResult>> GetValidationRuleErrorResults()
        {
            var data = await DbContext.ValidationRuleErrorResults.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleErrorResultData">The validationRuleErrorResultData.</param>
        public void Save(ValidationRuleErrorResult validationRuleErrorResultData)
        {
            if (validationRuleErrorResultData?.Id > 0)
            {
                this.UpdateValidationRuleErrorResult(validationRuleErrorResultData);
            }
            else
            {
                DbContext.Entry(validationRuleErrorResultData).State = EntityState.Added;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Updates the validation rule error result.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        private void UpdateValidationRuleErrorResult(ValidationRuleErrorResult data)
        {
            ValidationRuleErrorResult existValidationRuleErrorResult = DbContext.ValidationRuleErrorResults.FirstOrDefault(x => x.Id == data.Id);
            if (existValidationRuleErrorResult == null)
            {
                throw new ArgumentNullException("data");
            }

            ////existActivityAction.Id = data.Id;
            existValidationRuleErrorResult.Code = data.Code;
            existValidationRuleErrorResult.Description = data.Description;
            existValidationRuleErrorResult.UpdatedBy = data.UpdatedBy;
            existValidationRuleErrorResult.UpdatedOn = data.UpdatedOn;
           //// DbContext.Entry(existValidationRuleErrorResult).State = EntityState.Modified;
        }

        #endregion Private Methods
    }
}