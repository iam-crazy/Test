﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStatusRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStatusRepository. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare EquipmentStatusRepository.
    /// </summary>
    public class EquipmentStatusRepository : RepositoryBase<EMEDataContext, EquipmentStatus>, IEquipmentStatusRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStatusRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public EquipmentStatusRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <returns>
        /// Returns The EquipmentStatus Data.
        /// </returns>
        public async Task<IList<EquipmentStatus>> GetEquipmentStatus()
        {
            var data = await DbContext.EquipmentStatus.ToListAsync();
            return data;
        }

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentStatusData">The equipment status data.</param>
        public void Save(EquipmentStatus equipmentStatusData)
        {
            if (equipmentStatusData?.Id > 0)
            {
                DbContext.Entry(equipmentStatusData).State = EntityState.Modified;
            }
            else
            {
                DbContext.EquipmentStatus.Add(equipmentStatusData);
            }
        }

        /// <summary>
        /// Deletes the specified equipment status identifier.
        /// </summary>
        /// <param name="equipmentStatusId">The equipment status identifier.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<int> Delete(int equipmentStatusId)
        {
            int responseValue = 0;
            if (equipmentStatusId > 0)
            {
                var duplicate = DbContext.ActivityReferentials.Where(a => a.FullEmptyId == equipmentStatusId);
                if (duplicate != null && duplicate.Any())
                {
                    return responseValue;
                }

                var deleteRecord = DbContext.EquipmentStatus.FirstOrDefault(a => a.Id == equipmentStatusId);
                DbContext.Entry(deleteRecord).State = EntityState.Deleted;
                await DbContext.SaveChangesAsync();
            }

            return equipmentStatusId;
        }

        #endregion Public Methods
    }
}