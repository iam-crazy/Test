﻿//-----------------------------------------------------------------------
// <copyright file = "TimelineRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare TimelineRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Constant;
    using Contracts;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Declare TimelineRepository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.Logistics.EME.Service.DataAccess.Contracts.EMEDataContext, Msc.Logistics.EME.Service.DataAccess.Contracts.LogicalSequence}" />
    /// <seealso cref="Msc.Logistics.EME.Service.DataAccess.Contracts.ILogicalSequenceRepository" />
    public class TimelineRepository : RepositoryBase<EMEDataContext, EquipmentActivity>, ITimelineRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="TimelineRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public TimelineRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods 

        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="equipmentId">The equipment activity identifier.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <returns>
        /// Returns the equipment activity.
        /// </returns>
        public async Task<IList<EquipmentActivity>> GetEquipmentActivityList(long equipmentId, bool showCancel)
        {
            Equipment data = await DbContext.Equipments.Include(s => s.Equipment2).FirstOrDefaultAsync(s => s.EquipmentId == equipmentId);
            var equipmentids = new List<long>();
            while (data != null)
            {
                equipmentids.Add(data.EquipmentId);
                data = data.Equipment2;
            }

            return await DbContext.BuildQuery(TimelineSpecification.BySearchRequest(equipmentids, showCancel), EquipmentActivitySpecification.WithDetail()).ToListAsync();
        }

        #endregion Public Methods
    }
}