﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using Constant;
    using Contracts;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model.Pagination;
    using Framework.Service.DataAccess;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Declare EquipmentActivityRepository.
    /// </summary>
    public class EquipmentActivityRepository : RepositoryBase<EMEDataContext, EquipmentActivity>, IEquipmentActivityRepository
    {
        #region Fields

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivityRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public EquipmentActivityRepository(IAmbientDbContextLocator ambientDbContextLocator, IMapper mapper) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.mapper = mapper;
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Cancels the specified data.
        /// </summary>
        /// <param name="data">The cancel data.</param>
        /// <param name="equipmentStateId">The equipmentStateId.</param>
        /// <returns>
        /// Returns The Cancel Data.
        /// </returns>
        public async Task<int> Cancel(IList<CancelEquipmentActivity> data, byte? equipmentStateId)
        {
            foreach (var item in data)
            {
                var equipment = DbContext.EquipmentActivities.FirstOrDefault(r => r.EquipmentActivityId == item.EquipmentActivityId);
                equipment.EquipmentStateId = equipmentStateId;
                equipment.EquipmentActivityState = DataAccessConstant.Cancel;
                DbContext.Entry(equipment).State = EntityState.Modified;
                DbContext.CancelEquipmentActivities.Add(item);
                await DbContext.SaveChangesAsync();
            }

            return data.FirstOrDefault().CancelEquipmentActivityId;
        }

        /// <summary>
        /// Checks the equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipmentActivity identifier.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="voyage">The voyage parameter.</param>
        /// <returns>Returns Validate Equipment.</returns>
        public async Task<ValidateEquipment> CheckEquipment(string equipmentActivityId, string equipmentNumber, int activityReferentialId, DateTime activityDateTime, int locationId, int vesselId, int voyageId, string voyage)
        {
            try
            {
                IList<string> duplicateEquipments = new List<string>();
                List<string> equipmentNumbers = equipmentNumber.Split(',').ToList();
                IList<int> equipmentActivityIds = equipmentActivityId != null ? equipmentActivityId.Split(',').Select(int.Parse).ToList() : new List<int>();
                var availableEquipments = await DbContext.EquipmentActivities.Where(x => equipmentNumbers.Any(y => y == x.Equipment.EquipmentNumber && x.EquipmentActivityState != DataAccessConstant.Cancel)).ToListAsync();
                if (activityReferentialId > 0 && locationId > 0 && vesselId > 0 && (!string.IsNullOrEmpty(voyage) || voyageId > 0) && equipmentActivityIds.Any())
                {
                    foreach (var id in equipmentActivityIds)
                    {
                        string containerNumber = availableEquipments.FirstOrDefault(x => x.EquipmentActivityId == id).Equipment.EquipmentNumber;
                        DateTime dateTime = new DateTime();
                        if (default(DateTime) == activityDateTime)
                        {
                            dateTime = availableEquipments.FirstOrDefault(x => x.EquipmentActivityId == id).ActivityDateTime;
                        }
                        else
                        {
                            dateTime = activityDateTime;
                        }

                        var duplicateContainer = availableEquipments.FirstOrDefault(x => x.ActivityReferentialId == activityReferentialId
                                                                         && x.ActivityDateTime.Date == dateTime.Date
                                                                         && x.LocationId == locationId
                                                                         && x.VesselId == vesselId
                                                                         && ((voyageId > 0) ? x.VoyageId == voyageId : x.Voyage == voyage)
                                                                         && x.Equipment.EquipmentNumber == containerNumber
                                                                         && x.EquipmentActivityId != id);
                        if (duplicateContainer != null)
                        {
                            duplicateEquipments.Add(duplicateContainer.Equipment.EquipmentNumber);
                        }
                    }
                }

                if (activityReferentialId > 0 && default(DateTime) != activityDateTime && locationId > 0 && vesselId > 0 && (!string.IsNullOrEmpty(voyage) || voyageId > 0) && !equipmentActivityIds.Any())
                {
                    duplicateEquipments = availableEquipments.Where(x => x.ActivityReferentialId == activityReferentialId
                                                                         && x.ActivityDateTime.Date == activityDateTime.Date
                                                                         && x.LocationId == locationId
                                                                         && x.VesselId == vesselId
                                                                         && ((voyageId > 0) ? x.VoyageId == voyageId : x.Voyage == voyage)).Select(x => x.Equipment.EquipmentNumber).ToList();
                }

                var missingEquipments = equipmentNumbers.Where(x => !availableEquipments.Any(y => y.Equipment.EquipmentNumber == x)).ToList();
                availableEquipments = availableEquipments.GroupBy(x => x.Equipment.EquipmentNumber).Select(x => x.FirstOrDefault()).ToList();
                return new ValidateEquipment()
                {
                    AvailableEquipment = duplicateEquipments != null ? this.mapper.Map<IList<EquipmentFleet>>(availableEquipments.Where(x => !duplicateEquipments.Any(y => y == x.Equipment.EquipmentNumber)).ToList()) : this.mapper.Map<IList<EquipmentFleet>>(availableEquipments),
                    DuplicateEquipment = duplicateEquipments,
                    MissingEquipment = missingEquipments
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Checks the equipment activity.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns validation rule identifier.</returns>
        public async Task<bool> CheckEquipmentActivity(int? validationRuleId)
        {
            bool isunique;

            if (validationRuleId.HasValue && validationRuleId > 0)
            {
                var query = await DbContext.EquipmentActivities.FirstOrDefaultAsync(x => x.EquipmentActivityErrors.Any(s => s.ValidationRuleId == validationRuleId));

                isunique = await DbContext.EquipmentActivities.AllAsync(x => x.EquipmentActivityErrors.Any(s => s.ValidationRuleId == validationRuleId) && x.Equipment.EquipmentNumber != query.Equipment.EquipmentNumber && x.LocationId != query.LocationId && x.VesselId != query.VesselId && x.TerminalEquipmentHandlingFacilityId != query.TerminalEquipmentHandlingFacilityId && x.ActivityDateTime != query.ActivityDateTime);
                ////var query = DbContext.EquipmentActivities.FirstOrDefault(x => x.EquipmentActivityErrors.Any(x => x.EquipmentActivity.EquipmentNumber.FirstOrDefault() == validationRuleId.Value && x.EquipmentActivity.VesselId.Value == validationRuleId.Value && x.EquipmentActivity.TerminalEquipmentHandlingFacilityId == validationRuleId.Value && x.EquipmentActivity.LocationId == validationRuleId.Value && x.EquipmentActivity.Activity.ActivityActionId == validationRuleId.Value));
            }
            else
            {
                var query = await DbContext.EquipmentActivities.FirstOrDefaultAsync(x => !x.EquipmentActivityErrors.Any());
                isunique = await DbContext.EquipmentActivities.AllAsync(x => !x.EquipmentActivityErrors.Any() && x.Equipment.EquipmentNumber == query.Equipment.EquipmentNumber && x.LocationId == query.LocationId && x.VesselId == query.VesselId && x.TerminalEquipmentHandlingFacilityId == query.TerminalEquipmentHandlingFacilityId && x.ActivityDateTime == query.ActivityDateTime);
            }

            return isunique;
        }

        /// <summary>
        /// Gets the equipment activity.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="equipmentNumber">The equipment Number.</param>
        /// <returns>
        /// Returns The Equipment Activity Id.
        /// </returns>
        public async Task<EquipmentActivity> GetEquipmentActivity(int id, string equipmentNumber)
        {
            var query = DbContext.BuildQuery(EquipmentActivitySpecification.BySearchRequest(id, equipmentNumber), EquipmentActivitySpecification.WithDetail());
            return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// Gets the equipment activity ids.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns validation rule identifier.</returns>
        public async Task<IList<long>> GetEquipmentActivityIds(int? validationRuleId)
        {
            if (validationRuleId.HasValue)
            {
                return await DbContext.EquipmentActivityErrors.Where(x => x.ValidationRuleId == validationRuleId.Value).Select(s => s.EquipmentActivity.EquipmentActivityId).ToListAsync();
            }
            else
            {
                return await DbContext.EquipmentActivities.Where(x => !x.EquipmentActivityErrors.Any()).Select(s => s.EquipmentActivityId).ToListAsync();
            }
        }

        /// <summary>
        /// Gets the equipment activities.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <returns>
        /// Returns Equipment Activity Lists.
        /// </returns>
        public async Task<PageResponse<EquipmentActivity>> GetEquipmentActivityList(EquipmentActivityFilter activityFilter)
        {
            IEnumerable<long> ids = activityFilter.EquipmentActivityId?.Split(',').Select(long.Parse);
            IQueryable<EquipmentActivity> query = DbContext.BuildQuery(EquipmentActivitySpecification.BySearchRequest(activityFilter, ids).ToList(), EquipmentActivitySpecification.WithDetail());
            IList<EquipmentActivity> equipmentactivity;
            int totalCount;
            if (activityFilter.PageIndex == 0 && activityFilter.PageSize == 0)
            {
                equipmentactivity = await query.OrderByDescending(m => m.ActivityDateTime).ToListAsync();
                totalCount = equipmentactivity.Count;
            }
            else
            {
                equipmentactivity = await query.OrderByDescending(m => m.ActivityDateTime).Skip(activityFilter.PageIndex * activityFilter.PageSize).Take(activityFilter.PageSize).ToListAsync();
                totalCount = await query.CountAsync();
            }

            return new PageResponse<EquipmentActivity>() { TotalCount = totalCount, Items = equipmentactivity.ToList() };
        }

        /// <summary>
        /// Gets the next activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <returns>Returns the next activity.</returns>
        public async Task<EquipmentActivity> GetNextActivity(string equipmentNumber, DateTime activityDateTime)
        {
            IList<ISpecification<EquipmentActivity>> specifications = new List<ISpecification<EquipmentActivity>>();
            specifications.Add(new Specification<EquipmentActivity>(m => m.Equipment.EquipmentNumber == equipmentNumber));
            specifications.Add(new Specification<EquipmentActivity>(m => m.ActivityDateTime > activityDateTime));
            specifications.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityState != DataAccessConstant.Cancel));
            var query = DbContext.BuildQuery(specifications.ToList(), EquipmentActivitySpecification.WithDetail());
            return await query.OrderByDescending(d => d.ActivityDateTime).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Gets the previous activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <returns>Returns the previous activity.</returns>
        public async Task<EquipmentActivity> GetPreviousActivity(string equipmentNumber, DateTime activityDateTime)
        {
            IList<ISpecification<EquipmentActivity>> specifications = new List<ISpecification<EquipmentActivity>>();
            specifications.Add(new Specification<EquipmentActivity>(m => m.Equipment.EquipmentNumber == equipmentNumber));
            specifications.Add(new Specification<EquipmentActivity>(m => m.ActivityDateTime < activityDateTime));
            specifications.Add(new Specification<EquipmentActivity>(m => m.EquipmentActivityState != DataAccessConstant.Cancel));
            var query = DbContext.BuildQuery(specifications.ToList(), EquipmentActivitySpecification.WithDetail());
            return await query.Where(x => x.Activity.ActivityType.Code == DataAccessConstant.Move).OrderByDescending(d => d.ActivityDateTime).FirstOrDefaultAsync();
        }

        /// <summary>
        /// Gets the relevant equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <returns>Returns List Of Equipment Activity.</returns>
        public async Task<IList<EquipmentActivity>> GetRelevantEquipment(int equipmentActivityId)
        {
            EquipmentActivity equipmentActivity = await DbContext.BuildQuery(EquipmentActivitySpecification.BySearchRequest(equipmentActivityId, null), EquipmentActivitySpecification.WithDetail()).FirstOrDefaultAsync();
            if (equipmentActivity != null && equipmentActivity.ActivityReferentialId > 0 && equipmentActivity.LocationId > 0 && equipmentActivity.TerminalEquipmentHandlingFacilityId > 0 && equipmentActivity.VesselId > 0 && ((equipmentActivity.VoyageId != null && equipmentActivity.VoyageId > 0) || equipmentActivity.Voyage != null))
            {
                return DbContext.BuildQuery(EquipmentActivitySpecification.RelevantBySearchRequest(equipmentActivity.ActivityReferentialId, equipmentActivity.LocationId, equipmentActivity.TerminalEquipmentHandlingFacilityId.Value, equipmentActivity.VesselId.Value, equipmentActivity.VoyageId.GetValueOrDefault(), equipmentActivity.Voyage), EquipmentActivitySpecification.WithDetail()).ToList();
            }

            return null;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="equipmentActivity">The equipmentActivity.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        public IList<long> Save(IList<EquipmentActivity> equipmentActivity)
        {
            if (equipmentActivity == null)
            {
                throw new ArgumentNullException(nameof(equipmentActivity));
            }

            IList<long> equipmentActivityIds = new List<long>();
            foreach (var item in equipmentActivity)
            {
                if (item.EquipmentActivityId == 0)
                {
                    DbContext.EquipmentActivities.Add(item);
                }
                else
                {
                    this.EquipmentActivityEditSave(item);
                    var equipmentActivityDetail = DbContext.EquipmentActivities.Where(x => x.EquipmentActivityId == item.EquipmentActivityId).Include(s => s.EquipmentActivityErrors).FirstOrDefault();
                    if (equipmentActivityDetail.EquipmentActivityErrors.Any())
                    {
                        DbContext.EquipmentActivityErrors.RemoveRange(equipmentActivityDetail.EquipmentActivityErrors);
                    }

                    if (item.EquipmentActivityErrors != null && item.EquipmentActivityErrors.Any())
                    {
                        DbContext.EquipmentActivityErrors.AddRange(item.EquipmentActivityErrors);
                    }
                }

                equipmentActivityIds.Add(item.EquipmentActivityId);
            }

            return equipmentActivityIds;
        }

        /// <summary>
        /// Searches the equipment activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns the equipment number.</returns>
        public async Task<IList<Equipment>> SearchEquipmentActivity(string equipmentNumber)
        {
            var equipment = await DbContext.Equipments.Where(x => x.EquipmentNumber.Contains(equipmentNumber) && x.IsCanceled.HasValue).ToListAsync();
            return equipment?.Where(x => x.ValidFrom <= DateTime.Now && (!x.ValidTo.HasValue || x.ValidTo >= DateTime.Now)).ToList();
        }

        /// <summary>
        /// Gets the valid activity count.
        /// </summary>
        /// <returns>Valid activity count.</returns>
        public async Task<int> SearchValidActivityCount()
        {
            return await DbContext.EquipmentActivities.Where(s => !s.EquipmentActivityErrors.Any() && s.EquipmentActivityState != DataAccessConstant.Cancel).CountAsync();
        }

        /// <summary>
        /// Gets the valid activity count.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <returns>
        /// Valid activity count.
        /// </returns>
        public async Task<IList<Tuple<int?, string, string, int>>> SearchValidActivityCount(EquipmentActivityFilter activityFilter)
        {
            activityFilter.Valid = null;
            List<long> ids = activityFilter.EquipmentActivityId != null ? activityFilter.EquipmentActivityId.Split(',').Select(long.Parse).ToList() : new List<long>();
            List<ICollection<EquipmentActivityError>> activity = await DbContext.BuildQuery(EquipmentActivitySpecification.BySearchRequest(activityFilter, ids).ToList()).Select(s => s.EquipmentActivityErrors).ToListAsync();
            var query = await DbContext.ValidationRules.Include(s => s.EquipmentActivityErrors).Where(s => s.EquipmentActivityErrors.Any()).Select(s => new { s.ValidationRuleId, s.RuleNumber, s.ErrorDescription, Count = s.EquipmentActivityErrors.Count }).ToListAsync();
            List<Tuple<int?, string, string, int>> validationDetail = query.Select(s => new Tuple<int?, string, string, int>(s.ValidationRuleId, s.RuleNumber, s.ErrorDescription, activity.Count(q => q.Any(a => a != null && a.ValidationRuleId == s.ValidationRuleId)))).ToList();
            validationDetail.Add(new Tuple<int?, string, string, int>(null, string.Empty, string.Empty, activity.Count(s => s == null || s.Count == 0)));
            return validationDetail;
        }

        /// <summary>
        /// Determines whether [has equipment activity duplicate] [the specified equipment activity identifier].
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <returns>
        /// Returns Equipment Duplicate.
        /// </returns>
        public async Task<bool> HasEquipmentActivityDuplicate(long equipmentActivityId, long equipmentId, int activityReferentialId, DateTime activityDate, int locationId, int vesselId, int voyageId, string feederVoyage)
        {
            return await DbContext.EquipmentActivities.AnyAsync(x => x.EquipmentActivityId != equipmentActivityId &&
                                                                    x.EquipmentId == equipmentId &&
                                                                    x.ActivityReferentialId == activityReferentialId &&
                                                                    DbFunctions.TruncateTime(x.ActivityDateTime) == activityDate.Date &&
                                                                    x.LocationId == locationId &&
                                                                    x.VesselId == vesselId &&
                                                                    ((voyageId > 0) ? x.VoyageId == voyageId : x.Voyage == feederVoyage &&
                                                                    x.EquipmentActivityState != Constant.DataAccessConstant.Cancel));
        }

        /// <summary>
        /// Determines whether [has equipment activity valid] [the specified equipment identifier].
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <returns>Returns Duplicate Equipment Valid.</returns>
        public async Task<bool> HasEquipmentActivityValid(long equipmentId, DateTime activityDate)
        {
            var equipment = await DbContext.Equipments.FirstOrDefaultAsync(x => x.EquipmentId == equipmentId && (!x.IsCanceled.HasValue || !x.IsCanceled.Value));
            return equipment.ValidFrom <= activityDate && (!equipment.ValidTo.HasValue || equipment.ValidTo >= activityDate);
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Equipments the activity edit save.
        /// </summary>
        /// <param name="updatedEquipmentActivity">The updated equipment activity.</param>
        private void EquipmentActivityEditSave(EquipmentActivity updatedEquipmentActivity)
        {
            EquipmentActivity existEquipmentActivity = DbContext.EquipmentActivities.FirstOrDefault(x => x.EquipmentActivityId == updatedEquipmentActivity.EquipmentActivityId);
            existEquipmentActivity.EquipmentActivityId = updatedEquipmentActivity.EquipmentActivityId;
            existEquipmentActivity.EquipmentStateId = updatedEquipmentActivity.EquipmentStateId;

            existEquipmentActivity.ActivityDateTime = updatedEquipmentActivity.ActivityDateTime;
            existEquipmentActivity.ActivityUTCDateTime = updatedEquipmentActivity.ActivityUTCDateTime;
            existEquipmentActivity.LocationId = updatedEquipmentActivity.LocationId;
            existEquipmentActivity.BLNumber = updatedEquipmentActivity.BLNumber;
            existEquipmentActivity.BookingNumber = updatedEquipmentActivity.BookingNumber;
            existEquipmentActivity.PickupReference = updatedEquipmentActivity.PickupReference;
            existEquipmentActivity.MSCAuthorizationReference = updatedEquipmentActivity.MSCAuthorizationReference;
            existEquipmentActivity.LeasingCompanyReference = updatedEquipmentActivity.LeasingCompanyReference;
            existEquipmentActivity.LoadingPortId = updatedEquipmentActivity.LoadingPortId;
            existEquipmentActivity.ReceiptLocationId = updatedEquipmentActivity.ReceiptLocationId;
            existEquipmentActivity.ReturnDepotEquipmentHandlingFacilityId = updatedEquipmentActivity.ReturnDepotEquipmentHandlingFacilityId;
            existEquipmentActivity.ReturnEquipmentAuthorizationNumber = updatedEquipmentActivity.ReturnEquipmentAuthorizationNumber;
            existEquipmentActivity.ReturnLocationId = updatedEquipmentActivity.ReturnLocationId;
            existEquipmentActivity.ReturnTerminalEquipmentHandlingFacilityId = updatedEquipmentActivity.ReturnTerminalEquipmentHandlingFacilityId;
            existEquipmentActivity.SCACCodeId = updatedEquipmentActivity.SCACCodeId;
            existEquipmentActivity.SealNumber = updatedEquipmentActivity.SealNumber;
            existEquipmentActivity.ShippingInstructionNumber = updatedEquipmentActivity.ShippingInstructionNumber;
            existEquipmentActivity.TerminalEquipmentHandlingFacilityId = updatedEquipmentActivity.TerminalEquipmentHandlingFacilityId;
            existEquipmentActivity.TransshipmentPortId = updatedEquipmentActivity.TransshipmentPortId;
            existEquipmentActivity.VesselId = updatedEquipmentActivity.VesselId;
            existEquipmentActivity.Voyage = updatedEquipmentActivity.Voyage;
            existEquipmentActivity.VoyageETA = updatedEquipmentActivity.VoyageETA;
            existEquipmentActivity.VoyageETD = updatedEquipmentActivity.VoyageETD;
            existEquipmentActivity.VoyageId = updatedEquipmentActivity.VoyageId;
            existEquipmentActivity.DischargePortId = updatedEquipmentActivity.DischargePortId;
            existEquipmentActivity.EquipmentActivityState = updatedEquipmentActivity.EquipmentActivityState;
            existEquipmentActivity.DestinationLocationId = updatedEquipmentActivity.DestinationLocationId;
            existEquipmentActivity.DepotEquipmentHandlingFacilityId = updatedEquipmentActivity.DepotEquipmentHandlingFacilityId;
            existEquipmentActivity.DeliveryLocationId = updatedEquipmentActivity.DeliveryLocationId;
            existEquipmentActivity.UpdatedBy = updatedEquipmentActivity.UpdatedBy;
            existEquipmentActivity.UpdatedOn = updatedEquipmentActivity.UpdatedOn;
        }

        #endregion Private Methods
    }
}