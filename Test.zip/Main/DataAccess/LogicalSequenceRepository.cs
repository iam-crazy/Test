﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequenceRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Constant;
    using Contracts;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    ///   Declare LogicalSequenceRepository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.Logistics.EME.Service.DataAccess.Contracts.EMEDataContext, Msc.Logistics.EME.Service.DataAccess.Contracts.LogicalSequence}" />
    /// <seealso cref="Msc.Logistics.EME.Service.DataAccess.Contracts.ILogicalSequenceRepository" />
    public class LogicalSequenceRepository : RepositoryBase<EMEDataContext, LogicalActivity>, ILogicalSequenceRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalSequenceRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public LogicalSequenceRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the logical sequence list.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>
        /// Returns Logical Sequence List.
        /// </returns>
        public async Task<IList<LogicalActivity>> GetLogicalSequenceList(int moveCodeId)
        {
            var query = DbContext.BuildQuery(LogicalActivitySpecification.BySearchRequest(moveCodeId, 0, true, false), LogicalActivitySpecification.WithDetail());
            var data = await query.ToListAsync();
            var logicalSequenceList = data.OrderBy(m => m.FromActivityReferential.Code);
            return logicalSequenceList.Any() ? logicalSequenceList.ToList() : new List<LogicalActivity>();
        }

        /// <summary>
        /// Saves the specified logical sequence.
        /// </summary>
        /// <param name="logicalSequence">The logical sequence.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        /// <exception cref="System.ArgumentException">Given Sequence Already Exists.</exception>
        public async Task<int> Save(IList<LogicalActivity> logicalSequence)
        {
            foreach (LogicalActivity sequenceLogic in logicalSequence)
            {
                if (logicalSequence != null && logicalSequence.Any())
                {
                    if (sequenceLogic.RowStatus == DataAccessConstant.Active)
                    {
                        DbContext.LogicalActivities.Add(sequenceLogic);
                        await DbContext.SaveChangesAsync();
                    }
                    else
                    {
                        DbContext.Entry(sequenceLogic).State = EntityState.Modified;
                        await DbContext.SaveChangesAsync();
                    }
                }

                await DbContext.SaveChangesAsync();
            }

            return logicalSequence.FirstOrDefault().LogicalActivityId;
        }

        /// <summary>
        /// Updates the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="status">If set to <c>true</c> [status].</param>
        /// <param name="remarks">The remarks parameter.</param>
        public void Update(int id, bool status, string remarks)
        {
            LogicalActivity activity = DbContext.LogicalActivities.FirstOrDefault(m => m.LogicalActivityId == id);
            activity.Remarks = remarks;
            activity.Status = status;

            DbContext.Entry(activity).State = EntityState.Modified;
            DbContext.SaveChangesAsync();
        }

        /// <summary>
        /// Gets the previous moves.
        /// </summary>
        /// <param name="nextMoveId">The next move identifier.</param>
        /// <returns>Returns the previous moves.</returns>
        public async Task<IList<LogicalActivity>> GetPreviousMoves(int nextMoveId)
        {
            var query = DbContext.BuildQuery(LogicalActivitySpecification.BySearchRequest(0, nextMoveId, true, false), LogicalActivitySpecification.WithDetail());
            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets the logical activity identifier.
        /// </summary>
        /// <param name="logicalActivityId">The logical activity identifier.</param>
        /// <returns>
        /// Returns The logical activity.
        /// </returns>
        public async Task<LogicalActivity> GetLogicalActivityId(int logicalActivityId)
        {
            return await DbContext.LogicalActivities.Include(s => s.FromActivityReferential).Include(s => s.ToActivityReferential).FirstOrDefaultAsync(m => m.LogicalActivityId == logicalActivityId);
        }

        #endregion Public Methods
    }
}