﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalActivityStatusRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalActivityStatusRepository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Constant;
    using Contracts;
    using Contracts.Extension;
    using Contracts.Objects;
    using Contracts.Specifications;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Framework.Service.DataAccess;
    using Framework.Service.DataAccess.SQLServer;
    using Framework.Service.DataAccess.SQLServer.Extension;

    /// <summary>
    /// Declare LogicalActivityStatusRepository.
    /// </summary>
    /// <seealso cref="Msc.Framework.Service.DataAccess.SQLServer.RepositoryBase{Msc.Logistics.EME.Service.DataAccess.Contracts.EMEDataContext, Msc.Logistics.EME.Service.DataAccess.Contracts.LogicalCombination}" />
    /// <seealso cref="Msc.Logistics.EME.Service.DataAccess.Contracts.ILogicalCombinationRepository" />
    public class LogicalActivityStatusRepository : RepositoryBase<EMEDataContext, LogicalActivity>, ILogicalActivityStatusRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalActivityStatusRepository" /> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The ambient database context locator.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public LogicalActivityStatusRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
            if (ambientDbContextLocator == null)
            {
                throw new ArgumentNullException(nameof(ambientDbContextLocator));
            }
        }

        #endregion Constructor

        #region Public Methods        

        /// <summary>
        /// Updates the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="status">If set to <c>true</c> [status].</param>
        /// <param name="remarks">The remarks.</param>
        /// <returns>Return activity status Data.</returns>
        public async Task<int> UpdateLogicalActivityStatus(int activityId, bool status, string remarks)
        {
            var fromActivity = DbContext.LogicalActivities.Where(r => r.FromActivityReferentialId == activityId || r.ToActivityReferentialId == activityId).ToList();
            fromActivity.ForEach((item) =>
            {
                item.Status = status;
                DbContext.Entry(item).State = EntityState.Modified;
            });

            return await DbContext.SaveChangesAsync(); 
        }

        /// <summary>
        /// Checks the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>
        /// Return activity status Data.
        /// </returns>
        public async Task<AvailableStatus> CheckLogicalActivityStatus(int activityId, string activityType)
        {            
            IList<ISpecification<LogicalActivity>> sequenceSpecifications = new List<ISpecification<LogicalActivity>>();
            sequenceSpecifications.Add(new Specification<LogicalActivity>(m => (m.FromActivityReferentialId == activityId || m.ToActivityReferentialId == activityId) && m.Status == true && m.ActivityType == null));
            var query = DbContext.BuildQuery(sequenceSpecifications.ToList());
            var activitySequence = await query.FirstOrDefaultAsync();
            IList<ISpecification<LogicalActivity>> combinationSpecifications = new List<ISpecification<LogicalActivity>>();
            combinationSpecifications.Add(new Specification<LogicalActivity>(m => (m.FromActivityReferentialId == activityId || m.ToActivityReferentialId == activityId) && m.Status == true && m.ActivityType != null));
            query = DbContext.BuildQuery(combinationSpecifications.ToList());
            var activityCombination = query.FirstOrDefaultAsync(); 
            var available = new AvailableStatus();
            available.IsSequence = activitySequence != null ? true : false;
            available.IsCombination = activityCombination.Result != null ? true : false;
            available.IsLogical = (activitySequence != null && activityCombination != null) ? true : false;
            return available;             
        }

        #endregion Public Methods
    }
}