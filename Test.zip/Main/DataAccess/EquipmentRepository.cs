﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentRepository.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentRepository.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Service.DataAccess.SQLServer;

    /// <summary>
    /// Declare EquipmentRepository.
    /// </summary>
    public class EquipmentRepository : RepositoryBase<EMEDataContext, Equipment>, IEquipmentRepository
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentRepository"/> class.
        /// </summary>
        /// <param name="ambientDbContextLocator">The <see cref="IAmbientDbContextLocator"/></param>
        public EquipmentRepository(IAmbientDbContextLocator ambientDbContextLocator) : base(ambientDbContextLocator)
        {
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// The GetEquipments
        /// </summary>
        /// <param name="equipmentId">The <see cref="int"/></param>
        /// <returns>The <see cref="Task{IList{Equipment}}"/></returns>
        public async Task<IList<Equipment>> GetEquipment(int equipmentId)
        {
            Equipment data = await DbContext.Equipments.Include(s => s.Equipment2).Include(s => s.EquipmentDetail).FirstOrDefaultAsync(s => s.EquipmentId == equipmentId);
            var equipment = new List<Equipment>();
            if (data.EquipmentDetail != null && data.EquipmentDetail.Count > 0)
            {
                equipment.AddRange(data.EquipmentDetail);
            }

            while (data != null)
            {
                equipment.Add(data);
                data = data.Equipment2;
            }

            return equipment.OrderBy(s => s.CreatedOn).ToList();
        }

        /// <summary>
        /// The IsEquipmentNumber
        /// </summary>
        /// <param name="equipmentNumber">The <see cref="string"/></param>
        /// <returns>The <see cref="Task{bool}"/></returns>
        public Task<bool> IsEquipmentNumber(string equipmentNumber)
        {
            return DbContext.Equipments.AnyAsync(p => p.EquipmentNumber == equipmentNumber);
        }

        /// <summary>
        /// Saves the specified equipment data.
        /// </summary>
        /// <param name="equipmentData">The equipment data.</param>
        /// <returns>
        /// Returns The Equipment Data.
        /// </returns>
        public async Task Save(Equipment equipmentData)
        {
            try
            {
                bool? isCanceled = equipmentData.IsCanceled;
                var equipment = await this.GetPreviousEquipment(equipmentData);
                if (equipment != null)
                {
                    equipment.ValidTo = equipmentData.ValidFrom.AddSeconds(-1);
                    equipment.UpdatedBy = equipmentData.CreatedBy;
                    equipment.UpdatedOn = equipmentData.CreatedOn;
                    equipmentData.IsCanceled = null;
                }

                DbContext.Entry(equipment).State = EntityState.Modified;
                DbContext.Equipments.Add(equipmentData);
                DbContext.Entry(equipmentData).State = EntityState.Added;
                await DbContext.SaveChangesAsync();
                if (isCanceled.HasValue && isCanceled.Value)
                {
                    List<EquipmentActivity> equipments = await DbContext.EquipmentActivities.Where(s => s.EquipmentId == equipmentData.ParentEquipmentId).ToListAsync();
                    equipments.ForEach(s => s.EquipmentId = equipmentData.EquipmentId);
                    await DbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// The GetPreviousEquipment
        /// </summary>
        /// <param name="equipmentData">The <see cref="Equipment"/></param>
        /// <returns>The <see cref="Task{Equipment}"/></returns>
        private async Task<Equipment> GetPreviousEquipment(Equipment equipmentData)
        {
            Equipment data = await DbContext.Equipments.FindAsync(equipmentData.ParentEquipmentId);
            if (equipmentData.IsCanceled.HasValue && equipmentData.IsCanceled.Value)
            {
                data.IsCanceled = true;
                data.UpdatedBy = equipmentData.CreatedBy;
                data.UpdatedOn = equipmentData.CreatedOn;

                if (data.ParentEquipmentId.HasValue)
                {
                    return await DbContext.Equipments.FindAsync(data.ParentEquipmentId.Value);
                }

                return null;
            }

            return data;
        }

        #endregion Private Methods
    }
}