﻿//-----------------------------------------------------------------------
// <copyright file = "DataAccessConstant.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare DataAccessConstant.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.DataAccess.Constant
{
    /// <summary>
    /// Declare DataAccessConstant.
    /// </summary>
    public static class DataAccessConstant
    {
        /// <summary>
        /// The string active.
        /// </summary>
        public const string Active = "A";

        /// <summary>
        /// The Move Activity Type.
        /// </summary>
        public const string Move = "MOV";

        /// <summary>
        /// The Event Activity Type.
        /// </summary>
        public const string Event = "EVE";

        /// <summary>
        /// The string cancel.
        /// </summary>
        public const string Cancel = "C";

        /// <summary>
        /// The string delete.
        /// </summary>
        public const string Delete = "D";

        /// <summary>
        /// The update.
        /// </summary>
        public const string Update = "U";

        /// <summary>
        /// The unchanged.
        /// </summary>
        public const string Unchanged = "UC";

        /// <summary>
        /// The message.
        /// </summary>
        public const string Message = "Given Code Already Exists";

        /// <summary>
        /// The specification code.
        /// </summary>
        public const string SpecificationCode = "SPC";
    }
}