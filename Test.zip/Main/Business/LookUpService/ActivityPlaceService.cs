﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityPlaceService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityPlaceService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ActivityPlaceService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.ActivityPlace")]
    public class ActivityPlaceService : LockService, IActivityPlaceService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IActivityPlaceRepository activityPlaceRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityPlaceService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="activityPlaceRepository">The activity place repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ActivityPlaceService(IDbContextScopeFactory databaseContextScopeFactory, IActivityPlaceRepository activityPlaceRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (activityPlaceRepository == null)
            {
                throw new ArgumentNullException(nameof(activityPlaceRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.changeLog = changeLog;
            this.activityPlaceRepository = activityPlaceRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the activity places.
        /// </summary>
        /// <returns>
        /// Return ActivityPlace.
        /// </returns>
        public async Task<IList<TakePlaceAt>> GetActivityPlaces()
        {
            IList<DataAccessObjects.TakePlaceAt> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.activityPlaceRepository.GetActivityPlaces();
            }

            return this.mapper.Map<IList<TakePlaceAt>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="activityLocationData">The activityLocationData.</param>
        /// <returns>
        /// Return Operation Outcome.
        /// </returns>
        public async Task<BusinessOutcome> Save(TakePlaceAt activityLocationData)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = activityLocationData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), activityLocationData.Id, activityLocationData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.TakePlaceAt>(activityLocationData);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, activityLocationData.UserName))
                {
                    this.activityPlaceRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the specified activity location identifier.
        /// </summary>
        /// <param name="activityLocationId">The activity location identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int activityLocationId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), activityLocationId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.activityPlaceRepository.Delete(activityLocationId));
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}