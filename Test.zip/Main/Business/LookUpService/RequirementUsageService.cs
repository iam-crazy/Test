﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementUsageService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementUsageService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare RequirementUsageService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.RequirementUsage")]
    public class RequirementUsageService : LockService, IRequirementUsageService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IRequirementUsageRepository requirementUsageRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementUsageService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="requirementUsageRepository">The requirement usage repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public RequirementUsageService(IDbContextScopeFactory databaseContextScopeFactory, IRequirementUsageRepository requirementUsageRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (requirementUsageRepository == null)
            {
                throw new ArgumentNullException(nameof(requirementUsageRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}
            this.changeLog = changeLog;
            this.requirementUsageRepository = requirementUsageRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the requirement usages.
        /// </summary>
        /// <returns>
        /// Return RequirementUsage.
        /// </returns>
        public async Task<IList<RequirementUsage>> GetRequirementUsages()
        {
            IList<DataAccessObjects.RequirementUsage> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.requirementUsageRepository.GetRequirementUsages();
            }

            return this.mapper.Map<IList<RequirementUsage>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="requirementUsageData">The requirementUsageData.</param>
        /// <returns>
        /// Return OperationOutcome.
        /// </returns>
        public async Task<BusinessOutcome> Save(RequirementUsage requirementUsageData)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = requirementUsageData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), requirementUsageData.Id, requirementUsageData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.RequirementUsage>(requirementUsageData);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, requirementUsageData.UserName))
                {
                    this.requirementUsageRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the specified requirement usage identifier.
        /// </summary>
        /// <param name="requirementUsageId">The requirement usage identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int requirementUsageId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), requirementUsageId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.requirementUsageRepository.Delete(requirementUsageId));
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}