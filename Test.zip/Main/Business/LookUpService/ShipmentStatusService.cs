﻿//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatusService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ShipmentStatusService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ShipmentStatusService.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.IShipmentStatusService" />
    [LockInfoAttribute("EME.GeneralCode.ShipmentStatus")]
    public class ShipmentStatusService : LockService, IShipmentStatusService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The shipment repository.
        /// </summary>
        private readonly IShipmentRepository shipmentRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentStatusService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="shipmentStatusRepository">The shipment status repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ShipmentStatusService(IDbContextScopeFactory databaseContextScopeFactory, IShipmentRepository shipmentStatusRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (shipmentStatusRepository == null)
            {
                throw new ArgumentNullException(nameof(shipmentStatusRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}
            this.changeLog = changeLog;
            this.shipmentRepository = shipmentStatusRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the shipment status.
        /// </summary>
        /// <param name="shipmentStatusCodes">The ShipmentStatus code.</param>
        /// <returns>
        /// Returns Shipment status.
        /// </returns>
        public async Task<IList<ShipmentStatus>> GetShipmentStatus(string shipmentStatusCodes)
        {
            IList<ShipmentStatus> shipments = new List<ShipmentStatus>();
            IList<DataAccessObjects.ShipmentStatus> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.shipmentRepository.GetShipmentStatus(shipmentStatusCodes);
            }

            shipments = ShipmentStatusExtensions.ToBusinessModel(data.ToList());
            return shipments;
        }

        /// <summary>
        /// Saves the specified shipment status data.
        /// </summary>
        /// <param name="shipmentStatusData">The shipment status data.</param>
        /// <returns>Return Save Data.</returns>
        public async Task<BusinessOutcome> Save(ShipmentStatus shipmentStatusData)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = shipmentStatusData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), shipmentStatusData.Id, shipmentStatusData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.ShipmentStatus>(shipmentStatusData);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, shipmentStatusData.UserName))
                {
                    this.shipmentRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the specified shipment status identifier.
        /// </summary>
        /// <param name="shipmentStatusId">The shipment status identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<BusinessOutcome> Delete(int shipmentStatusId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), shipmentStatusId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.shipmentRepository.Delete(shipmentStatusId));
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}