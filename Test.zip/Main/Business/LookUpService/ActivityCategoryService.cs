﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityCategoryService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityCategoryService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ActivityCategoryService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.ActivityCategory")]
    public class ActivityCategoryService : LockService, IActivityCategoryService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IActivityCategoryRepository activityCategoryRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ActivityCategoryService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="activityCategoryRepository">The activity category repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ActivityCategoryService(IDbContextScopeFactory databaseContextScopeFactory, IActivityCategoryRepository activityCategoryRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (activityCategoryRepository == null)
            {
                throw new ArgumentNullException(nameof(activityCategoryRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.changeLog = changeLog;
            this.activityCategoryRepository = activityCategoryRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified activity category identifier.
        /// </summary>
        /// <param name="activityCategoryId">The activity category identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        /// <exception cref="System.NotImplementedException">Not Implemented Exception.</exception>
        public async Task<BusinessOutcome> Delete(int activityCategoryId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), activityCategoryId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.activityCategoryRepository.Delete(activityCategoryId));
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the ActivityCategory.
        /// </summary>
        /// <returns>
        /// Returns ActivityCategory Lists.
        /// </returns>
        public async Task<IList<ActivityCategory>> GetActivityCategories()
        {
            IList<DataAccessObjects.ActivityCategory> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.activityCategoryRepository.GetActivityCategories();
            }

            return this.mapper.Map<IList<ActivityCategory>>(data);
        }

        /// <summary>
        /// Saves the specified ActivityCategory.
        /// </summary>
        /// <param name="data">The ActivityCategory.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        public async Task<BusinessOutcome> Save(ActivityCategory data)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = data.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), data.Id, data.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.ActivityCategory>(data);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, data.UserName))
                {
                    this.activityCategoryRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}