﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleErrorResultService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleErrorResultService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ValidationRuleErrorResultService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.ValidationRuleErrorResult")]
    public class ValidationRuleErrorResultService : LockService, IValidationRuleErrorResultService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IValidationRuleErrorResultRepository validationRuleErrorRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleErrorResultService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="validationRuleErrorRepository">The validation rule error repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleErrorResultService(IDbContextScopeFactory databaseContextScopeFactory, IValidationRuleErrorResultRepository validationRuleErrorRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (validationRuleErrorRepository == null)
            {
                throw new ArgumentNullException(nameof(validationRuleErrorRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}
            this.validationRuleErrorRepository = validationRuleErrorRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.changeLog = changeLog;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Methods

        /// <summary>
        /// Deletes the specified validation rule error result identifier.
        /// </summary>
        /// <param name="validationRuleErrorResultId">The validation rule error result identifier.</param>
        /// <param name = "userId" > Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int validationRuleErrorResultId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), validationRuleErrorResultId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.validationRuleErrorRepository.Delete(validationRuleErrorResultId));
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the validation rule error results.
        /// </summary>
        /// <returns>
        /// Return ValidationRuleErrorResult.
        /// </returns>
        public async Task<IList<ValidationRuleErrorResult>> GetValidationRuleErrorResults()
        {
            IList<DataAccessObjects.ValidationRuleErrorResult> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.validationRuleErrorRepository.GetValidationRuleErrorResults();
            }

            return this.mapper.Map<IList<ValidationRuleErrorResult>>(data);
        }

        /// <summary>
        /// Saves the specified validation rule error result data.
        /// </summary>
        /// <param name="validationRuleErrorResultData">The validation rule error result data.</param>
        /// <returns>Return Save Data.</returns>
        public async Task<BusinessOutcome> Save(ValidationRuleErrorResult validationRuleErrorResultData)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = validationRuleErrorResultData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), validationRuleErrorResultData.Id, validationRuleErrorResultData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.ValidationRuleErrorResult>(validationRuleErrorResultData);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, validationRuleErrorResultData.UserName))
                {
                    this.validationRuleErrorRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        #endregion Methods
    }
}