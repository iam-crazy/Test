﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleGroupService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleGroupService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ValidationRuleGroupService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.ValidationRuleGroup")]
    public class ValidationRuleGroupService : LockService, IValidationRuleGroupService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IValidationRuleGroupRepository validationRuleGroupRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleGroupService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="validationRuleGroupRepository">The validation rule group repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleGroupService(IDbContextScopeFactory databaseContextScopeFactory, IValidationRuleGroupRepository validationRuleGroupRepository, IMapper mapper, LockHttpClient locker, IChangeLog changeLog) : base(locker)
        {
            if (validationRuleGroupRepository == null)
            {
                throw new ArgumentNullException(nameof(validationRuleGroupRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}
            this.validationRuleGroupRepository = validationRuleGroupRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.changeLog = changeLog;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rule groups.
        /// </summary>
        /// <returns>
        /// Return ValidationRuleGroup.
        /// </returns>
        public async Task<IList<ValidationRuleGroup>> GetValidationRuleGroups()
        {
            IList<DataAccessObjects.ValidationRuleGroup> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.validationRuleGroupRepository.GetValidationRuleGroups();
            }

            return this.mapper.Map<IList<ValidationRuleGroup>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleGroupData">The validationRuleGroupData.</param>
        /// <returns>
        /// Return OperationOutcome.
        /// </returns>
        public async Task<BusinessOutcome> Save(ValidationRuleGroup validationRuleGroupData)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = validationRuleGroupData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), validationRuleGroupData.Id, validationRuleGroupData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.ValidationRuleGroup>(validationRuleGroupData);

                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, validationRuleGroupData.UserName))
                {
                    this.validationRuleGroupRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the specified validation rule group identifier.
        /// </summary>
        /// <param name="validationRuleGroupId">The validation rule group identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int validationRuleGroupId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), validationRuleGroupId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.validationRuleGroupRepository.Delete(validationRuleGroupId));
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}