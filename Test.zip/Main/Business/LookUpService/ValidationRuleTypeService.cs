﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleTypeService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleTypeService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using BusinessContracts = Business.Contracts.Objects;
    using DataAccessContracts = DataAccess.Contracts;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ValidationRuleTypeService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.ValidationRuleType")]
    public class ValidationRuleTypeService : LockService, IValidationRuleTypeService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly DataAccessContracts.IValidationRuleTypeRepository validationRuleTypeRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleTypeService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="validationRuleTypeRepository">The validation rule type repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleTypeService(IDbContextScopeFactory databaseContextScopeFactory, DataAccessContracts.IValidationRuleTypeRepository validationRuleTypeRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (validationRuleTypeRepository == null)
            {
                throw new ArgumentNullException(nameof(validationRuleTypeRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.validationRuleTypeRepository = validationRuleTypeRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.changeLog = changeLog;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rule types.
        /// </summary>
        /// <returns>
        /// Return ValidationRuleType.
        /// </returns>
        public async Task<IList<BusinessContracts.ValidationRuleType>> GetValidationRuleTypes()
        {
            IList<DataAccessObjects.ValidationRuleType> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.validationRuleTypeRepository.GetValidationRuleTypes();
            }

            return this.mapper.Map<IList<BusinessContracts.ValidationRuleType>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="validationRuleTypeData">The validationRuleTypeData.</param>
        /// <returns>
        /// Return OperationOutcome.
        /// </returns>
        public async Task<BusinessOutcome> Save(BusinessContracts.ValidationRuleType validationRuleTypeData)
        {
            try
            {
                BusinessOutcome result = new BusinessOutcome();
                bool hasLockConfirmed = validationRuleTypeData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), validationRuleTypeData.Id, validationRuleTypeData.UpdatedBy.Value, string.Empty);
                if (!hasLockConfirmed)
                {
                    result.AddLockConfirmationWarning();
                }
                else
                {
                    var items = this.mapper.Map<DataAccessObjects.ValidationRuleType>(validationRuleTypeData);
                    using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, validationRuleTypeData.UserName))
                    {
                        this.validationRuleTypeRepository.Save(items);
                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                        result.IdentityValue = Convert.ToString(items.Id);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Deletes the specified validation rule type identifier.
        /// </summary>
        /// <param name="validationRuleTypeId">The validation rule type identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int validationRuleTypeId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), validationRuleTypeId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.validationRuleTypeRepository.Delete(validationRuleTypeId));
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}