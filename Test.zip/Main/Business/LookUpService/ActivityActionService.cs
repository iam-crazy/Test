﻿//-----------------------------------------------------------------------
// <copyright file = "ActivityActionService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ActivityActionService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ActivityActionService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.ActivityAction")]
    public class ActivityActionService : LockService, IActivityActionService
    {
        #region Member

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IActivityActionRepository activityActionRepository;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ActivityActionService class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="activityActionRepository">The activity action repository.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="changeLog">The Changelog to have log.</param>
        /// <param name="locker"> The lockerclient.</param>
        /// <exception cref="System.ArgumentNullException">
        /// Argument Null Exception.
        /// </exception>
        public ActivityActionService(IDbContextScopeFactory databaseContextScopeFactory, IActivityActionRepository activityActionRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (activityActionRepository == null)
            {
                throw new ArgumentNullException(nameof(activityActionRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.changeLog = changeLog;
            this.activityActionRepository = activityActionRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified activity action identifier.
        /// </summary>
        /// <param name="activityActionId">The activity action identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<BusinessOutcome> Delete(int activityActionId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), activityActionId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.activityActionRepository.Delete(activityActionId));
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the ActivityAction.
        /// </summary>
        /// <returns>
        /// Returns ActivityAction Lists.
        /// </returns>
        public async Task<IList<ActivityAction>> GetActivityActions()
        {
            IList<DataAccessObjects.ActivityAction> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.activityActionRepository.GetActivityActions();
            }

            return this.mapper.Map<IList<ActivityAction>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The Save data.</param>
        /// <returns>Return Save Data.</returns>
        public async Task<BusinessOutcome> Save(ActivityAction data)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = data.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), data.Id, data.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var item = this.mapper.Map<DataAccessObjects.ActivityAction>(data);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, data.UserName))
                {
                    try
                    {
                        this.activityActionRepository.Save(item);
                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(item);
                        result.IdentityValue = Convert.ToString(item.Id);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}