﻿//-----------------------------------------------------------------------
// <copyright file = "BusinessCycleService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare BusinessCycleService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare BusinessCycleService.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.LockService" />
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.IBusinessCycleService" />
    public class BusinessCycleService : LockService, IBusinessCycleService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The business cycle repository.
        /// </summary>
        private readonly IBusinessCycleRepository businessCycleRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessCycleService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="businessCycleRepository">The business cycle repository.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public BusinessCycleService(IDbContextScopeFactory databaseContextScopeFactory, IBusinessCycleRepository businessCycleRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (businessCycleRepository == null)
            {
                throw new ArgumentNullException(nameof(businessCycleRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            this.changeLog = changeLog;
            this.businessCycleRepository = businessCycleRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified business cyle identifier.
        /// </summary>
        /// <param name="businessCycleId">The business cycle identifier.</param>
        /// <param name="userId">The UserId.</param>
        /// <returns>
        /// Return Delete Data.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int businessCycleId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), businessCycleId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.businessCycleRepository.Delete(businessCycleId, userId));
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the business cycles.
        /// </summary>
        /// <returns>Reteruns the business cycle list.</returns>
        public async Task<IList<BusinessCycle>> GetBusinessCycles()
        {
            IList<DataAccessObjects.BusinessCycle> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.businessCycleRepository.GetBusinessCycles();
            }

            return this.mapper.Map<IList<BusinessCycle>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        public async Task<BusinessOutcome> Save(BusinessCycle data)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = data.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), data.Id, data.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.BusinessCycle>(data);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, data.UserName))
                {
                    this.businessCycleRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}