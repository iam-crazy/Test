﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStatusService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStatusService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentStatusService.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.IEquipmentStatusService" />
    [LockInfoAttribute("EME.GeneralCode.EquipmentStatus")]
    public class EquipmentStatusService : LockService, IEquipmentStatusService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The equipment repository.
        /// </summary>
        private readonly IEquipmentStatusRepository equipmentRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStatusService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="equipmentStatusRepository">The equipment status repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public EquipmentStatusService(IDbContextScopeFactory databaseContextScopeFactory, IEquipmentStatusRepository equipmentStatusRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (equipmentStatusRepository == null)
            {
                throw new ArgumentNullException(nameof(equipmentStatusRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.changeLog = changeLog;
            this.equipmentRepository = equipmentStatusRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <returns>
        /// Returns equipment Status.
        /// </returns>
        public async Task<IList<EquipmentStatus>> GetEquipmentStatus()
        {
            IList<EquipmentStatus> equipments = new List<EquipmentStatus>();
            IList<DataAccessObjects.EquipmentStatus> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.equipmentRepository.GetEquipmentStatus();
            }

            equipments = EquipmentStatusExtensions.ToBusinessModel(data.ToList());
            return equipments;
        }

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentStatusData">The equipment status data.</param>
        /// <returns>Return Save Data.</returns>
        public async Task<BusinessOutcome> Save(EquipmentStatus equipmentStatusData)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = equipmentStatusData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), equipmentStatusData.Id, equipmentStatusData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var items = this.mapper.Map<DataAccessObjects.EquipmentStatus>(equipmentStatusData);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, equipmentStatusData.UserName))
                {
                    this.equipmentRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the specified equipment status identifier.
        /// </summary>
        /// <param name="equipmentStatusId">The equipment status identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>Return Delete Data.</returns>
        public async Task<BusinessOutcome> Delete(int equipmentStatusId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), equipmentStatusId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result.IdentityValue = Convert.ToString(await this.equipmentRepository.Delete(equipmentStatusId));
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}