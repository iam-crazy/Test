﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementGroupService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare RequirementGroupService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare RequirementGroupService.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.IRequirementGroupService" />
    [LockInfoAttribute("EME.GeneralCode.RequirementGroup")]
    public class RequirementGroupService : LockService, IRequirementGroupService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IRequirementGroupRepository requirementGroupRepository;

        #endregion Member

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementGroupService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="requirementGroupRepository">The requirement group repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public RequirementGroupService(IDbContextScopeFactory databaseContextScopeFactory, IRequirementGroupRepository requirementGroupRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (requirementGroupRepository == null)
            {
                throw new ArgumentNullException(nameof(requirementGroupRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}
            this.changeLog = changeLog;
            this.requirementGroupRepository = requirementGroupRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        /// <summary>
        /// Gets the requirement groups.
        /// </summary>
        /// <returns>
        /// Return GetRequirementGroups.
        /// </returns>
        public async Task<IList<RequirementGroup>> GetRequirementGroups()
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                var data = await this.requirementGroupRepository.GetRequirementGroups();
                return this.mapper.Map<IList<RequirementGroup>>(data);
            }
        }

        /// <summary>
        /// Saves the specified validation rule type data.
        /// </summary>
        /// <param name="requirementGroupData">The requirement Group Data.</param>
        /// <returns>
        /// Return OperationOutcome.
        /// </returns>
        public async Task<OperationOutcome> Save(RequirementGroup requirementGroupData)
        {
            OperationOutcome result = new OperationOutcome();
            bool hasLockConfirmed = requirementGroupData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), requirementGroupData.Id, requirementGroupData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarningOperation();
            }
            else
            {
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, requirementGroupData.UserName))
                {
                    var items = this.mapper.Map<DataAccessObjects.RequirementGroup>(requirementGroupData);
                    this.requirementGroupRepository.Save(items);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(items);
                    result.IdentityValue = Convert.ToString(items.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes the specified requirement group identifier.
        /// </summary>
        /// <param name="requirementGroupId">The requirement group identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<OperationOutcome> Delete(int requirementGroupId, int userId)
        {
            OperationOutcome result = new OperationOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), requirementGroupId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarningOperation();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.Create())
                {
                    result = await this.requirementGroupRepository.Delete(requirementGroupId);
                }
            }

            return result;
        }
    }
}