﻿//-----------------------------------------------------------------------
// <copyright file = "RequirementFieldService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare RequirementFieldService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare RequirementFieldService.
    /// </summary>
    [LockInfoAttribute("EME.GeneralCode.RequirementField")]
    public class RequirementFieldService : LockService, IRequirementFieldService
    {
        #region Member

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The activity action repository.
        /// </summary>
        private readonly IRequirementFieldRepository requirementFieldRepository;

        #endregion Member

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RequirementFieldService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="requirementFieldRepository">The requirement field repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public RequirementFieldService(IDbContextScopeFactory databaseContextScopeFactory, IRequirementFieldRepository requirementFieldRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (requirementFieldRepository == null)
            {
                throw new ArgumentNullException(nameof(requirementFieldRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }
            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}
            this.changeLog = changeLog;
            this.requirementFieldRepository = requirementFieldRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Deletes the specified requirement field identifier.
        /// </summary>
        /// <param name="requirementFieldId">The requirement field identifier.</param>
        /// <param name="userId">Current user id.</param>
        /// <returns>
        /// Return Delete Record.
        /// </returns>
        public async Task<BusinessOutcome> Delete(int requirementFieldId, int userId)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), requirementFieldId, userId, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.CreateReadOnly())
                {
                    result.IdentityValue = Convert.ToString(await this.requirementFieldRepository.Delete(requirementFieldId));
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the requirement fields.
        /// </summary>
        /// <returns>
        /// Return RequirementField.
        /// </returns>
        public async Task<IList<RequirementField>> GetRequirementFields()
        {
            IList<DataAccessObjects.RequirementField> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.requirementFieldRepository.GetRequirementFields();
            }

            return this.mapper.Map<IList<RequirementField>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="requirementFieldData">The requirementFieldData.</param>
        /// <returns>
        /// Return OperationOutcome.
        /// </returns>
        public async Task<BusinessOutcome> Save(RequirementField requirementFieldData)
        {
            if (requirementFieldData == null)
            {
                throw new ArgumentNullException(nameof(requirementFieldData));
            }

            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = requirementFieldData.Id == 0 ? true : await ConfirmExistingLock(this.GetLockName(), requirementFieldData.Id, requirementFieldData.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var data = this.ToBusinessRequirementFieldModel(requirementFieldData);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, requirementFieldData.UserName))
                {
                    this.requirementFieldRepository.Save(data);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(data);
                    result.IdentityValue = Convert.ToString(data.Id);
                }
            }

            return result;
        }

        /// <summary>
        /// To the business requirement field model.
        /// </summary>
        /// <param name="item">The item parameter.</param>
        /// <returns>Return List of equipment category.</returns>
        /// <exception cref="System.ArgumentNullException">The ArgumentNullException.</exception>
        private DataAccess.Contracts.Objects.RequirementField ToBusinessRequirementFieldModel(Contracts.Objects.RequirementField item)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item));
            }

            DataAccess.Contracts.Objects.RequirementField reqfield = new DataAccess.Contracts.Objects.RequirementField();
            reqfield.Id = item.Id;
            reqfield.Code = item.Code;
            reqfield.Description = item.Description;
            reqfield.RequirementGroupId = item.RequirementGroup.Id;
            return reqfield;
        }

        #endregion Public Methods
    }
}