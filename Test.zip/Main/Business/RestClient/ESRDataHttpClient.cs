﻿//-----------------------------------------------------------------------
// <copyright file = "ESRDataHttpClient.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ESRDataHttpClient. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using Constants;

    /// <summary>
    /// Declare ESRDataHttpClient.
    /// </summary>
    public class ESRDataHttpClient : HttpClient
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ESRDataHttpClient"/> class.
        /// </summary>
        /// <param name="baseAddress">The base address.</param>
        /// <param name="userId">The user identifier.</param>
        public ESRDataHttpClient(string baseAddress, string userId)
        {
            this.BaseAddress = new Uri(baseAddress);
            this.DefaultRequestHeaders.Accept.Clear();
            this.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(BusinessConstant.ApplicationJson));
            this.DefaultRequestHeaders.Add(BusinessConstant.UserId, userId);
        }

        #endregion Constructor
    }
}