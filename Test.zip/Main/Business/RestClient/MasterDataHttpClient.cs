﻿//-----------------------------------------------------------------------
// <copyright file = "MasterDataHttpClient.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare MasterDataHttpClient.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using Constants;

    /// <summary>
    /// Declare MasterDataHttpClient.
    /// </summary>
    public class MasterDataHttpClient : HttpClient
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MasterDataHttpClient"/> class.
        /// </summary>
        /// <param name="baseAddress">The base address.</param>
        /// <param name="userId">The user identifier.</param>
        public MasterDataHttpClient(string baseAddress, string userId)
        {
            this.BaseAddress = new Uri(baseAddress);
            this.DefaultRequestHeaders.Accept.Clear();
            this.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(BusinessConstant.ApplicationJson));
            this.DefaultRequestHeaders.Add(BusinessConstant.UserId, userId);
        }
    }
}