﻿//-----------------------------------------------------------------------
// <copyright file = "SecurityHttpClient.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare SecurityHttpClient.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.RestClient
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using Constants;

    /// <summary>
    /// Declare SecurityHttpClient.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class SecurityHttpClient : HttpClient
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SecurityHttpClient"/> class.
        /// </summary>
        /// <param name="baseAddress">The base address.</param>
        /// <param name="userId">The user identifier.</param>
        public SecurityHttpClient(string baseAddress, string userId)
        {
            this.BaseAddress = new Uri(baseAddress);
            this.DefaultRequestHeaders.Accept.Clear();
            this.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(BusinessConstant.ApplicationJson));
            this.DefaultRequestHeaders.Add(BusinessConstant.UserId, userId);
        }

        #endregion
    }
}
