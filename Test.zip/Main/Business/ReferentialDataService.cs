﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataService.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Referential Data Service.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.IReferentialDataService" />
    [LockInfoAttribute("EME.ReferentialData")]
    public class ReferentialDataService : LockService, IReferentialDataService
    {
        #region Members

        /// <summary>
        /// The master data service.
        /// </summary>
        private readonly IEquipmentStockRepositionService equipmentStockRepositionService;

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The referential data repository.
        /// </summary>
        private readonly IReferentialDataRepository referentialDataRepository;

        /// <summary>
        /// The business cycle repository.
        /// </summary>
        private readonly IBusinessCycleRepository businessCycleRepository;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferentialDataService" /> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="referentialRepository">The referential repository.</param>
        /// <param name="businessCycleRepository">The business cycle repository.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="equipmentStockRepositionService">The equipment stock reposition service.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", Justification = "changeLog", MessageId = "changeLog")]
        public ReferentialDataService(IDbContextScopeFactory databaseContextScopeFactory, IReferentialDataRepository referentialRepository, IBusinessCycleRepository businessCycleRepository, IMapper mapper, IEquipmentStockRepositionService equipmentStockRepositionService, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (referentialRepository == null)
            {
                throw new ArgumentNullException(nameof(referentialRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            if (equipmentStockRepositionService == null)
            {
                throw new ArgumentNullException(nameof(equipmentStockRepositionService));
            }

            if (businessCycleRepository == null)
            {
                throw new ArgumentNullException(nameof(businessCycleRepository));
            }

            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.referentialDataRepository = referentialRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
            this.equipmentStockRepositionService = equipmentStockRepositionService;
            this.changeLog = changeLog;
            this.businessCycleRepository = businessCycleRepository;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the referential list.
        /// </summary>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>
        /// Return the referential list.
        /// </returns>
        public async Task<IList<SearchReferentialData>> GetReferentialList(ReferentialDataFilter referentialData)
        {
            IList<DataAccessObjects.ActivityReferential> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.referentialDataRepository.GetReferentialList(referentialData.Action, referentialData.Activities, referentialData.ActivityType, referentialData.Categories, referentialData.EquipmentStatus, referentialData.FullEmpty, referentialData.GroupCode, referentialData.IsDisplayToCustomer, referentialData.IsValidationRuleActive, referentialData.Location, referentialData.RequirementFields, referentialData.RequirementUsage, referentialData.ShipmentStatus, referentialData.ValidationRule, referentialData.Status, referentialData.IsMapped, referentialData.BusinessCycle);
            }

            return this.mapper.Map<IList<SearchReferentialData>>(data);
        }

        /// <summary>
        /// Gets the referential data list.
        /// </summary>
        /// <param name="isMapped">Is Mapped with EDI.</param>
        /// <returns>
        /// Returns The Data.
        /// </returns>
        public async Task<IList<SearchReferentialData>> GetReferentialList(bool? isMapped)
        {
            IList<DataAccessObjects.ActivityReferential> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.referentialDataRepository.GetReferentialDataList(isMapped);
            }

            return this.mapper.Map<IList<SearchReferentialData>>(data);
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The Referential data.</param>
        /// <returns>
        /// Save The Referential Data.
        /// </returns>
        public async Task<BusinessOutcome> Save(ReferentialData data)
        {
            BusinessOutcome result = new BusinessOutcome();
            result.Messages = new List<ValidationResult>();
            bool hasLockConfirmed = (data.ActivityReferentialId == BusinessConstant.DefaultId) ? true : await ConfirmExistingLock(this.GetLockName(), (int)data.ActivityReferentialId, data.UpdatedBy.Value, string.Empty);

            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                if (Regex.IsMatch(data.Code, @"^[ A-Z]{1,4}$", RegexOptions.Compiled) && (data.Code.Length == 3 || data.Code.Length == 4))
                {
                    var referentialdata = ReferentialDataExtensions.ToConvertReferentialData(data);
                    using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, data.UserName))
                    {
                        this.referentialDataRepository.Save(referentialdata);
                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(referentialdata);
                        result.IdentityValue = Convert.ToString(referentialdata.ActivityReferentialId);
                    }
                }
                else
                {
                    result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ActivityCodeErrrorMessage));
                }

                if (result.IdentityValue == BusinessConstant.Value)
                {
                    result.Messages.Add(new ValidationResult(false, ValidationMessageType.Information, Resource.ValidationMessage.LBL_ActivityCodeAlready));
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Returns The Data Based On ID.
        /// </returns>
        public async Task<ReferentialData> GetReferentialData(int id)
        {
            ReferentialData businessReferentialData = new ReferentialData();
            DataAccessObjects.ActivityReferential referentialData;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                referentialData = await this.referentialDataRepository.GetReferentialData(id);
            }

            businessReferentialData = this.mapper.Map<ReferentialData>(referentialData);
            if (businessReferentialData != null)
            {
                businessReferentialData.LogisticsStatus = this.equipmentStockRepositionService.GetLogisticsStatus(id).Result;
                businessReferentialData.EDIMappings = ReferentialDataExtensions.ConvertToEDIMappingBusinessModel(referentialData.EDIMappings.ToList());
            }

            return businessReferentialData;
        }

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <returns>
        /// Return ReferentialData.
        /// </returns>
        public async Task<IList<RequirementField>> GetReferentialFields()
        {
            IList<RequirementField> businessReferentialFields = new List<RequirementField>();
            IList<DataAccessObjects.RequirementField> referentialFields;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                referentialFields = await this.referentialDataRepository.GetRequirementFields();
            }

            businessReferentialFields = ReferentialDataExtensions.ToBusinessModelRequirement(referentialFields.ToList());
            return businessReferentialFields;
        }

        /// <summary>
        /// Gets the Full Empty data.
        /// </summary>
        /// <returns>
        /// Return Full Empty.
        /// </returns>
        public async Task<IList<FullEmpty>> GetFullEmptyDetails()
        {
            IList<DataAccessObjects.FullEmpty> fullEmpties;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                fullEmpties = await this.referentialDataRepository.GetFullEmptyDetails();
            }

            return this.mapper.Map<IList<FullEmpty>>(fullEmpties);
        }

        /// <summary>
        /// Gets the referential data.
        /// </summary>
        /// <returns>
        /// Return ReferentialData.
        /// </returns>
        public async Task<IList<RequirementUsage>> GetReferentialUsage()
        {
            IList<RequirementUsage> businessReferentialUsage = new List<RequirementUsage>();
            IList<DataAccessObjects.RequirementUsage> referentialUsage;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                referentialUsage = await this.referentialDataRepository.GetRequirementUsage();
            }

            businessReferentialUsage = ReferentialDataExtensions.ToBusinessModelUsage(referentialUsage.ToList());
            return businessReferentialUsage;
        }

        /// <summary>
        /// Gets the activity referential list.
        /// </summary>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>Return ReferentialData.</returns>
        public async Task<IList<Activity>> GetActivityReferentialList(string activityType)
        {
            IList<DataAccessObjects.ActivityReferential> referentialUsage;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                referentialUsage = await this.referentialDataRepository.SearchReferentialData(activityType);
            }

            return this.mapper.Map<IList<Activity>>(referentialUsage);
        }

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <returns>Get Mapped Count.</returns>
        public async Task<Tuple<int, int, int>> SearchQuickAccessCount()
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                return await this.referentialDataRepository.SearchQuickAccessCount();
            }
        }

        /// <summary>
        /// Gets the quick access count.
        /// </summary>
        /// <param name="referentialData">The referential data.</param>
        /// <returns>
        /// Get Mapped Count.
        /// </returns>
        public async Task<Tuple<int, int, int>> GetQuickAccessCount(ReferentialDataFilter referentialData)
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                return await this.referentialDataRepository.GetQuickAccessCount(referentialData.Action, referentialData.Activities, referentialData.ActivityType, referentialData.Categories, referentialData.EquipmentStatus, referentialData.FullEmpty, referentialData.GroupCode, referentialData.IsDisplayToCustomer, referentialData.IsValidationRuleActive, referentialData.Location, referentialData.RequirementFields, referentialData.RequirementUsage, referentialData.ShipmentStatus, referentialData.ValidationRule, referentialData.Status, referentialData.BusinessCycle);
            }
        }

        /// <summary>
        /// Gets the Referential Validation rules associated with the given validation rule id.
        /// </summary>
        /// <param name="validationRuleId">The Validation rule id.</param>
        /// <returns>Referential Validation rules.</returns>
        public async Task<IList<ReferentialValidationRule>> GetReferentialValidationRules(int validationRuleId)
        {
            IList<DataAccessObjects.ReferentialValidationRule> referentialValidationrules;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                referentialValidationrules = await this.referentialDataRepository.GetReferentialValidationRules(validationRuleId);
            }

            return this.mapper.Map<IList<ReferentialValidationRule>>(referentialValidationrules);
        }

        /// <summary>
        /// Saves the referential validation rules.
        /// </summary>
        /// <param name="referentialValidationRule">The referential validation rule.</param>
        public void SaveReferentialValidationRules(IList<ReferentialValidationRule> referentialValidationRule)
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                this.referentialDataRepository.SaveReferentialValidationRules(this.mapper.Map<IList<DataAccessObjects.ReferentialValidationRule>>(referentialValidationRule));
            }
        }

        /// <summary>
        /// Updates the business cycle.
        /// </summary>
        /// <param name="referentialStatus">The referential status.</param>
        /// <returns>
        /// Returns the updated cycle.
        /// </returns>
        public async Task<BusinessOutcome> UpdateBusinessCycle(ReferentialDataStatus referentialStatus)
        {
            BusinessOutcome result = new BusinessOutcome();
            result.Messages = new List<ValidationResult>();
            bool hasLockConfirmed = (referentialStatus.ActivityReferentialId == BusinessConstant.DefaultId) ? true : await ConfirmExistingLock(this.GetLockName(), (int)referentialStatus.ActivityReferentialId, referentialStatus.UpdatedBy.Value, referentialStatus.UserName);

            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                DataAccessObjects.BusinessCycle businessCycleId;
                IList<DataAccessObjects.BusinessCycle> businessCycleList = new List<DataAccessObjects.BusinessCycle>();
                using (var scope = this.dataBaseContextScopeFactory.CreateReadOnly())
                {
                    businessCycleList = await this.businessCycleRepository.GetBusinessCycles();
                }

                businessCycleId = referentialStatus.IsGateIn.HasValue ? (referentialStatus.IsGateIn.Value ? businessCycleList.Where(x => x.Code == BusinessConstant.BusinessCycleEnd).First() : businessCycleList.Where(x => x.Code == BusinessConstant.BusinessCycleStart).First()) : null;

                var referentialdata = ReferentialDataExtensions.UpdateBusinessCycle(businessCycleId, referentialStatus);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, referentialStatus.UserName))
                {
                    this.referentialDataRepository.UpdateBusinessCycle(referentialdata);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(referentialdata);

                    result.IdentityValue = Convert.ToString(referentialdata.ActivityReferentialId);
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}