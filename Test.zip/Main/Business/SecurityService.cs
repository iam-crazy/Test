﻿//-----------------------------------------------------------------------
// <copyright file = "SecurityService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare SecurityService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;
    using RestClient;
    using Rest = Msc.Framework.UI.Rest;

    /// <summary>
    /// Declare SecurityService.
    /// </summary>
    /// <seealso cref="Msc.Logistics.CR.Service.Business.Contracts.ISecurityService" />
    public class SecurityService : ISecurityService
    {
        #region Fields

        /// <summary>
        /// The rest client.
        /// </summary>
        private readonly HttpClient restClient;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SecurityService"/> class.
        /// </summary>
        /// <param name="securityClient">The security client.</param>
        public SecurityService(SecurityHttpClient securityClient)
        {
            this.restClient = securityClient;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the user by identifier.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>
        /// Return user Object.
        /// </returns>
        public async Task<UserBase> GetUserById(int userId)
        {
            var restApi = new Rest.RestClient(this.restClient);
            return await restApi.GetAsync<UserBase>(path: "V1/users/" + userId);
        }

        /// <summary>
        /// Searches the users.
        /// </summary>
        /// <returns>
        /// Returns List of users.
        /// </returns>
        public async Task<IList<UserBase>> SearchUsers()
        {
            var restApi = new Rest.RestClient(this.restClient);
            return await restApi.GetAsync<IList<UserBase>>(path: "V1/users");
        }

        #endregion
    }
}
