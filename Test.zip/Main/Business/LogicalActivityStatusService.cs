﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalActivityStatusService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalActivityStatusService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Threading.Tasks;
    using AutoMapper;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare LogicalActivityStatusService.
    /// </summary>       
    public class LogicalActivityStatusService : ILogicalActivityStatusService
    {
        #region Members

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The logical activity status repository.
        /// </summary>
        private readonly ILogicalActivityStatusRepository logicalActivityStatusRepository;

        /// <summary>
        /// The mapper value.
        /// </summary>
        private readonly IMapper mapper;

        /////// <summary>
        /////// The change log.
        /////// </summary>
        ////private readonly IChangeLog changeLog;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalActivityStatusService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="logicalActivityStatusRepository">The logical activity status repository.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public LogicalActivityStatusService(IDbContextScopeFactory databaseContextScopeFactory, ILogicalActivityStatusRepository logicalActivityStatusRepository, IMapper mapper)
        {
            if (logicalActivityStatusRepository == null)
            {
                throw new ArgumentNullException(nameof(logicalActivityStatusRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.logicalActivityStatusRepository = logicalActivityStatusRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
            ////this.changeLog = changeLog;
        }

        #endregion Constructor

        #region Public Methods    

        /// <summary>
        /// Updates the logical activity status.
        /// </summary>
        /// <param name="activity">The activity.</param>
        /// <returns>
        /// Returns the logical activity status.
        /// </returns>
        public async Task<BusinessOutcome> UpdateLogicalActivityStatus(LogicalSequenceUpdate activity)
        {
            BusinessOutcome result = new BusinessOutcome();
            using (this.dataBaseContextScopeFactory.Create())
            {
                await this.logicalActivityStatusRepository.UpdateLogicalActivityStatus(activity.LogicalActivityId, activity.Status, activity.Remarks);
                result.IdentityValue = activity.LogicalActivityId.ToString();                
            }

            return result;
        }        

        /// <summary>
        /// Checks the logical activity status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <param name="activityType">Type of the activity.</param>
        /// <returns>
        /// Return activity status Data.
        /// </returns>
        public async Task<AvailableStatus> CheckLogicalActivityStatus(int activityId, string activityType)
        {
            DataAccessObjects.AvailableStatus activityStatus;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                activityStatus = await this.logicalActivityStatusRepository.CheckLogicalActivityStatus(activityId, activityType);
            }

            AvailableStatus status = this.mapper.Map<AvailableStatus>(activityStatus);
            return status;
        }

        #endregion Public Methods
    }
}