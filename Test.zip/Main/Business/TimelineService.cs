﻿//-----------------------------------------------------------------------
// <copyright file = "TimelineService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare TimelineService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare TimelineService.
    /// </summary>
    [LockInfoAttribute("EME.Timeline")]
    public class TimelineService : LockService, ITimelineService
    {
        #region Fields

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The mapper value.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The master data service.
        /// </summary>
        private readonly IMasterDataService masterDataService;

        /// <summary>
        /// The time line repository.
        /// </summary>
        private readonly ITimelineRepository timelineRepository;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TimelineService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="timelineRepository">The timeline repository.</param>
        /// <param name="masterDataService">The master data service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        /// <exception cref="System.ArgumentNullException"> Argument Exception.
        /// </exception>
        public TimelineService(IDbContextScopeFactory databaseContextScopeFactory, ITimelineRepository timelineRepository, IMasterDataService masterDataService, IMapper mapper, LockHttpClient locker) : base(locker)
        {
            if (timelineRepository == null)
            {
                throw new ArgumentNullException(nameof(timelineRepository));
            }

            if (masterDataService == null)
            {
                throw new ArgumentNullException(nameof(masterDataService));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            this.timelineRepository = timelineRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.masterDataService = masterDataService;
            this.mapper = mapper;
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Gets the equipment activity list.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="showCancel">The show cancel.</param>
        /// <returns>
        /// Returns the equipment activity.
        /// </returns>
        public async Task<IList<EquipmentActivity>> GetEquipmentActivityList(long equipmentActivityId, bool showCancel)
        {
            var businessData = new List<EquipmentActivity>();
            IList<DataAccessObjects.EquipmentActivity> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.timelineRepository.GetEquipmentActivityList(equipmentActivityId, showCancel);
            }

            if (data != null)
            {
                businessData = new List<EquipmentActivity>();
                IList<EquipmentSizeType> sizeTypes = this.GetEquipmentSizeTypes(data.Select(x => x.Equipment.EquipmentSizeTypeId).ToList());
                IList<EquipmentISOCode> isoCodes = this.GetEquipmentISOCodes(data.Select(x => x.Equipment.EquipmentISOId).ToList());
                IList<Port> ports = this.GetPorts(data);
                IList<TerminalDepot> terminalDepots = this.GetTerminalDepots(data);
                IList<Location> locations = this.GetLocations(data);
                IList<Vessel> vessels = this.GetVessels(data);

                foreach (var item in data)
                {
                    EquipmentActivity equipmentActivity = this.GetEquipmentActivityDetails(sizeTypes, ports, terminalDepots, vessels, locations, item, isoCodes);
                    businessData.Add(equipmentActivity);
                }
            }

            return businessData;
        }

        /// <summary>
        /// Gets the equipment iso codes.
        /// </summary>
        /// <param name="equipmentISOCodes">The equipment iso codes.</param>
        /// <returns>Return Equipment Codes.</returns>
        public IList<EquipmentISOCode> GetEquipmentISOCodes(List<short> equipmentISOCodes)
        {
            if (equipmentISOCodes != null && equipmentISOCodes.Any())
            {
                var sizeTypeIds = new List<short>();
                sizeTypeIds.AddRange(equipmentISOCodes);
                sizeTypeIds = sizeTypeIds.Where(x => x != 0).Distinct().ToList();
                if (sizeTypeIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetEquipmentISOCodes(sizeTypeIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the equipment size types.
        /// </summary>
        /// <param name="equipmentSizeTypeIds">The equipment size type ids.</param>
        /// <returns>Returns Equipment Activity SizeType.</returns>
        public IList<EquipmentSizeType> GetEquipmentSizeTypes(List<short> equipmentSizeTypeIds)
        {
            if (equipmentSizeTypeIds != null && equipmentSizeTypeIds.Any())
            {
                var sizeTypeIds = new List<short>();
                sizeTypeIds.AddRange(equipmentSizeTypeIds);
                sizeTypeIds = sizeTypeIds.Where(x => x != 0).Distinct().ToList();
                if (sizeTypeIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetEquipmentSizeTypes(sizeTypeIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the locations.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns location list.</returns>
        public IList<Location> GetLocations(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var locationIds = new List<int>();
                locationIds.AddRange(dataAccessData.Where(l => l.DestinationLocationId.HasValue).Select(x => x.DestinationLocationId.Value));
                locationIds.AddRange(dataAccessData.Where(l => l.DeliveryLocationId.HasValue).Select(x => x.DeliveryLocationId.Value));
                locationIds.AddRange(dataAccessData.Where(l => l.ReceiptLocationId.HasValue).Select(x => x.ReceiptLocationId.Value));
                locationIds.AddRange(dataAccessData.Where(l => l.ReturnLocationId.HasValue).Select(x => x.ReturnLocationId.Value));
                locationIds = locationIds.Distinct().ToList();
                if (locationIds.Any(x => x != 0))
                {
                    return Task.Run(() => this.masterDataService.GetLocations(locationIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the ports.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns Port Values.</returns>
        public IList<Port> GetPorts(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var portIds = new List<int>();
                portIds.AddRange(dataAccessData.Select(l => l.LocationId));
                portIds.AddRange(dataAccessData.Where(l => l.LoadingPortId.HasValue).Select(x => x.LoadingPortId.Value));
                portIds.AddRange(dataAccessData.Where(l => l.DischargePortId.HasValue).Select(l => l.DischargePortId.Value));
                portIds.AddRange(dataAccessData.Where(l => l.TransshipmentPortId.HasValue).Select(l => l.TransshipmentPortId.Value));
                portIds = portIds.Where(x => x != 0).Distinct().ToList();
                if (portIds != null && portIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetPorts(portIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the terminal depots.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns Terminal Depot.</returns>
        public IList<TerminalDepot> GetTerminalDepots(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var terminalDepotIds = new List<int>();
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.TerminalEquipmentHandlingFacilityId.HasValue).Select(x => x.TerminalEquipmentHandlingFacilityId.Value));
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.DepotEquipmentHandlingFacilityId.HasValue).Select(x => x.DepotEquipmentHandlingFacilityId.Value));
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.ReturnTerminalEquipmentHandlingFacilityId.HasValue).Select(x => x.ReturnTerminalEquipmentHandlingFacilityId.Value));
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.ReturnDepotEquipmentHandlingFacilityId.HasValue).Select(x => x.ReturnDepotEquipmentHandlingFacilityId.Value));
                terminalDepotIds = terminalDepotIds.Where(x => x != 0).Distinct().ToList();
                if (terminalDepotIds != null && terminalDepotIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetTerminalDepots(terminalDepotIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the vessels.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns Vessel Data.</returns>
        public IList<Vessel> GetVessels(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var vesselIds = new List<int>();
                vesselIds.AddRange(dataAccessData.Where(l => l.VesselId.HasValue).Select(x => x.VesselId.Value));
                vesselIds = vesselIds.Where(x => x != 0).Distinct().ToList();
                if (vesselIds != null && vesselIds.Any())
                {
                    var vessels = Task.Run(async () => await this.masterDataService.GetVessels(vesselIds)).Result;
                    var apivessels = new List<Vessel>();
                    foreach (var item in vessels)
                    {
                        var apivessel = new Vessel();
                        apivessel.VesselId = item.VesselId;
                        apivessel.LongDisplayName = item.VesselVersions.FirstOrDefault().LongDisplayName;
                        apivessel.Name = item.VesselVersions.FirstOrDefault().Name;
                        apivessel.OwnershipType = this.mapper.Map<OwnershipType>(item.VesselVersions.FirstOrDefault().OwnershipType);
                        apivessels.Add(apivessel);
                    }

                    return apivessels;
                }
            }

            return null;
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Gets the equipmen iso code identifier.
        /// </summary>
        /// <param name="isoCodes">The iso codes.</param>
        /// <param name="isoCodeId">The iso code identifier.</param>
        /// <returns>Return Eequipment Code.</returns>
        private EquipmentISOCode GetEquipmenISOCodeId(IList<EquipmentISOCode> isoCodes, int isoCodeId)
        {
            return isoCodes.FirstOrDefault(x => x.EquipmentSizeTypeCodeId == isoCodeId);
        }

        /// <summary>
        /// Gets the equipment activity details.
        /// </summary>
        /// <param name="sizeTypes">The Size Types.</param>
        /// <param name="ports">The Ports.</param>
        /// <param name="terminalDepots">The TerminalDepots.</param>
        /// <param name="vessels">The Vessels.</param>
        /// <param name="locations">The Locations.</param>
        /// <param name="item">The DataAccessObjects Item.</param>
        /// <param name="isoCodes">The Iso Codes.</param>
        /// <returns>Returns the equipment activity details.</returns>
        private EquipmentActivity GetEquipmentActivityDetails(IList<EquipmentSizeType> sizeTypes, IList<Port> ports, IList<TerminalDepot> terminalDepots, IList<Vessel> vessels, IList<Location> locations, DataAccessObjects.EquipmentActivity item, IList<EquipmentISOCode> isoCodes)
        {
            EquipmentActivity equipmentActivity = this.mapper.Map<EquipmentActivity>(item);
            equipmentActivity.Equipment = new Equipment { EquipmentSizeType = this.GetEquipmentSizeTypeById(sizeTypes, item.Equipment.EquipmentSizeTypeId), EquipmentId = item.EquipmentId, EquipmentNumber = item.Equipment.EquipmentNumber, EquipmentISO = this.GetEquipmenISOCodeId(isoCodes, item.Equipment.EquipmentISOId) };
            equipmentActivity.Location = this.mapper.Map<Port>(this.GetPortById(ports, item.LocationId));
            equipmentActivity.PortOfLoad = this.mapper.Map<Port>(this.GetPortById(ports, item.LoadingPortId));
            equipmentActivity.PortOfDischarge = this.mapper.Map<Port>(this.GetPortById(ports, item.DischargePortId));
            equipmentActivity.TransshipmentPort = this.mapper.Map<Port>(this.GetPortById(ports, item.TransshipmentPortId));
            equipmentActivity.TerminalEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.TerminalEquipmentHandlingFacilityId));
            equipmentActivity.DepotEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.DepotEquipmentHandlingFacilityId));
            equipmentActivity.ReturnTerminalEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.ReturnTerminalEquipmentHandlingFacilityId));
            equipmentActivity.ReturnDepotEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.ReturnDepotEquipmentHandlingFacilityId));
            equipmentActivity.DestinationLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.DestinationLocationId));
            equipmentActivity.DeliveryLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.DeliveryLocationId));
            equipmentActivity.ReceiptLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.ReceiptLocationId));
            equipmentActivity.ReturnLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.ReturnLocationId));
            equipmentActivity.Vessel = this.mapper.Map<Vessel>(this.GetVesselById(vessels, item.VesselId));
            if (item.VesselId > 0 && item.VoyageId > 0)
            {
                equipmentActivity.VesselVoyage = VesselVoyageData.GetVesselVoyage(item.VoyageId);
            }
            else if (item.VesselId > 0)
            {
                equipmentActivity.VesselVoyage = new VesselVoyage { Voyage = item.Voyage, Vessel = equipmentActivity.Vessel.LongDisplayName };
            }

            equipmentActivity.Voyage = item.Voyage;

            return equipmentActivity;
        }

        /// <summary>
        /// Gets the equipment size type by identifier.
        /// </summary>
        /// <param name="equipmentSizeTypes">The equipment size types.</param>
        /// <param name="equipmentSizeTypeId">The equipment size type identifier.</param>
        /// <returns>Returns SizeType Id.</returns>
        private EquipmentSizeType GetEquipmentSizeTypeById(IList<EquipmentSizeType> equipmentSizeTypes, int equipmentSizeTypeId)
        {
            return equipmentSizeTypes.FirstOrDefault(x => x.EquipmentSizeTypeId == equipmentSizeTypeId);
        }

        /// <summary>
        /// Gets the location by identifier.
        /// </summary>
        /// <param name="locations">The locations.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <returns>Returns location Id.</returns>
        private Location GetLocationById(IList<Location> locations, int? locationId)
        {
            if (locationId.HasValue && locationId.Value > 0)
            {
                var location = locations.FirstOrDefault(x => x.LocationId == locationId);
                return location;
            }

            return null;
        }

        /// <summary>
        /// Gets the port by identifier.
        /// </summary>
        /// <param name="ports">The ports.</param>
        /// <param name="portId">The port identifier.</param>
        /// <returns>Returns Port Id.</returns>
        private Port GetPortById(IList<Port> ports, int? portId)
        {
            if (portId > 0)
            {
                return ports.FirstOrDefault(x => x.PortId == portId);
            }

            return null;
        }

        /// <summary>
        /// Gets the terminal depot by identifier.
        /// </summary>
        /// <param name="terminalDepots">The terminal depots.</param>
        /// <param name="terminalDepotId">The terminal depot identifier.</param>
        /// <returns>Returns Terminal Depot Id.</returns>
        private TerminalDepot GetTerminalDepotById(IList<TerminalDepot> terminalDepots, int? terminalDepotId)
        {
            if (terminalDepotId > 0)
            {
                return terminalDepots.FirstOrDefault(x => x.EquipmentHandlingFacilityId == terminalDepotId);
            }

            return null;
        }

        /// <summary>
        /// Gets the vessel by identifier.
        /// </summary>
        /// <param name="vessels">The vessels.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <returns>Returns Vessel Id.</returns>
        private Vessel GetVesselById(IList<Vessel> vessels, int? vesselId)
        {
            if (vesselId > 0)
            {
                return vessels.FirstOrDefault(x => x.VesselId == vesselId);
            }

            return null;
        }

        #endregion Private Methods
    }
}