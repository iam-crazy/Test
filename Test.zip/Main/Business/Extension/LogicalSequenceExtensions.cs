﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequenceExtensions.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using Constants;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare LogicalSequenceExtensions.
    /// </summary>
    public static class LogicalSequenceExtensions
    {
        /// <summary>
        /// To the convert logical sequence.
        /// </summary>
        /// <param name="logicalSequence">The logical sequence.</param>
        /// <returns>Returns Logical Sequence.</returns>
        public static IList<DataAccessObjects.LogicalActivity> ToConvertLogicalSequence(IList<LogicalSequence> logicalSequence)
        {
            return ToLogicalCombination(logicalSequence);
        }

        /// <summary>
        /// To the logical sequence.
        /// </summary>
        /// <param name="logicalData">The logical data.</param>
        /// <returns>Returns Logical data.</returns>
        public static IList<DataAccessObjects.LogicalActivity> ToLogicalCombination(IList<LogicalSequence> logicalData)
        {
            if (logicalData == null)
            {
                return null;
            }

            IList<DataAccessObjects.LogicalActivity> logicalCombinationList = new List<DataAccessObjects.LogicalActivity>();
            foreach (LogicalSequence data in logicalData)
            {
                DataAccessObjects.LogicalActivity dataAccessData = new DataAccessObjects.LogicalActivity();
                dataAccessData.EquipmentCategoryId = data.EquipmentCategory.EquipmentCategoryId;
                dataAccessData.FromActivityReferentialId = data.FromActivityReferential.ActivityReferentialId;
                dataAccessData.ToActivityReferentialId = data.ToActivityReferential.ActivityReferentialId;
                dataAccessData.Remarks = data.Remarks;
                dataAccessData.Status = data.Status;
                dataAccessData.RowStatus = data.RowStatus;
                if (data.RowStatus == BusinessConstant.ActiveStatus)
                {
                    dataAccessData.CreatedBy = data.CreatedBy;
                    dataAccessData.CreatedOn = data.CreatedOn;
                }

                logicalCombinationList.Add(dataAccessData);
            }

            return logicalCombinationList;
        }         
    }
}