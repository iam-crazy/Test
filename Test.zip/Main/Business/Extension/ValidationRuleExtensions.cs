﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare Validation Rule Repository.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using Constants;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Validation Rule Extensions.
    /// </summary>
    public static class ValidationRuleExtensions
    {
        /// <summary>
        /// To the data access model.
        /// </summary>
        /// <param name="data">The validation rule data.</param>
        /// <returns>Returns The Data.</returns>
        public static DataAccessObjects.ValidationRule ToDataAccessModel(ValidationRule data)
        {
            if (data == null)
            {
                return null;
            }

            DataAccessObjects.ValidationRule dataAccessData = new DataAccessObjects.ValidationRule();
            {
                dataAccessData.ValidationRuleId = data.ValidationRuleId;
                dataAccessData.RuleNumber = data.RuleNumber;
                dataAccessData.ValidationRuleGroupId = data.ValidationRuleGroup.Id;
                dataAccessData.Description = data.Description;
                dataAccessData.ValidFrom = data.ValidFrom;
                dataAccessData.ValidTo = data.ValidTo;
                dataAccessData.ValidationRuleTypeId = data.ValidationRuleType.Id;
                dataAccessData.Status = data.Status;
                dataAccessData.ValidationRuleErrorResultId = data.ValidationRuleErrorResult.Id;
                dataAccessData.ErrorDescription = data.ErrorDescription;
                dataAccessData.Remarks = data.Remarks;
                if (data.ValidationRuleId > 0)
                {
                    dataAccessData.CreatedBy = data.CreatedBy;
                    dataAccessData.UpdatedBy = data.UpdatedBy;
                    dataAccessData.UpdatedOn = data.UpdatedOn;
                    dataAccessData.CreatedOn = data.CreatedOn;
                }
                else
                {
                    dataAccessData.CreatedBy = data.CreatedBy;
                    dataAccessData.CreatedOn = data.CreatedOn;
                }
            }

            return dataAccessData;
        }
    }
}