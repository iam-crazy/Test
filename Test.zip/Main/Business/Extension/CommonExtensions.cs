﻿//-----------------------------------------------------------------------
// <copyright file = "CommonExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare CommonExtensions.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using Msc.Framework.Common.Model;

    /// <summary>
    /// To have the common extensions for the business services.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class CommonExtensions
    {
        /// <summary>
        /// Adds the lock confirmation warning.
        /// </summary>
        /// <param name="outcome">The outcome.</param>
        /// <exception cref="System.ArgumentNullException">Null check for argument outcome.</exception>
        internal static void AddLockConfirmationWarning(this BusinessOutcome outcome)
        {
            if (outcome == null)
            {
                throw new ArgumentNullException(nameof(outcome));
            }

            outcome.Messages = new List<ValidationResult>();
            outcome.Messages.Add(new ValidationResult(false, ValidationMessageType.Warning, Resource.CommonMessages.InvalidLock));
        }

        /// <summary>
        /// Adds the lock confirmation warning.
        /// </summary>
        /// <param name="outcome">The outcome.</param>
        /// <exception cref="System.ArgumentNullException">Null check for argument outcome.</exception>
        internal static void AddLockConfirmationWarningOperation(this OperationOutcome outcome)
        {
            if (outcome == null)
            {
                throw new ArgumentNullException(nameof(outcome));
            }

            outcome.Messages = new List<OperationOutcomeMessage>();
            outcome.Messages.Add(new OperationOutcomeMessage() { Message = Resource.CommonMessages.InvalidLock, Severity = OperationOutcomeSeverity.Warning });
        }
    }
}