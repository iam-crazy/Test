﻿//-----------------------------------------------------------------------
// <copyright file = "ShipmentStatusExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ShipmentStatusExtensions.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Shipment Status Extensions.
    /// </summary>
    public static class ShipmentStatusExtensions
    {
        /// <summary>
        /// To the business model.
        /// </summary>
        /// <param name="data">The business data.</param>
        /// <returns>Returns The Data.</returns>
        public static IList<ShipmentStatus> ToBusinessModel(IList<DataAccessObjects.ShipmentStatus> data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            IList<ShipmentStatus> shipmentStatusList = new List<ShipmentStatus>();
            foreach (DataAccessObjects.ShipmentStatus shipmentStatus in data)
            {
                ShipmentStatus shipment = new ShipmentStatus();
                shipment.Id = shipmentStatus.Id;
                shipment.Code = shipmentStatus.Code;
                shipment.Description = shipmentStatus.Description;
                shipmentStatusList.Add(shipment);
            }

            return shipmentStatusList;
        }
    }
}