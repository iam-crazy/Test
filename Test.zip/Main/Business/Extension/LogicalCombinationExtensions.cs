﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombinationExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalCombinationExtensions.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using Constants;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare LogicalCombinationExtensions.
    /// </summary>
    public static class LogicalCombinationExtensions
    {
        #region Save

        /// <summary>
        /// To the convert logical combination.
        /// </summary>
        /// <param name="logicalCombination">The logical combination.</param>
        /// <returns>Returns The Data.</returns>
        public static IList<DataAccessObjects.LogicalActivity> ToConvertLogicalCombination(IList<LogicalCombination> logicalCombination)
        {
            return ToLogicalCombination(logicalCombination);
        }

        /// <summary>
        /// To the logical combination.
        /// </summary>
        /// <param name="logicalData">The logical Data.</param>
        /// <returns>Returns The Data.</returns>
        public static IList<DataAccessObjects.LogicalActivity> ToLogicalCombination(IList<LogicalCombination> logicalData)
        {
            if (logicalData == null)
            {
                return null;
            }

            List<DataAccessObjects.LogicalActivity> logicalCombinationList = new List<DataAccessObjects.LogicalActivity>();
            foreach (LogicalCombination data in logicalData)
            {
                DataAccessObjects.LogicalActivity dataAccessData = new DataAccessObjects.LogicalActivity();
                dataAccessData.LogicalActivityId = data.LogicalActivityId;
                dataAccessData.FromActivityReferentialId = data.FromActivityReferential.ActivityReferentialId;
                dataAccessData.Status = data.Status == "False" ? false : true;
                dataAccessData.ToActivityReferentialId = data.ToActivityReferential.ActivityReferentialId;
                dataAccessData.ActivityType = data.ActivityType;
                dataAccessData.Remarks = data.Remarks;
                dataAccessData.RowStatus = data.RowStatus;
                if (data.RowStatus != BusinessConstant.ActiveStatus)
                {
                    dataAccessData.CreatedBy = data.CreatedBy;
                    dataAccessData.CreatedOn = data.CreatedOn;
                    dataAccessData.UpdatedBy = data.UpdatedBy;
                    dataAccessData.UpdatedOn = data.UpdatedOn;
                }
                else
                {
                    dataAccessData.CreatedBy = data.CreatedBy;
                    dataAccessData.CreatedOn = data.CreatedOn;
                }

                logicalCombinationList.Add(dataAccessData);
            }

            return logicalCombinationList;
        }

        #endregion Save

        #region Detail View

        /////// <summary>
        /////// To the business model.
        /////// </summary>
        /////// <param name="logicalCombination">The logical combination.</param>
        /////// <returns>Returns The Data.</returns>
        ////public static LogicalCombination ToBusinessModel(DataAccessObjects.LogicalActivity logicalCombination)
        ////{
        ////    if (logicalCombination == null)
        ////    {
        ////        return null;
        ////    }

        ////    LogicalCombination logicalCombinationBusiness = new LogicalCombination();
        ////    logicalCombinationBusiness.LogicalCombinationId = logicalCombination.LogicalActivityId;
        ////    logicalCombinationBusiness.Event = new Activity { Id = logicalCombination.ToActivityReferential.ActivityReferentialId, Code = logicalCombination.ToActivityReferential.Code, Description = logicalCombination.ToActivityReferential.Description };
        ////    if (logicalCombination.IsActive == true)
        ////    {
        ////        logicalCombinationBusiness.Status = "Activity";
        ////    }
        ////    else
        ////    {
        ////        logicalCombinationBusiness.Status = "InActivity";
        ////    }

        ////    logicalCombinationBusiness.Move = new Activity { Id = logicalCombination.FromActivityReferential.ActivityReferentialId, Code = logicalCombination.FromActivityReferential.Code, Description = logicalCombination.FromActivityReferential.Description };
        ////    logicalCombinationBusiness.ActivityMode = GeneralCodeData.GetGeneralCode("Position", logicalCombination.ActivityType);

        ////    return logicalCombinationBusiness;
        ////}

        /// <summary>
        /// To the business model.
        /// </summary>
        /// <param name="logicalCombination">The logical combination.</param>
        /// <returns>Returns The Data.</returns>
        ////public static LogicalCombination ToSearchBusinessModel(DataAccessObjects.LogicalActivity logicalCombination)
        ////{
        ////    if (logicalCombination == null)
        ////    {
        ////        return null;
        ////    }

        ////    LogicalCombination logicalCombinationBusiness = new LogicalCombination();
        ////    logicalCombinationBusiness.LogicalCombinationId = logicalCombination.FromActivityReferential.ActivityReferentialId;
        ////    logicalCombinationBusiness.Move = new Activity { Code = logicalCombination.FromActivityReferential.Code, Description = logicalCombination.FromActivityReferential.Description, Id = logicalCombination.FromActivityReferential.ActivityReferentialId };
        ////    logicalCombinationBusiness.Event = new Activity { Code = logicalCombination.ToActivityReferential.Code, Description = logicalCombination.ToActivityReferential.Description, Id = logicalCombination.ToActivityReferential.ActivityReferentialId };
        ////    logicalCombinationBusiness.Remarks = logicalCombination.Remarks;
        ////    logicalCombinationBusiness.ActivityMode = new GeneralCode { Code = logicalCombination.ActivityType };

        ////    return logicalCombinationBusiness;
        ////}

        #endregion Detail View
    }
}