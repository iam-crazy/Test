﻿//-----------------------------------------------------------------------
// <copyright file = "ReferentialDataExtensions.cs" company = "MSC">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare ReferentialDataExtensions.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Constants;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Referential Data Extensions.
    /// </summary>
    public static class ReferentialDataExtensions
    {
        /// <summary>
        /// To the convert referential data.
        /// </summary>
        /// <param name="referentialDataVersion">The referential data version.</param>
        /// <returns>
        /// Returns The Data.
        /// </returns>
        public static DataAccessObjects.ActivityReferential ToConvertReferentialData(ReferentialData referentialDataVersion)
        {
            return ToReferentialData(referentialDataVersion);
        }

        /// <summary>
        /// To the referential data.
        /// </summary>
        /// <param name="data">The referential data.</param>
        /// <returns>
        /// Returns The Data.
        /// </returns>
        public static DataAccessObjects.ActivityReferential ToReferentialData(ReferentialData data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            DataAccessObjects.ActivityReferential dataAccessData = new DataAccessObjects.ActivityReferential();
            dataAccessData.Code = data.Code;
            dataAccessData.ActivityReferentialId = data.ActivityReferentialId;
            dataAccessData.ActivityActionId = data.ActivityAction.Id;
            dataAccessData.FullEmptyId = data.FullEmpty.Id;
            dataAccessData.ActivityTypeId = data.ActivityType.Id;
            if (data.BusinessCycle != null)
            {
                dataAccessData.BusinessCycleId = data.BusinessCycle.Id;
            }

            if (data.ActivityCategory != null)
            {
                dataAccessData.ActivityCategoryId = data.ActivityCategory.Id;
            }

            dataAccessData.ActivityLocationId = data.ActivityLocation.Id;

            dataAccessData.IsActive = data.IsActive;
            dataAccessData.Description = data.Description;
            dataAccessData.Glossary = data.Glossary;
            dataAccessData.ReasonForInactive = data.Reason;
            dataAccessData.IsDisplayToCustomer = data.IsDisplayToCustomer;
            dataAccessData.Remarks = data.Remarks;
            if (data.ActivityReferentialId > 0)
            {
                dataAccessData.CreatedBy = data.CreatedBy;
                dataAccessData.CreatedOn = data.CreatedOn;
                dataAccessData.UpdatedBy = data.UpdatedBy;
                dataAccessData.UpdatedOn = data.UpdatedOn;
            }
            else
            {
                dataAccessData.CreatedBy = data.CreatedBy;
                dataAccessData.CreatedOn = data.CreatedOn;
            }

            dataAccessData.ReferentialValidationRules = ToReferentialValidationRulesData(data.ReferentialValidationRules);
            dataAccessData.BasicRequirements = ToBasicRequirementsData(data.BasicRequirements, data.ActivityReferentialId);
            dataAccessData.EDIMappings = ToEDIMappingData(data.EDIMappings);
            return dataAccessData;
        }

        /// <summary>
        /// To the referential validation rules data.
        /// </summary>
        /// <param name="data">The referential data.</param>
        /// <returns>
        /// Returns The Data.
        /// </returns>
        public static IList<DataAccessObjects.ReferentialValidationRule> ToReferentialValidationRulesData(IList<ReferentialValidationRule> data)
        {
            if (data == null)
            {
                return null;
            }

            IList<DataAccessObjects.ReferentialValidationRule> rules = new List<DataAccessObjects.ReferentialValidationRule>();
            foreach (var item in data)
            {
                DataAccessObjects.ReferentialValidationRule rule = new DataAccessObjects.ReferentialValidationRule();
                if (item.ReferentialValidationRuleId > 0)
                {
                    rule.ReferentialValidationRuleId = item.ReferentialValidationRuleId;
                    rule.CreatedBy = item.CreatedBy;
                    rule.CreatedOn = item.CreatedOn;
                    rule.UpdatedBy = item.UpdatedBy;
                    rule.UpdatedOn = DateTime.Now;
                }
                else
                {
                    rule.CreatedBy = item.CreatedBy;
                    rule.CreatedOn = DateTime.Now;
                }

                rule.ActivityReferentialId = item.ReferentialDataId;
                rule.ValidationRuleId = item.ValidationRuleId;
                rule.EffectiveDate = item.EffectiveDate;
                rule.EffectiveTo = item.EffectiveTo;
                rules.Add(rule);
            }

            return rules;
        }

        /// <summary>
        /// To the edi mapping data.
        /// </summary>
        /// <param name="data">The edi data.</param>
        /// <returns>
        /// Returns the mapping list.
        /// </returns>
        public static IList<DataAccessObjects.EDIMapping> ToEDIMappingData(IList<EDIMapping> data)
        {
            if (data == null)
            {
                return null;
            }

            IList<DataAccessObjects.EDIMapping> maps = new List<DataAccessObjects.EDIMapping>();
            foreach (var item in data)
            {
                DataAccessObjects.EDIMapping map = new DataAccessObjects.EDIMapping();
                if (item.EDIMappingId > 0)
                {
                    map.EDIMappingId = item.EDIMappingId;
                    map.CreatedBy = item.CreatedBy;
                    map.CreatedOn = item.CreatedOn;
                    map.UpdatedBy = item.UpdatedBy;
                    map.UpdatedOn = DateTime.Now;
                }
                else
                {
                    map.CreatedBy = item.CreatedBy;
                    map.CreatedOn = DateTime.Now;
                }

                map.ActivityReferentialId = item.ActivityReferentialId;
                if (item.ShipmentStatus == null && item.EquipmentStatus == null)
                {
                    map.ShipmentStatusId = null;
                    map.EquipmentStatusId = null;
                }
                else
                {
                    map.ShipmentStatusId = item.ShipmentStatus.Id;
                    map.EquipmentStatusId = item.EquipmentStatus.Id;
                }

                maps.Add(map);
            }

            return maps;
        }

        /// <summary>
        /// To the basic requirements data.
        /// </summary>
        /// <param name="data">The activity data.</param>
        /// <param name="activityId">The activity identifier.</param>
        /// <returns>
        /// Returns Basic Requirement Data.
        /// </returns>
        public static IList<DataAccessObjects.BasicRequirement> ToBasicRequirementsData(IList<BasicRequirement> data, short activityId)
        {
            if (data == null)
            {
                return null;
            }

            IList<DataAccessObjects.BasicRequirement> basicRequirements = new List<DataAccessObjects.BasicRequirement>();
            foreach (var item in data)
            {
                DataAccessObjects.BasicRequirement basicRequirement = new DataAccessObjects.BasicRequirement();
                basicRequirement.RowStatus = item.BasicStatus;
                basicRequirement.RequirementFieldId = item.RequirementField.Id;
                basicRequirement.ActivityReferentialId = activityId;
                basicRequirement.BasicRequirementId = item.BasicRequirementId;
                if (item.RequirementFieldTwo != null && item.RequirementFieldTwo.Id > 0)
                {
                    basicRequirement.RequirementFieldIdTwo = item.RequirementFieldTwo.Id;
                }

                if (item.RequirementFieldThree != null && item.RequirementFieldThree.Id > 0)
                {
                    basicRequirement.RequirementFieldIdThree = item.RequirementFieldThree.Id;
                }

                basicRequirement.RequirementUsageId = item.RequirementUsage.Id;

                if (item.BasicRequirementId > 0)
                {
                    basicRequirement.CreatedBy = item.CreatedBy;
                    basicRequirement.CreatedOn = item.CreatedOn;
                    basicRequirement.UpdatedBy = item.UpdatedBy;
                    basicRequirement.UpdatedOn = DateTime.Now;
                }
                else
                {
                    basicRequirement.CreatedBy = item.CreatedBy;
                    basicRequirement.CreatedOn = DateTime.Now;
                }

                basicRequirements.Add(basicRequirement);
            }

            return basicRequirements;
        }

        /// <summary>
        /// To the business model requirement.
        /// </summary>
        /// <param name="data">The requirement data.</param>
        /// <returns>
        /// Returns The Data.
        /// </returns>
        public static IList<RequirementField> ToBusinessModelRequirement(IList<DataAccessObjects.RequirementField> data)
        {
            if (data == null)
            {
                return null;
            }

            IList<RequirementField> requirementFieldlist = new List<RequirementField>();
            foreach (DataAccessObjects.RequirementField requirementField in data)
            {
                RequirementField referentialFieldBusiness = new RequirementField();
                referentialFieldBusiness.Id = requirementField.Id;
                referentialFieldBusiness.Description = requirementField.Description;

                requirementFieldlist.Add(referentialFieldBusiness);
            }

            return requirementFieldlist;
        }

        /// <summary>
        /// To the business model usage.
        /// </summary>
        /// <param name="data">The model data.</param>
        /// <returns>
        /// Returns The requirement usage.
        /// </returns>
        public static IList<RequirementUsage> ToBusinessModelUsage(IList<DataAccessObjects.RequirementUsage> data)
        {
            if (data == null)
            {
                return null;
            }

            IList<RequirementUsage> requirementUsagelist = new List<RequirementUsage>();
            foreach (DataAccessObjects.RequirementUsage requirementUsage in data)
            {
                RequirementUsage referentialFieldBusiness = new RequirementUsage();
                referentialFieldBusiness.Id = requirementUsage.Id;
                referentialFieldBusiness.Description = requirementUsage.Description;

                requirementUsagelist.Add(referentialFieldBusiness);
            }

            return requirementUsagelist;
        }

        /// <summary>
        /// Converts to edi mapping business model.
        /// </summary>
        /// <param name="items">The items.</param>
        /// <returns>Returns the mapping data.</returns>
        public static IList<EDIMapping> ConvertToEDIMappingBusinessModel(IList<DataAccessObjects.EDIMapping> items)
        {
            if (items != null && items.Any())
            {
                IList<EDIMapping> ediMappings = new List<EDIMapping>();
                foreach (var item in items)
                {
                    EDIMapping ediMapping = new EDIMapping();
                    ediMapping.EDIMappingId = item.EDIMappingId;
                    ediMapping.ActivityReferentialId = item.ActivityReferentialId;
                    ediMapping.EquipmentStatus = new EquipmentStatus { Id = item.EquipmentState.Id, Code = item.EquipmentState.Code, Description = item.EquipmentState.Description };
                    ediMapping.ShipmentStatus = new ShipmentStatus { Id = item.ShipmentStatus.Id, Code = item.ShipmentStatus.Code, Description = item.ShipmentStatus.Description };
                    ediMapping.CreatedBy = item.CreatedBy;
                    ediMapping.CreatedOn = item.CreatedOn;
                    ediMapping.UpdatedBy = item.UpdatedBy;
                    ediMapping.UpdatedOn = item.UpdatedOn;
                    ediMappings.Add(ediMapping);
                }

                return ediMappings;
            }

            return null;
        }

        /////// <summary>
        /////// To the description.
        /////// </summary>
        /////// <param name="value">The description value.</param>
        /////// <returns>
        /////// Return The Value.
        /////// </returns>
        ////private static string ToDescription(string value)
        ////{
        ////    value = Regex.Replace(value, @"\r\n", BusinessConstant.EmptyString);
        ////    return value.Length > 50 ? value.Substring(0, 50) + ".." : value;
        ////}

        /// <summary>
        /// Updates the business cycle.
        /// </summary>
        /// <param name="businessCycle">The business cycle identifier.</param>
        /// <param name="activityReferential">The activity referential identifier.</param>
        /// <returns>Returns Updated data.</returns>
        public static DataAccessObjects.ActivityReferential UpdateBusinessCycle(DataAccessObjects.BusinessCycle businessCycle, ReferentialDataStatus activityReferential)
        {
            DataAccessObjects.ActivityReferential obj = new DataAccessObjects.ActivityReferential();
            if (activityReferential != null && activityReferential.ActivityReferentialId > 0)
            {
                obj.ActivityReferentialId = (short)activityReferential.ActivityReferentialId;
                obj.CreatedBy = activityReferential.CreatedBy;
                obj.CreatedOn = activityReferential.CreatedOn;
                obj.UpdatedBy = activityReferential.UpdatedBy;
                obj.UpdatedOn = activityReferential.UpdatedOn;
            }

            obj.BusinessCycleId = (businessCycle != null && businessCycle.Id > 0) ? (byte?)businessCycle.Id : null;

            return obj;
        }
    }
}