﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStatusExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentStatusExtensions.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Equipment Status Extensions.
    /// </summary>
    public static class EquipmentStatusExtensions
    {
        /// <summary>
        /// To the business model.
        /// </summary>
        /// <param name="data">The business data.</param>
        /// <returns>Returns The Data.</returns>
        public static IList<EquipmentStatus> ToBusinessModel(IList<DataAccessObjects.EquipmentStatus> data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            IList<EquipmentStatus> equipmentStatusList = new List<EquipmentStatus>();
            foreach (DataAccessObjects.EquipmentStatus shipmentStatus in data)
            {
                EquipmentStatus equipment = new EquipmentStatus();
                equipment.Id = shipmentStatus.Id;
                equipment.Code = shipmentStatus.Code;
                equipment.Description = shipmentStatus.Description;
                equipmentStatusList.Add(equipment);
            }

            return equipmentStatusList;
        }
    }
}