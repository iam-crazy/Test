﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityExtensions.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using System.Collections.Generic;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityExtensions.
    /// </summary>
    public static class EquipmentActivityExtensions
    {
        #region Public Methods

        /////// <summary>
        /////// To the business model equipment fleet.
        /////// </summary>
        /////// <param name="equipmentActivity">The equipment activity.</param>
        /////// <returns>Returns the equipment fleet.</returns>
        ////public static EquipmentFleet ToBusinessModelEquipmentFleet(DataAccessObjects.EquipmentActivity equipmentActivity)
        ////{
        ////    if (equipmentActivity == null)
        ////    {
        ////        return null;
        ////    }

        ////    EquipmentFleet equipmentActivityBusiness = new EquipmentFleet();
        ////    equipmentActivityBusiness.Id = equipmentActivity.EquipmentActivityId;
        ////    equipmentActivityBusiness.EquipmentISO.ISOCodeId = equipmentActivity.EquipmentISOId;
        ////    equipmentActivityBusiness.EquipmentNumber = equipmentActivity.EquipmentNumber;
        ////    equipmentActivityBusiness.EquipmentSizeType.EquipmentSizeTypeId = equipmentActivity.EquipmentSizeTypeId;
        ////    return equipmentActivityBusiness;
        ////}

        ////public static EquipmentActivity ToBusinessEquipmentActivity(DataAccessObjects.EquipmentActivity equipmentActivity)
        ////{
        ////    if (equipmentActivity == null)
        ////    {
        ////        return null;
        ////    }

        ////    EquipmentActivity equipmentActivityBusiness = new EquipmentActivity();
        ////    equipmentActivityBusiness.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
        ////    equipmentActivityBusiness.EquipmentNumber = equipmentActivity.EquipmentNumber;
        ////    equipmentActivityBusiness.ActivityDateTime = equipmentActivity.ActivityDateTime;
        ////    equipmentActivityBusiness.HasSOC = equipmentActivity.HasSOC;

        ////    equipmentActivityBusiness.ActivityUTCDateTime = equipmentActivity.ActivityUTCDateTime;
        ////    equipmentActivityBusiness.EquipmentISO = new EquipmentISOCode() { ISOCodeId = equipmentActivity.EquipmentISOId };
        ////    if (equipmentActivity.LoadingPortId.HasValue)
        ////    {
        ////        equipmentActivityBusiness.PortOfLoad = new Port() { PortId = equipmentActivity.LoadingPortId.Value };
        ////    }

        ////    if (equipmentActivity.DischargePortId.HasValue)
        ////    {
        ////        equipmentActivityBusiness.PortOfDischarge = new Port() { PortId = equipmentActivity.DischargePortId.Value };
        ////    }

        ////    if (equipmentActivity.TransshipmentPortId.HasValue)
        ////    {
        ////        equipmentActivityBusiness.TransshipmentPort = new Port() { PortId = equipmentActivity.TransshipmentPortId.Value };
        ////    }

        ////    if (equipmentActivity.EquipmentSizeTypeId > 0)
        ////    {
        ////        equipmentActivityBusiness.EquipmentSizeType = new EquipmentSizeType() { EquipmentSizeTypeId = equipmentActivity.EquipmentSizeTypeId };
        ////    }

        ////    equipmentActivityBusiness.EquipmentActivityErrors = ToBusinessEquipmentActivityError(equipmentActivity.EquipmentActivityErrors);

        ////    //equipmentActivityBusiness.EquipmentSizeType.EquipmentSizeTypeId = equipmentActivityEquipmentSizeTypeId;
        ////    return equipmentActivityBusiness;
        ////}

        ///// <summary>
        ///// To the business equipment activity error.
        ///// </summary>
        ///// <param name="equipmentActivityErrors">The equipment activity errors.</param>
        ///// <returns></returns>
        ///// <exception cref="System.ArgumentNullException">Argument Null Exception</exception>
        ////public static IList<EquipmentActivityError> ToBusinessEquipmentActivityError(ICollection<DataAccessObjects.EquipmentActivityError> equipmentActivityErrors)
        ////{
        ////    if (equipmentActivityErrors == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(equipmentActivityErrors));
        ////    }

        ////    IList<EquipmentActivityError> errors = new List<EquipmentActivityError>();
        ////    foreach (var item in equipmentActivityErrors)
        ////    {
        ////        EquipmentActivityError error = new EquipmentActivityError();
        ////        error.EquipmentActivityId = item.EquipmentActivityId;
        ////        error.ValidationRule.ValidationRuleId = item.ValidationRuleId;
        ////        error.ValidationRule.ErrorDescription = item.ValidationRule.ErrorDescription;
        ////        error.ValidationRule.ErrorDescrip = new GeneralCode { Description = item.ValidationRule.ValidationRuleErrorResult.Description };
        ////        errors.Add(error);
        ////    }

        ////    return errors;
        ////}

        /// <summary>
        /// To the cancel equipment activity.
        /// </summary>
        /// <param name="data">The cancel equipment data.</param>
        /// <returns>Returns The Data.</returns>
        public static IList<DataAccessObjects.CancelEquipmentActivity> ToCancelEquipmentActivity(IList<CancelEquipmentActivity> data)
        {
            if (data == null)
            {
                return null;
            }

            IList<DataAccessObjects.CancelEquipmentActivity> activitydata = new List<DataAccessObjects.CancelEquipmentActivity>();
            foreach (var cancelEquipmentActivity in data)
            {
                DataAccessObjects.CancelEquipmentActivity cancelEquipmentData = new DataAccessObjects.CancelEquipmentActivity();
                cancelEquipmentData.EquipmentActivityId = cancelEquipmentActivity.EquipmentActivityId;
                cancelEquipmentData.EquipmentActivityCancelReasonId = cancelEquipmentActivity.Reason.Id;
                cancelEquipmentData.Remarks = cancelEquipmentActivity.Remarks;
                cancelEquipmentData.CreatedBy = cancelEquipmentActivity.CreatedBy;
                cancelEquipmentData.CreatedOn = cancelEquipmentActivity.CreatedOn;
                cancelEquipmentData.UpdatedBy = cancelEquipmentActivity.UpdatedBy;
                cancelEquipmentData.UpdatedOn = cancelEquipmentActivity.UpdatedOn;
                activitydata.Add(cancelEquipmentData);
            }

            return activitydata;
        }

        /// <summary>
        /// To the referential data.
        /// </summary>
        /// <param name="data">The referential data.</param>
        /// <returns>Returns The Data.</returns>
        public static DataAccessObjects.EquipmentActivity ToEquipmentActivity(EquipmentActivity data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            DataAccessObjects.EquipmentActivity equipmentData = new DataAccessObjects.EquipmentActivity();
            equipmentData.ActivityDateTime = data.ActivityDateTime;
            equipmentData.EquipmentActivityId = data.EquipmentActivityId;
            equipmentData.EquipmentId = data.Equipment.EquipmentId;
            equipmentData.EquipmentActivityState = data.EquipmentActivityState;
            equipmentData.ActivityReferentialId = data.Activity.ActivityReferentialId;
            if (data.Location != null)
            {
                equipmentData.LocationId = data.Location.PortId;
            }

            if (data.TerminalEquipmentHandlingFacility != null)
            {
                equipmentData.TerminalEquipmentHandlingFacilityId = data.TerminalEquipmentHandlingFacility.EquipmentHandlingFacilityId;
            }

            if (data.DepotEquipmentHandlingFacility != null)
            {
                equipmentData.DepotEquipmentHandlingFacilityId = data.DepotEquipmentHandlingFacility.EquipmentHandlingFacilityId;
            }

            equipmentData.ActivityUTCDateTime = data.ActivityUTCDateTime.UtcDateTime;
            if (data.PortOfLoad != null)
            {
                equipmentData.LoadingPortId = data.PortOfLoad.PortId;
            }

            if (data.PortOfDischarge != null)
            {
                equipmentData.DischargePortId = data.PortOfDischarge.PortId;
            }

            if (data.DeliveryLocation != null)
            {
                equipmentData.DeliveryLocationId = data.DeliveryLocation.LocationId;
            }

            if (data.DestinationLocation != null)
            {
                equipmentData.DestinationLocationId = data.DestinationLocation.LocationId;
            }

            if (data.ReceiptLocation != null)
            {
                equipmentData.ReceiptLocationId = data.ReceiptLocation.LocationId;
            }

            if (data.TransshipmentPort != null)
            {
                equipmentData.TransshipmentPortId = data.TransshipmentPort.PortId;
            }

            if (data.ReturnLocation != null)
            {
                equipmentData.ReturnLocationId = data.ReturnLocation.LocationId;
            }

            if (data.ReturnTerminalEquipmentHandlingFacility != null)
            {
                equipmentData.ReturnTerminalEquipmentHandlingFacilityId = data.ReturnTerminalEquipmentHandlingFacility.EquipmentHandlingFacilityId;
            }

            if (data.ReturnDepotEquipmentHandlingFacility != null)
            {
                equipmentData.ReturnDepotEquipmentHandlingFacilityId = data.ReturnDepotEquipmentHandlingFacility.EquipmentHandlingFacilityId;
            }

            if (data.Vessel != null)
            {
                equipmentData.VesselId = data.Vessel.VesselId;
            }

            if (data.VesselVoyage != null)
            {
                equipmentData.VoyageId = data.VesselVoyage.Id;
            }

            equipmentData.Voyage = data.Voyage;
            equipmentData.VoyageETA = data.VoyageETA;
            equipmentData.VoyageETD = data.VoyageETD;
            equipmentData.SealNumber = data.SealNumber;
            equipmentData.BLNumber = data.BLNumber;
            equipmentData.BookingNumber = data.BookingNumber;
            equipmentData.LeasingCompanyReference = data.LeasingCompanyReference;
            equipmentData.MSCAuthorizationReference = data.MSCAuthorizationReference;
            equipmentData.PickupReference = data.PickupReference;
            equipmentData.ShippingInstructionNumber = data.ShippingInstructionNumber;
            equipmentData.ReturnEquipmentAuthorizationNumber = data.ReturnEquipmentAuthorizationNumber;
            equipmentData.SCACCodeId = data.SCACCodeId;
            if (data.EquipmentActivityId > 0)
            {
                equipmentData.CreatedBy = data.CreatedBy;
                equipmentData.CreatedOn = data.CreatedOn;
                equipmentData.UpdatedBy = data.UpdatedBy;
                equipmentData.UpdatedOn = data.UpdatedOn;
            }
            else
            {
                equipmentData.CreatedBy = data.CreatedBy;
                equipmentData.CreatedOn = data.CreatedOn;
            }

            equipmentData.EquipmentActivityErrors = ToEquipmentActivityError(data.EquipmentActivityErrors);
            return equipmentData;
        }

        /// <summary>
        /// To the equipment activity error.
        /// </summary>
        /// <param name="equipmentActivityErrors">The equipment activity errors.</param>
        /// <returns>Return the equipmentActivityErrors.</returns>
        public static IList<DataAccessObjects.EquipmentActivityError> ToEquipmentActivityError(IList<EquipmentActivityError> equipmentActivityErrors)
        {
            if (equipmentActivityErrors == null)
            {
                throw new ArgumentNullException(nameof(equipmentActivityErrors));
            }

            IList<DataAccessObjects.EquipmentActivityError> errors = new List<DataAccessObjects.EquipmentActivityError>();
            foreach (var item in equipmentActivityErrors)
            {
                DataAccessObjects.EquipmentActivityError error = new DataAccessObjects.EquipmentActivityError();
                error.EquipmentActivityId = item.EquipmentActivityId;
                error.ValidationRuleId = item.ValidationRule.ValidationRuleId;
                error.ErrorDescription = item.ErrorDescription;
                error.CreatedBy = item.CreatedBy;
                error.CreatedOn = item.CreatedOn;
                errors.Add(error);
            }

            return errors;
        }

        #endregion
    }
}
