﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeExtensions.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare GeneralCodeExtensions. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare GeneralCodeExtensions.
    /// </summary>
    public static class GeneralCodeExtensions
    {
        #region Method

        /////// <summary>
        /////// To the business general code model.
        /////// </summary>
        /////// <param name="item">The general code item.</param>
        /////// <returns>Returns the general code data.</returns>
        ////public static GeneralCode ToBusinessGeneralCodeModel(DataAccessObjects.ActivityAction item)
        ////{
        ////    if (item == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(item));
        ////    }

        ////    GeneralCode genealCode = new GeneralCode();
        ////    genealCode.Id = item.Id;
        ////    genealCode.Code = item.Code;
        ////    genealCode.Description = item.Description;
        ////    return genealCode;
        ////}

        /////// <summary>
        /////// To the business general code model.
        /////// </summary>
        /////// <param name="item">The general code item.</param>
        /////// <returns>Returns the general code data.</returns>
        ////public static GeneralCode ToBusinessGeneralCodeModel(DataAccessObjects.ActivityType item)
        ////{
        ////    if (item == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(item));
        ////    }

        ////    GeneralCode genealCode = new GeneralCode();
        ////    genealCode.Id = item.Id;
        ////    genealCode.Code = item.Code;
        ////    genealCode.Description = item.Description;
        ////    return genealCode;
        ////}

        /////// <summary>
        /////// To the business general code model.
        /////// </summary>
        /////// <param name="item">The general code item.</param>
        /////// <returns>Returns the general code data.</returns>
        ////public static GeneralCode ToBusinessGeneralCodeModel(DataAccessObjects.TakePlaceAt item)
        ////{
        ////    if (item == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(item));
        ////    }

        ////    GeneralCode genealCode = new GeneralCode();
        ////    genealCode.Id = item.Id;
        ////    genealCode.Code = item.Code;
        ////    genealCode.Description = item.Description;
        ////    return genealCode;
        ////}

        /////// <summary>
        /////// To the business general code model.
        /////// </summary>
        /////// <param name="item">The general code item.</param>
        /////// <returns>Returns the general code data.</returns>
        ////public static GeneralCode ToBusinessGeneralCodeModel(DataAccessObjects.ActivityCategory item)
        ////{
        ////    if (item == null)
        ////    {
        ////        throw new ArgumentNullException(nameof(item));
        ////    }

        ////    GeneralCode genealCode = new GeneralCode();
        ////    genealCode.Id = item.Id;
        ////    genealCode.Code = item.Code;
        ////    genealCode.Description = item.Description;
        ////    return genealCode;
        ////}

        #endregion Method
    }
}