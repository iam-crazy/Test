﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityNoteExtension.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentActivityNoteExtension.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business.Extension
{
    using System;
    using Contracts.Objects;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityNoteExtension.
    /// </summary>
    public static class EquipmentActivityNoteExtension
    {
        #region Public Methods

        /// <summary>
        /// To the equipment.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns the equipment value.</returns>
        public static DataAccessObjects.Equipment ToEquipment(Equipment equipmentNote)
        {
            if (equipmentNote == null)
            {
                return null;
            }

            DataAccessObjects.Equipment dataAccessData = new DataAccessObjects.Equipment();
            dataAccessData.EquipmentId = equipmentNote.EquipmentId;
            dataAccessData.EquipmentNumber = equipmentNote.EquipmentNumber;
            dataAccessData.EquipmentISOId = Convert.ToInt16(equipmentNote.EquipmentISO.EquipmentSizeTypeCodeId);
            dataAccessData.EquipmentSizeTypeId = Convert.ToInt16(equipmentNote.EquipmentISO.EquipmentSizeTypeId);
            dataAccessData.HasSOC = equipmentNote.HasSOC;
            dataAccessData.IsCanceled = equipmentNote.IsCanceled;
            dataAccessData.ParentEquipmentId = equipmentNote.ParentEquipmentId;
            dataAccessData.ValidFrom = equipmentNote.ValidFrom;
            dataAccessData.ValidTo = equipmentNote.ValidTo;
            dataAccessData.UpdatedBy = equipmentNote.UpdatedBy;
            dataAccessData.UpdatedOn = equipmentNote.UpdatedOn;
            dataAccessData.CreatedOn = equipmentNote.CreatedOn;
            dataAccessData.CreatedBy = equipmentNote.CreatedBy;
            return dataAccessData;
        }

        /// <summary>
        /// To the equipment activity note.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns the equipment note.</returns>
        public static DataAccessObjects.EquipmentActivityNote ToEquipmentActivityNote(EquipmentActivityNote equipmentNote)
        {
            if (equipmentNote == null)
            {
                return null;
            }

            DataAccessObjects.EquipmentActivityNote dataAccessData = new DataAccessObjects.EquipmentActivityNote();
            dataAccessData.Id = equipmentNote.Id;
            dataAccessData.EquipmentActivityId = equipmentNote.EquipmentActivityId;
            dataAccessData.Notes = equipmentNote.Notes;
            dataAccessData.UserId = equipmentNote.UserBase.UserId;
            dataAccessData.CreatedOn = equipmentNote.CreatedOn;
            return dataAccessData;
        }

        /// <summary>
        /// To the equipment note.
        /// </summary>
        /// <param name="equipmentNote">The equipment note.</param>
        /// <returns>Returns the equipment note.</returns>
        public static DataAccessObjects.EquipmentNote ToEquipmentNote(EquipmentNote equipmentNote)
        {
            if (equipmentNote == null)
            {
                return null;
            }

            DataAccessObjects.EquipmentNote dataAccessData = new DataAccessObjects.EquipmentNote();
            dataAccessData.EquipmentId = equipmentNote.EquipmentId;
            dataAccessData.Id = equipmentNote.Id;
            dataAccessData.Notes = equipmentNote.Notes;
            dataAccessData.UserId = equipmentNote.UserBase.UserId;
            dataAccessData.CreatedOn = equipmentNote.CreatedOn;
            return dataAccessData;
        }

        #endregion Public Methods
    }
}