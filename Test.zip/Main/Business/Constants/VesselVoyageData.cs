﻿//-----------------------------------------------------------------------
// <copyright file = "VesselVoyageData.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare VesselVoyageData.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Constants
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using System.Linq;
    using System.Web;
    using System.Web.Hosting;
    using System.Xml;
    using Contracts.Objects;

    /// <summary>
    /// Declare VesselVoyageData.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class VesselVoyageData
    {
        /// <summary>
        /// The  VesselVoyageData path.
        /// </summary>       
        private static string path = HostingEnvironment.MapPath("~/") + "\\Docs\\VesselVoyage.xml";
        ////private static string path = HostingEnvironment.MapPath("~/") + "\\Equipment_Moves_and_Events\\Service\\Main\\Business\\Docs\\VesselVoyage.xml";

        /// <summary>
        /// Gets or sets the LST vessel voyage.
        /// </summary>
        /// <value>
        /// The LST vessel voyage.
        /// </value>
        public static IList<VesselVoyage> ListVesselVoyage { get; set; }

        /// <summary>
        /// Loads the data.
        /// </summary>
        /// <returns>Returns the list.</returns>
        public static IList<VesselVoyage> LoadData()
        {
            if (ListVesselVoyage == null)
            {
                ListVesselVoyage = ReadXML();
            }

            return ListVesselVoyage.ToList();
        }

        /// <summary>
        /// Gets the vessel voyage.
        /// </summary>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <returns>Returns the list.</returns>
        public static VesselVoyage GetVesselVoyage(int? voyageId)
        {
            VesselVoyage voyage = new VesselVoyage();
            if (ListVesselVoyage == null)
            {
                ListVesselVoyage = ReadXML();
                voyage = ListVesselVoyage.Where(x => x.Id == voyageId).FirstOrDefault();
            }
            else
            {
                voyage = ListVesselVoyage.Where(x => x.Id == voyageId).FirstOrDefault();
            }

            return voyage;
        }

        /// <summary>
        /// Reads the XML.
        /// </summary>
        /// <returns>Returns xml list.</returns>
        private static List<VesselVoyage> ReadXML()
        {
            List<VesselVoyage> lstVesselVoyage = new List<VesselVoyage>();
            XmlDocument doc = new XmlDocument();
            doc.Load(path);

            foreach (XmlNode node in doc.DocumentElement.ChildNodes)
            {
                VesselVoyage obj = new VesselVoyage();

                obj.Id = Convert.ToInt32(node.Attributes["Id"].Value.ToString(), CultureInfo.InvariantCulture);
                obj.Vessel = node.Attributes["Vessel"].Value.ToString();
                obj.Voyage = node.Attributes["Voyage"].Value.ToString();
                ////  obj.Port = node.Attributes["Port"].Value.ToString();
                if (!string.IsNullOrEmpty(node.Attributes["Arrival"].Value.ToString()))
                {
                    obj.Arrival = DateTime.ParseExact(node.Attributes["Arrival"].Value.ToString().Substring(3, node.Attributes["Arrival"].Value.ToString().Length - 3).ToString(), "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                }

                if (!string.IsNullOrEmpty(node.Attributes["Departure"].Value.ToString()))
                {
                    obj.Departure = DateTime.ParseExact(node.Attributes["Departure"].Value.ToString().Substring(3, node.Attributes["Departure"].Value.ToString().Length - 3).ToString(), "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                }

                obj.Service = node.Attributes["Service"].Value.ToString();
                lstVesselVoyage.Add(obj);
            }

            return lstVesselVoyage;
        }
    }
}