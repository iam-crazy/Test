﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeData.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare GeneralCodeData. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Constants
{
    using System.Collections.Generic;
    using System.Linq;
    using Contracts.Objects;

    /// <summary>
    /// Declare GeneralCodeData.
    /// </summary>
    public static class GeneralCodeData
    {
        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="referenceName">Name of the reference.</param>
        /// <returns>Returns The List Of GeneralCode Data.</returns>
        public static IList<GeneralCode> GetGeneralCodes(string referenceName)
        {
            IList<GeneralCode> codes = new List<GeneralCode>();
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Type", Value = "MOV", Description = "Move" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Type", Value = "EVE", Description = "Event" });

            codes.Add(new GeneralCode { Id = 3, ReferenceName = "FullEmpty", Value = "FEM", Description = "Full/Empty" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "FullEmpty", Value = "FUL", Description = "Full" });
            codes.Add(new GeneralCode { Id = 2, ReferenceName = "FullEmpty", Value = "EMP", Description = "Empty" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "STA", Description = "Status" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "GIN", Description = "Gate In" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "GOT", Description = "Gate Out" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "DIS", Description = "Discharge" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "LOD", Description = "Load" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "POS", Description = "Position" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "STF", Description = "Stuffing" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Action", Value = "STR", Description = "Stripping" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Location", Value = "TOD", Description = "Terminal/Depot" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Location", Value = "TDT", Description = "Terminal/Depot/At Client" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Location", Value = "ADM", Description = "Administrative" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Location", Value = "TER", Description = "Terminal" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Location", Value = "DPT", Description = "Depot" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Location", Value = "ATC", Description = "At Client" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "BAR", Description = "Barge" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "BAT", Description = "Barge Tranship" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FLA", Description = "Fleet Activity" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FTA", Description = "Fleet Activation" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FTD", Description = "Fleet Deactivation" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FLF", Description = "Fleet Flag" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FTI", Description = "Fleet Inactivation" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FLR", Description = "Fleet Reactivation" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FLS", Description = "Fleet Status" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "FSE", Description = "Fleet Status End" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "INT", Description = "Intermodal" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "RAL", Description = "Rail" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "RLT", Description = "Rail Tranship" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "REP", Description = "Re-positioning" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "RES", Description = "Restow" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "TRA", Description = "Transhipment" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "TRK", Description = "Truck" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "VSL", Description = "Vessel" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Category", Value = "VST", Description = "Vessel Tranship" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "EIS", Description = "Export in stack" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "EXP", Description = "Export positioned" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "FAS", Description = "Full at sea" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "EMS", Description = "Empty in stock" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "EWS", Description = "Export with shipper" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "IMP", Description = "Import positioned" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "IWS", Description = "Import with Consignee" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "FTS", Description = "Full Transshipment in stack" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "FTP", Description = "Full transshipment positioned" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "IIS", Description = "Import in stack" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "EMP", Description = "Empty positioned" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "EAS", Description = "Empty at sea" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "ESH", Description = "Empty with shipper" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "ETS", Description = "Empty transshipment in stock" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "LogisticsStatus", Value = "ETP", Description = "Empty transshipment positioned" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Status", Value = "A", Description = "Active" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Status", Value = "IA", Description = "Inactive" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ReasonforInactive", Value = "CCU", Description = "Code is Conflict with the user undestanding" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ReasonforInactive", Value = "CC", Description = "Code Conflict" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Group", Value = "I", Description = "Group 1 - Open Rule" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Group", Value = "II", Description = "Group 2 -Vessel Rule" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Group", Value = "III", Description = "Group 3 -New Container Rule" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Group", Value = "IV", Description = "Group 4 -Time Rule" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Group", Value = "V", Description = "Group 5 -Location Rule" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Group", Value = "VI", Description = "Group 6 -Reference Rule" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "RuleType", Value = "COM", Description = "Common" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "RuleType", Value = "SPE", Description = "Specific" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "State", Value = "A", Description = "ACTIVE" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "State", Value = "X", Description = "CANCELLED" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "DisplayCustomer", Value = "Y", Description = "Yes" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "DisplayCustomer", Value = "N", Description = "No" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ErrorResult", Value = "IV", Description = "Invalid" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ErrorResult", Value = "VBI", Description = "Valid But Incomplete" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "CombinationMode", Value = "A", Description = "After" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "CombinationMode", Value = "B", Description = "Before" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "CombinationMode", Value = "BOTH", Description = "BeforeAfter" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "Reason", Value = "IAE", Description = "Incorrect activity for the selected equipment" });
            codes.Add(new GeneralCode { Id = 2, ReferenceName = "Reason", Value = "IDE", Description = "Incorrect data for the selected equipment" });
            codes.Add(new GeneralCode { Id = 3, ReferenceName = "Reason", Value = "RAA", Description = "Replaced by actual activity sent by the agency (auto cancellation)" });
            codes.Add(new GeneralCode { Id = 4, ReferenceName = "Reason", Value = "OTH", Description = "Others" });

            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ShipmentCode", Value = "AF", Description = "Departed Pickup Location" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ShipmentCode", Value = "AL", Description = "Loaded On Rail" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ShipmentCode", Value = "AM", Description = "Loaded On truck" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ShipmentCode", Value = "AO", Description = "Loaded On Barge" });
            codes.Add(new GeneralCode { Id = 1, ReferenceName = "ShipmentCode", Value = "B", Description = "Bad Order" });
            return codes.Where(a => a.ReferenceName == referenceName).ToList();
        }

        /////// <summary>
        /////// Gets the general code.
        /////// </summary>
        /////// <param name="referenceName">Name of the reference.</param>
        /////// <param name="value">The value.</param>
        /////// <returns>Returns The Data.</returns>
        ////public static GeneralCode GetGeneralCode(string referenceName, string value)
        ////{
        ////    return new GeneralCode { Value = value, Description = GetGeneralCodeDescription(referenceName, value), ReferenceName = referenceName };
        ////}

        /////// <summary>
        /////// Gets the general code description.
        /////// </summary>
        /////// <param name="referenceName">Name of the reference.</param>
        /////// <param name="value">The value.</param>
        /////// <returns>Returns The Data.</returns>
        ////public static string GetGeneralCodeDescription(string referenceName, string value)
        ////{
        ////    return GeneralCodeData.GetGeneralCodes(referenceName).FirstOrDefault(a => a.Value == value)?.Description;
        ////}

        /////// <summary>
        /////// Gets the general code.
        /////// </summary>
        /////// <param name="referenceName">Name of the reference.</param>
        /////// <param name="id">The identifier.</param>
        /////// <returns>Returns the general code.</returns>
        ////public static GeneralCode GetGeneralCode(string referenceName, int id)
        ////{
        ////    return GetGeneralCodes(referenceName).FirstOrDefault(a => a.Id == id);
        ////}
    }
}