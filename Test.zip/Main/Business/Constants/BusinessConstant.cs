﻿//-----------------------------------------------------------------------
// <copyright file = "BusinessConstant.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare BusinessConstant.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business.Constants
{
    /// <summary>
    /// Declare BusinessConstant.
    /// </summary>
    public static class BusinessConstant
    {
        /// <summary>
        /// The user name.
        /// </summary>
        public const string UserName = "Jorge";

        /// <summary>
        /// The date format.
        /// </summary>
        public const string DateFormat = "dd-MMM-yyyy";

        /// <summary>
        /// The vessel date format.
        /// </summary>
        public const string VesselDateFormat = "yyyy-MM-dd";

        /// <summary>
        /// The number one.
        /// </summary>
        public const int CreatedBy = 1;

        /// <summary>
        /// The number Zero.
        /// </summary>
        public const int DefaultId = 0;

        /// <summary>
        /// The number one.
        /// </summary>
        public const int IncrementId = 1;

        /// <summary>
        /// The string A.
        /// </summary>
        public const string ActiveStatus = "A";

        /// <summary>
        /// The string X.
        /// </summary>
        public const string InactiveStatus = "X";

        /// <summary>
        /// The string C.
        /// </summary>
        public const string CanceledCharCheck = "C";

        /// <summary>
        /// The active.
        /// </summary>
        public const string Active = "Active";

        /// <summary>
        /// The full empty.
        /// </summary>
        public const string FullEmpty = "FullEmpty";

        /// <summary>
        /// The in active.
        /// </summary>
        public const string Inactive = "InActive";

        /// <summary>
        /// The reason for in active.
        /// </summary>
        public const string ReasonForInactive = "ReasonforInactive";

        /// <summary>
        /// The application JSON.
        /// </summary>
        public const string ApplicationJson = "application/json";

        /// <summary>
        /// The user identifier.
        /// </summary>
        public const string UserId = "UserId";

        /// <summary>
        /// The activity type after.
        /// </summary>
        public const string ActivityTypeAfter = "A";

        /// <summary>
        /// The activity type before.
        /// </summary>
        public const string ActivityTypeBefore = "B";

        /// <summary>
        /// The activity type before after.
        /// </summary>
        public const string ActivityTypeBeforeAfter = "O";

        /// <summary>
        /// The string cancelled.
        /// </summary>
        public const string Canceled = "Cancelled";

        /// <summary>
        /// The equipment state new.
        /// </summary>
        public const string EquipmentStateNew = "NEW";

        /// <summary>
        /// The equipment state update.
        /// </summary>
        public const string EquipmentStateUpdate = "UPDATED";

        /// <summary>
        /// The equipment state cancel.
        /// </summary>
        public const string EquipmentStateCancel = "CANCELLED";

        /// <summary>
        /// The empty string.
        /// </summary>
        public const string EmptyString = " ";

        /// <summary>
        /// The string status.
        /// </summary>
        public const string Status = "Status : ";

        /// <summary>
        /// The string valid.
        /// </summary>
        public const string Valid = "Valid";

        /// <summary>
        /// The string move.
        /// </summary>
        public const string Move = "MOV";

        /// <summary>
        /// The string event.
        /// </summary>
        public const string Event = "EVE";

        /// <summary>
        /// The rule zero.
        /// </summary>
        public const string RuleZero = "EME000";

        /// <summary>
        /// The rule001.
        /// </summary>
        public const string RuleOne = "EME001";

        /// <summary>
        /// The rule 002.
        /// </summary>
        public const string RuleTwo = "EME002";

        /// <summary>
        /// The rule 003.
        /// </summary>
        public const string RuleThree = "EME003";

        /// <summary>
        /// The rule 004.
        /// </summary>
        public const string RuleFour = "EME004";

        /// <summary>
        /// The hyphen.
        /// </summary>
        public const string Hyphen = " - ";

        /// <summary>
        /// The slash value.
        /// </summary>
        public const string Operator = "  /  ";

        /// <summary>
        /// The slash value.
        /// </summary>
        public const string Value = "0";

        /// <summary>
        /// The illogical sequence.
        /// </summary>
        public const string IllogicalSequence = "Move(s) created, but it has an Illogical Sequence.";

        /// <summary>
        /// The illogical combination.
        /// </summary>
        public const string IllogicalCombination = "Event(s) created, but it has an Illogical Combination.";

        /// <summary>
        /// The business cycle end.
        /// </summary>
        public const string BusinessCycleEnd = "EN";

        /// <summary>
        /// The business cycle start.
        /// </summary>
        public const string BusinessCycleStart = "ST";
    }
}