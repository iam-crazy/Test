﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalSequenceService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalSequenceService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare LogicalSequenceService.
    /// </summary>
    [LockInfoAttribute("EME.LogicalSequence")]
    public class LogicalSequenceService : LockService, ILogicalSequenceService
    {
        #region Members

        /// <summary>
        /// The data base context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The logical sequence repository.
        /// </summary>
        private readonly ILogicalSequenceRepository logicalSequenceRepository;

        /// <summary>
        /// The mapper value.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The master data service.
        /// </summary>
        private readonly IMasterDataService masterDataService;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalSequenceService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="logicalSequenceRepository">The logical sequence repository.</param>
        /// <param name="masterDataService">The master data service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        /// <exception cref="System.ArgumentNullException">
        /// Argument exception.
        /// </exception>
        public LogicalSequenceService(IDbContextScopeFactory databaseContextScopeFactory, ILogicalSequenceRepository logicalSequenceRepository, IMasterDataService masterDataService, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (logicalSequenceRepository == null)
            {
                throw new ArgumentNullException(nameof(logicalSequenceRepository));
            }

            if (masterDataService == null)
            {
                throw new ArgumentNullException(nameof(masterDataService));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.logicalSequenceRepository = logicalSequenceRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.masterDataService = masterDataService;
            this.mapper = mapper;
            this.changeLog = changeLog;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the logical sequence list.
        /// </summary>
        /// <param name="currentMoveId">The current move identifier.</param>
        /// <returns>
        /// Returns Current Move Identifier.
        /// </returns>
        public async Task<IList<LogicalSequence>> GetLogicalSequenceList(int currentMoveId)
        {
            IList<DataAccessObjects.LogicalActivity> businessLogic;
            IList<LogicalSequence> logicalSequence = new List<LogicalSequence>();
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                businessLogic = await this.logicalSequenceRepository.GetLogicalSequenceList(currentMoveId);
            }

            IList<EquipmentCategory> category = this.GetEquipmentCategory();
            foreach (var item in businessLogic)
            {
                LogicalSequence logicalSequenceInfo = this.GetLogicalSequence(category, item);
                logicalSequence.Add(logicalSequenceInfo);
            }

            ////List<LogicalSequence> logicalSequence = LogicalSequenceExtensions.ToSearchLogicalSequence(businessLogic.ToList());
            return logicalSequence;
        }

        /// <summary>
        /// Saves the specified logical sequence.
        /// </summary>
        /// <param name="logicalSequence">The logical sequence.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        public async Task<BusinessOutcome> Save(IList<LogicalSequence> logicalSequence)
        {
            BusinessOutcome result = new BusinessOutcome();
            var sequenceLogic = LogicalSequenceExtensions.ToConvertLogicalSequence(logicalSequence);
            using (this.dataBaseContextScopeFactory.Create())
            {
                result.IdentityValue = Convert.ToString(await this.logicalSequenceRepository.Save(sequenceLogic));
            }

            return result;
        }

        /// <summary>
        /// Updates the specified sequence.
        /// </summary>
        /// <param name="sequence">The sequence.</param>
        /// <returns>
        /// Returns the Saved data.
        /// </returns>
        public async Task<BusinessOutcome> Update(LogicalSequenceUpdate sequence)
        {
            BusinessOutcome result = new BusinessOutcome();
            bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), sequence.LogicalActivityId, sequence.UpdatedBy.Value, string.Empty);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var item = this.mapper.Map<DataAccessObjects.LogicalActivity>(sequence);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, sequence.UserName))
                {
                    try
                    {
                        this.logicalSequenceRepository.Update(sequence.LogicalActivityId, sequence.Status, sequence.Remarks);
                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(item);
                        result.IdentityValue = sequence.LogicalActivityId.ToString();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the logical activity identifier.
        /// </summary>
        /// <param name="logicalActivityId">The logical activity identifier.</param>
        /// <returns>
        /// Return the LogicalSequence List.
        /// </returns>
        public async Task<LogicalSequence> GetLogicalActivityId(int logicalActivityId)
        {
            DataAccessObjects.LogicalActivity logicalSequence;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                logicalSequence = await this.logicalSequenceRepository.GetLogicalActivityId(logicalActivityId);
            }

            LogicalSequence activity = this.mapper.Map<LogicalSequence>(logicalSequence);
            IList<EquipmentCategory> equipmentCategories = await this.masterDataService.GetEquipmentCategories();
            if (equipmentCategories != null)
            {
                activity.EquipmentCategory = equipmentCategories.FirstOrDefault(s => s.EquipmentCategoryId == logicalSequence.EquipmentCategoryId);
            }

            return activity;
        }

        /// <summary>
        /// Gets the equipment category.
        /// </summary>
        /// <returns>Returns The Save Data.</returns>
        public IList<EquipmentCategory> GetEquipmentCategory()
        {
            return Task.Run(() => this.masterDataService.GetEquipmentCategories()).Result;
        }

        #endregion Public Methods

        /// <summary>
        /// Gets the logical sequence.
        /// </summary>
        /// <param name="category">The category.</param>
        /// <param name="item">The item value.</param>
        /// <returns>Returns The Save Data.</returns>
        private LogicalSequence GetLogicalSequence(IList<EquipmentCategory> category, DataAccessObjects.LogicalActivity item)
        {
            LogicalSequence logicalSequence = this.mapper.Map<LogicalSequence>(item);
            logicalSequence.EquipmentCategory = category.FirstOrDefault(x => x.EquipmentCategoryId == item.EquipmentCategoryId);
            return logicalSequence;
        }
    }
}