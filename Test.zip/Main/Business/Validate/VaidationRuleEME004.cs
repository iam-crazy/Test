﻿//-----------------------------------------------------------------------
// <copyright file = "VaidationRuleEME004.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare VaidationRuleEME004. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityValidation.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.IEquipmentActivityService" />
    public partial class EquipmentActivityService
    {
        /// <summary>
        /// Terminals the active check.
        /// </summary>
        /// <param name="item">The item value.</param>
        /// <returns>Return TerminalActive.</returns>
        ////public Contracts.Objects.EquipmentActivityError TerminalActiveCheck(Contracts.Objects.EquipmentActivity item)
        ////{
        ////    if (item != null && item.TerminalEquipmentHandlingFacility != null && item.TerminalEquipmentHandlingFacility.TerminalDepotId.HasValue && item.TerminalEquipmentHandlingFacility.TerminalDepotId > 0 && item.Location != null && item.Location.PortId > 0)
        ////    {
        ////        var terminals = Task.Run(() => this.masterDataService.GetTerminalDepotList(item.Location.PortId)).Result;
        ////        if (terminals.Any(x => x.EquipmentHandlingFacilityId == item.TerminalEquipmentHandlingFacility.TerminalDepotId))
        ////        {
        ////            ValidationRule validationRule;
        ////            using (this.dataBaseContextScopeFactory.CreateReadOnly())
        ////            {
        ////                validationRule = Task.Run(async () => await this.validationRuleRepository.GetValidationRule(BusinessConstant.RuleFour)).Result;
        ////            }

        ////            Contracts.Objects.EquipmentActivityError validationResult = new Contracts.Objects.EquipmentActivityError();
        ////            validationResult.EquipmentActivityId = item.EquipmentActivityId;
        ////            validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
        ////            return validationResult;
        ////        }
        ////    }

        ////    return null;
        ////}
    }
}