﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleEME005.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Declare Class1.
    /// </summary>
    public partial class EquipmentActivityService
    {
        /////// <summary>
        /////// Activities the duplicate validation.
        /////// </summary>
        /////// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /////// <param name="equipmentNumber">The equipment number.</param>
        /////// <param name="activityReferentialId">The activity referential identifier.</param>
        /////// <param name="activityDateTime">The activity date time.</param>
        /////// <param name="locationId">The location identifier.</param>
        /////// <param name="vesselId">The vessel identifier.</param>
        /////// <param name="voyageId">The voyage identifier.</param>
        /////// <param name="voyage">The voyage.</param>
        /////// <returns>Returns the duplicate list.</returns>
        ////public async Task<IList<string>> ActivityDuplicateValidation(string equipmentActivityId, string equipmentNumber, int activityReferentialId, DateTime activityDateTime, int locationId, int vesselId, int voyageId, string voyage)
        ////{
        ////    var validationResult = await this.equipmentActivityRepository.CheckEquipment(equipmentActivityId, equipmentNumber, activityReferentialId, activityDateTime, locationId, vesselId, voyageId, voyage);
        ////    return validationResult.DuplicateEquipment;
        ////}
    }
}