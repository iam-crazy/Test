﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleEME003.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityService. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare Class1.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class EquipmentActivityService
    {
        #region Public Methods

        /// <summary>
        /// Logical the combination validation.
        /// </summary>
        /// <param name="equipmentActivity">The equipment activity.</param>
        /// <returns>Return EquipmentActivityError.</returns>
        public Contracts.Objects.EquipmentActivityError LogicalCombinationValidation(Contracts.Objects.EquipmentActivity equipmentActivity)
        {
            if (equipmentActivity != null && equipmentActivity.Activity.ActivityType.Code == BusinessConstant.Event)
            {
                ValidationRule validationRule;
                EquipmentActivity previousActivity;
                EquipmentActivity nextActivity;
                IList<LogicalActivity> combinationmoves;
                Contracts.Objects.EquipmentActivityError validationResult = null;
                using (this.dataBaseContextScopeFactory.CreateReadOnly())
                {
                    previousActivity = Task.Run(async () => await this.equipmentActivityRepository.GetPreviousActivity(equipmentActivity.Equipment.EquipmentNumber, equipmentActivity.ActivityDateTime)).Result;
                    nextActivity = Task.Run(async () => await this.equipmentActivityRepository.GetNextActivity(equipmentActivity.Equipment.EquipmentNumber, equipmentActivity.ActivityDateTime)).Result;
                    combinationmoves = Task.Run(async () => await this.logicalCombinationRepository.GetPreviousMoves(equipmentActivity.Activity.ActivityReferentialId)).Result;
                    validationRule = Task.Run(async () => await this.validationRuleRepository.GetValidationRule(BusinessConstant.RuleThree)).Result;
                }

                ////not defined moves againts event
                if (!combinationmoves.Any())
                {
                    validationResult = new Contracts.Objects.EquipmentActivityError();
                    validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                    validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                    validationResult.ErrorDescription = equipmentActivity.Activity.Code;
                }
                else
                {
                    var beforeMoves = combinationmoves.Where(x => x.ActivityType == BusinessConstant.ActivityTypeBefore || x.ActivityType == BusinessConstant.ActivityTypeBeforeAfter);
                    var afterMoves = combinationmoves.Where(x => x.ActivityType == BusinessConstant.ActivityTypeAfter || x.ActivityType == BusinessConstant.ActivityTypeBeforeAfter);

                    ////Previous Move only defined in EquipmentActivity
                    if (nextActivity == null && previousActivity != null && !beforeMoves.Any(x => x.FromActivityReferentialId == previousActivity.ActivityReferentialId))
                    {
                        validationResult = new Contracts.Objects.EquipmentActivityError();
                        validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                        validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                        validationResult.ErrorDescription = equipmentActivity.Activity.Code + " - " + previousActivity.Activity.Code;
                    }
                    else
                    {
                        ////Next Move only defined in EquipmentActivity
                        validationResult = EquipmentActivityNextMove(equipmentActivity, validationRule, previousActivity, nextActivity, validationResult, beforeMoves, afterMoves);
                    }
                }

                return validationResult;
            }

            return null;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Equipment the activity next move.
        /// </summary>
        /// <param name="equipmentActivity">The equipment activity.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="previousActivity">The previous activity.</param>
        /// <param name="nextActivity">The next activity.</param>
        /// <param name="validationResult">The validation result.</param>
        /// <param name="beforeMoves">The before moves.</param>
        /// <param name="afterMoves">The after moves.</param>
        /// <returns>Returns the Equipment list.</returns>
        private static Contracts.Objects.EquipmentActivityError EquipmentActivityNextMove(Contracts.Objects.EquipmentActivity equipmentActivity, ValidationRule validationRule, EquipmentActivity previousActivity, EquipmentActivity nextActivity, Contracts.Objects.EquipmentActivityError validationResult, IEnumerable<LogicalActivity> beforeMoves, IEnumerable<LogicalActivity> afterMoves)
        {
            if (previousActivity == null && nextActivity != null && !afterMoves.Any(x => x.FromActivityReferentialId == nextActivity.ActivityReferentialId))
            {
                validationResult = new Contracts.Objects.EquipmentActivityError();
                validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                validationResult.ErrorDescription = equipmentActivity.Activity.Code + " - " + nextActivity.Activity.Code;
            }
            else if (previousActivity != null && nextActivity != null)
            {
                ////Both defined in EquipmentActivity
                bool hasBefore = !beforeMoves.Any(x => x.FromActivityReferentialId == previousActivity.ActivityReferentialId);
                bool hasAfter = !afterMoves.Any(x => x.FromActivityReferentialId == nextActivity.ActivityReferentialId);
                validationResult = PositionMove(equipmentActivity, validationRule, previousActivity, nextActivity, validationResult, hasBefore, hasAfter);
            }

            return validationResult;
        }

        /// <summary>
        /// Positions the move.
        /// </summary>
        /// <param name="equipmentActivity">The equipment activity.</param>
        /// <param name="validationRule">The validation rule.</param>
        /// <param name="previousActivity">The previous activity.</param>
        /// <param name="nextActivity">The next activity.</param>
        /// <param name="validationResult">The validation result.</param>
        /// <param name="hasBefore">If set to <c>true</c> [is before].</param>
        /// <param name="hasAfter">If set to <c>true</c> [is after].</param>
        /// <returns>Returns the Equipment list.</returns>
        private static Contracts.Objects.EquipmentActivityError PositionMove(Contracts.Objects.EquipmentActivity equipmentActivity, ValidationRule validationRule, EquipmentActivity previousActivity, EquipmentActivity nextActivity, Contracts.Objects.EquipmentActivityError validationResult, bool hasBefore, bool hasAfter)
        {
            if (hasBefore && !hasAfter)
            {
                validationResult = new Contracts.Objects.EquipmentActivityError();
                validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                validationResult.ErrorDescription = equipmentActivity.Activity.Code + " - " + previousActivity.Activity.Code;
            }
            else if (!hasBefore && hasAfter)
            {
                validationResult = new Contracts.Objects.EquipmentActivityError();
                validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                validationResult.ErrorDescription = equipmentActivity.Activity.Code + " - " + nextActivity.Activity.Code;
            }
            else if (hasBefore && hasAfter)
            {
                validationResult = new Contracts.Objects.EquipmentActivityError();
                validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                validationResult.ErrorDescription = "(" + previousActivity.Activity.Code + " - " + equipmentActivity.Activity.Code + ") Or (" + equipmentActivity.Activity.Code + " - " + nextActivity.Activity.Code + ")";
            }

            return validationResult;
        }

        #endregion
    }
}
