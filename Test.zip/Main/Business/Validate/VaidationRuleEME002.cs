﻿//-----------------------------------------------------------------------
// <copyright file = "VaidationRuleEME002.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityService. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityValidation.
    /// </summary>
    public partial class EquipmentActivityService
    {
        #region Public Methods

        /// <summary>
        /// Logical the sequence validation.
        /// </summary>
        /// <param name="equipmentActivity">The equipment activity.</param>
        /// <returns>Return EquipmentActivityError.</returns>
        public Contracts.Objects.EquipmentActivityError LogicalSequenceValidation(Contracts.Objects.EquipmentActivity equipmentActivity)
        {
            Contracts.Objects.EquipmentActivityError validationResult = null;
            if (equipmentActivity != null && equipmentActivity.Activity.ActivityType.Code == BusinessConstant.Move)
            {
                EquipmentActivity previousActivity;
                IList<LogicalActivity> previousMove;
                ValidationRule validationRule;
                using (this.dataBaseContextScopeFactory.CreateReadOnly())
                {
                    previousActivity = Task.Run(async () => await this.equipmentActivityRepository.GetPreviousActivity(equipmentActivity.Equipment.EquipmentNumber, equipmentActivity.ActivityDateTime)).Result;
                    previousMove = Task.Run(async () => await this.logicalSequenceRepository.GetPreviousMoves(equipmentActivity.Activity.ActivityReferentialId)).Result;
                    validationRule = Task.Run(async () => await this.validationRuleRepository.GetValidationRule(BusinessConstant.RuleTwo)).Result;
                }

                if (validationRule == null)
                {
                    validationResult = null;
                }

                if (previousActivity == null)
                {
                    validationResult = new Contracts.Objects.EquipmentActivityError();
                    validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                    validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                    validationResult.ErrorDescription = equipmentActivity.Activity.Code;
                }
                else if (previousActivity != null && !previousMove.Any(index => index.FromActivityReferential.ActivityReferentialId == previousActivity.Activity.ActivityReferentialId))
                {
                    validationResult = new Contracts.Objects.EquipmentActivityError();
                    validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
                    validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
                    validationResult.ErrorDescription = previousActivity.Activity.Code + "- " + equipmentActivity.Activity.Code;
                }
            }

            return validationResult;
        }

        #endregion
    }
}
