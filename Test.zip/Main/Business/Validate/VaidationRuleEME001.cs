﻿//-----------------------------------------------------------------------
// <copyright file = "VaidationRuleEME001.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare VaidationRuleEME001. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using Constants;
    using DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityValidation.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.Contracts.IEquipmentActivityService" />
    public partial class EquipmentActivityService
    {
        /////// <summary>
        /////// Vessels the activities.
        /////// </summary>
        /////// <param name="equipmentActivity">The equipment activity.</param>
        /////// <returns>Return EquipmentActivityError.</returns>
        ////public Contracts.Objects.EquipmentActivityError VesselActivities(Business.Contracts.Objects.EquipmentActivity equipmentActivity)
        ////{
        ////    if (equipmentActivity != null && equipmentActivity.Vessel != null && equipmentActivity.Vessel.VesselId.HasValue && equipmentActivity.Vessel.VesselId > 0)
        ////    {
        ////        var vessel = Task.Run(() => this.masterDataService.GetVessel(equipmentActivity.Vessel.VesselId, equipmentActivity.ActivityDateTime)).Result;
        ////        if (vessel == null)
        ////        {
        ////            ValidationRule validationRule;
        ////            using (this.dataBaseContextScopeFactory.CreateReadOnly())
        ////            {
        ////                validationRule = Task.Run(async () => await this.validationRuleRepository.GetValidationRule(BusinessConstant.RuleOne)).Result;
        ////            }

        ////            Contracts.Objects.EquipmentActivityError validationResult = new Contracts.Objects.EquipmentActivityError();
        ////            validationResult.EquipmentActivityId = equipmentActivity.EquipmentActivityId;
        ////            validationResult.ValidationRule.ValidationRuleId = validationRule.ValidationRuleId;
        ////            return validationResult;
        ////        }
        ////    }

        ////    return null;
        ////}
    }
}