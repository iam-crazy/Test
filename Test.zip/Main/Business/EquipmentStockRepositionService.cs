﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentStockRepositionService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentStockRepositionService. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System.Net.Http;
    using System.Threading.Tasks;
    using Contracts;
    using Contracts.Objects;

    /// <summary>
    /// Declare EquipmentStockRepositionService.
    /// </summary>
    public class EquipmentStockRepositionService : IEquipmentStockRepositionService
    {
        #region Fields

        /// <summary>
        /// The master data rest client.
        /// </summary>
        private readonly HttpClient esrRestClient;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentStockRepositionService"/> class.
        /// </summary>
        /// <param name="httpClient">The HTTP client.</param>
        public EquipmentStockRepositionService(ESRDataHttpClient httpClient)
        {
            this.esrRestClient = httpClient;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the logistics status.
        /// </summary>
        /// <param name="activityId">The activity identifier.</param>
        /// <returns>Returns the logistic status list.</returns>
        public Task<LogisticsStatus> GetLogisticsStatus(int activityId)
        {
            var api = new Framework.UI.Rest.RestClient(this.esrRestClient);
            string url = "V1/logisticMovesMapping/GetLogisticStatusByActivityId/" + activityId;
            var logisticsStatus = Task.Run(async () => await api.GetAsync<LogisticsStatus>(url));
            return logisticsStatus;
        }

        #endregion
    }
}
