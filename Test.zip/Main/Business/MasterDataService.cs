﻿//-----------------------------------------------------------------------
// <copyright file = "MasterDataService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare MasterDataService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using System.Linq;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using Framework.Common.Model.Pagination;

    /// <summary>
    /// Declare MasterCodeDataService.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class MasterDataService : IMasterDataService
    {
        #region Fields

        /// <summary>
        /// The master data rest client.
        /// </summary>
        private readonly HttpClient masterDataRestClient;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MasterDataService"/> class.
        /// </summary>
        /// <param name="httpClient">The HTTP client.</param>
        public MasterDataService(MasterDataHttpClient httpClient)
        {
            this.masterDataRestClient = httpClient;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the equipment category.
        /// </summary>
        /// <returns>Return List of equipment category.</returns>
        public async Task<IList<EquipmentCategory>> GetEquipmentCategories()
        {
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/equipmentCategories?onlyValidEquipmentCategories=" + false;
            var category = await api.GetAsync<IList<EquipmentCategory>>(url);
            return category;
        }

        /// <summary>
        /// Gets the equipment iso code.
        /// </summary>
        /// <param name="equipmentISOCode">The equipment iso code.</param>
        /// <returns>
        /// Return EquipmentISO.
        /// </returns>
        public async Task<EquipmentISOCode> GetEquipmentISOCode(int? equipmentISOCode)
        {
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/equipmentSizeTypeCodes?equipmentSizeTypeCodeId=" + equipmentISOCode;
            var isoEquipmentCodes = await api.GetAsync<IList<EquipmentISOCode>>(url);
            return isoEquipmentCodes.FirstOrDefault();
        }

        /// <summary>
        /// Gets the equipment iso codes.
        /// </summary>
        /// <param name="equipmentISOCodes">The equipment iso codes.</param>
        /// <returns>
        /// Return EquipmentISO.
        /// </returns>
        public async Task<IList<EquipmentISOCode>> GetEquipmentISOCodes(IList<short> equipmentISOCodes)
        {
            var isoCode = string.Join(",", equipmentISOCodes);
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/equipmentSizeTypeCodes?equipmentSizeTypeCodeId=" + isoCode;
            var isoEquipmentCodes = await api.GetAsync<IList<EquipmentISOCode>>(url);
            return isoEquipmentCodes;
        }

        /// <summary>
        /// Searches the equipment size types.
        /// </summary>
        /// <param name="sizeTypeId">Type of the size.</param>
        /// <returns>
        /// Returns The Equipment Size Type.
        /// </returns>
        public async Task<EquipmentSizeType> GetEquipmentSizeType(int? sizeTypeId)
        {
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/equipmentSizeTypes/" + sizeTypeId;
            var sizeType = await api.GetAsync<EquipmentSizeType>(url);
            return sizeType;
        }

        /// <summary>
        /// Gets the equipment size types.
        /// </summary>
        /// <param name="sizeTypeIds">The size type ids.</param>
        /// <returns>Returns Size Type.</returns>
        public async Task<IList<EquipmentSizeType>> GetEquipmentSizeTypes(IList<short> sizeTypeIds)
        {
            var sizeTypeId = string.Join(",", sizeTypeIds);
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/equipmentSizeTypes?equipmentSizeTypeId=" + sizeTypeId;
            var sizeTypes = await api.GetAsync<IList<EquipmentSizeType>>(url);
            return sizeTypes;
        }

        /// <summary>
        /// Gets the locations.
        /// </summary>
        /// <param name="locationIds">The location Ids.</param>
        /// <returns>Returns the Locations.</returns>
        public async Task<IList<Location>> GetLocations(IList<int> locationIds)
        {
            var portId = string.Join(",", locationIds);
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/locations?locationId=" + portId;
            var locations = await api.GetAsync<PageResponse<Location>>(url);
            return locations.Items;
        }

        /// <summary>
        /// Gets the ports.
        /// </summary>
        /// <param name="portIds">The port ids.</param>
        /// <returns>Returns Port Id.</returns>
        public async Task<IList<Port>> GetPorts(IList<int> portIds)
        {
            var portId = string.Join(",", portIds);
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/ports?portId=" + portId;
            ////string url = "V1/ports?portId=" + portId + "&asOfDate=" + DateTime.Today.ToString(BusinessConstant.DateFormat);
            var ports = await api.GetAsync<PageResponse<Port>>(url);
            return ports.Items;
        }

        /// <summary>
        /// Gets the terminal depots.
        /// </summary>
        /// <param name="terminalDepotIds">The terminal depot ids.</param>
        /// <returns>
        /// Return List of Terminal Depot.
        /// </returns>
        public async Task<IList<TerminalDepot>> GetTerminalDepots(IList<int> terminalDepotIds)
        {
            var terminalDepotId = string.Join(",", terminalDepotIds);
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            ////string url = "V1/equipmentHandlingFacilities?equipmentHandlingFacilityId=" + terminalDepotId + "&asOfDate=" + DateTime.Today.ToString(BusinessConstant.DateFormat);
            string url = "V1/EquipmentHandlingFacilities?equipmentHandlingFacilityId=" + terminalDepotId + "&pagesize=100";
            var terminalDepots = await api.GetAsync<PageResponse<TerminalDepot>>(url);
            return terminalDepots.Items;
        }

        /////// <summary>
        /////// Gets the terminal depot list.
        /////// </summary>
        /////// <param name="terminalDepotId">The terminal depot identifier.</param>
        /////// <returns>
        /////// Return List of Terminal Depot.
        /////// </returns>
        ////public async Task<IList<TerminalDepot>> GetTerminalDepotList(int? terminalDepotId)
        ////{
        ////    var api = new RestClient(this.masterDataRestClient);
        ////    string url = "V1/EquipmentHandlingFacilityMaritimes?PortId=" + terminalDepotId + "&additionalFields=Port";
        ////    ////string url = "V1/equipmentHandlingFacilities?PortId=" + locationId + "&additionalFields=Port" + "&asOfDate=" + DateTime.Today.ToString(BusinessConstant.DateFormat);
        ////    var terminalDepots = await api.GetAsync<PageResponse<TerminalDepot>>(url);
        ////    return terminalDepots.Items;
        ////}

        /////// <summary>
        /////// Gets the vessel.
        /////// </summary>
        /////// <param name="vesselId">The vessel identifier.</param>
        /////// <param name="activityDate">The activity Date.</param>
        /////// <returns>
        /////// Return Vessel.
        /////// </returns>
        ////public async Task<Vessel> GetVessel(int? vesselId, DateTime activityDate)
        ////{
        ////    var api = new RestClient(this.masterDataRestClient);
        ////    ////string url = "V1/vessels/" + vesselId + "?asOfDate=" + activityDate;
        ////    string url = "V1/vessels/" + vesselId;
        ////    var vessels = await api.GetAsync<Vessel>(url);
        ////    return vessels;
        ////}

        /// <summary>
        /// Gets the vessels.
        /// </summary>
        /// <param name="vesselIds">The vessel ids.</param>
        /// <returns>Returns Vessel.</returns>
        public async Task<IList<Vessel>> GetVessels(IList<int> vesselIds)
        {
            var vesselId = string.Join(",", vesselIds);
            var api = new Framework.UI.Rest.RestClient(this.masterDataRestClient);
            string url = "V1/vessels?vesselId=" + vesselId + "&additionalFields=OwnershipType" + "&asOfDate=" + DateTime.Now.Date.ToString(BusinessConstant.VesselDateFormat, CultureInfo.CurrentCulture);
            ////string url = "V1/vessels?vesselId=" + vesselId + "&asOfDate=" + DateTime.Today.ToString(BusinessConstant.DateFormat);
            var vessels = await api.GetAsync<PageResponse<Vessel>>(url);
            return vessels.Items;
        }

        /// <summary>
        /// Gets the voyage.
        /// </summary>
        /// <returns>Returns The Voyage.</returns>
        public IList<VesselVoyage> SearchVoyage()
        {
            return VesselVoyageData.LoadData();
        }

        #endregion
    }
}
