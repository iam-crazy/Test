﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentNoteService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentNoteService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentNoteService.
    /// </summary>
    public class EquipmentNoteService : LockService, IEquipmentNoteService
    {
        #region Fields

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory databaseContextScopeFactory;

        /// <summary>
        /// The equipment repository.
        /// </summary>
        private readonly IEquipmentNoteRepository equipmentNoteRepository;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The master data service.
        /// </summary>
        private readonly ISecurityService securityService;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentNoteService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The <see cref="IDbContextScopeFactory"/></param>
        /// <param name="securityService">The <see cref="ISecurityService"/></param>
        /// <param name="equipmentNoteRepository">The <see cref="IEquipmentNoteRepository"/></param>
        /// <param name="mapper">The <see cref="IMapper"/></param>
        /// <param name="locker">The <see cref="LockHttpClient"/></param>
        public EquipmentNoteService(IDbContextScopeFactory databaseContextScopeFactory, ISecurityService securityService, IEquipmentNoteRepository equipmentNoteRepository, IMapper mapper, LockHttpClient locker) : base(locker)
        {
            if (equipmentNoteRepository == null)
            {
                throw new ArgumentNullException(nameof(equipmentNoteRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            if (securityService == null)
            {
                throw new ArgumentNullException(nameof(securityService));
            }

            this.equipmentNoteRepository = equipmentNoteRepository;
            this.databaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
            this.securityService = securityService;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <param name="equipmentNote">The equipmentNote.</param>
        /// <returns>
        /// Returns equipment Status.
        /// </returns>
        public async Task<IList<EquipmentNote>> GetEquipmentNote(int equipmentNote)
        {
            IList<DataAccessObjects.EquipmentNote> data;
            using (this.databaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.equipmentNoteRepository.GetEquipmentNote(equipmentNote);
            }

            var equipments = this.mapper.Map<IList<EquipmentNote>>(data);
            if (equipments != null && equipments.Any())
            {
                var ids = equipments.Select(s => s.UserId).Distinct();
                foreach (var id in ids)
                {
                    ////Call Service
                    UserBase user = await Task.Run(() => this.securityService.GetUserById(id));
                    foreach (var equipment in equipments.Where(s => s.UserId == id))
                    {
                        equipment.UserBase = user;
                    }
                }
            }

            return equipments;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="equipmentNoteData">The equipmentNoteData.</param>
        /// <returns>
        /// Return OperationOutcome.
        /// </returns>
        public async Task<BusinessOutcome> Save(EquipmentNote equipmentNoteData)
        {
            var result = new BusinessOutcome();
            DataAccessObjects.EquipmentNote equipmentNote = EquipmentActivityNoteExtension.ToEquipmentNote(equipmentNoteData);
            using (this.databaseContextScopeFactory.Create())
            {
               await this.equipmentNoteRepository.Save(equipmentNote);
               result.IdentityValue = Convert.ToString(equipmentNote.Id);
            }

            return result;
        }

        #endregion
    }
}
