﻿//-----------------------------------------------------------------------
// <copyright file = "LogicalCombinationService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare LogicalCombinationService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare LogicalCombinationService.
    /// </summary>
    [LockInfoAttribute("EME.LogicalCombination")]
    public class LogicalCombinationService : LockService, ILogicalCombinationService
    {
        #region Fields

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The logical combination repository.
        /// </summary>
        private readonly ILogicalCombinationRepository logicalCombinationRepository;

        /// <summary>
        /// The mapper value.
        /// </summary>
        private readonly IMapper mapper;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LogicalCombinationService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The Database Context factory.</param>
        /// <param name="logicalCombinationRepository">The logical combination repository.</param>
        /// <param name="mapper">The mapper for object mapping.</param>
        /// <param name="changeLog">The log for trace on update.</param>
        /// <param name="locker">The locker confrim the locking.</param>
        public LogicalCombinationService(IDbContextScopeFactory databaseContextScopeFactory, ILogicalCombinationRepository logicalCombinationRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (logicalCombinationRepository == null)
            {
                throw new ArgumentNullException(nameof(logicalCombinationRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.logicalCombinationRepository = logicalCombinationRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
            this.changeLog = changeLog;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the logical combination list.
        /// </summary>
        /// <param name="moveCodeId">The move code identifier.</param>
        /// <returns>
        /// Returns Logical Combination List.
        /// </returns>
        public async Task<IList<LogicalCombination>> GetLogicalCombinationList(int moveCodeId)
        {
            IList<DataAccessObjects.LogicalActivity> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.logicalCombinationRepository.GetLogicalCombinationList(moveCodeId);
            }

            IList<LogicalCombination> logicalCombinationList = this.mapper.Map<IList<LogicalCombination>>(data);
            return logicalCombinationList;
        }

        /// <summary>
        /// Saves the specified logical combination.
        /// </summary>
        /// <param name="logicalCombination">The logical combination.</param>
        /// <returns>
        /// Returns The logical Data.
        /// </returns>
        public async Task<BusinessOutcome> Save(IList<LogicalCombination> logicalCombination)
        {
            BusinessOutcome result = new BusinessOutcome();
            List<int> lockids = logicalCombination.Where(x => x.RowStatus != Constants.BusinessConstant.ActiveStatus).Select(x => (int)x.LogicalActivityId).ToList();
            bool hasLockConfirmed = true;
            if (lockids != null && lockids.Any())
            {
                hasLockConfirmed = await this.ConfirmMultipleExistingLocks(this.GetLockName(), lockids, logicalCombination[0].UpdatedBy.Value);
            }

            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                var combination = LogicalCombinationExtensions.ToConvertLogicalCombination(logicalCombination);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, logicalCombination[0].UserName))
                {
                    this.logicalCombinationRepository.Save(combination.ToList());
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(combination.ToList());
                    result.IdentityValue = combination.FirstOrDefault().ToActivityReferentialId.ToString();
                }
            }

            return result;
        }

        #endregion
    }
}
