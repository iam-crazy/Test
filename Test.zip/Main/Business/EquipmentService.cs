﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare EquipmentService.
// </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentService.
    /// </summary>
    public class EquipmentService : IEquipmentService
    {
        #region Fields

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory databaseContextScopeFactory;

        /// <summary>
        /// The equipment repository.
        /// </summary>
        private readonly IEquipmentRepository equipmentRepository;

        /// <summary>
        /// The master data service.
        /// </summary>
        private readonly IMasterDataService masterDataService;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="equipmentRepository">The equipment repository.</param>
        /// <param name="masterDataService">The master data service.</param>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public EquipmentService(IDbContextScopeFactory databaseContextScopeFactory, IEquipmentRepository equipmentRepository, IMasterDataService masterDataService)
        {
            if (equipmentRepository == null)
            {
                throw new ArgumentNullException(nameof(equipmentRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            this.masterDataService = masterDataService;
            this.equipmentRepository = equipmentRepository;
            this.databaseContextScopeFactory = databaseContextScopeFactory;
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Gets the equipment status.
        /// </summary>
        /// <param name="equipmentId">The equipmentId.</param>
        /// <returns>
        /// Returns The EquipmentStatus Data.
        /// </returns>
        public async Task<IList<Equipment>> GetEquipment(int equipmentId)
        {
            IList<Equipment> equipments = null;
            IList<DataAccessObjects.Equipment> data;
            using (this.databaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.equipmentRepository.GetEquipment(equipmentId);
            }

            if (data != null)
            {
                var sizeTypeIds = data.Where(x => x.EquipmentSizeTypeId > 0).Select(x => x.EquipmentSizeTypeId).Distinct();
                var isoCodeIds = data.Where(x => x.EquipmentISOId > 0).Select(x => x.EquipmentISOId).Distinct();
                var sizeTypes = await this.GetEquipmentSizeTypes(sizeTypeIds);
                var isoCodes = await this.GetEquipmentISOCodes(isoCodeIds);

                equipments = data.Select(s =>
                    new Equipment()
                    {
                        EquipmentId = s.EquipmentId,
                        EquipmentISO = isoCodes.FirstOrDefault(f => f.EquipmentSizeTypeCodeId == s.EquipmentISOId),
                        EquipmentSizeType = sizeTypes.FirstOrDefault(f => f.EquipmentSizeTypeId == s.EquipmentSizeTypeId),
                        ValidFrom = s.ValidFrom,
                        CreatedBy = s.CreatedBy,
                        CreatedOn = s.CreatedOn,
                        EquipmentNumber = s.EquipmentNumber,
                        HasSOC = s.HasSOC,
                        ParentEquipmentId = s.ParentEquipmentId,
                        IsCanceled = s.IsCanceled,
                        UpdatedBy = s.UpdatedBy,
                        UpdatedOn = s.UpdatedOn,
                        ValidTo = s.ValidTo
                    }).ToList();
            }

            return equipments;
        }

        /// <summary>
        /// Saves the specified equipment status data.
        /// </summary>
        /// <param name="equipmentData">The equipmentData.</param>
        /// <returns>Returns the equipment value.</returns>
        public async Task<BusinessOutcome> Save(Equipment equipmentData)
        {
            var result = new BusinessOutcome();
            result.Messages = new List<ValidationResult>();
            DataAccessObjects.Equipment equipmentNote = EquipmentActivityNoteExtension.ToEquipment(equipmentData);

            ////bool alreadyExists;
            ////using (this.databaseContextScopeFactory.CreateReadOnly())
            ////{
            ////    alreadyExists = await this.equipmentRepository.IsEquipmentNumber(equipmentData.EquipmentNumber);
            ////}

            ////if (alreadyExists)
            ////{
            ////    result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_EquipmentNumber));
            ////}
            ////else
            ////{
            ////}

            using (this.databaseContextScopeFactory.Create())
            {
                await this.equipmentRepository.Save(equipmentNote);
                result.IdentityValue = Convert.ToString(equipmentNote.EquipmentId);
            }

            return result;
        }

        #endregion Public Methods

        /// <summary>
        /// Gets the equipment size types.
        /// </summary>
        /// <param name="equipmentSizeTypeIds">The equipment size type ids.</param>
        /// <returns>Returns Equipment Activity SizeType.</returns>
        public async Task<IList<EquipmentSizeType>> GetEquipmentSizeTypes(IEnumerable<short> equipmentSizeTypeIds)
        {
            IList<EquipmentSizeType> sizeTypes = null;
            if (equipmentSizeTypeIds != null && equipmentSizeTypeIds.Any())
            {
                sizeTypes = await this.masterDataService.GetEquipmentSizeTypes(equipmentSizeTypeIds.ToList());
            }

            return sizeTypes;
        }

        /// <summary>
        /// Gets the equipment iso codes.
        /// </summary>
        /// <param name="equipmentISOCodes">The equipment iso codes.</param>
        /// <returns>Return Equipment Codes.</returns>
        public async Task<IList<EquipmentISOCode>> GetEquipmentISOCodes(IEnumerable<short> equipmentISOCodes)
        {
            if (equipmentISOCodes != null && equipmentISOCodes.Any())
            {
                return await this.masterDataService.GetEquipmentISOCodes(equipmentISOCodes.ToList());
            }

            return null;
        }
    }
}