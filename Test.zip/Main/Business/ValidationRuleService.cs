﻿//-----------------------------------------------------------------------
// <copyright file = "ValidationRuleService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare ValidationRuleService. </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare ValidationRuleService.
    /// </summary>
    /// <seealso cref="Msc.Logistics.EME.Service.Business.IValidationRuleService" />
    [LockInfoAttribute("EME.ValidationRule")]
    public class ValidationRuleService : LockService, IValidationRuleService
    {
        #region Members

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The Validation rule repository.
        /// </summary>
        private readonly IValidationRuleRepository validationRuleRepository;

        /// <summary>
        /// The referential data repository.
        /// </summary>
        private readonly IReferentialDataRepository referentialDataRepository;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        #endregion Members

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationRuleService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="ruleRepository">The rule repository.</param>
        /// <param name="mapper">The mapper parameter.</param>
        /// <param name="referentialRepository">The referential repository.</param>
        /// <param name="changeLog">The change log parameter.</param>
        /// <param name="locker">The locker parameter.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public ValidationRuleService(IDbContextScopeFactory databaseContextScopeFactory, IValidationRuleRepository ruleRepository, IMapper mapper, IReferentialDataRepository referentialRepository, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (ruleRepository == null)
            {
                throw new ArgumentNullException(nameof(ruleRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            if (referentialRepository == null)
            {
                throw new ArgumentNullException(nameof(referentialRepository));
            }

            this.validationRuleRepository = ruleRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.mapper = mapper;
            this.referentialDataRepository = referentialRepository;
            this.changeLog = changeLog;
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the validation rules.
        /// </summary>
        /// <param name="ruleNumber">The rule number.</param>
        /// <param name="group">The group.</param>
        /// <param name="description">The description.</param>
        /// <param name="validFrom">The valid from.</param>
        /// <param name="validTo">The valid to.</param>
        /// <param name="status">The rule status.</param>
        /// <param name="type">The rule type.</param>
        /// <param name="limit">The rule limit.</param>
        /// <param name="offset">The offset.</param>
        /// <param name="searchValue">The search Value.</param>
        /// <returns>
        /// Returns the validation rule list.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public async Task<IList<ValidationRule>> GetValidationRules(int? ruleNumber, string group, string description, DateTime? validFrom, DateTime? validTo, bool? status, string type, int limit, int offset, string searchValue)
        {
            IList<DataAccessObjects.ValidationRule> data;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                data = await this.validationRuleRepository.GetValidationRules(ruleNumber, group, description, validFrom, validTo, status, type, limit, offset, searchValue);
            }

            IList<ValidationRule> rules = this.mapper.Map<IList<ValidationRule>>(data);
            foreach (var rule in rules)
            {
                rule.Status = rule.ValidTo.HasValue && rule.ValidTo.Value < DateTime.Now ? false : rule.Status;
            }

            return rules;
        }

        /// <summary>
        /// Save the specified validation rule.
        /// </summary>
        /// <param name="validationRule">The validation rule.</param>
        /// <returns>
        /// Returns The Save Data.
        /// </returns>
        public async Task<BusinessOutcome> Save(ValidationRule validationRule)
        {
            if (validationRule == null)
            {
                throw new ArgumentNullException(nameof(validationRule));
            }

            BusinessOutcome result = new BusinessOutcome();

            result = BusinessValidationRule(validationRule);
            if (!string.IsNullOrWhiteSpace(validationRule.RuleNumber) && validationRule.ValidationRuleId == BusinessConstant.DefaultId)
            {
                bool alreadyExist;
                using (this.dataBaseContextScopeFactory.CreateReadOnly())
                {
                    alreadyExist = await this.validationRuleRepository.IsRuleNumberExist(validationRule.RuleNumber);
                }

                if (alreadyExist)
                {
                    result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_RuleNumberAlreadyExist));
                }
            }

            if (result.ConvertToOperationOutcome().Status == OperationOutcomeStatus.Success)
            {
                var rule = ValidationRuleExtensions.ToDataAccessModel(validationRule);
                if (rule.ValidationRuleId > 0)
                {
                    bool hasLockConfirmed = await ConfirmExistingLock(this.GetLockName(), validationRule.ValidationRuleId, validationRule.UpdatedBy.Value, string.Empty);
                    if (!hasLockConfirmed)
                    {
                        result.AddLockConfirmationWarning();
                    }
                    else
                    {
                        IList<DataAccessObjects.ReferentialValidationRule> referentiallist;
                        if (!rule.Status)
                        {
                            await this.ValidationRuleUpdate(validationRule.UserName, result, rule);
                            using (this.dataBaseContextScopeFactory.CreateReadOnly())
                            {
                                referentiallist = await this.referentialDataRepository.GetReferentialValidationRules(rule.ValidationRuleId);
                            }

                            if (validationRule.ActivityCodeChangeStatus || !validationRule.Status)
                            {
                                if (referentiallist != null && referentiallist.Any())
                                {
                                    foreach (var referntialrule in referentiallist.Where(x => x.ValidationRuleId == rule.ValidationRuleId && (x.EffectiveTo == null || x.EffectiveTo > System.DateTime.Now)))
                                    {
                                        referntialrule.EffectiveTo = rule.UpdatedOn.Value;
                                        if (validationRule.ActivityCodeChangeStatus)
                                        {
                                            referntialrule.EffectiveDate = DateTime.Now;
                                            referntialrule.EffectiveTo = null;
                                        }

                                        if (!validationRule.Status)
                                        {
                                            referntialrule.EffectiveTo = DateTime.Now;
                                        }
                                    }

                                    using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, validationRule.UserName))
                                    {
                                        this.referentialDataRepository.SaveReferentialValidationRules(referentiallist);
                                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(referentiallist);
                                        result.IdentityValue = Convert.ToString(rule.ValidationRuleId);
                                    }
                                }
                            }
                        }
                        else if (rule.Status && !string.IsNullOrWhiteSpace(validationRule.Remarks))
                        {
                            rule.ValidFrom = rule.UpdatedOn.Value;
                            rule.ValidTo = null;
                            rule.Remarks = string.Empty;
                            await this.ValidationRuleUpdate(validationRule.UserName, result, rule);
                            if (validationRule.ActivityCodeChangeStatus)
                            {
                                using (this.dataBaseContextScopeFactory.CreateReadOnly())
                                {
                                    referentiallist = await this.referentialDataRepository.GetReferentialValidationRules(rule.ValidationRuleId);
                                }

                                if (referentiallist != null && referentiallist.Any())
                                {
                                    foreach (var referntialrule in referentiallist.Where(x => x.ValidationRuleId == rule.ValidationRuleId && (x.EffectiveTo.Value.Date == validationRule.UpdatedOn.Value.Date)))
                                    {
                                        referntialrule.EffectiveDate = rule.UpdatedOn.Value;
                                        referntialrule.EffectiveTo = null;
                                    }

                                    using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, validationRule.UserName))
                                    {
                                        this.referentialDataRepository.SaveReferentialValidationRules(referentiallist);
                                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(referentiallist);
                                        result.IdentityValue = Convert.ToString(rule.ValidationRuleId);
                                    }
                                }
                            }
                        }
                        else
                        {
                            await this.ValidationRuleUpdate(validationRule.UserName, result, rule);
                        }
                    }
                }
                else
                {
                    using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, validationRule.UserName))
                    {
                        this.validationRuleRepository.Save(rule);
                        await scope.SaveChangesAsyncChangeLog<EMEDataContext>(rule);
                        result.IdentityValue = Convert.ToString(rule.ValidationRuleId);
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Get the validation rule.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Returns The Id.
        /// </returns>
        public async Task<ValidationRule> GetValidationRule(int id)
        {
            DataAccessObjects.ValidationRule rule;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                rule = await this.validationRuleRepository.GetValidationRule(id);
            }

            ValidationRule validationRule = this.mapper.Map<ValidationRule>(rule);
            return validationRule;
        }

        /// <summary>
        /// Gets the rule number.
        /// </summary>
        /// <returns>
        /// Returns Rule Number.
        /// </returns>
        public async Task<string> GenerateRuleNumber()
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                var ruleNumber = await this.validationRuleRepository.GenerateRuleNumber();
                string zero = BusinessConstant.RuleZero;
                if (ruleNumber.Length < 4 && Convert.ToInt32(ruleNumber) > 0)
                {
                    return zero.Substring(ruleNumber.Length) + ruleNumber;
                }
                else
                {
                    return BusinessConstant.RuleOne;
                }
            }
        }

        /// <summary>
        /// Gets the List of validation Rules.
        /// </summary>
        /// <param name="group">Validation group.</param>
        /// <param name="id">Validation Id.</param>
        /// <returns>
        /// Returns List of validation Rules.
        /// </returns>
        public async Task<IList<ValidationRuleBase>> SearchValidationRules(string group, int id)
        {
            List<DataAccessObjects.ValidationRule> rule;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                rule = await this.validationRuleRepository.SearchValidationRules(group, id);
            }

            IList<ValidationRuleBase> validationRuleBaseList = this.mapper.Map<IList<ValidationRuleBase>>(rule);
            return validationRuleBaseList;
        }

        #endregion Public Methods

        /// <summary>
        /// Businesses the validation rule.
        /// </summary>
        /// <param name="validationRule">The validation rule.</param>
        /// <returns>Return Operation Out come.</returns>
        private static BusinessOutcome BusinessValidationRule(ValidationRule validationRule)
        {
            BusinessOutcome result = new BusinessOutcome();
            result.Messages = new List<ValidationResult>();
            if (string.IsNullOrEmpty(validationRule.RuleNumber))
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_RuleNumber));
            }

            if (validationRule.ValidFrom == default(DateTime))
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidFrom));
            }

            if (validationRule.ValidTo != null && validationRule.ValidTo < validationRule.ValidFrom)
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidTo));
            }

            if (validationRule.ValidationRuleGroup != null && validationRule.ValidationRuleGroup.Id == 0)
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidationRuleGroup));
            }

            if (string.IsNullOrEmpty(validationRule.Description))
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidationRuleDescription));
            }

            if (validationRule.ValidationRuleType != null && validationRule.ValidationRuleType.Id == 0)
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidationActivityType));
            }

            if (validationRule.ValidationRuleErrorResult != null && validationRule.ValidationRuleErrorResult.Id == 0)
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidationErrorResult));
            }

            if (string.IsNullOrEmpty(validationRule.ErrorDescription))
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_ValidationErrorDescription));
            }

            if (!validationRule.Status && string.IsNullOrWhiteSpace(validationRule.Remarks))
            {
                result.Messages.Add(new ValidationResult(false, ValidationMessageType.Exception, Resource.ValidationMessage.LBL_Remarks));
            }

            return result;
        }

        /// <summary>
        /// Validations the rule update.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="result">The result parameter.</param>
        /// <param name="rule">The rule parameter.</param>
        /// <returns>Return Operation Out come.</returns>
        private async Task ValidationRuleUpdate(string userName, BusinessOutcome result, DataAccessObjects.ValidationRule rule)
        {
            using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, userName))
            {
                this.validationRuleRepository.Update(rule);
                await scope.SaveChangesAsyncChangeLog<EMEDataContext>(rule);
                result.IdentityValue = Convert.ToString(rule.ValidationRuleId);
            }
        }
    }
}