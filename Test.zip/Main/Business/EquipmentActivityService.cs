﻿//-----------------------------------------------------------------------
// <copyright file = "EquipmentActivityService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary> Declare EquipmentActivityService. </summary>
//-----------------------------------------------------------------------

namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using ChangeLog.Service;
    using ChangeLog.Service.Extensions;
    using Constants;
    using Contracts;
    using Contracts.Objects;
    using DataAccess.Contracts;
    using EntityFramework.DbContextScope.Interfaces;
    using Extension;
    using Framework.Common.Model;
    using Framework.Common.Model.Pagination;
    using Locking.Service.Api.Contracts;
    using Locking.Service.Api.Contracts.Attributes;
    using DataAccessObjects = DataAccess.Contracts.Objects;

    /// <summary>
    /// Declare EquipmentActivityService.
    /// </summary>
    [LockInfoAttribute("EME.EquipmentActivity")]
    public partial class EquipmentActivityService : LockService, IEquipmentActivityService
    {
        #region Fields

        /// <summary>
        /// The change log.
        /// </summary>
        private readonly IChangeLog changeLog;

        /// <summary>
        /// The database context scope factory.
        /// </summary>
        private readonly IDbContextScopeFactory dataBaseContextScopeFactory;

        /// <summary>
        /// The equipment activity repository.
        /// </summary>
        private readonly IEquipmentActivityRepository equipmentActivityRepository;

        /// <summary>
        /// The equipment state data service.
        /// </summary>
        private readonly IEquipmentStateRepository equipmentStateRepository;

        /// <summary>
        /// The equipment stock reposition repository.
        /// </summary>
        private readonly IEquipmentStockRepositionService equipmentStockRepositionRepository;

        /// <summary>
        /// The logical combination repository.
        /// </summary>
        private readonly ILogicalCombinationRepository logicalCombinationRepository;

        /// <summary>
        /// The logical sequence repository.
        /// </summary>
        private readonly ILogicalSequenceRepository logicalSequenceRepository;

        /// <summary>
        /// The mapper.
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// The master data service.
        /// </summary>
        private readonly IMasterDataService masterDataService;

        /// <summary>
        /// The validation rule repository.
        /// </summary>
        private readonly IValidationRuleRepository validationRuleRepository;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentActivityService"/> class.
        /// </summary>
        /// <param name="databaseContextScopeFactory">The database context scope factory.</param>
        /// <param name="equipmentActivityRepository">The equipment activity repository.</param>
        /// <param name="masterService">The master service.</param>
        /// <param name="logicalSequenceRepository">The logical sequence repository.</param>
        /// <param name="validationRuleRepository">The validation rule repository.</param>
        /// <param name="logicalCombinationRepository">The logical combination repository.</param>
        /// <param name="equipmentStateRepository">The equipment state repository.</param>
        /// <param name="equipmentStockRepositionRepository">The equipment stock reposition repository.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="changeLog">The change log.</param>
        /// <param name="locker">The locker.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.
        /// </exception>
        public EquipmentActivityService(IDbContextScopeFactory databaseContextScopeFactory, IEquipmentActivityRepository equipmentActivityRepository, IMasterDataService masterService, ILogicalSequenceRepository logicalSequenceRepository, IValidationRuleRepository validationRuleRepository, ILogicalCombinationRepository logicalCombinationRepository, IEquipmentStateRepository equipmentStateRepository, IEquipmentStockRepositionService equipmentStockRepositionRepository, IMapper mapper, IChangeLog changeLog, LockHttpClient locker) : base(locker)
        {
            if (equipmentActivityRepository == null)
            {
                throw new ArgumentNullException(nameof(equipmentActivityRepository));
            }

            if (databaseContextScopeFactory == null)
            {
                throw new ArgumentNullException(nameof(databaseContextScopeFactory));
            }

            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }

            ////if (changeLog == null)
            ////{
            ////    throw new ArgumentNullException(nameof(changeLog));
            ////}

            this.equipmentActivityRepository = equipmentActivityRepository;
            this.dataBaseContextScopeFactory = databaseContextScopeFactory;
            this.masterDataService = masterService;
            this.logicalSequenceRepository = logicalSequenceRepository;
            this.logicalCombinationRepository = logicalCombinationRepository;
            this.validationRuleRepository = validationRuleRepository;
            this.equipmentStateRepository = equipmentStateRepository;
            this.equipmentStockRepositionRepository = equipmentStockRepositionRepository;
            this.mapper = mapper;
            this.changeLog = changeLog;
        }

        #endregion Constructors

        #region Public Methods

        /// <summary>
        /// Cancels the specified data.
        /// </summary>
        /// <param name="data">The Cancel data.</param>
        /// <returns>
        /// Returns The Cancel Data.
        /// </returns>
        public async Task<BusinessOutcome> Cancel(IList<CancelEquipmentActivity> data)
        {
            var result = new BusinessOutcome();
            IList<DataAccessObjects.CancelEquipmentActivity> equipmentActivity = EquipmentActivityExtensions.ToCancelEquipmentActivity(data);
            IList<EquipmentState> equipmentStates = await this.SearchEquipmentStates();
            byte equipmentStateId = equipmentStates.FirstOrDefault(x => x.Code == BusinessConstant.EquipmentStateCancel).EquipmentStateId;
            bool hasLockConfirmed = await ConfirmMultipleExistingLocks(this.GetLockName(), data.Select(x => (int)x.EquipmentActivityId).ToList(), data[0].UpdatedBy.Value);
            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                using (this.dataBaseContextScopeFactory.CreateReadOnly())
                {
                    result.IdentityValue = Convert.ToString(await this.equipmentActivityRepository.Cancel(equipmentActivity, equipmentStateId));
                }
            }

            return result;
        }

        /// <summary>
        /// Checks the equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipmentActivity identifier.</param>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDateTime">The activity date time.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="voyage">The voyage.</param>
        /// <returns>Returns The Validate Equipment.</returns>
        public async Task<ValidateEquipment> CheckEquipment(string equipmentActivityId, string equipmentNumber, int activityReferentialId, DateTime activityDateTime, int locationId, int vesselId, int voyageId, string voyage)
        {
            var validateEquipmentBusiness = new ValidateEquipment();
            DataAccessObjects.ValidateEquipment validateEquipmentDataAccess;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                validateEquipmentDataAccess = await this.equipmentActivityRepository.CheckEquipment(equipmentActivityId, equipmentNumber, activityReferentialId, activityDateTime, locationId, vesselId, voyageId, voyage);
            }

            IList<EquipmentSizeType> equipmentSizeTypes = this.GetEquipmentSizeTypes(validateEquipmentDataAccess.AvailableEquipment.Select(x => x.EquipmentSizeTypeId).ToList());
            IList<EquipmentISOCode> isoCodes = this.GetEquipmentISOCodes(validateEquipmentDataAccess.AvailableEquipment.Select(x => x.EquipmentISOId).ToList());
            foreach (var item in validateEquipmentDataAccess.AvailableEquipment)
            {
                var equipmentFleet = new EquipmentFleet();
                equipmentFleet.Id = item.Id;
                equipmentFleet.EquipmentNumber = item.EquipmentNumber;
                equipmentFleet.HasSOC = item.HasSOC;
                if (item.EquipmentSizeTypeId > 0)
                {
                    equipmentFleet.EquipmentSizeType = this.mapper.Map<EquipmentSizeType>(this.GetEquipmentSizeTypeById(equipmentSizeTypes, item.EquipmentSizeTypeId));
                    equipmentFleet.EquipmentISO = this.mapper.Map<EquipmentISOCode>(this.GetEquipmenISOCodeId(isoCodes, item.EquipmentISOId));
                }

                validateEquipmentBusiness.AvailableEquipment.Add(equipmentFleet);
            }

            validateEquipmentBusiness.DuplicateEquipment = this.mapper.Map<IList<string>>(validateEquipmentDataAccess.DuplicateEquipment);
            validateEquipmentBusiness.MissingEquipment = this.mapper.Map<IList<string>>(validateEquipmentDataAccess.MissingEquipment);
            return validateEquipmentBusiness;
        }

        /// <summary>
        /// Checks the equipment activity.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Returns validation rule identifier.</returns>
        public async Task<bool> CheckEquipmentActivity(int? validationRuleId)
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                return await this.equipmentActivityRepository.CheckEquipmentActivity(validationRuleId);
            }
        }

        /// <summary>
        /// Gets the equipment activity.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="equipmentNumber">The equipment Number.</param>
        /// <returns>
        /// Returns The Equipment Activity Id.
        /// </returns>
        public async Task<EquipmentActivity> GetEquipmentActivity(int id, string equipmentNumber)
        {
            DataAccessObjects.EquipmentActivity dataAccessItem;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                dataAccessItem = await this.equipmentActivityRepository.GetEquipmentActivity(id, equipmentNumber);
            }

            IList<DataAccessObjects.EquipmentActivity> dataAccessData = new List<DataAccessObjects.EquipmentActivity>();
            dataAccessData.Add(dataAccessItem);
            IList<EquipmentSizeType> sizeTypes = this.GetEquipmentSizeTypes(dataAccessData.Select(x => x.Equipment.EquipmentSizeTypeId).ToList());
            IList<EquipmentISOCode> isoCodes = this.GetEquipmentISOCodes(dataAccessData.Select(x => x.Equipment.EquipmentISOId).ToList());
            IList<Port> ports = this.GetPorts(dataAccessData);
            IList<TerminalDepot> terminalDepots = this.GetTerminalDepots(dataAccessData);
            IList<Vessel> vessels = this.GetVessels(dataAccessData);
            IList<Location> locations = this.GetLocations(dataAccessData);
            return this.GetEquipmentActivityDetails(sizeTypes, ports, terminalDepots, vessels, locations, dataAccessItem, isoCodes);
        }

        /// <summary>
        /// Gets the equipment activity ids.
        /// </summary>
        /// <param name="validationRuleId">The validation rule identifier.</param>
        /// <returns>Return Activity Id.</returns>
        public async Task<IList<long>> GetEquipmentActivityIds(int? validationRuleId)
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                return await this.equipmentActivityRepository.GetEquipmentActivityIds(validationRuleId);
            }
        }

        /// <summary>
        /// Gets the equipment activities.
        /// </summary>
        /// <param name="activityFilter">The activity filter.</param>
        /// <returns>
        /// Returns The Equipment Activities.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public async Task<PageResponse<EquipmentActivity>> GetEquipmentActivityList(EquipmentActivityFilter activityFilter)
        {
            if (activityFilter == null)
            {
                throw new ArgumentNullException(nameof(activityFilter));
            }

            var businessData = new PageResponse<EquipmentActivity>();
            PageResponse<DataAccessObjects.EquipmentActivity> dataAccessData;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                dataAccessData = await this.equipmentActivityRepository.GetEquipmentActivityList(this.mapper.Map<DataAccessObjects.EquipmentActivityFilter>(activityFilter));
            }

            if (dataAccessData != null)
            {
                businessData.Items = new List<EquipmentActivity>();
                IList<EquipmentSizeType> sizeTypes = this.GetEquipmentSizeTypes(dataAccessData.Items.Select(x => x.Equipment.EquipmentSizeTypeId).ToList());
                IList<EquipmentISOCode> isoCodes = this.GetEquipmentISOCodes(dataAccessData.Select(x => x.Equipment.EquipmentISOId).ToList());
                IList<Port> ports = this.GetPorts(dataAccessData.Items);
                IList<TerminalDepot> terminalDepots = this.GetTerminalDepots(dataAccessData.Items);
                IList<Location> locations = this.GetLocations(dataAccessData.Items);
                IList<Vessel> vessels = this.GetVessels(dataAccessData.Items);
                businessData.TotalCount = dataAccessData.TotalCount;
                foreach (var item in dataAccessData)
                {
                    EquipmentActivity equipmentActivity = this.GetEquipmentActivityDetails(sizeTypes, ports, terminalDepots, vessels, locations, item, isoCodes);
                    businessData.Items.Add(equipmentActivity);
                }
            }

            return businessData;
        }

        /// <summary>
        /// Gets the equipment by fleet.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>
        /// Returns the fleet.
        /// </returns>
        public async Task<EquipmentFleet> GetEquipmentByFleet(string equipmentNumber)
        {
            DataAccessObjects.EquipmentActivity equipmentActivity;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                equipmentActivity = await this.equipmentActivityRepository.GetEquipmentActivity(0, equipmentNumber);
            }

            EquipmentFleet businessEquipmentActivity = this.ToBusinessModelEquipmentFleet(equipmentActivity);
            return businessEquipmentActivity;
        }

        /// <summary>
        /// Gets the equipment iso codes.
        /// </summary>
        /// <param name="equipmentISOCodes">The equipment iso codes.</param>
        /// <returns>Return Equipment Codes.</returns>
        public IList<EquipmentISOCode> GetEquipmentISOCodes(List<short> equipmentISOCodes)
        {
            if (equipmentISOCodes != null && equipmentISOCodes.Any())
            {
                var sizeTypeIds = new List<short>();
                sizeTypeIds.AddRange(equipmentISOCodes);
                sizeTypeIds = sizeTypeIds.Where(x => x != 0).Distinct().ToList();
                if (sizeTypeIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetEquipmentISOCodes(sizeTypeIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the equipment size types.
        /// </summary>
        /// <param name="equipmentSizeTypeIds">The equipment size type ids.</param>
        /// <returns>Returns Equipment Activity SizeType.</returns>
        public IList<EquipmentSizeType> GetEquipmentSizeTypes(List<short> equipmentSizeTypeIds)
        {
            if (equipmentSizeTypeIds != null && equipmentSizeTypeIds.Any())
            {
                var sizeTypeIds = new List<short>();
                sizeTypeIds.AddRange(equipmentSizeTypeIds);
                sizeTypeIds = sizeTypeIds.Where(x => x != 0).Distinct().ToList();
                if (sizeTypeIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetEquipmentSizeTypes(sizeTypeIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the locations.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns location list.</returns>
        public IList<Location> GetLocations(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var locationIds = new List<int>();
                locationIds.AddRange(dataAccessData.Where(l => l.DestinationLocationId.HasValue).Select(x => x.DestinationLocationId.Value));
                locationIds.AddRange(dataAccessData.Where(l => l.DeliveryLocationId.HasValue).Select(x => x.DeliveryLocationId.Value));
                locationIds.AddRange(dataAccessData.Where(l => l.ReceiptLocationId.HasValue).Select(x => x.ReceiptLocationId.Value));
                locationIds.AddRange(dataAccessData.Where(l => l.ReturnLocationId.HasValue).Select(x => x.ReturnLocationId.Value));
                locationIds = locationIds.Distinct().ToList();
                if (locationIds.Any(x => x != 0))
                {
                    return Task.Run(() => this.masterDataService.GetLocations(locationIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the ports.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns Port Values.</returns>
        public IList<Port> GetPorts(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var portIds = new List<int>();
                portIds.AddRange(dataAccessData.Select(l => l.LocationId));
                portIds.AddRange(dataAccessData.Where(l => l.LoadingPortId.HasValue).Select(x => x.LoadingPortId.Value));
                portIds.AddRange(dataAccessData.Where(l => l.DischargePortId.HasValue).Select(l => l.DischargePortId.Value));
                portIds.AddRange(dataAccessData.Where(l => l.TransshipmentPortId.HasValue).Select(l => l.TransshipmentPortId.Value));
                portIds = portIds.Where(x => x != 0).Distinct().ToList();
                if (portIds != null && portIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetPorts(portIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the relevant equipment.
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <returns>Returns Equipment Activity Id.</returns>
        public async Task<IList<EquipmentActivity>> GetRelevantEquipment(int equipmentActivityId)
        {
            IList<DataAccessObjects.EquipmentActivity> dataAccessData;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                dataAccessData = await this.equipmentActivityRepository.GetRelevantEquipment(equipmentActivityId);
            }

            if (dataAccessData != null)
            {
                IList<EquipmentSizeType> sizeTypes = this.GetEquipmentSizeTypes(dataAccessData.Select(x => x.Equipment.EquipmentSizeTypeId).ToList());
                IList<EquipmentISOCode> isoCodes = this.GetEquipmentISOCodes(dataAccessData.Select(x => x.Equipment.EquipmentISOId).ToList());
                IList<Port> ports = this.GetPorts(dataAccessData);
                IList<TerminalDepot> terminalDepots = this.GetTerminalDepots(dataAccessData);
                IList<Location> locations = this.GetLocations(dataAccessData);
                IList<Vessel> vessels = this.GetVessels(dataAccessData);
                IList<EquipmentActivity> relaventEquipments = new List<EquipmentActivity>();
                foreach (var item in dataAccessData)
                {
                    EquipmentActivity equipmentActivity = this.GetEquipmentActivityDetails(sizeTypes, ports, terminalDepots, vessels, locations, item, isoCodes);
                    relaventEquipments.Add(equipmentActivity);
                }

                return relaventEquipments;
            }

            return null;
        }

        /// <summary>
        /// Gets the terminal depots.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns Terminal Depot.</returns>
        public IList<TerminalDepot> GetTerminalDepots(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var terminalDepotIds = new List<int>();
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.TerminalEquipmentHandlingFacilityId.HasValue).Select(x => x.TerminalEquipmentHandlingFacilityId.Value));
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.DepotEquipmentHandlingFacilityId.HasValue).Select(x => x.DepotEquipmentHandlingFacilityId.Value));
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.ReturnTerminalEquipmentHandlingFacilityId.HasValue).Select(x => x.ReturnTerminalEquipmentHandlingFacilityId.Value));
                terminalDepotIds.AddRange(dataAccessData.Where(l => l.ReturnDepotEquipmentHandlingFacilityId.HasValue).Select(x => x.ReturnDepotEquipmentHandlingFacilityId.Value));
                terminalDepotIds = terminalDepotIds.Where(x => x != 0).Distinct().ToList();
                if (terminalDepotIds != null && terminalDepotIds.Any())
                {
                    return Task.Run(() => this.masterDataService.GetTerminalDepots(terminalDepotIds)).Result;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the valid equipment activity.
        /// </summary>
        /// <param name="valid">The valid.</param>
        /// <returns>Returns Valid Equipment Activity.</returns>
        public async Task<IList<EquipmentActivityHeaderDetail>> GetValidEquipmentActivity(bool? valid)
        {
            var equipmentActivityHeaders = new List<EquipmentActivityHeaderDetail>();
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                if (!valid.HasValue || valid.Value)
                {
                    int validCount = await this.equipmentActivityRepository.SearchValidActivityCount();
                    equipmentActivityHeaders.Add(new EquipmentActivityHeaderDetail() { Count = validCount, ErrorDescription = "Valid", RuleNumber = string.Empty });
                }

                if (!valid.HasValue || !valid.Value)
                {
                    IList<Tuple<int, string, string, int>> invalidDetail = await this.validationRuleRepository.SearchInvalidEquipmentActivity();
                    equipmentActivityHeaders.AddRange(invalidDetail.Select(s => new EquipmentActivityHeaderDetail() { Count = s.Item4, ErrorDescription = s.Item3, RuleNumber = s.Item2, ValidationId = s.Item1 }));
                }
            }

            return equipmentActivityHeaders;
        }

        /// <summary>
        /// Get Valid EquipmentActivity.
        /// </summary>
        /// <param name="activityFilter">The activity Filter rule.</param>
        /// <returns>
        /// Return the equipment List.
        /// </returns>
        public async Task<IList<EquipmentActivityHeaderDetail>> GetValidEquipmentActivity(EquipmentActivityFilter activityFilter)
        {
            var equipmentActivityHeaders = new List<EquipmentActivityHeaderDetail>();
            IList<Tuple<int?, string, string, int>> header;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                header = await this.equipmentActivityRepository.SearchValidActivityCount(this.mapper.Map<DataAccessObjects.EquipmentActivityFilter>(activityFilter));
            }

            if (!activityFilter.Valid.HasValue || activityFilter.Valid.Value)
            {
                equipmentActivityHeaders.Add(new EquipmentActivityHeaderDetail() { Count = header.FirstOrDefault(s => !s.Item1.HasValue).Item4, ErrorDescription = "Valid", RuleNumber = string.Empty });
            }

            if (!activityFilter.Valid.HasValue || !activityFilter.Valid.Value)
            {
                equipmentActivityHeaders.AddRange(header.Where(s => s.Item1.HasValue).Select(s => new EquipmentActivityHeaderDetail() { Count = s.Item4, ErrorDescription = s.Item3, RuleNumber = s.Item2, ValidationId = s.Item1 }));
            }

            return equipmentActivityHeaders;
        }

        /// <summary>
        /// Gets the vessels.
        /// </summary>
        /// <param name="dataAccessData">The data access data.</param>
        /// <returns>Returns Vessel Data.</returns>
        public IList<Vessel> GetVessels(IList<DataAccessObjects.EquipmentActivity> dataAccessData)
        {
            if (dataAccessData != null && dataAccessData.Any())
            {
                var vesselIds = new List<int>();
                vesselIds.AddRange(dataAccessData.Where(l => l.VesselId.HasValue).Select(x => x.VesselId.Value));
                vesselIds = vesselIds.Where(x => x != 0).Distinct().ToList();
                if (vesselIds != null && vesselIds.Any())
                {
                    var vessels = Task.Run(async () => await this.masterDataService.GetVessels(vesselIds)).Result;
                    var apivessels = new List<Vessel>();
                    foreach (var item in vessels)
                    {
                        var apivessel = new Vessel();
                        apivessel.VesselId = item.VesselId;
                        apivessel.LongDisplayName = item.VesselVersions.FirstOrDefault().LongDisplayName;
                        apivessel.Name = item.VesselVersions.FirstOrDefault().Name;
                        apivessel.OwnershipType = this.mapper.Map<OwnershipType>(item.VesselVersions.FirstOrDefault().OwnershipType);
                        apivessels.Add(apivessel);
                    }

                    return apivessels;
                }
            }

            return null;
        }

        /// <summary>
        /// Saves the specified data.
        /// </summary>
        /// <param name="data">The Equipment Activity data.</param>
        /// <returns>
        /// Save The Equipment Activity Data.
        /// </returns>
        /// <exception cref="System.ArgumentException">Argument Exception.</exception>
        public async Task<BusinessOutcome> Save(IList<EquipmentActivity> data)
        {
            if (data == null || !data.Any())
            {
                throw new ArgumentException(nameof(data));
            }

            BusinessOutcome result = new BusinessOutcome();
            result.Messages = new List<ValidationResult>();
            IList<long> ids = new List<long>();
            bool hasLockConfirmed = true;
            if (data.Any(s => s.EquipmentActivityId > 0))
            {
                hasLockConfirmed = await this.ConfirmMultipleExistingLocks(this.GetLockName(), data.Select(x => (int)x.EquipmentActivityId).ToList(), data[0].UpdatedBy.Value);
            }

            if (!hasLockConfirmed)
            {
                result.AddLockConfirmationWarning();
            }
            else
            {
                IList<DataAccessObjects.EquipmentActivity> equipmentActivities = this.ConvertToDataAccessEquipmentActivities(data);
                using (var scope = this.dataBaseContextScopeFactory.CreateWithChangeLog<EMEDataContext>(EntityFramework.DbContextScope.DbContextScopeOption.ForceCreateNew, this.changeLog, data.FirstOrDefault().UserName))
                {
                    this.equipmentActivityRepository.Save(equipmentActivities);
                    await scope.SaveChangesAsyncChangeLog<EMEDataContext>(equipmentActivities);
                    ids = equipmentActivities.Select(x => x.EquipmentActivityId).ToList();
                }

                if (equipmentActivities != null && equipmentActivities.Count == 1)
                {
                    DataAccessObjects.EquipmentActivity equipmentActivity = equipmentActivities.FirstOrDefault();
                    if (equipmentActivity.EquipmentActivityErrors != null && equipmentActivity.EquipmentActivityErrors.Any() && data.FirstOrDefault().Activity.ActivityType.Code == BusinessConstant.Move)
                    {
                        result.Messages.Add(new ValidationResult(false, ValidationMessageType.Warning, BusinessConstant.IllogicalSequence));
                    }

                    if (equipmentActivity.EquipmentActivityErrors != null && equipmentActivity.EquipmentActivityErrors.Any() && data.FirstOrDefault().Activity.ActivityType.Code == BusinessConstant.Event)
                    {
                        result.Messages.Add(new ValidationResult(false, ValidationMessageType.Warning, BusinessConstant.IllogicalCombination));
                    }
                }

                result.IdentityValue = string.Join(",", ids);
            }

            return result;
        }

        /// <summary>
        /// Searches the equipment activity.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <returns>Returns the equipment number.</returns>
        public async Task<IList<FleetBase>> SearchEquipmentActivity(string equipmentNumber)
        {
            IList<EquipmentFleet> businessEquipmentActivity = new List<EquipmentFleet>();
            IList<DataAccessObjects.Equipment> equipmentActivity;
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                equipmentActivity = await this.equipmentActivityRepository.SearchEquipmentActivity(equipmentNumber);
            }

            return this.mapper.Map<IList<FleetBase>>(equipmentActivity);
        }

        /// <summary>
        /// Determines whether [has equipment activity duplicate] [the specified equipment activity identifier].
        /// </summary>
        /// <param name="equipmentActivityId">The equipment activity identifier.</param>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityReferentialId">The activity referential identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <param name="voyageId">The voyage identifier.</param>
        /// <param name="feederVoyage">The feeder voyage.</param>
        /// <returns>
        /// Returns Equipment Duplicate.
        /// </returns>
        public async Task<bool> HasEquipmentActivityDuplicate(long equipmentActivityId, long equipmentId, int activityReferentialId, string activityDate, int locationId, int vesselId, int voyageId, string feederVoyage)
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                return await this.equipmentActivityRepository.HasEquipmentActivityDuplicate(equipmentActivityId, equipmentId, activityReferentialId, Convert.ToDateTime(activityDate), locationId, vesselId, voyageId, feederVoyage);
            }
        }

        /// <summary>
        /// Determines whether [has equipment activity valid] [the specified equipment identifier].
        /// </summary>
        /// <param name="equipmentId">The equipment identifier.</param>
        /// <param name="activityDate">The activity date.</param>
        /// <returns>
        /// Returns Equipment valid.
        /// </returns>
        /// &gt;
        public async Task<bool> HasEquipmentActivityValid(long equipmentId, string activityDate)
        {
            using (this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                return await this.equipmentActivityRepository.HasEquipmentActivityValid(equipmentId, Convert.ToDateTime(activityDate));
            }
        }

        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Converts to data access equipment activities.
        /// </summary>
        /// <param name="businessEquipmentActivities">The business equipment activities.</param>
        /// <returns>Returns the equipment activity details.</returns>
        private IList<DataAccessObjects.EquipmentActivity> ConvertToDataAccessEquipmentActivities(IList<EquipmentActivity> businessEquipmentActivities)
        {
            IList<DataAccessObjects.EquipmentActivity> equipmentActivities = new List<DataAccessObjects.EquipmentActivity>();
            IList<DataAccessObjects.EquipmentState> equipmentStates = new List<DataAccessObjects.EquipmentState>();
            using (var scope = this.dataBaseContextScopeFactory.CreateReadOnly())
            {
                equipmentStates = Task.Run(async () => await this.equipmentStateRepository.SearchEquipmentStates()).Result;
            }

            foreach (var item in businessEquipmentActivities)
            {
                item.EquipmentActivityErrors = this.InvokeValidation(item);
                DataAccessObjects.EquipmentActivity equipmentActivitiy = EquipmentActivityExtensions.ToEquipmentActivity(item);
                var logisticsStatus = Task.Run(async () => await this.equipmentStockRepositionRepository.GetLogisticsStatus(item.Activity.ActivityReferentialId)).Result;
                equipmentActivitiy.LogisticsStatusId = (byte?)logisticsStatus?.Id;
                if (equipmentActivitiy.EquipmentActivityId > 0)
                {
                    equipmentActivitiy.EquipmentStateId = equipmentStates.FirstOrDefault(x => x.Code == BusinessConstant.EquipmentStateUpdate).EquipmentStateId;
                }
                else
                {
                    equipmentActivitiy.EquipmentStateId = equipmentStates.FirstOrDefault(x => x.Code == BusinessConstant.EquipmentStateNew).EquipmentStateId;
                }

                equipmentActivities.Add(equipmentActivitiy);
            }

            return equipmentActivities;
        }

        /// <summary>
        /// Gets the equipmen iso code identifier.
        /// </summary>
        /// <param name="isoCodes">The iso codes.</param>
        /// <param name="isoCodeId">The iso code identifier.</param>
        /// <returns>Return Eequipment Code.</returns>
        private EquipmentISOCode GetEquipmenISOCodeId(IList<EquipmentISOCode> isoCodes, int isoCodeId)
        {
            return isoCodes.FirstOrDefault(x => x.EquipmentSizeTypeCodeId == isoCodeId);
        }

        /// <summary>
        /// Gets the equipment activity details.
        /// </summary>
        /// <param name="sizeTypes">The Size Types.</param>
        /// <param name="ports">The Ports.</param>
        /// <param name="terminalDepots">The TerminalDepots.</param>
        /// <param name="vessels">The Vessels.</param>
        /// <param name="locations">The Locations.</param>
        /// <param name="item">The DataAccessObjects Item.</param>
        /// <param name="isoCodes">The Iso Codes.</param>
        /// <returns>Returns the equipment activity details.</returns>
        private EquipmentActivity GetEquipmentActivityDetails(IList<EquipmentSizeType> sizeTypes, IList<Port> ports, IList<TerminalDepot> terminalDepots, IList<Vessel> vessels, IList<Location> locations, DataAccessObjects.EquipmentActivity item, IList<EquipmentISOCode> isoCodes)
        {
            EquipmentActivity equipmentActivity = this.mapper.Map<EquipmentActivity>(item);
            equipmentActivity.Equipment = new Equipment { EquipmentSizeType = this.GetEquipmentSizeTypeById(sizeTypes, item.Equipment.EquipmentSizeTypeId), EquipmentId = item.EquipmentId, EquipmentNumber = item.Equipment.EquipmentNumber, EquipmentISO = this.GetEquipmenISOCodeId(isoCodes, item.Equipment.EquipmentISOId) };
            equipmentActivity.Location = this.mapper.Map<Port>(this.GetPortById(ports, item.LocationId));
            equipmentActivity.PortOfLoad = this.mapper.Map<Port>(this.GetPortById(ports, item.LoadingPortId));
            equipmentActivity.PortOfDischarge = this.mapper.Map<Port>(this.GetPortById(ports, item.DischargePortId));
            equipmentActivity.TransshipmentPort = this.mapper.Map<Port>(this.GetPortById(ports, item.TransshipmentPortId));
            equipmentActivity.TerminalEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.TerminalEquipmentHandlingFacilityId));
            equipmentActivity.DepotEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.DepotEquipmentHandlingFacilityId));
            equipmentActivity.ReturnTerminalEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.ReturnTerminalEquipmentHandlingFacilityId));
            equipmentActivity.ReturnDepotEquipmentHandlingFacility = this.mapper.Map<TerminalDepot>(this.GetTerminalDepotById(terminalDepots, item.ReturnDepotEquipmentHandlingFacilityId));
            equipmentActivity.DestinationLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.DestinationLocationId));
            equipmentActivity.DeliveryLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.DeliveryLocationId));
            equipmentActivity.ReceiptLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.ReceiptLocationId));
            equipmentActivity.ReturnLocation = this.mapper.Map<Location>(this.GetLocationById(locations, item.ReturnLocationId));
            equipmentActivity.Vessel = this.mapper.Map<Vessel>(this.GetVesselById(vessels, item.VesselId));
            if (item.VesselId > 0 && item.VoyageId > 0)
            {
                equipmentActivity.VesselVoyage = VesselVoyageData.GetVesselVoyage(item.VoyageId);
            }
            else if (item.VesselId > 0)
            {
                equipmentActivity.VesselVoyage = new VesselVoyage { Voyage = item.Voyage, Vessel = equipmentActivity.Vessel.LongDisplayName };
            }

            equipmentActivity.Voyage = item.Voyage;

            return equipmentActivity;
        }

        /// <summary>
        /// Gets the equipment size type by identifier.
        /// </summary>
        /// <param name="equipmentSizeTypes">The equipment size types.</param>
        /// <param name="equipmentSizeTypeId">The equipment size type identifier.</param>
        /// <returns>Returns SizeType Id.</returns>
        private EquipmentSizeType GetEquipmentSizeTypeById(IList<EquipmentSizeType> equipmentSizeTypes, int equipmentSizeTypeId)
        {
            return equipmentSizeTypes.FirstOrDefault(x => x.EquipmentSizeTypeId == equipmentSizeTypeId);
        }

        /// <summary>
        /// Gets the location by identifier.
        /// </summary>
        /// <param name="locations">The locations.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <returns>Returns location Id.</returns>
        private Location GetLocationById(IList<Location> locations, int? locationId)
        {
            if (locationId.HasValue && locationId.Value > 0)
            {
                var location = locations.FirstOrDefault(x => x.LocationId == locationId);
                return location;
            }

            return null;
        }

        /// <summary>
        /// Gets the port by identifier.
        /// </summary>
        /// <param name="ports">The ports.</param>
        /// <param name="portId">The port identifier.</param>
        /// <returns>Returns Port Id.</returns>
        private Port GetPortById(IList<Port> ports, int? portId)
        {
            if (portId > 0)
            {
                return ports.FirstOrDefault(x => x.PortId == portId);
            }

            return null;
        }

        /// <summary>
        /// Gets the terminal depot by identifier.
        /// </summary>
        /// <param name="terminalDepots">The terminal depots.</param>
        /// <param name="terminalDepotId">The terminal depot identifier.</param>
        /// <returns>Returns Terminal Depot Id.</returns>
        private TerminalDepot GetTerminalDepotById(IList<TerminalDepot> terminalDepots, int? terminalDepotId)
        {
            if (terminalDepotId > 0)
            {
                return terminalDepots.FirstOrDefault(x => x.EquipmentHandlingFacilityId == terminalDepotId);
            }

            return null;
        }

        /// <summary>
        /// Gets the vessel by identifier.
        /// </summary>
        /// <param name="vessels">The vessels.</param>
        /// <param name="vesselId">The vessel identifier.</param>
        /// <returns>Returns Vessel Id.</returns>
        private Vessel GetVesselById(IList<Vessel> vessels, int? vesselId)
        {
            if (vesselId > 0)
            {
                return vessels.FirstOrDefault(x => x.VesselId == vesselId);
            }

            return null;
        }

        /// <summary>
        /// To the business model equipment fleet.
        /// </summary>
        /// <param name="equipmentActivity">The equipment activity.</param>
        /// <returns>Returns Equipment Activity.</returns>
        private EquipmentFleet ToBusinessModelEquipmentFleet(DataAccessObjects.EquipmentActivity equipmentActivity)
        {
            if (equipmentActivity == null)
            {
                return null;
            }

            EquipmentFleet equipmentFleet = new EquipmentFleet();
            equipmentFleet.Id = equipmentActivity.EquipmentActivityId;
            equipmentFleet.EquipmentNumber = equipmentActivity.Equipment.EquipmentNumber;
            equipmentFleet.HasSOC = equipmentActivity.Equipment.HasSOC;
            if (equipmentActivity.Equipment.EquipmentSizeTypeId > 0)
            {
                equipmentFleet.EquipmentSizeType = Task.Run(() => this.masterDataService.GetEquipmentSizeType(equipmentActivity.Equipment.EquipmentSizeTypeId)).Result;
                equipmentFleet.EquipmentISO = Task.Run(() => this.masterDataService.GetEquipmentISOCode(equipmentActivity.Equipment.EquipmentISOId)).Result;
            }

            return equipmentFleet;
        }

        #endregion Private Methods
    }
}