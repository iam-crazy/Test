﻿//-----------------------------------------------------------------------
// <copyright file = "GeneralCodeDataService.cs" company = "MSC Technology">
//   Mediterranean Shipping Company SA. OneVision Project.
// </copyright>
// <summary>
//   Declare GeneralCodeDataService.
// </summary>
//-----------------------------------------------------------------------
namespace Msc.Logistics.EME.Service.Business
{
    using System;
    using System.Collections.Generic;
    using AutoMapper;
    using Constants;
    using Contracts;
    using Contracts.Objects;

    /// <summary>
    /// Declare GeneralCodeDataService.
    /// </summary>
    public class GeneralCodeDataService : IGeneralCodeDataService
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="GeneralCodeDataService"/> class.
        /// </summary>
        /// <param name="mapper">The mapper.</param>
        /// <exception cref="System.ArgumentNullException">Argument Null Exception.</exception>
        public GeneralCodeDataService(IMapper mapper)
        {
            if (mapper == null)
            {
                throw new ArgumentNullException(nameof(mapper));
            }
        }

        #endregion Constructor

        #region Public Methods

        /// <summary>
        /// Gets the general codes.
        /// </summary>
        /// <param name="code">The general code.</param>
        /// <param name="description">The description.</param>
        /// <param name="referenceName">Name of the reference.</param>
        /// <param name="limit">The limit.</param>
        /// <param name="offset">The offset.</param>
        /// <param name="searchValue">The search Value.</param>
        /// <returns>
        /// Returns The GeneralCode Data.
        /// </returns>
        /// <exception cref="ArgumentNullException">Argument Null Exception.</exception>
        public IList<GeneralCode> GetGeneralCodes(string code, string description, string referenceName, int limit, int offset, string searchValue)
        {
            IList<GeneralCode> data = new List<GeneralCode>();
            if (!string.IsNullOrEmpty(referenceName))
            {
                data = GeneralCodeData.GetGeneralCodes(referenceName);
            }

            return data;
        }

        #endregion Public Methods
    }
}