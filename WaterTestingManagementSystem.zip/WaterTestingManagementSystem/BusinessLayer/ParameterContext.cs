﻿// ------------------------------------------------------------------------------//
// <copyright file="ParameterService.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BusinessLayer.Contract;
using CommonLayer;
using CommonLayer.ViewModel;
using DataAccessLayer;
using DataAccessLayer.Contract;
using MySql.Data.MySqlClient;

namespace BusinessLayer
{
    /// <summary>
    /// Initialize ParameterService class
    /// </summary>
    public class ParameterContext : IParameterContext
    {
        /// <summary>
        /// The i repository
        /// </summary>
        private readonly IExecuteDataRepository iRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugContext"/> class.
        /// </summary>
        public ParameterContext() : this(new ExecuteDataRepository())
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugContext"/> class.
        /// </summary>
        /// <param name="repository">The repository.</param>
        public ParameterContext(IExecuteDataRepository repository)
        {
            iRepository = repository;
        }

        /// <summary>
        /// Gets the specified object connection string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public IList<T> Get<T>(string objConnString, long jobId, string jobTitle)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$jobId",jobId),
                    new MySqlParameter("$jobTitle", jobTitle)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.jobresultSelection.ToString(),
            objCmdParameters: objCmdParameters);
        }

        /// <summary>
        /// Gets the specified object connection string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public IList<T> Get<T>(string objConnString)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("KEYCODE","ALL"),
                    new MySqlParameter("ID", 0)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.WmsParamterSelection.ToString(),
            objCmdParameters: objCmdParameters);
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="Id">           The patient identifier.</param>
        /// <returns></returns>
        public T GetById<T>(string objConnString, long Id)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("KEYCODE", "EDIT"),
                    new MySqlParameter("ID", Id)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.WmsParamterSelection.ToString(),
            objCmdParameters: objCmdParameters).FirstOrDefault();
        }

        /// <summary>
        /// Posts the specified object connection string.
        /// </summary>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public object Post(string objConnString, ParameterModel request)
        {
            MySqlParameter objOutPutValue = new MySqlParameter("$OUTPUT", MySqlDbType.VarChar, 100);
            objOutPutValue.Direction = ParameterDirection.Output;
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$ISSAVE", (request.Id == 0 ? true : false)),
                    new MySqlParameter("$ID", request.Id),
                    new MySqlParameter("$NAME", Utility.ToString(request.Name).Trim()),
                    new MySqlParameter("$ACCEPTABLELIMIT", Utility.ToString(request.AcceptableLimit).Trim()),
                    new MySqlParameter("$PERMISSABLELIMIT", Utility.ToString(request.PermissableLimit).Trim()),
                    new MySqlParameter("$HasAnalyticalPurpose", request.HasAnalyticalPurpose),
                    new MySqlParameter("$HasConstructionPurpose", request.HasConstructionPurpose),
                    new MySqlParameter("$HasDrinkingPurpose", request.HasDrinkingPurpose),
                    new MySqlParameter("$CREATEDBY", request.CreatedBy),
                    objOutPutValue
            };
            return iRepository.ExecuteNonQuery(
            objConString: objConnString,
            objProcName: ProcedureName.WmsParamterInsertUpdate.ToString(),
            objCmdParameters: objCmdParameters);
        }
    }
}