﻿// ------------------------------------------------------------------------------//
// <copyright file="JobDetails.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace BusinessLayer
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using CommonLayer;
    using CommonLayer.ViewModel;
    using Contract;
    using DataAccessLayer;
    using DataAccessLayer.Contract;
    using MySql.Data.MySqlClient;

    /// <summary>
    /// Initialize JobDetails class
    /// </summary>
    public class ConstructionPurposeContext : IConstructionPurposeContext
    {
        /// <summary>
        /// The i repository
        /// </summary>
        private readonly IExecuteDataRepository iRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugContext"/> class.
        /// </summary>
        public ConstructionPurposeContext() : this(new ExecuteDataRepository())
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugContext"/> class.
        /// </summary>
        /// <param name="repository">The repository.</param>
        public ConstructionPurposeContext(IExecuteDataRepository repository)
        {
            iRepository = repository;
        }

        /// <summary>
        /// Gets the specified object connection string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public IList<T> Get<T>(string objConnString)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$KEYCODE","ALL"),
                    new MySqlParameter("$ID", 0)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.WmsParamterSelection.ToString(),
            objCmdParameters: objCmdParameters);
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="Id">           The patient identifier.</param>
        /// <returns></returns>
        public T GetById<T>(string objConnString, long Id)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$KEYCODE", "EDIT"),
                    new MySqlParameter("$ID", Id)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.WmsParamterSelection.ToString(),
            objCmdParameters: objCmdParameters).FirstOrDefault();
        }

        /// <summary>
        /// Posts the specified object connection string.
        /// </summary>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public object Post(string objConnString, JobDetailsModel request)
        {
            MySqlParameter objOutPutValue = new MySqlParameter("$OUTPUT", MySqlDbType.VarChar, 100);
            objOutPutValue.Direction = ParameterDirection.Output;
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$ISSAVE", (request.Id == 0 ? true : false)),
                    new MySqlParameter("$ID", request.Id),
                    new MySqlParameter("$CHALLANNO", Utility.ToString(request.ChallanNo).Trim()),
                    new MySqlParameter("$CHALLANDATE", request.ChallanDate),
                    new MySqlParameter("$DATEOFCOLLECTION",request.DateOfCollection),
                    new MySqlParameter("$DATEOFRECEIPT", request.DateOfReceipt),
                    new MySqlParameter("$SOURCEASPERLABEL", Utility.ToString(request.SourceAsPerLabel)),
                    new MySqlParameter("$SAMPLESENTBY", Utility.ToString(request.SampleSentBy)),
                    new MySqlParameter("$CREATEDBY", request.CreatedBy),
                    new MySqlParameter("$JOBTITLE", request.JobTitle),
                    objOutPutValue
            };
            return iRepository.ExecuteNonQuery(
            objConString: objConnString,
            objProcName: ProcedureName.WmsJobDetailsInsertUpdate.ToString(),
            objCmdParameters: objCmdParameters);
        }

        /// <summary>
        /// Posts the specified object connection string.
        /// </summary>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public object Post(string objConnString, JobResult request, Int64 id)
        {
            MySqlParameter objOutPutValue = new MySqlParameter("$OUTPUT", MySqlDbType.VarChar, 100);
            objOutPutValue.Direction = ParameterDirection.Output;
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$ISSAVE", (request.Id == 0 ? true : false)),
                    new MySqlParameter("$ID", request.Id),
                    new MySqlParameter("$JOBID", id),
                    new MySqlParameter("$PARAMETER", request.Name),
                    new MySqlParameter("$RESULT",request.Result),
                    new MySqlParameter("$PERMISSABLELIMIT",request.PermissableLimit),
                    new MySqlParameter("$ACCEPTABLELIMIT", request.AcceptableLimit),
                    objOutPutValue
            };
            return iRepository.ExecuteNonQuery(
            objConString: objConnString,
            objProcName: ProcedureName.WmsJobResultInsertUpdate.ToString(),
            objCmdParameters: objCmdParameters);
        }
    }
}