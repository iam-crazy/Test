﻿// ------------------------------------------------------------------------------//
// <copyright file="JobSummary.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace BusinessLayer
{
    using System;
    using System.Collections.Generic;
    using CommonLayer;
    using CommonLayer.ViewModel;
    using Contract;
    using DataAccessLayer;
    using DataAccessLayer.Contract;
    using MySql.Data.MySqlClient;

    /// <summary>
    /// Initialize JobSummary class
    /// </summary>
    public class JobSummaryContext : IJobSummaryContext
    {
        /// <summary>
        /// The i repository
        /// </summary>
        private readonly IExecuteDataRepository iRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugContext"/> class.
        /// </summary>
        public JobSummaryContext() : this(new ExecuteDataRepository())
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugContext"/> class.
        /// </summary>
        /// <param name="repository">The repository.</param>
        public JobSummaryContext(IExecuteDataRepository repository)
        {
            iRepository = repository;
        }

        /// <summary>
        /// Gets the specified object connection string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        public IList<T> Get<T>(string objConnString, JobSummarySearchRequest request)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$KEYCODE",request.Key),
                    new MySqlParameter("$CHALLANNO", request.ChallanNo),
                    new MySqlParameter("$FROMDATE", request.FromDate),
                    new MySqlParameter("$TODATE", request.ToDate)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.JobSummarySelection.ToString(),
            objCmdParameters: objCmdParameters);
        }

        public IList<T> GetJobResult<T>(string objConnString, Int64 jobId, string jobTitle)
        {
            MySqlParameter[] objCmdParameters =
               {
                    new MySqlParameter("$jobId",jobId),
                    new MySqlParameter("$jobTitle", jobTitle)
                };
            return iRepository.ExecuteDataReaderMapToList<T>(
            objConString: objConnString,
            objProcName: ProcedureName.JobresultSelection.ToString(),
            objCmdParameters: objCmdParameters);
        }
    }
}