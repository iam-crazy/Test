﻿// ------------------------------------------------------------------------------//
// <copyright file="IJobDetailsContext.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace BusinessLayer.Contract
{
    using System;
    using System.Collections.Generic;
    using CommonLayer.ViewModel;

    /// <summary>
    /// Initialize IJobDetailsContext class
    /// </summary>
    public interface IJobDetailsContext
    {
        /// <summary>
        /// Gets the specified object connection string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        IList<T> Get<T>(string objConnString, string keyCode);

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="id">           The identifier.</param>
        /// <returns></returns>
        T GetById<T>(string objConnString, long id);

        /// <summary>
        /// Posts the specified object connection string.
        /// </summary>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        object Post(string objConnString, JobDetailsModel request);

        /// <summary>
        /// Posts the specified object connection string.
        /// </summary>
        /// <param name="objConnString">The object connection string.</param>
        /// <param name="request">      The request.</param>
        /// <returns></returns>
        object Post(string objConnString, JobResult request, Int64 id);
    }
}