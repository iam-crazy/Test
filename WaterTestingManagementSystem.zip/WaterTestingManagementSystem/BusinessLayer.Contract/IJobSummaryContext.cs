﻿// ------------------------------------------------------------------------------//
// <copyright file="IJobSummary.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Collections.Generic;
using CommonLayer.ViewModel;

namespace BusinessLayer.Contract
{
    /// <summary>
    /// Initialize IJobSummary interface
    /// </summary>
    public interface IJobSummaryContext
    {
        IList<T> Get<T>(string objConnString, JobSummarySearchRequest request);

        IList<T> GetJobResult<T>(string objConnString, Int64 jobId, string jobTitle);
    }
}