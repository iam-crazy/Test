﻿// ------------------------------------------------------------------------------//
// <copyright file="IExecuteDataRepository.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace DataAccessLayer.Contract
{
    using System.Collections.Generic;
    using CommonLayer;
    using MySql.Data.MySqlClient;

    /// <summary>
    /// Initialize IExecuteDataRepository class
    /// </summary>
    public interface IExecuteDataRepository
    {
        List<T> ExecuteDataReaderMapToList<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objRowCount);

        List<T> ExecuteDataReaderMapToList<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters);

        List<T> ExecuteDataReaderMapToList<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objPhoneNo, OutVar<string> objMailId);

        List<T> ExecuteDataReaderMapToListNotAsync<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objPhoneNo, OutVar<string> objMailId);

        List<T> ExecuteDataReaderMapToListNotAsync<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters);

        List<T> ExecuteDataReaderMapToListNotAsync<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objRowCount);

        object ExecuteNonQuery(string objConString, string objProcName, MySqlParameter[] objCmdParameters);
    }
}