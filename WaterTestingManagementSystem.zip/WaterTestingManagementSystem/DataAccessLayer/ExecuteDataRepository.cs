﻿// ------------------------------------------------------------------------------//
// <copyright file="ExecuteDataRepository.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace DataAccessLayer
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Reflection;
    using CommonLayer;
    using Contract;
    using MySql.Data.MySqlClient;

    /// <summary>
    /// Initialize ExecuteDataRepository class
    /// </summary>
    public class ExecuteDataRepository : IExecuteDataRepository
    {
        /// <summary>
        /// Method for Execute DataReader Map To List
        /// </summary>
        /// <typeparam name="T">Generic parameter</typeparam>
        /// <param name="objConString">    Connection String</param>
        /// <param name="objProcName">     Procedure Name</param>
        /// <param name="objCmdParameters">Command Parameters</param>
        /// <param name="objRowCount">     Row Count</param>
        /// <returns></returns>
        public List<T> ExecuteDataReaderMapToList<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objRowCount)
        {
            List<T> objList = new List<T>();
            T obj = default(T);
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                objConn.Open();
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }
                    using (MySqlDataReader objDataReader = objCmd.ExecuteReader())
                    {
                        while (objDataReader.Read())
                        {
                            obj = Activator.CreateInstance<T>();
                            foreach (PropertyInfo prop in obj.GetType().GetProperties())
                            {
                                if (Enumerable.Range(0, objDataReader.FieldCount).Any(i => objDataReader.GetName(i).ToUpper() == prop.Name.ToUpper()))
                                {
                                    if (!object.Equals(objDataReader[prop.Name], DBNull.Value))
                                    {
                                        prop.SetValue(obj, objDataReader[prop.Name], null);
                                    }
                                }
                            }
                            if (obj != null)
                            {
                                objList.Add(obj);
                            }
                        }
                    }
                    objRowCount.Value = Utility.ToString(objCmd.Parameters["@P_RECORD_COUNT"].Value);
                }
            }
            return objList;
        }

        /// <summary>
        /// Method for Execute DataReader Map To List
        /// </summary>
        /// <typeparam name="T">Generic parameter</typeparam>
        /// <param name="objConString">    Connection String</param>
        /// <param name="objProcName">     Procedure Name</param>
        /// <param name="objCmdParameters">Command Parameters</param>
        /// <returns>List of data</returns>
        public List<T> ExecuteDataReaderMapToList<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters)
        {
            List<T> objList = new List<T>();
            T obj = default(T);
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                objConn.Open();
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }
                    using (MySqlDataReader objDataReader = objCmd.ExecuteReader())
                    {
                        while (objDataReader.Read())
                        {
                            obj = Activator.CreateInstance<T>();
                            foreach (PropertyInfo prop in obj.GetType().GetProperties())
                            {
                                if (Enumerable.Range(0, objDataReader.FieldCount).Any(i => objDataReader.GetName(i).ToUpper() == prop.Name.ToUpper()))
                                {
                                    if (!object.Equals(objDataReader[prop.Name], DBNull.Value))
                                    {
                                        prop.SetValue(obj, objDataReader[prop.Name], null);
                                    }
                                }
                            }
                            if (obj != null)
                            {
                                objList.Add(obj);
                            }
                        }
                    }
                }
            }
            return objList;
        }

        /// <summary>
        /// Method for Execute DataReader Map To List
        /// </summary>
        /// <typeparam name="T">Generic parameter</typeparam>
        /// <param name="objConString">    Connection String</param>
        /// <param name="objProcName">     Procedure Name</param>
        /// <param name="objCmdParameters">Command Parameters</param>
        /// <returns>List of data</returns>
        public List<T> ExecuteDataReaderMapToList<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objPhoneNo, OutVar<string> objMailId)
        {
            List<T> objList = new List<T>();
            T obj = default(T);
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                objConn.Open();
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }

                    using (MySqlDataReader objDataReader = objCmd.ExecuteReader())
                    {
                        if (objDataReader.HasRows)
                        {
                            while (objDataReader.Read())
                            {
                                obj = Activator.CreateInstance<T>();
                                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                                {
                                    if (Enumerable.Range(0, objDataReader.FieldCount).Any(i => objDataReader.GetName(i).ToUpper() == prop.Name.ToUpper()))
                                    {
                                        if (!object.Equals(objDataReader[prop.Name], DBNull.Value))
                                        {
                                            prop.SetValue(obj, objDataReader[prop.Name], null);
                                        }
                                    }
                                }
                                if (obj != null)
                                {
                                    objList.Add(obj);
                                }
                            }
                        }
                    }
                    objPhoneNo.Value = Utility.ToString(objCmd.Parameters["@PhoneNumber"].Value);
                    objMailId.Value = Utility.ToString(objCmd.Parameters["@MailId"].Value);
                }
            }
            return objList;
        }

        /// <summary>
        /// Method for Execute DataReader Map To List
        /// </summary>
        /// <typeparam name="T">Generic parameter</typeparam>
        /// <param name="objConString">    Connection String</param>
        /// <param name="objProcName">     Procedure Name</param>
        /// <param name="objCmdParameters">Command Parameters</param>
        /// <param name="objRowCount">     Row Count</param>
        /// <returns></returns>
        public List<T> ExecuteDataReaderMapToListNotAsync<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objRowCount)
        {
            List<T> objList = new List<T>();
            T obj = default(T);
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                objConn.Open();
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }
                    using (MySqlDataReader objDataReader = objCmd.ExecuteReader())
                    {
                        while (objDataReader.Read())
                        {
                            obj = Activator.CreateInstance<T>();
                            foreach (PropertyInfo prop in obj.GetType().GetProperties())
                            {
                                if (Enumerable.Range(0, objDataReader.FieldCount).Any(i => objDataReader.GetName(i).ToUpper() == prop.Name.ToUpper()))
                                {
                                    if (!object.Equals(objDataReader[prop.Name], DBNull.Value))
                                    {
                                        prop.SetValue(obj, objDataReader[prop.Name], null);
                                    }
                                }
                            }
                            if (obj != null)
                            {
                                objList.Add(obj);
                            }
                        }
                    }
                    objRowCount.Value = Utility.ToString(objCmd.Parameters["@P_RECORD_COUNT"].Value);
                }
            }
            return objList;
        }

        /// <summary>
        /// Method for Execute DataReader Map To List
        /// </summary>
        /// <typeparam name="T">Generic parameter</typeparam>
        /// <param name="objConString">    Connection String</param>
        /// <param name="objProcName">     Procedure Name</param>
        /// <param name="objCmdParameters">Command Parameters</param>
        /// <returns>List of data</returns>
        public List<T> ExecuteDataReaderMapToListNotAsync<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters)
        {
            List<T> objList = new List<T>();
            T obj = default(T);
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                objConn.Open();
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }
                    using (MySqlDataReader objDataReader = objCmd.ExecuteReader())
                    {
                        while (objDataReader.Read())
                        {
                            obj = Activator.CreateInstance<T>();
                            foreach (PropertyInfo prop in obj.GetType().GetProperties())
                            {
                                if (Enumerable.Range(0, objDataReader.FieldCount).Any(i => objDataReader.GetName(i).ToUpper() == prop.Name.ToUpper()))
                                {
                                    if (!object.Equals(objDataReader[prop.Name], DBNull.Value))
                                    {
                                        prop.SetValue(obj, objDataReader[prop.Name], null);
                                    }
                                }
                            }
                            if (obj != null)
                            {
                                objList.Add(obj);
                            }
                        }
                    }
                }
            }
            return objList;
        }

        /// <summary>
        /// Method for Execute DataReader Map To List
        /// </summary>
        /// <typeparam name="T">Generic parameter</typeparam>
        /// <param name="objConString">    Connection String</param>
        /// <param name="objProcName">     Procedure Name</param>
        /// <param name="objCmdParameters">Command Parameters</param>
        /// <returns>List of data</returns>
        public List<T> ExecuteDataReaderMapToListNotAsync<T>(string objConString, string objProcName, MySqlParameter[] objCmdParameters, OutVar<string> objPhoneNo, OutVar<string> objMailId)
        {
            List<T> objList = new List<T>();
            T obj = default(T);
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                objConn.Open();
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }

                    using (MySqlDataReader objDataReader = objCmd.ExecuteReader())
                    {
                        if (objDataReader.HasRows)
                        {
                            while (objDataReader.Read())
                            {
                                obj = Activator.CreateInstance<T>();
                                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                                {
                                    if (Enumerable.Range(0, objDataReader.FieldCount).Any(i => objDataReader.GetName(i).ToUpper() == prop.Name.ToUpper()))
                                    {
                                        if (!object.Equals(objDataReader[prop.Name], DBNull.Value))
                                        {
                                            prop.SetValue(obj, objDataReader[prop.Name], null);
                                        }
                                    }
                                }
                                if (obj != null)
                                {
                                    objList.Add(obj);
                                }
                            }
                        }
                    }
                    objPhoneNo.Value = Utility.ToString(objCmd.Parameters["@PhoneNumber"].Value);
                    objMailId.Value = Utility.ToString(objCmd.Parameters["@MailId"].Value);
                }
            }
            return objList;
        }

        public object ExecuteNonQuery(string objConString, string objProcName, MySqlParameter[] objCmdParameters)
        {
            object objResult = "";
            using (MySqlConnection objConn = new MySqlConnection(objConString))
            {
                if (objConn.State != ConnectionState.Open)
                {
                    objConn.Open();
                }
                using (MySqlCommand objCmd = new MySqlCommand())
                {
                    objCmd.Connection = objConn;
                    objCmd.CommandType = CommandType.StoredProcedure;
                    objCmd.CommandText = objProcName;
                    if (objCmdParameters != null)
                    {
                        objCmd.Parameters.AddRange(objCmdParameters);
                    }
                    objCmd.ExecuteNonQuery();
                    objResult = objCmd.Parameters["$OUTPUT"].Value;
                    objConn.Close();
                }
            }
            return objResult;
        }
    }
}