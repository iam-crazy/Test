﻿// ------------------------------------------------------------------------------//
// <copyright file="XmlParse.cs">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    /// <summary>
    /// Initialize XmlParse class
    /// </summary>
    public static class XmlParse
    {
        /// <summary>
        /// Datas the table to list.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="table">The table.</param>
        /// <returns></returns>
        public static IList<T> DataTableToList<T>(this DataTable table) where T : new()
        {
            IList<PropertyInfo> properties = typeof(T).GetProperties().ToList();
            IList<T> result = new List<T>();

            foreach (var row in table.Rows)
            {
                var item = CreateItemFromRow<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }

        /// <summary>
        /// Reads the x ml.
        /// </summary>
        /// <param name="xmlPath">The XML path.</param>
        /// <returns></returns>
        public static List<T> ReadXMl<T>(this string xmlPath) where T : new()
        {
            List<T> listOfData = new List<T>();
            if (File.Exists(xmlPath))
            {
                DataSet objDtPdSummery = new DataSet("grdPdSummery");
                objDtPdSummery.ReadXml(xmlPath);
                if (objDtPdSummery.Tables.Count > 0)
                {
                    DataTable listOfDetails = objDtPdSummery.Tables[0];
                    if (listOfDetails != null && listOfDetails.Rows.Count > 0)
                    {
                        listOfData = listOfDetails.DataTableToList<T>().ToList();
                    }
                }
            }
            return listOfData;
        }

        /// <summary>
        /// To the data table.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="items">The items.</param>
        /// <returns></returns>
        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        /// <summary>
        /// Creates the item from row.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="row">       The row.</param>
        /// <param name="properties">The properties.</param>
        /// <returns></returns>
        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties) where T : new()
        {
            T item = new T();
            var objT = Activator.CreateInstance<T>();
            foreach (var property in properties)
            {
                if (row.Table.Columns.Contains(property.Name))
                {
                    PropertyInfo pI = objT.GetType().GetProperty(property.Name);
                    property.SetValue(item, row[property.Name] == DBNull.Value ? null : Convert.ChangeType(row[property.Name], pI.PropertyType), null);
                }
            }
            return item;
        }
    }
}