﻿// ------------------------------------------------------------------------------//
// <copyright file="Utility.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer
{
    using System;

    /// <summary>
    /// Initialize Utility class
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// Converts the int16.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value">The value.</param>
        /// <returns>Return short data.</returns>
        public static short ConvertInt16<T>(T value)
        {
            if (value == null)
            {
                return default(short);
            }

            string input = value.ToString();
            short resout;
            return short.TryParse(input, out resout) ? resout : default(short);
        }

        /// <summary>
        /// This is method is used for Integer Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="parameterName">Integer value.</param>
        /// <returns>Returns The Integer Value.</returns>
        public static int ConvertInt32<T>(T parameterName)
        {
            if (parameterName == null)
            {
                return default(int);
            }

            string input = parameterName.ToString();
            int resout;
            return int.TryParse(input, out resout) ? resout : default(int);
        }

        /// <summary>
        /// This method is used for Long conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Long value.</param>
        /// <returns>Returns The Long Value.</returns>
        public static long ConvertInt64<T>(T value)
        {
            if (value == null)
            {
                return default(long);
            }

            string input = value.ToString();
            long resout;
            return long.TryParse(input, out resout) ? resout : default(long);
        }

        /// <summary>
        /// This method is used for boolean conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Boolean value.</param>
        /// <returns>Returns The Boolean Value.</returns>
        public static bool ToBoolean<T>(T value)
        {
            if (value == null)
            {
                return default(bool);
            }

            string input = value.ToString();
            bool resout;
            return bool.TryParse(input, out resout) ? resout : default(bool);
        }

        /// <summary>
        /// This method is used for Character Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Character value.</param>
        /// <returns>Returns The Character Value.</returns>
        public static char ToChar<T>(T value)
        {
            if (value == null)
            {
                return default(char);
            }

            string input = value.ToString();
            char resout;
            return char.TryParse(input, out resout) ? resout : default(char);
        }

        /// <summary>
        /// This method is used for Date Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Date value.</param>
        /// <returns>Returns The DateTime Value.</returns>
        public static DateTime ToDate<T>(T value)
        {
            if (value == null)
            {
                return default(DateTime);
            }

            string input = value.ToString();
            DateTime resout;
            return DateTime.TryParse(input, out resout) ? resout : default(DateTime);
        }

        /// <summary>
        /// This method is used for DateTime Offset Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Date value.</param>
        /// <returns>Returns The DateTime offset Value.</returns>
        public static DateTimeOffset ToDateTimeOffset<T>(T value)
        {
            if (value == null)
            {
                return default(DateTimeOffset);
            }

            string input = value.ToString();
            DateTimeOffset resout;
            return DateTimeOffset.TryParse(input, out resout) ? resout : default(DateTimeOffset);
        }

        /// <summary>
        /// This method is used for Decimal Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Decimal value.</param>
        /// <returns>Returns The Value.</returns>
        public static decimal ToDecimal<T>(T value)
        {
            if (value == null)
            {
                return default(decimal);
            }

            string input = value.ToString();
            decimal resout;
            return decimal.TryParse(input, out resout) ? resout : default(decimal);
        }

        /// <summary>
        /// This method is used for Double Conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">Double value.</param>
        /// <returns>Returns The Value.</returns>
        public static double ToDouble<T>(T value)
        {
            if (value == null)
            {
                return default(double);
            }

            string input = value.ToString();
            double resout;
            return double.TryParse(input, out resout) ? resout : default(double);
        }

        /// <summary>
        /// This method is used for string conversion.
        /// </summary>
        /// <typeparam name="T">Base type.</typeparam>
        /// <param name="value">String value.</param>
        /// <returns>Returns The String Value.</returns>
        public static string ToString<T>(T value)
        {
            if (value == null)
            {
                return string.Empty;
            }
            else
            {
                return value.ToString();
            }
        }

        /// <summary>
        /// This method is used to split a string to an string array.
        /// </summary>
        /// <param name="value">    Multi-line String.</param>
        /// <param name="separator">String separator.</param>
        /// <returns>Returns String Array based on separator.</returns>
        public static string[] ToStringArray(this string value, string separator)
        {
            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            if (string.IsNullOrEmpty(separator))
            {
                string[] arrayvalue = new string[1];
                arrayvalue[0] = value;
                return arrayvalue;
            }

            return value.Split(separator.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
        }

        /// <summary>
        /// This method is used to split a string to an string array by splitting the "\r\n".
        /// </summary>
        /// <param name="value">Multi-line String.</param>
        /// <returns>Returns String Array based on "\r\n".</returns>
        public static string[] ToStringArray(this string value)
        {
            return value.ToStringArray(separator: "\r\n");
        }
    }
}