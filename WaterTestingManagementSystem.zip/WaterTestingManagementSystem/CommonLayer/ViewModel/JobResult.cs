﻿// ------------------------------------------------------------------------------//
// <copyright file="DrinkingPurposeGridModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//

using System;

namespace CommonLayer.ViewModel
{
    /// <summary>
    /// Initialize DrinkingPurposeGridModel class
    /// </summary>
    public class JobResult : BaseModel
    {
        /// <summary>
        /// Gets or sets the acceptable limit.
        /// </summary>
        /// <value>The acceptable limit.</value>
        private string acceptableLimit;

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        private long id;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        private string jobTitle;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        private string name;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        private Int64 parameterId;

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        private string permissableLimit;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        private string result;

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        private Int64 serialNo;

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public string AcceptableLimit
        {
            get { return acceptableLimit; }
            set
            {
                if (value != acceptableLimit)
                {
                    acceptableLimit = value;
                    OnPropertyChanged("AcceptableLimit");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public long Id
        {
            get { return id; }
            set
            {
                if (value != id)
                {
                    id = value;
                    OnPropertyChanged("Id");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public string JobTitle
        {
            get { return jobTitle; }
            set
            {
                if (value != jobTitle)
                {
                    jobTitle = value;
                    OnPropertyChanged("JobTitle");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public string Name
        {
            get { return name; }
            set
            {
                if (value != name)
                {
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public Int64 ParameterId
        {
            get { return parameterId; }
            set
            {
                if (value != parameterId)
                {
                    parameterId = value;
                    OnPropertyChanged("ParameterId");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public string PermissableLimit
        {
            get { return permissableLimit; }
            set
            {
                if (value != permissableLimit)
                {
                    permissableLimit = value;
                    OnPropertyChanged("PermissableLimit");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public string Result
        {
            get { return result; }
            set
            {
                if (value != result)
                {
                    result = value;
                    OnPropertyChanged("Result");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public Int64
            SerialNo
        {
            get { return serialNo; }
            set
            {
                if (value != serialNo)
                {
                    serialNo = value;
                    OnPropertyChanged("SerialNo");
                }
            }
        }
    }
}