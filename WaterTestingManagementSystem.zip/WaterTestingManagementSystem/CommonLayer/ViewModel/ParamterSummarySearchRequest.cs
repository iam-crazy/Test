﻿// ------------------------------------------------------------------------------//
// <copyright file="ParamterSummarySearchRequest.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer.ViewModel
{
    /// <summary>
    /// Initialize ParamterSummarySearchRequest class
    /// </summary>
    public class ParamterSummarySearchRequest
    {
        /// <summary>
        /// Gets or sets the name of the patient.
        /// </summary>
        /// <value>The name of the patient.</value>
        public string Name { get; set; }
    }
}