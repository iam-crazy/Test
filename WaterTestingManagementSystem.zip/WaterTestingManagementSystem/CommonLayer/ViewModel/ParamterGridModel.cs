﻿// ------------------------------------------------------------------------------//
// <copyright file="ParamterGridModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;

namespace CommonLayer.ViewModel
{
    /// <summary>
    /// </summary>
    public class ParamterGridModel
    {
        /// <summary>
        /// Gets or sets the acceptable limit.
        /// </summary>
        /// <value>The acceptable limit.</value>
        public string AcceptableLimit { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>The created on.</value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public UInt64 HasAnalyticalPurpose { get; set; }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public UInt64 HasConstructionPurpose { get; set; }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public UInt64 HasDrinkingPurpose { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        public string ModifiedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>The created on.</value>
        public DateTime? ModifiedOn { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        public string PermissableLimit { get; set; }

        /// <summary>
        /// Gets or sets the serial no.
        /// </summary>
        /// <value>The serial no.</value>
        public Int64 SerialNo { get; set; }
    }
}