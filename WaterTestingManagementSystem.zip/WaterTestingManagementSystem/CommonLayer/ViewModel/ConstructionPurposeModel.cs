﻿// ------------------------------------------------------------------------------//
// <copyright file="DrinkingPurposeModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer.ViewModel
{
    using System;

    /// <summary>
    /// Initialize DrinkingPurposeModel class
    /// </summary>
    public class ConstructionPurposeModel : BaseModel
    {
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        private DateTime? challanDate;

        /// <summary>
        /// Gets or sets the acceptable limit.
        /// </summary>
        /// <value>The acceptable limit.</value>
        private string challanNo;

        private string createdBy;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        private DateTime? dateOfCollection;

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        private DateTime? dateOfReceipt;

        private long id;

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        private string jobTitle;

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        private string sampleSentBy;

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        private string sourceAsPerLabel;

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public DateTime? ChallanDate
        {
            get { return challanDate; }
            set
            {
                if (value != challanDate)
                {
                    challanDate = value;
                    OnPropertyChanged("ChallanDate");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public string ChallanNo
        {
            get { return challanNo; }
            set
            {
                if (value != challanNo)
                {
                    challanNo = value;
                    OnPropertyChanged("ChallanNo");
                }
            }
        }

        public string CreatedBy
        {
            get { return createdBy; }
            set
            {
                if (value != createdBy)
                {
                    createdBy = value;
                    OnPropertyChanged("CreatedBy");
                }
            }
        }

        public DateTime? DateOfCollection
        {
            get { return dateOfCollection; }
            set
            {
                if (value != dateOfCollection)
                {
                    dateOfCollection = value;
                    OnPropertyChanged("DateOfCollection");
                }
            }
        }

        public DateTime? DateOfReceipt
        {
            get { return dateOfReceipt; }
            set
            {
                if (value != dateOfReceipt)
                {
                    dateOfReceipt = value;
                    OnPropertyChanged("DateOfReceipt");
                }
            }
        }

        /// <summary>
        /// Gets or sets the drug type identifier.
        /// </summary>
        /// <value>The drug type identifier.</value>
        public long Id
        {
            get { return id; }
            set
            {
                if (value != id)
                {
                    id = value;
                    OnPropertyChanged("Id");
                }
            }
        }

        public string JobTitle
        {
            get { return jobTitle; }
            set
            {
                if (value != jobTitle)
                {
                    jobTitle = value;
                    OnPropertyChanged("JobTitle");
                }
            }
        }

        public string SampleSentBy
        {
            get { return sampleSentBy; }
            set
            {
                if (value != sampleSentBy)
                {
                    sampleSentBy = value;
                    OnPropertyChanged("SampleSentBy");
                }
            }
        }

        public string SourceAsPerLabel
        {
            get { return sourceAsPerLabel; }
            set
            {
                if (value != sourceAsPerLabel)
                {
                    sourceAsPerLabel = value;
                    OnPropertyChanged("SourceAsPerLabel");
                }
            }
        }
    }
}