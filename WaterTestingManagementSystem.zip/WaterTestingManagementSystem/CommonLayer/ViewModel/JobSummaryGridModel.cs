﻿// ------------------------------------------------------------------------------//
// <copyright file="JobSummaryGridModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer.ViewModel
{
    using System;

    /// <summary>
    /// Initialize JobSummaryGridModel class
    /// </summary>
    public class JobSummaryGridModel
    {
        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        public DateTime? ChallanDate { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string ChallanNo { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>The created on.</value>
        public string CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the acceptable limit.
        /// </summary>
        /// <value>The acceptable limit.</value>
        public DateTime? DateOfCollection { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public long Id { get; set; }

        /// <summary>
        /// Gets or sets the created by.
        /// </summary>
        /// <value>The created by.</value>
        public string ModifiedBy { get; set; }

        /// <summary>
        /// Gets or sets the created on.
        /// </summary>
        /// <value>The created on.</value>
        public string ModifiedOn { get; set; }

        /// <summary>
        /// Gets or sets the permissable limit.
        /// </summary>
        /// <value>The permissable limit.</value>
        public string Purpose { get; set; }

        /// <summary>
        /// Gets or sets the serial no.
        /// </summary>
        /// <value>The serial no.</value>
        public Int64 SerialNo { get; set; }

        /// <summary>
        /// Gets or sets the Status.
        /// </summary>
        /// <value>The Status.</value>
        public string Status { get; set; }
    }
}