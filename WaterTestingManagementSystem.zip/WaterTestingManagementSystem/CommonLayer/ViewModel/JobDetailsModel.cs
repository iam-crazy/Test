﻿// ------------------------------------------------------------------------------//
// <copyright file="DrinkingPurposeModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer.ViewModel
{
    using System;

    /// <exclude/>
    public class JobDetailsModel : BaseModel
    {
        public string report;

        /// <exclude/>
        private Decimal? amount;

        /// <exclude/>
        private DateTime? challanDate;

        /// <exclude/>
        private string challanNo;

        /// <exclude/>
        private string createdBy;

        /// <exclude/>
        private DateTime? dateOfCollection;

        /// <exclude/>
        private DateTime? dateOfReceipt;

        /// <exclude/>
        private long id;

        /// <exclude/>
        private string jobTitle;

        /// <exclude/>
        private string result;

        /// <exclude/>
        private string sampleSentBy;

        private Int64 serialNo;

        /// <exclude/>
        private string sourceAsPerLabel;

        /// <exclude/>
        private string status;

        /// <exclude/>
        private string usage;

        /// <exclude/>
        public decimal? Amount
        {
            get { return amount; }
            set
            {
                if (value != amount)
                {
                    amount = value;
                    OnPropertyChanged("Amount");
                }
            }
        }

        /// <exclude/>
        public DateTime? ChallanDate
        {
            get { return challanDate; }
            set
            {
                if (value != challanDate)
                {
                    challanDate = value;
                    OnPropertyChanged("ChallanDate");
                }
            }
        }

        /// <exclude/>
        public string ChallanNo
        {
            get { return challanNo; }
            set
            {
                if (value != challanNo)
                {
                    challanNo = value;
                    OnPropertyChanged("ChallanNo");
                }
            }
        }

        /// <exclude/>
        public string CreatedBy
        {
            get { return createdBy; }
            set
            {
                if (value != createdBy)
                {
                    createdBy = value;
                    OnPropertyChanged("CreatedBy");
                }
            }
        }

        /// <exclude/>
        public DateTime? DateOfCollection
        {
            get { return dateOfCollection; }
            set
            {
                if (value != dateOfCollection)
                {
                    dateOfCollection = value;
                    OnPropertyChanged("DateOfCollection");
                }
            }
        }

        /// <exclude/>
        public DateTime? DateOfReceipt
        {
            get { return dateOfReceipt; }
            set
            {
                if (value != dateOfReceipt)
                {
                    dateOfReceipt = value;
                    OnPropertyChanged("DateOfReceipt");
                }
            }
        }

        /// <exclude/>
        public long Id
        {
            get { return id; }
            set
            {
                if (value != id)
                {
                    id = value;
                    OnPropertyChanged("Id");
                }
            }
        }

        /// <exclude/>
        public string JobTitle
        {
            get { return jobTitle; }
            set
            {
                if (value != jobTitle)
                {
                    jobTitle = value;
                    OnPropertyChanged("JobTitle");
                }
            }
        }

        /// <exclude/>
        public string Report
        {
            get { return report; }
            set
            {
                if (value != report)
                {
                    report = value;
                    OnPropertyChanged("Report");
                }
            }
        }

        /// <exclude/>
        public string Result
        {
            get { return result; }
            set
            {
                if (value != result)
                {
                    result = value;
                    OnPropertyChanged("Result");
                }
            }
        }

        /// <exclude/>
        public string SampleSentBy
        {
            get { return sampleSentBy; }
            set
            {
                if (value != sampleSentBy)
                {
                    sampleSentBy = value;
                    OnPropertyChanged("SampleSentBy");
                }
            }
        }

        /// <exclude/>
        public Int64 SerialNo
        {
            get { return serialNo; }
            set
            {
                if (value != serialNo)
                {
                    serialNo = value;
                    OnPropertyChanged("SerialNo");
                }
            }
        }

        /// <exclude/>
        public string SourceAsPerLabel
        {
            get { return sourceAsPerLabel; }
            set
            {
                if (value != sourceAsPerLabel)
                {
                    sourceAsPerLabel = value;
                    OnPropertyChanged("SourceAsPerLabel");
                }
            }
        }

        /// <exclude/>
        public string Status
        {
            get { return status; }
            set
            {
                if (value != status)
                {
                    status = value;
                    OnPropertyChanged("Status");
                }
            }
        }

        /// <exclude/>
        public string Usage
        {
            get { return usage; }
            set
            {
                if (value != usage)
                {
                    usage = value;
                    OnPropertyChanged("Usage");
                }
            }
        }
    }
}