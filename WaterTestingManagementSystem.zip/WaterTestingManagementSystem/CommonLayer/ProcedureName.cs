﻿// ------------------------------------------------------------------------------//
// <copyright file="ProcedureName.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer
{
    /// <summary>
    /// Initialize ProcedureName class
    /// </summary>
    public enum ProcedureName
    {
        WmsParamterSelection,
        WmsParamterInsertUpdate,
        WmsJobDetailsInsertUpdate,
        WmsJobResultInsertUpdate,
        JobSummarySelection,
        JobresultSelection,
        jobresultSelection
    }
}