﻿// ------------------------------------------------------------------------------//
// <copyright file="BaseModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer
{
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using Behaviour;

    /// <summary>
    /// Initialize CommonNotificationModel class
    /// </summary>
    public class BaseModel : INotifyPropertyChanged, INotifyDataErrorInfo
    {
        /// <summary>
        /// The errors
        /// </summary>
        public readonly ErrorBehaviour errors;

        /// <summary>
        /// Initializes a new instance of the <see cref="Patient"/> class.
        /// </summary>
        public BaseModel()
        {
            errors = new ErrorBehaviour(this, this.OnErrorsChanged);
        }

        /// <summary>
        /// Occurs when [errors changed].
        /// </summary>
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        /// <summary>
        /// Occurs when [property changed1].
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets a value indicating whether this instance has errors.
        /// </summary>
        /// <value><c>true</c> if this instance has errors; otherwise, <c>false</c>.</value>
        public bool HasErrors => this.errors.HasErrors;

        /// <summary>
        /// Gets the errors.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <returns>Return the result.</returns>
        public IEnumerable GetErrors(string propertyName) => this.errors.GetErrors(propertyName);

        /// <summary>
        /// Raises the <see cref="E:ErrorsChanged"/> event.
        /// </summary>
        /// <param name="e">
        /// The <see cref="DataErrorsChangedEventArgs"/> instance containing the event data.
        /// </param>
        protected virtual void OnErrorsChanged(DataErrorsChangedEventArgs e)
        {
            this.ErrorsChanged?.Invoke(this, e);
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}