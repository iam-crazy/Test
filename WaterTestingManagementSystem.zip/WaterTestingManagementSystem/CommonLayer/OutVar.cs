﻿// ------------------------------------------------------------------------------//
// <copyright file="OutVar.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace CommonLayer
{
    /// <summary>
    /// OutVar
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class OutVar<T>
    {
        /// <summary>
        /// The value
        /// </summary>
        public T Value;
    }
}