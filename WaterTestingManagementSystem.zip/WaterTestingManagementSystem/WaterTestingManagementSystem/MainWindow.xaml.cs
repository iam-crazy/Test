﻿namespace WaterTestingManagementSystem
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using System.Windows;
    using System.Windows.Controls.Primitives;
    using System.Windows.Input;
    using System.Windows.Media;
    using CommonLayer;
    using global::FrameWork;
    using MaterialDesign.Domain;
    using MaterialDesignDemo.Domain;
    using MaterialDesignThemes.Wpf;
    using WaterTestingManagementSystem.ViewModel;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : INotifyPropertyChanged
    {
        /// The content </summary>
        private object content;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public Object Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
                ContentUserControl.Content = content;
                OnPropertyChanged("Content");
            }
        }

        public TreesViewModel ViewModel => DataContext as TreesViewModel;

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private async void MenuPopupButton_OnClick(object sender, RoutedEventArgs e)
        {
            var sampleMessageDialog = new SampleMessageDialog
            {
                Message = { Text = ((ButtonBase)sender).Content.ToString() }
            };

            await DialogHost.Show(sampleMessageDialog, "RootDialog");
        }

        /// <summary>
        /// TreesView's SelectedItem is read-only. Hence we can't bind it. There is a way to obtain a
        /// selected item.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">     </param>
        private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e != null)
            {
                MenuFormatViewModel MovieCategory = e.NewValue as MenuFormatViewModel;
                if (MovieCategory == null)
                {
                    SubMenuFormatViewModel movie = e.NewValue as SubMenuFormatViewModel;
                    if (movie?.Content != null)
                    {
                        ConvertDbTextIntoViewModel.FunForConvertDbTextIntoViewModel(movie.Name, true);
                        Content = movie.Content;
                        MenuToggleButton1.IsLeftDrawerOpen = false;
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(Utility.ToString(MovieCategory?.Content)))
                    {
                        Content = MovieCategory.Content;
                        MenuToggleButton1.IsLeftDrawerOpen = false;
                    }
                }
            }
            else
            {
                ConvertDbTextIntoViewModel.FunForConvertDbTextIntoViewModel("Home", false);
                MenuToggleButton1.IsLeftDrawerOpen = false;
            }
        }

        private void UIElement_OnPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //until we had a StaysOpen glag to Drawer, this will help with scroll bars
            var dependencyObject = Mouse.Captured as DependencyObject;
            while (dependencyObject != null)
            {
                if (dependencyObject is ScrollBar) return;
                dependencyObject = VisualTreeHelper.GetParent(dependencyObject);
            }

            MenuToggleButton.IsChecked = false;
        }
    }
}