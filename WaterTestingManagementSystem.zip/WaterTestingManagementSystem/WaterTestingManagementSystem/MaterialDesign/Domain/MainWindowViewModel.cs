﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using CommonLayer.ViewModel;
using FrameWork;
using LightInject;
using WaterTestingManagementSystem.View;
using WaterTestingManagementSystem.ViewModel;

namespace MaterialDesign.Domain
{
    public class MainWindowViewModel
    {
        private bool isVisible = false;

        public MainWindowViewModel()
        {
            ////string objBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            ////string objPdXmlPath = objBaseDirectory + "\\Data\\PersonalDetails.Xml";
            IList<MainMenuFormat> mainMenu = new List<MainMenuFormat>();
            ////mainMenu = objPdXmlPath.ReadXMl<MainMenuFormat>();
            mainMenu.Add(new MainMenuFormat()
            {
                Id = 1,
                Name = "Home",
                Icon = "Home",
                ViewModel = "Home"
            });
            mainMenu.Add(new MainMenuFormat()
            {
                Id = 2,
                Name = "Master",
                Icon = "Windows",
                ViewModel = null
            });
            mainMenu.Add(new MainMenuFormat()
            {
                Id = 3,
                Name = "Job Details",
                Icon = "LibraryBooks",
                ViewModel = null
            });
            mainMenu.Add(new MainMenuFormat()
            {
                Id = 4,
                Name = "Report",
                Icon = "Report",
                ViewModel = null
            });
            IList<SubMenuFormat> subMenu = new List<SubMenuFormat>();
            subMenu.Add(new SubMenuFormat()
            {
                Id = 1,
                MainMenuId = 2,
                Name = "Parameter",
                Icon = "AccountPlus",
                ViewModel = "Parameter"
            });
            subMenu.Add(new SubMenuFormat()
            {
                Id = 2,
                MainMenuId = 3,
                Name = "Job Summary",
                Icon = "AccountPlus",
                ViewModel = "JobSummary"
            });
            subMenu.Add(new SubMenuFormat()
            {
                Id = 3,
                MainMenuId = 3,
                Name = "Drinking Purpose",
                Icon = "AccountPlus",
                ViewModel = "DrinkingPurpose"
            });
            subMenu.Add(new SubMenuFormat()
            {
                Id = 4,
                MainMenuId = 3,
                Name = "Construction Purpose",
                Icon = "AccountPlus",
                ViewModel = "ConstructionPurpose"
            });
            subMenu.Add(new SubMenuFormat()
            {
                Id = 5,
                MainMenuId = 3,
                Name = "Analytical Report",
                Icon = "AccountPlus",
                ViewModel = "AnalyticalReport"
            });
            MenuDetails = new ObservableCollection<MenuFormatViewModel>();
            foreach (var item in mainMenu)
            {
                IList<SubMenuFormat> objFiltersubMenu = subMenu.Where(w => w.MainMenuId == item.Id).ToList();
                if (objFiltersubMenu.Count > 0)
                {
                    IList<SubMenuFormatViewModel> objFiltersubMenuViewModel = new List<SubMenuFormatViewModel>();
                    foreach (var item1 in objFiltersubMenu)
                    {
                        SubMenuFormatViewModel obj = new SubMenuFormatViewModel
                            (
                                name: item1.Name,
                                content: ConvertDbTextIntoViewModel.FunForConvertDbTextIntoViewModel(item1.ViewModel, false),
                                documentation: new[]
                                                {
                                                DocumentationLink.NoLink(item.Name+"   /   "+item1.Name, item.Name+" / "+item1.Name),
                                                },
                                menuIcon: item1.Icon
                            );
                        objFiltersubMenuViewModel.Add(obj);
                    }
                    MenuFormatViewModel objMenu = new MenuFormatViewModel
                        (
                            name: item.Name,
                            content: ConvertDbTextIntoViewModel.FunForConvertDbTextIntoViewModel(item.ViewModel, false),
                            documentation: new[]
                            {
                            DocumentationLink.NoLink("Home", "Home"),
                            },
                            menuIcon: item.Icon,
                           subMenuFormat: objFiltersubMenuViewModel,
                           hasSelected: false
                        );

                    MenuDetails.Add(objMenu);
                }
                else
                {
                    bool hasSelected = item.Name.ToUpper() == "HOME" ? true : false;
                    MenuFormatViewModel objMenu = new MenuFormatViewModel
                        (
                            name: item.Name,
                            content: ConvertDbTextIntoViewModel.FunForConvertDbTextIntoViewModel(item.ViewModel, false),
                            documentation: null,
                            menuIcon: item.Icon,
                            subMenuFormat: null,
                           hasSelected: hasSelected
                        );
                    MenuDetails.Add(objMenu);
                }
            }

            //MovieCategories = new ObservableCollection<MovieCategory>
            //{
            //    new MovieCategory("Home",new Home(), new []
            //        {
            //          DocumentationLink.NoLink("Home", "Home"),
            //        }),
            //    new MovieCategory("Master", null,  null,
            //        new Movie ("Patient Master", new PatientMaster(false), new []
            //        {
            //          DocumentationLink.NoLink("Patient Master", "Patient Master"),
            //        }, "Patient Master")
            //    //    ,new Movie("Buttons", new Buttons(), new []
            //    //    {
            //    //      DocumentationLink.NoLink("Buttons", "Buttons"),
            //    //    }, "Buttons"),
            //    //    new Movie("TextFields", new TextFields(), new []
            //    //    {
            //    //      DocumentationLink.NoLink("TextFields", "TextFields"),
            //    //    }, "TextFields")),
            //    //new MovieCategory("Transaction",null,null,
            //    //    new Movie("Chips", new Chips(), new []
            //    //    {
            //    //      DocumentationLink.NoLink("Chips", "Chips"),
            //    //    }, "Chips"),
            //    //    new Movie("Typography", new Typography(), new []
            //    //    {
            //    //      DocumentationLink.NoLink("Typography", "Typography"),
            //    //    },"Typography")
            //    )
            //};

            //DemoItems = new[]
            //{
            //    new DemoItem("Home", new Home(),
            //        new []
            //        {
            //            new DocumentationLink(DocumentationLinkType.Wiki, "https://github.com/ButchersBoy/MaterialDesignInXamlToolkit/wiki", "WIKI"),
            //            DocumentationLink.DemoPageLink<Home>()
            //        }
            //    ),
            //     new DemoItem("Patient Master", new PatientMaster(false), new []
            //        {
            //          DocumentationLink.NoLink("Patient Master", "Patient Master"),
            //        }),
            //    //new DemoItem("Palette", new PaletteSelector { DataContext = new PaletteSelectorViewModel() },
            //    //    new []
            //    //    {
            //    //        DocumentationLink.WikiLink("Brush-Names", "Brushes"),
            //    //        DocumentationLink.WikiLink("Custom-Palette-Hues", "Custom Palettes"),
            //    //        DocumentationLink.WikiLink("Swatches-and-Recommended-Colors", "Swatches"),
            //    //        DocumentationLink.DemoPageLink<PaletteSelector>("Demo View"),
            //    //        DocumentationLink.DemoPageLink<PaletteSelectorViewModel>("Demo View Model"),
            //    //        DocumentationLink.ApiLink<PaletteHelper>()
            //    //    }),
            //    //                new DemoItem("Buttons & Toggles", new Buttons(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.WikiLink("Button-Styles", "Buttons"),
            //    //        DocumentationLink.DemoPageLink<Buttons>(),
            //    //        DocumentationLink.StyleLink("Button"),
            //    //        DocumentationLink.StyleLink("CheckBox"),
            //    //        DocumentationLink.StyleLink("PopupBox"),
            //    //        DocumentationLink.StyleLink("ToggleButton"),
            //    //        DocumentationLink.ApiLink<PopupBox>()
            //    //    })
            //    //    {
            //    //        VerticalScrollBarVisibilityRequirement = ScrollBarVisibility.Auto
            //    //    },
            //    //new DemoItem("Fields", new TextFields(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<TextFields>(),
            //    //        DocumentationLink.StyleLink("TextBox"),
            //    //        DocumentationLink.StyleLink("ComboBox"),
            //    //    })
            //    //    {
            //    //        VerticalScrollBarVisibilityRequirement = ScrollBarVisibility.Auto
            //    //    },
            //    //new DemoItem("Pickers", new Pickers { DataContext = new PickersViewModel()},
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<TextFields>(),
            //    //        DocumentationLink.StyleLink("Clock"),
            //    //        DocumentationLink.StyleLink("DatePicker"),
            //    //        DocumentationLink.ApiLink<TimePicker>()
            //    //    }),
            //    //new DemoItem("Sliders", new Sliders(), new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Sliders>(),
            //    //        DocumentationLink.StyleLink("Sliders")
            //    //    }),
            //    //new DemoItem("Chips", new Chips(), new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Chips>(),
            //    //        DocumentationLink.StyleLink("Chip"),
            //    //        DocumentationLink.ApiLink<Chip>()
            //    //    }),
            //    //new DemoItem("Typography", new Typography(), new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Typography>(),
            //    //        DocumentationLink.StyleLink("TextBlock")
            //    //    })
            //    //    {
            //    //        VerticalScrollBarVisibilityRequirement = ScrollBarVisibility.Auto,
            //    //        HorizontalScrollBarVisibilityRequirement = ScrollBarVisibility.Auto
            //    //    },
            //    //new DemoItem("Cards", new Cards(), new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Cards>(),
            //    //        DocumentationLink.StyleLink("Card"),
            //    //        DocumentationLink.ApiLink<Card>()
            //    //    })
            //    //{
            //    //    VerticalScrollBarVisibilityRequirement = ScrollBarVisibility.Auto
            //    //},
            //    //new DemoItem("Icon Pack", new IconPack { DataContext = new IconPackViewModel() },
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<IconPack>("Demo View"),
            //    //        DocumentationLink.DemoPageLink<IconPackViewModel>("Demo View Model"),
            //    //        DocumentationLink.ApiLink<PackIcon>()
            //    //    }),
            //    //new DemoItem("Colour Zones", new ColorZones(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<ColorZones>(),
            //    //        DocumentationLink.ApiLink<ColorZone>()
            //    //    }),
            //    //new DemoItem("Lists", new Lists { DataContext = new ListsAndGridsViewModel()},
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Lists>("Demo View"),
            //    //        DocumentationLink.DemoPageLink<ListsAndGridsViewModel>("Demo View Model"),
            //    //        DocumentationLink.StyleLink("ListBox"),
            //    //        DocumentationLink.StyleLink("ListView")
            //    //    })
            //    //{
            //    //    VerticalScrollBarVisibilityRequirement = ScrollBarVisibility.Auto
            //    //},
            //    //new DemoItem("Trees", new Trees { DataContext = new TreesViewModel() },
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Trees>("Demo View"),
            //    //        DocumentationLink.DemoPageLink<TreesViewModel>("Demo View Model"),
            //    //        DocumentationLink.StyleLink("TreeView")
            //    //    }),
            //    //new DemoItem("Grids", new Grids { DataContext = new ListsAndGridsViewModel()},
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Lists>("Demo View"),
            //    //        DocumentationLink.DemoPageLink<ListsAndGridsViewModel>("Demo View Model"),
            //    //        DocumentationLink.StyleLink("DataGrid")
            //    //    }),
            //    //               new DemoItem("Group Boxes", new GroupBoxes(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Cards>(),
            //    //        DocumentationLink.StyleLink("Card")
            //    //    }),
            //    //new DemoItem("Menus & Tool Bars", new MenusAndToolBars(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<MenusAndToolBars>(),
            //    //        DocumentationLink.StyleLink("Menu"),
            //    //        DocumentationLink.StyleLink("ToolBar")
            //    //    }),
            //    //new DemoItem("Progress Indicators", new Progress(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Progress>(),
            //    //        DocumentationLink.StyleLink("ProgressBar")
            //    //    }),
            //    //new DemoItem("Dialogs", new Dialogs { DataContext = new DialogsViewModel()},
            //    //    new []
            //    //    {
            //    //        DocumentationLink.WikiLink("Dialogs", "Dialogs"),
            //    //        DocumentationLink.DemoPageLink<Dialogs>("Demo View"),
            //    //        DocumentationLink.DemoPageLink<DialogsViewModel>("Demo View Model"),
            //    //        DocumentationLink.ApiLink<DialogHost>()
            //    //    }),
            //    //new DemoItem("Drawer", new Drawers(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Drawers>(),
            //    //        DocumentationLink.ApiLink<DrawerHost>()
            //    //    }),
            //    //new DemoItem("Snackbar", new Snackbars(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.WikiLink("Snackbar", "Snackbar"),
            //    //        DocumentationLink.DemoPageLink<Snackbars>(),
            //    //        DocumentationLink.StyleLink("Snackbar"),
            //    //        DocumentationLink.ApiLink<Snackbar>(),
            //    //        DocumentationLink.ApiLink<ISnackbarMessageQueue>()
            //    //    }),
            //    //new DemoItem("Transitions", new Transitions(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.WikiLink("Transitions", "Transitions"),
            //    //        DocumentationLink.DemoPageLink<Transitions>(),
            //    //        DocumentationLink.ApiLink<Transitioner>("Transitions"),
            //    //        DocumentationLink.ApiLink<TransitionerSlide>("Transitions"),
            //    //        DocumentationLink.ApiLink<TransitioningContent>("Transitions"),
            //    //    }),
            //    //new DemoItem("Shadows", new Shadows(),
            //    //    new []
            //    //    {
            //    //        DocumentationLink.DemoPageLink<Shadows>(),
            //    //    }),
            //};
        }

        public static Home Current { get; internal set; }
        public DemoItem[] DemoItems { get; }

        public bool IsVisible
        {
            get { return isVisible; }

            set { isVisible = value; }
        }

        public ObservableCollection<MenuFormatViewModel> MenuDetails { get; }

        /// <summary>
        /// Gets the service.
        /// </summary>
        /// <typeparam name="T">The UI Service.</typeparam>
        /// <returns>Call the Service.</returns>
        internal static T GetService<T>()
        {
            return ConfiguredContainer.Current.GetInstance<T>();
        }
    }
}