﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System.Windows.Controls;

namespace MaterialDesign.Domain
{
    /// <summary>
    /// Interaction logic for SampleProgressDialog.xaml
    /// </summary>
    public partial class SampleProgressDialog : UserControl
    {
        public SampleProgressDialog()
        {
            InitializeComponent();
        }
    }
}