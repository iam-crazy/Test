﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System.Windows.Controls;

namespace MaterialDesign.Domain
{
    /// <summary>
    /// Interaction logic for SampleMessageDialog.xaml
    /// </summary>
    public partial class SampleMessageDialog : UserControl
    {
        public SampleMessageDialog()
        {
            InitializeComponent();
        }
    }
}