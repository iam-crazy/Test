﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using MaterialDesign.Domain;

namespace MaterialDesignDemo.Domain
{
    public sealed class Movie : INotifyPropertyChanged
    {
        private object _content;
        private ScrollBarVisibility _horizontalScrollBarVisibilityRequirement;
        private Thickness _marginRequirement = new Thickness(16);
        private ScrollBarVisibility _verticalScrollBarVisibilityRequirement;

        public Movie(string name, object content, IEnumerable<DocumentationLink> documentation, string director)
        {
            Name = name;
            Content = content;
            Director = director;
            Documentation = documentation;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public object Content
        {
            get { return _content; }
            set { this.MutateVerbose(ref _content, value, RaisePropertyChanged()); }
        }

        public string Director { get; }

        public IEnumerable<DocumentationLink> Documentation { get; }

        public ScrollBarVisibility HorizontalScrollBarVisibilityRequirement
        {
            get { return _horizontalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _horizontalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        public Thickness MarginRequirement
        {
            get { return _marginRequirement; }
            set { this.MutateVerbose(ref _marginRequirement, value, RaisePropertyChanged()); }
        }

        public string Name { get; }

        public ScrollBarVisibility VerticalScrollBarVisibilityRequirement
        {
            get { return _verticalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _verticalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        private Action<PropertyChangedEventArgs> RaisePropertyChanged()
        {
            return args => PropertyChanged?.Invoke(this, args);
        }
    }

    public sealed class MovieCategory : INotifyPropertyChanged
    {
        private object _content;
        private ScrollBarVisibility _horizontalScrollBarVisibilityRequirement;
        private Thickness _marginRequirement = new Thickness(16);
        private ScrollBarVisibility _verticalScrollBarVisibilityRequirement;

        public MovieCategory(string name, object content, IEnumerable<DocumentationLink> documentation, params Movie[] movies)
        {
            Name = name;
            Content = content;
            Movies = new ObservableCollection<Movie>(movies);
            Documentation = documentation;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public object Content
        {
            get { return _content; }
            set { this.MutateVerbose(ref _content, value, RaisePropertyChanged()); }
        }

        public IEnumerable<DocumentationLink> Documentation { get; }

        public ScrollBarVisibility HorizontalScrollBarVisibilityRequirement
        {
            get { return _horizontalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _horizontalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        public Thickness MarginRequirement
        {
            get { return _marginRequirement; }
            set { this.MutateVerbose(ref _marginRequirement, value, RaisePropertyChanged()); }
        }

        public ObservableCollection<Movie> Movies { get; }

        public string Name { get; }

        public ScrollBarVisibility VerticalScrollBarVisibilityRequirement
        {
            get { return _verticalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _verticalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        private Action<PropertyChangedEventArgs> RaisePropertyChanged()
        {
            return args => PropertyChanged?.Invoke(this, args);
        }
    }

    public sealed class TreesViewModel : INotifyPropertyChanged
    {
        private object _selectedItem;

        public TreesViewModel()
        {
            MovieCategories = new ObservableCollection<MovieCategory>
            {
                //new MovieCategory("Action", null,  null,
                //    new Movie ("Predator", new PatientMaster(false), new []
                //    {
                //      DocumentationLink.NoLink("Patient Master", "Patient Master"),
                //    }, "John McTiernan"),
                //    new Movie("Alien", new PatientMaster(false), new []
                //    {
                //      DocumentationLink.NoLink("Patient Master", "Patient Master"),
                //    }, "Ridley Scott"),
                //    new Movie("Prometheus", new PatientMaster(false), new []
                //    {
                //      DocumentationLink.NoLink("Patient Master", "Patient Master"),
                //    }, "Ridley Scott")),
                //new MovieCategory("Comedy",null,null,
                //    new Movie("EuroTrip", new PatientMaster(false), new []
                //    {
                //      DocumentationLink.NoLink("Patient Master", "Patient Master"),
                //    }, "Jeff Schaffer"),
                //    new Movie("EuroTrip", new PatientMaster(false), new []
                //    {
                //      DocumentationLink.NoLink("Patient Master", "Patient Master"),
                //    },"Jeff Schaffer")
                //)
            };

            AddCommand = new AnotherCommandImplementation(
                _ =>
                {
                    if (!MovieCategories.Any())
                    {
                        MovieCategories.Add(new MovieCategory(GenerateString(15), null, null));
                    }
                    else
                    {
                        var index = new Random().Next(0, MovieCategories.Count);

                        MovieCategories[index].Movies.Add(
                            new Movie(GenerateString(15), GenerateString(20), null, null));
                    }
                });

            RemoveSelectedItemCommand = new AnotherCommandImplementation(
                _ =>
                {
                    var movieCategory = SelectedItem as MovieCategory;
                    if (movieCategory != null)
                    {
                        MovieCategories.Remove(movieCategory);
                    }
                    else
                    {
                        var movie = SelectedItem as Movie;
                        if (movie == null) return;
                        MovieCategories.FirstOrDefault(v => v.Movies.Contains(movie))?.Movies.Remove(movie);
                    }
                },
                _ => SelectedItem != null);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public AnotherCommandImplementation AddCommand { get; }
        public ObservableCollection<MovieCategory> MovieCategories { get; }
        public AnotherCommandImplementation RemoveSelectedItemCommand { get; }

        public object SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                this.MutateVerbose(ref _selectedItem, value, args => PropertyChanged?.Invoke(this, args));
            }
        }

        private static string GenerateString(int length)
        {
            var random = new Random();

            return string.Join(string.Empty,
                Enumerable.Range(0, length)
                .Select(v => (char)random.Next('a', 'z' + 1)));
        }
    }
}