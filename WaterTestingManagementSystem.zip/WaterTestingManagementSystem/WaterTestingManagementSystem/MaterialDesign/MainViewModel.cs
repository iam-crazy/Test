﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace MaterialDesignDemo.Domain
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using MaterialDesign.Domain;

    public class MainViewModel : MainWindowViewModel, INotifyPropertyChanged
    {
        private object content;
        private object filter;

        public event PropertyChangedEventHandler PropertyChanged;

        public static MainViewModel Current { get; set; } = new MainViewModel();

        public Object Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
                OnPropertyChanged("Content");
            }
        }

        public object Filter
        {
            get { return filter; }
            set
            {
                filter = value;
                OnPropertyChanged();
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}