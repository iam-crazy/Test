﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//

namespace MaterialDesign.Domain
{
    public class CustomMaterialMessageBox : MessageBoxWindow
    {
        public new void Show()
        {
            ShowDialog();
        }
    }
}