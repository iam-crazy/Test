﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Windows.Input;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    /// <seealso cref="System.Windows.Input.ICommand"/>
    public class CustomCommand : ICommand
    {
        /// <summary>
        /// The can execute evaluator
        /// </summary>
        private Func<bool> canExecuteEvaluator;

        /// <summary>
        /// The method to execute
        /// </summary>
        private Action methodToExecute;

        /// <summary>
        /// The on show hide command
        /// </summary>
        private Action<object> onShowHideCommand;
        private object create;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomCommand"/> class.
        /// </summary>
        /// <param name="methodToExecute">    The method to execute.</param>
        /// <param name="canExecuteEvaluator">The can execute evaluator.</param>
        public CustomCommand(Action methodToExecute, Func<bool> canExecuteEvaluator)
        {
            this.methodToExecute = methodToExecute;
            this.canExecuteEvaluator = canExecuteEvaluator;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomCommand"/> class.
        /// </summary>
        /// <param name="methodToExecute">The method to execute.</param>
        public CustomCommand(Action methodToExecute)
            : this(methodToExecute, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomCommand"/> class.
        /// </summary>
        /// <param name="onShowHideCommand">The on show hide command.</param>
        public CustomCommand(Action<object> onShowHideCommand)
        {
            this.onShowHideCommand = onShowHideCommand;
        }

        public CustomCommand(object create)
        {
            this.create = create;
        }

        /// <summary>
        /// Occurs when changes occur that affect whether or not the command should execute.
        /// </summary>
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        /// <summary>
        /// Defines the method that determines whether the command can execute in its current state.
        /// </summary>
        /// <param name="parameter">
        /// Data used by the command. If the command does not require data to be passed, this object
        /// can be set to null.
        /// </param>
        /// <returns>true if this command can be executed; otherwise, false.</returns>
        public bool CanExecute(object parameter)
        {
            if (this.canExecuteEvaluator == null)
            {
                return true;
            }
            else
            {
                bool result = this.canExecuteEvaluator.Invoke();
                return result;
            }
        }

        /// <summary>
        /// Defines the method to be called when the command is invoked.
        /// </summary>
        /// <param name="parameter">
        /// Data used by the command. If the command does not require data to be passed, this object
        /// can be set to null.
        /// </param>
        public void Execute(object parameter)
        {
            this.methodToExecute.Invoke();
        }
    }

    //public class RelayCommand : ICommand
    //{
    //    Action _TargetExecuteMethod;
    //    Func<bool> _TargetCanExecuteMethod;
    //    private Action<object> addUser;

    // public RelayCommand(Action executeMethod) { _TargetExecuteMethod = executeMethod; }

    // public RelayCommand(Action executeMethod, Func<bool> canExecuteMethod) { _TargetExecuteMethod
    // = executeMethod; _TargetCanExecuteMethod = canExecuteMethod; }

    // public RelayCommand(Action<object> addUser) { this.addUser = addUser; }

    // public void RaiseCanExecuteChanged() { CanExecuteChanged(this, EventArgs.Empty); } #region
    // ICommand Members

    // bool ICommand.CanExecute(object parameter) { if (_TargetCanExecuteMethod != null) { return
    // _TargetCanExecuteMethod(); } if (_TargetExecuteMethod != null) { return true; } return false; }

    // // Beware - should use weak references if command instance lifetime is longer than lifetime of
    // UI objects that get hooked up to command // Prism commands solve this in their implementation
    // public event EventHandler CanExecuteChanged = delegate { };

    //    void ICommand.Execute(object parameter)
    //    {
    //        if (_TargetExecuteMethod != null)
    //        {
    //            _TargetExecuteMethod();
    //        }
    //    }
    //    #endregion
    //}

    //public class RelayCommand<T> : ICommand
    //{
    //    Action<T> _TargetExecuteMethod;
    //    Func<T, bool> _TargetCanExecuteMethod;

    // public RelayCommand(Action<T> executeMethod) { _TargetExecuteMethod = executeMethod; }

    // public RelayCommand(Action<T> executeMethod, Func<T, bool> canExecuteMethod) {
    // _TargetExecuteMethod = executeMethod; _TargetCanExecuteMethod = canExecuteMethod; }

    // public void RaiseCanExecuteChanged() { CanExecuteChanged(this, EventArgs.Empty); } #region
    // ICommand Members

    // bool ICommand.CanExecute(object parameter) { if (_TargetCanExecuteMethod != null) { T tparm =
    // (T)parameter; return _TargetCanExecuteMethod(tparm); } if (_TargetExecuteMethod != null) {
    // return true; } return false; }

    // // Beware - should use weak references if command instance lifetime is longer than lifetime of
    // UI objects that get hooked up to command // Prism commands solve this in their implementation
    // public event EventHandler CanExecuteChanged = delegate { };

    //    void ICommand.Execute(object parameter)
    //    {
    //        if (_TargetExecuteMethod != null)
    //        {
    //            _TargetExecuteMethod((T)parameter);
    //        }
    //    }
    //    #endregion
    //}
}