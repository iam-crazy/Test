﻿//-----------------------------------------------------------------------
// <copyright file = "DataGridCellDetail.cs" company = "">
// </copyright>
// <summary>
//   Declare DataGridCellDetail.
// </summary>
//-----------------------------------------------------------------------
namespace FrameWork
{
    /// <summary>
    /// Declare DataGridCellDetail.
    /// </summary>
    public class DataGridCellDetail
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DataGridCellDetail"/> class.
        /// </summary>
        public DataGridCellDetail()
        {
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// Gets or sets the cell header.
        /// </summary>
        /// <value>The cell header.</value>
        public object CellHeader { get; set; }

        /// <summary>
        /// Gets or sets the current.
        /// </summary>
        /// <value>The current.</value>
        public object Current { get; set; }

        /// <summary>
        /// Gets or sets the cell header.
        /// </summary>
        /// <value>The cell header.</value>
        public object GroupCellHeader { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public object Value { get; set; }

        #endregion Properties
    }
}