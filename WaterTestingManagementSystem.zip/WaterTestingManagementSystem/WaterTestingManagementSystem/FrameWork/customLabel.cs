﻿// ------------------------------------------------------------------------------//
// <copyright file="CustomLabel.cs" company="">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace FrameWork
{
    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    /// Initialize CustomLabel class
    /// </summary>
    public class Label : HeaderedContentControl
    {
        static Label()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Label), new FrameworkPropertyMetadata(typeof(Label)));
        }
    }
}