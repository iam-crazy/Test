﻿// ------------------------------------------------------------------------------//
// <copyright file="NavigationManager.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.FrameWork
{
    /// <summary>
    /// Initialize NavigationManager class
    /// </summary>
    public class NavigationManager
    {
    }
}