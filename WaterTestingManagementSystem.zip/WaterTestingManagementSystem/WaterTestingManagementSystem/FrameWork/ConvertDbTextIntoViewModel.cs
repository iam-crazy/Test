﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//

using WaterTestingManagementSystem.View;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    public static class ConvertDbTextIntoViewModel
    {
        /// <summary>
        /// Funs for convert database text into view model.
        /// </summary>
        /// <param name="objText">The object text.</param>
        /// <param name="isValid">if set to <c>true</c> [is valid].</param>
        /// <returns>Return the result.</returns>
        public static object FunForConvertDbTextIntoViewModel(object objText, bool isValid)
        {
            object result = "";
            if (objText != null)
            {
                switch (objText.ToString())
                {
                    case "HOME":
                        result = new Home();
                        break;

                    case "Parameter":
                        result = new Parameter();
                        break;

                    case "JobSummary":
                        result = new JobSummary();
                        break;

                    case "Job Summary":
                        result = new JobSummary();
                        break;

                    case "DrinkingPurpose":
                        result = new DrinkingPurpose(0);
                        break;

                    case "Drinking Purpose":
                        result = new DrinkingPurpose(0);
                        break;

                    case "AnalyticalReport":
                        result = new AnalyticalReport(0);
                        break;

                    case "Analytical Report":
                        result = new AnalyticalReport(0);
                        break;

                    case "ConstructionPurpose":
                        result = new ConstructionPurpose(0);
                        break;

                    case "Construction Purpose":
                        result = new ConstructionPurpose(0);
                        break;

                    default:
                        result = new Home();
                        break;
                }
            }
            return result;
        }
    }
}