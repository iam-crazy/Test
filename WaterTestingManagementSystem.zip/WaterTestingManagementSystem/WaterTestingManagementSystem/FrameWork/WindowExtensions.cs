﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Application = System.Windows.Application;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    public static class WindowExtensions
    {
        /// <summary>
        /// Exits the frame.
        /// </summary>
        /// <param name="f">The f.</param>
        /// <returns>Return the result.</returns>
        public static object ExitFrame(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }

        /// <summary>
        /// Parents the WND move.
        /// </summary>
        /// <param name="dialogWindow">The dialog window.</param>
        public static void ParentWndMove(Window dialogWindow)
        {
            Window owner = dialogWindow.Owner;
            PresentationSource presentationsource = PresentationSource.FromVisual(dialogWindow);
            Matrix m = presentationsource.CompositionTarget.TransformToDevice;

            double centerWidth = owner.Left + owner.ActualWidth / 2;
            double centerHeight = owner.Top + owner.ActualHeight / 2;
            if (owner.WindowState == WindowState.Normal)
            {
                dialogWindow.Top = centerHeight - dialogWindow.ActualHeight / 2;
                dialogWindow.Left = centerWidth - dialogWindow.ActualWidth / 2;
            }
        }

        /// <summary>
        /// Parents the WND state changed.
        /// </summary>
        /// <param name="dialogWindow">The dialog window.</param>
        public static void ParentWndStateChanged(Window dialogWindow)
        {
            Window owner = dialogWindow.Owner;
            if (owner.WindowState != WindowState.Maximized)
            {
                dialogWindow.WindowState = owner.WindowState;
            }
            ParentWndMove(dialogWindow);
        }

        /// <summary>
        /// Shows the Dialog Modal.
        /// </summary>
        /// <param name="dialogWindow">The dialog window.</param>
        public static void ShowModal(this Window dialogWindow)
        {
            Window window = Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w.IsKeyboardFocusWithin) ?? Application.Current.MainWindow;
            IInputElement lastFocused = FocusManager.GetFocusedElement(window);
            IInputElement lastKeyboardSelected = Keyboard.FocusedElement;
            EventHandler locationChanged = (sender, args) => ParentWndMove(dialogWindow);
            SizeChangedEventHandler sizeChanged = (sender, args) => ParentWndMove(dialogWindow);
            EventHandler stateChanged = (sender, args) => ParentWndStateChanged(dialogWindow);

            window.LocationChanged += locationChanged;
            window.SizeChanged += sizeChanged;
            window.StateChanged += stateChanged;

            EventHandler close = (sender, args) =>
            {
                if (dialogWindow.Dispatcher.CheckAccess())
                {
                    dialogWindow.Close();
                }
                else
                {
                    dialogWindow.Dispatcher.Invoke(dialogWindow.Close);
                }

                window.LocationChanged -= locationChanged;
                window.SizeChanged -= sizeChanged;
                window.StateChanged -= stateChanged;
            };

            EventHandler closed = (sender, args) =>
            {
                Window self = sender as Window;
                Enable();
                if (self != null)
                {
                    self.Owner = null;
                }
            };

            ExitEventHandler exit = (sender, args) => close(sender, args);

            DependencyPropertyChangedEventHandler isEnabledChanged = null;
            isEnabledChanged = (o, eventArgs) =>
            {
                window.Dispatcher.BeginInvoke(
                  DispatcherPriority.ApplicationIdle,
                  new Action(
                    () =>
                    {
                        FocusManager.SetFocusedElement(window, lastFocused);
                        Keyboard.Focus(lastKeyboardSelected);
                    }));

                ((Window)o).IsEnabledChanged -= isEnabledChanged;
            };
            window.IsEnabledChanged += isEnabledChanged;
            dialogWindow.Closed += closed;
            Application.Current.Exit += exit;

            dialogWindow.Show();
            ParentWndMove(dialogWindow);

            while (Application.Current != null)
            {
                DoEvents();
            }
        }

        /// <summary>
        /// Does the events.
        /// </summary>
        private static void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, new DispatcherOperationCallback(ExitFrame), frame);
            Dispatcher.PushFrame(frame);
            Thread.Sleep(10);
        }

        /// <summary>
        /// Enables this instance.
        /// </summary>
        private static void Enable()
        {
            foreach (Window window in Application.Current.Windows.OfType<Window>().Where(window => !window.OwnedWindows.OfType<Window>().Any()))
            {
                window.IsEnabled = true;
            }
        }
    }
}