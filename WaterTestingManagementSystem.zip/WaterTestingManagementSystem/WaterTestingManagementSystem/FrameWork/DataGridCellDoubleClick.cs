﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    public static class Behaviours
    {
        /// <summary>
        /// The double click command property
        /// </summary>
        public static DependencyProperty DoubleClickCommandProperty =
         DependencyProperty.RegisterAttached("DoubleClickCommand", typeof(ICommand), typeof(Behaviours),
                                             new PropertyMetadata(DoubleClick_PropertyChanged));

        /// <summary>
        /// Gets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>Return the result.</returns>
        public static ICommand GetDoubleClickCommand(UIElement element)
        {
            return (ICommand)element.GetValue(DoubleClickCommandProperty);
        }

        /// <summary>
        /// Sets the double click command.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">  The value.</param>
        public static void SetDoubleClickCommand(UIElement element, ICommand value)
        {
            element.SetValue(DoubleClickCommandProperty, value);
        }

        /// <summary>
        /// Handles the MouseDoubleClick event of the DataGrid control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">     
        /// The <see cref="RoutedEventArgs"/> instance containing the event data.
        /// </param>
        private static void DataGrid_MouseDoubleClick(object sender, RoutedEventArgs e)
        {
            var row = sender as DataGridRow;

            if (row != null)
            {
                var cmd = GetDoubleClickCommand(row);
                if (cmd.CanExecute(row.Item))
                    cmd.Execute(row.Item);
            }
        }

        /// <summary>
        /// Doubles the click property changed.
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">
        /// The <see cref="DependencyPropertyChangedEventArgs"/> instance containing the event data.
        /// </param>
        private static void DoubleClick_PropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var row = d as DataGridRow;
            if (row == null) return;

            if (e.NewValue != null)
            {
                row.AddHandler(DataGridRow.MouseDoubleClickEvent, new RoutedEventHandler(DataGrid_MouseDoubleClick));
            }
            else
            {
                row.RemoveHandler(DataGridRow.MouseDoubleClickEvent, new RoutedEventHandler(DataGrid_MouseDoubleClick));
            }
        }
    }
}