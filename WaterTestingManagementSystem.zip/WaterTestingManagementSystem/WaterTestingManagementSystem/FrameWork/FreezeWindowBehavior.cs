﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Windows;
using System.Windows.Interop;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    public static class FreezeWindowBehavior
    {
        /// <summary>
        /// Freezes the window.
        /// </summary>
        /// <param name="window">The window.</param>
        public static void FreezeWindow(Window window)
        {
            WindowInteropHelper helper = new WindowInteropHelper(window);
            HwndSource source = HwndSource.FromHwnd(helper.Handle);
            source.AddHook(FreezeWindowBehavior.WndProc);
        }

        /// <summary>
        /// WNDs the proc.
        /// </summary>
        /// <param name="hwnd">   The HWND.</param>
        /// <param name="msg">    The MSG.</param>
        /// <param name="wParam"> The w parameter.</param>
        /// <param name="lParam"> The l parameter.</param>
        /// <param name="handled">if set to <c>true</c> [handled].</param>
        /// <returns>Return the result.</returns>
        public static IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_SYSCOMMAND = 0x0112;
            const int SC_MOVE = 0xF010;

            switch (msg)
            {
                case WM_SYSCOMMAND:
                    int command = wParam.ToInt32() & 0xfff0;
                    if (command == SC_MOVE)
                    {
                        handled = true;
                    }
                    break;

                default:
                    break;
            }
            return IntPtr.Zero;
        }
    }
}