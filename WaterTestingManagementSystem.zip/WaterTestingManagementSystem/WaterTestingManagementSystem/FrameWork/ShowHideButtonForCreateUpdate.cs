﻿// ------------------------------------------------------------------------------//
// <copyright file="ShowHideButtonForCreateUpdate.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace FrameWork
{
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// Initialize ShowHideButtonForCreateUpdate class
    /// </summary>
    public class ShowHideButtonForCreateUpdate : INotifyPropertyChanged
    {
        /// <summary>
        /// The has summary screen
        /// </summary>
        private bool hasNewEntry;

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets or sets a value indicating whether this instance has summary screen.
        /// </summary>
        /// <value><c>true</c> if this instance has summary screen; otherwise, <c>false</c>.</value>
        public bool HasNewEntry
        {
            get
            {
                return this.hasNewEntry;
            }

            set
            {
                hasNewEntry = value;
                OnPropertyChanged("HasNewEntry");
            }
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}