﻿// ------------------------------------------------------------------------------//
// <copyright file="ShowHideButtonForJobDetails.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace FrameWork
{
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// Initialize ShowHideButtonForJobDetails class
    /// </summary>
    public class ShowHideButtonForJobDetails : INotifyPropertyChanged
    {
        /// <summary>
        /// The has summary screen
        /// </summary>
        private bool hasAnalyticalPurpose;

        /// <summary>
        /// The has summary screen
        /// </summary>
        private bool hasJobSummary;

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets or sets a value indicating whether this instance has summary screen.
        /// </summary>
        /// <value><c>true</c> if this instance has summary screen; otherwise, <c>false</c>.</value>
        public bool HasAnalyticalPurpose
        {
            get
            {
                return this.hasAnalyticalPurpose;
            }

            set
            {
                hasAnalyticalPurpose = value;
                OnPropertyChanged("HasAnalyticalPurpose");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has summary screen.
        /// </summary>
        /// <value><c>true</c> if this instance has summary screen; otherwise, <c>false</c>.</value>
        public bool HasJobSummary
        {
            get
            {
                return this.hasJobSummary;
            }

            set
            {
                hasJobSummary = value;
                OnPropertyChanged("HasJobSummary");
            }
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}