﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged"/>
    public class FilterShowHideViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The arrow text
        /// </summary>
        private string arrowText;

        /// <summary>
        /// The button state
        /// </summary>
        private ButtonState buttonState;

        /// <summary>
        /// The grid visibility
        /// </summary>
        private Visibility gridVisibility;

        /// <summary>
        /// The show hide command
        /// </summary>
        private ShowHideCommand showHideCommand;

        /// <summary>
        /// The show hide text
        /// </summary>
        private string showHideText;

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// </summary>
        private enum ButtonState
        {
            /// <summary>
            /// The shown
            /// </summary>
            Shown,

            /// <summary>
            /// The hidden
            /// </summary>
            Hidden
        }

        /// <summary>
        /// Gets or sets the arrow text.
        /// </summary>
        /// <value>The arrow text.</value>
        public string ArrowText
        {
            get
            {
                return arrowText;
            }
            set
            {
                arrowText = value;
                OnPropertyChanged("ArrowText");
            }
        }

        /// <summary>
        /// Gets or sets the grid visibility.
        /// </summary>
        /// <value>The grid visibility.</value>
        public Visibility GridVisibility
        {
            get
            {
                return gridVisibility;
            }
            set
            {
                gridVisibility = value;
                OnPropertyChanged("GridVisibility");
            }
        }

        /// <summary>
        /// Gets the show hidecommand.
        /// </summary>
        /// <value>The show hidecommand.</value>
        public ShowHideCommand ShowHidecommand
        {
            get { return showHideCommand ?? (showHideCommand = new ShowHideCommand((o) => OnShowHideCommand(o), () => true)); }
        }

        /// <summary>
        /// Gets or sets the show hide text.
        /// </summary>
        /// <value>The show hide text.</value>
        public string ShowHideText
        {
            get
            {
                return showHideText;
            }
            set
            {
                showHideText = value;
                OnPropertyChanged("ShowHideText");
            }
        }

        /// <summary>
        /// Called when [show hide command].
        /// </summary>
        /// <param name="obj">The object.</param>
        public void OnShowHideCommand(object obj)
        {
            if (buttonState == ButtonState.Shown)
            {
                buttonState = ButtonState.Hidden;
                GridVisibility = Visibility.Collapsed;
                ShowHideText = "Show Filter";
                ArrowText = "ArrowDownDropCircleOutline";
            }
            else
            {
                buttonState = ButtonState.Shown;
                GridVisibility = Visibility.Visible;
                ShowHideText = "Hide Filter";
                ArrowText = "ArrowUpDropCircleOutline";
            }
        }

        /// <summary>
        /// Sets the initial state.
        /// </summary>
        public void SetInitialState()
        {
            buttonState = ButtonState.Shown;
            GridVisibility = Visibility.Visible;
            ShowHideText = "Hide Filter";
            ArrowText = "ArrowUpDropCircleOutline";
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}