﻿// ------------------------------------------------------------------------------//
// <copyright file="Drug.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Globalization;
using System.Linq;
using System.Windows.Controls;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ValidationRule"/>
    public class FutureDateValidationRule : ValidationRule
    {
        /// <summary>
        /// When overridden in a derived class, performs validation checks on a value.
        /// </summary>
        /// <param name="value">      The value from the binding target to check.</param>
        /// <param name="cultureInfo">The culture to use in this rule.</param>
        /// <returns>A <see cref="T:System.Windows.Controls.ValidationResult"/> object.</returns>
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value != null)
            {
                if (string.IsNullOrWhiteSpace((value ?? "").ToString()))
                {
                    return new ValidationResult(false, "Field is required.");
                }
                else
                {
                    DateTime time;
                    if (!DateTime.TryParse((value ?? "").ToString(),
                        CultureInfo.CurrentCulture,
                        DateTimeStyles.AssumeLocal | DateTimeStyles.AllowWhiteSpaces,
                        out time))
                        return new ValidationResult(false, "Invalid date");

                    return time.Date <= DateTime.Now.Date
                        ? new ValidationResult(false, "Future date required")
                        : ValidationResult.ValidResult;
                }
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }

    /// <summary>
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ValidationRule"/>
    public class MandatoryNumericOnlyValidationRule : ValidationRule
    {
        /// <summary>
        /// When overridden in a derived class, performs validation checks on a value.
        /// </summary>
        /// <param name="value">      The value from the binding target to check.</param>
        /// <param name="cultureInfo">The culture to use in this rule.</param>
        /// <returns>A <see cref="T:System.Windows.Controls.ValidationResult"/> object.</returns>
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (string.IsNullOrWhiteSpace((value ?? "").ToString()))
            {
                return new ValidationResult(false, "This Field is required.");
            }
            else if (!value.ToString().All(char.IsDigit))
            {
                return new ValidationResult(false, "Enter only numeric.");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }

    /// <summary>
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ValidationRule"/>
    public class NotEmptyValidationRule : ValidationRule
    {
        /// <summary>
        /// When overridden in a derived class, performs validation checks on a value.
        /// </summary>
        /// <param name="value">      The value from the binding target to check.</param>
        /// <param name="cultureInfo">The culture to use in this rule.</param>
        /// <returns>A <see cref="T:System.Windows.Controls.ValidationResult"/> object.</returns>
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value != null)
            {
                if (string.IsNullOrWhiteSpace((value ?? "").ToString()))
                {
                    return new ValidationResult(false, "Field is required.");
                }
                else
                {
                    return ValidationResult.ValidResult;
                }
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }

    /// <summary>
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ValidationRule"/>
    public class NumericOnlyValidationRule : ValidationRule
    {
        /// <summary>
        /// When overridden in a derived class, performs validation checks on a value.
        /// </summary>
        /// <param name="value">      The value from the binding target to check.</param>
        /// <param name="cultureInfo">The culture to use in this rule.</param>
        /// <returns>A <see cref="T:System.Windows.Controls.ValidationResult"/> object.</returns>
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value != null && !value.ToString().All(char.IsDigit))
            {
                return new ValidationResult(false, "Enter only numeric.");
            }
            else
            {
                return ValidationResult.ValidResult;
            }
        }
    }
}