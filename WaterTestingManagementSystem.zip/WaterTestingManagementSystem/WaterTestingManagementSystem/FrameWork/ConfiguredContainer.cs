﻿// ------------------------------------------------------------------------------//
// <copyright file="ConfiguredContainer.cs" company="">
//     Copyright (c) BTrust All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
using System;
using System.Configuration;
using System.Globalization;
using BusinessLayer;
using BusinessLayer.Contract;
using LightInject;

namespace FrameWork
{
    /// <summary>
    /// </summary>
    public static class ConfiguredContainer
    {
        #region Constructors and private fields

        /// <summary>
        /// The container lock.
        /// </summary>
        private static readonly object ContainerLock = new object();

        /// <summary>
        /// The container.
        /// </summary>
        private static ServiceContainer container;

        #endregion Constructors and private fields

        #region Public and protected properties

        public static string ConnectionString { get { return ConfigurationManager.AppSettings.Get("WmsAddress"); } }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        public static ServiceContainer Current
        {
            get
            {
                if (null == container)
                {
                    lock (ContainerLock)
                    {
                        if (null == container)
                        {
                            var serviceContainer = new ServiceContainer();
                            serviceContainer.LoadConfiguration();
                            //serviceContainer.LoadCustomConfiguration();
                            container = serviceContainer;
                        }
                    }
                }

                return container;
            }
        }

        #endregion Public and protected properties

        #region Private helpers

        /// <summary>
        /// Loads the configuration.
        /// </summary>
        /// <param name="container">The container.</param>
        /// <exception cref="System.ArgumentNullException">container</exception>
        /// <exception cref="ArgumentNullException">Throw Exception.</exception>
        private static void LoadConfiguration(this ServiceContainer container)
        {
            if (null == container)
            {
                throw new ArgumentNullException(nameof(container));
            }

            container.Register<IParameterContext, ParameterContext>();
            container.Register<IJobDetailsContext, JobDetailsContext>();
            container.Register<IJobSummaryContext, JobSummaryContext>();
            container.Register<IAnalyticalReportContext, AnalyticalReportContext>();
            container.Register<IConstructionPurposeContext, ConstructionPurposeContext>();

            //string esrApiBaseAddress = ConfigurationManager.AppSettings.Get("WebApiAddress");
            string userId = Convert.ToString(1, CultureInfo.CurrentCulture);
            //container.Register(factory => new CustomHttpClient(esrApiBaseAddress, userId), new PerContainerLifetime());
        }

        #endregion Private helpers
    }
}