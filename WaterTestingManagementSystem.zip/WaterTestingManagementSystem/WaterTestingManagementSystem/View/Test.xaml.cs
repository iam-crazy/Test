﻿namespace WaterTestingManagementSystem.View
{
    using System.Windows.Controls;
    using ViewModel;

    /// <summary>
    /// Interaction logic for Parameter.xaml
    /// </summary>
    public partial class Test : UserControl
    {
        public Test()
        {
            InitializeComponent();
            DataContext = new TestViewModel();
        }
    }
}