﻿using System.Windows.Controls;
using WaterTestingManagementSystem.ViewModel;

namespace WaterTestingManagementSystem.View
{
    /// <summary>
    /// Interaction logic for JobSummary.xaml
    /// </summary>
    public partial class JobSummary : UserControl
    {
        public JobSummary()
        {
            InitializeComponent();
            this.DataContext = new JobSummaryViewModel();
        }
    }
}