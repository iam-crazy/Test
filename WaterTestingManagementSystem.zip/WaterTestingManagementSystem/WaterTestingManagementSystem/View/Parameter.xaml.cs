﻿namespace WaterTestingManagementSystem.View
{
    using System.Windows.Controls;
    using ViewModel;

    /// <summary>
    /// Interaction logic for Parameter.xaml
    /// </summary>
    public partial class Parameter : UserControl
    {
        public Parameter()
        {
            InitializeComponent();
            DataContext = new ParameterViewModel();
        }
    }
}