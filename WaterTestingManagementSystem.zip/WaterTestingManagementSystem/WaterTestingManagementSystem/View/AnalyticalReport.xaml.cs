﻿using System.Windows.Controls;
using WaterTestingManagementSystem.ViewModel;

namespace WaterTestingManagementSystem.View
{
    /// <summary>
    /// Interaction logic for AnalyticalReport.xaml
    /// </summary>
    public partial class AnalyticalReport : UserControl
    {
        public AnalyticalReport(long id)
        {
            InitializeComponent();
            DataContext = null;
            DataContext = new AnalyticalReportViewModel(id);
        }
    }
}