﻿using System.Windows.Controls;
using WaterTestingManagementSystem.ViewModel;

namespace WaterTestingManagementSystem.View
{
    /// <summary>
    /// Interaction logic for JobDetails.xaml
    /// </summary>
    public partial class JobDetailsView : UserControl
    {
        public JobDetailsView()
        {
            InitializeComponent();

            DataContext = new JobDetailsViewModel(true);
        }
    }
}