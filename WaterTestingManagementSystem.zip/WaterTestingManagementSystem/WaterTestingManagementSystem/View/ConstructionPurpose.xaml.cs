﻿using System.Windows.Controls;
using WaterTestingManagementSystem.ViewModel;

namespace WaterTestingManagementSystem.View
{
    /// <summary>
    /// Interaction logic for ConstructionPurpose.xaml
    /// </summary>
    public partial class ConstructionPurpose : UserControl
    {
        public ConstructionPurpose(int id)
        {
            InitializeComponent();
            DataContext = new ConstructionPurposeViewModel(id);
        }
    }
}