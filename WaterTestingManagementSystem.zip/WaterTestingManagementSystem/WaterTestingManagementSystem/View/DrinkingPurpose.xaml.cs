﻿using System.Windows.Controls;
using WaterTestingManagementSystem.ViewModel;

namespace WaterTestingManagementSystem.View
{
    /// <summary>
    /// Interaction logic for DrinkingPurpose.xaml
    /// </summary>
    public partial class DrinkingPurpose : UserControl
    {
        public DrinkingPurpose(int id)
        {
            InitializeComponent();
            DataContext = new DrinkingPurposeViewModel(id);
        }
    }
}