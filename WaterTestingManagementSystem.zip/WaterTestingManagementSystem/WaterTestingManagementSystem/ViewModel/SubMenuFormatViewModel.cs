﻿// ------------------------------------------------------------------------------//
// <copyright file="SubMenuFormatViewModel.cs" >
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Controls;
    using MaterialDesign.Domain;

    /// <summary>
    /// </summary>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged"/>
    public sealed class SubMenuFormatViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The content
        /// </summary>
        private object _content;

        /// <summary>
        /// The horizontal scroll bar visibility requirement
        /// </summary>
        private ScrollBarVisibility _horizontalScrollBarVisibilityRequirement;

        /// <summary>
        /// The margin requirement
        /// </summary>
        private Thickness _marginRequirement = new Thickness(16);

        /// <summary>
        /// The vertical scroll bar visibility requirement
        /// </summary>
        private ScrollBarVisibility _verticalScrollBarVisibilityRequirement;

        /// <summary>
        /// Initializes a new instance of the <see cref="SubMenuFormatViewModel"/> class.
        /// </summary>
        /// <param name="name">         The name.</param>
        /// <param name="content">      The content.</param>
        /// <param name="menuIcon">     The menu icon.</param>
        /// <param name="documentation">The documentation.</param>
        public SubMenuFormatViewModel(string name, object content, string menuIcon, IEnumerable<DocumentationLink> documentation)
        {
            Name = name;
            Content = content;
            Documentation = documentation;
            Icon = menuIcon;
            HasSelected = false;
        }

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets or sets the content.
        /// </summary>
        /// <value>The content.</value>
        public object Content
        {
            get { return _content; }
            set { this.MutateVerbose(ref _content, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Gets or sets the documentation.
        /// </summary>
        /// <value>The documentation.</value>
        public IEnumerable<DocumentationLink> Documentation { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has selected.
        /// </summary>
        /// <value><c>true</c> if this instance has selected; otherwise, <c>false</c>.</value>
        public bool HasSelected { get; set; }

        /// <summary>
        /// Gets or sets the horizontal scroll bar visibility requirement.
        /// </summary>
        /// <value>The horizontal scroll bar visibility requirement.</value>
        public ScrollBarVisibility HorizontalScrollBarVisibilityRequirement
        {
            get { return _horizontalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _horizontalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Gets or sets the icon.
        /// </summary>
        /// <value>The icon.</value>
        public string Icon { get; set; }

        /// <summary>
        /// Gets or sets the margin requirement.
        /// </summary>
        /// <value>The margin requirement.</value>
        public Thickness MarginRequirement
        {
            get { return _marginRequirement; }
            set { this.MutateVerbose(ref _marginRequirement, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the vertical scroll bar visibility requirement.
        /// </summary>
        /// <value>The vertical scroll bar visibility requirement.</value>
        public ScrollBarVisibility VerticalScrollBarVisibilityRequirement
        {
            get { return _verticalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _verticalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Raises the property changed.
        /// </summary>
        /// <returns></returns>
        private Action<PropertyChangedEventArgs> RaisePropertyChanged()
        {
            return args => PropertyChanged?.Invoke(this, args);
        }
    }
}