﻿// ------------------------------------------------------------------------------//
// <copyright file="BaseSummaryViewModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.ViewModel
{
    using System.ComponentModel;
    using GalaSoft.MvvmLight;
    using global::FrameWork;

    /// <summary>
    /// Initialize BaseSummaryViewModel class
    /// </summary>
    /// <seealso cref="GalaSoft.MvvmLight.ViewModelBase"/>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged"/>
    public class BaseSummaryViewModel : ViewModelBase, INotifyPropertyChanged
    {
        /// <summary>
        /// The apply Filter.
        /// </summary>
        private string applyFilter;

        /// <summary>
        /// The filter view model
        /// </summary>
        private FilterShowHideViewModel filterViewModel = new FilterShowHideViewModel();

        /// <summary>
        /// The has summary screen
        /// </summary>
        private bool hasSummaryScreen;

        /// <summary>
        /// Gets or sets the Apply Filter.
        /// </summary>
        /// <value>The Apply Filter.</value>
        public string ApplyFilter
        {
            get
            {
                return this.applyFilter;
            }

            set
            {
                this.Set(ref this.applyFilter, value);
            }
        }

        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>The stock filter.</value>
        public FilterShowHideViewModel FilterViewModel
        {
            get
            {
                return this.filterViewModel;
            }

            set
            {
                this.Set(ref this.filterViewModel, value);
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has summary screen.
        /// </summary>
        /// <value><c>true</c> if this instance has summary screen; otherwise, <c>false</c>.</value>
        public bool HasSummaryScreen
        {
            get
            {
                return this.hasSummaryScreen;
            }

            set
            {
                this.hasSummaryScreen = value;
            }
        }
    }
}