﻿// ------------------------------------------------------------------------------//
// <copyright file="ParameterViewModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.ViewModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Windows.Input;
    using BusinessLayer;
    using BusinessLayer.Contract;
    using CommonLayer;
    using CommonLayer.ViewModel;
    using GalaSoft.MvvmLight;
    using GalaSoft.MvvmLight.Command;
    using global::FrameWork;
    using LightInject;
    using MaterialDesign.Domain;

    /// <exclude/>
    public class ParameterViewModel : ViewModelBase, INotifyPropertyChanged
    {
        /// <exclude/>
        private readonly IParameterContext context;

        /// <exclude/>
        private ShowHideButtonForCreateUpdate filterViewModel = new ShowHideButtonForCreateUpdate();

        /// <exclude/>
        private IList<ParamterGridModel> girdData;

        /// <exclude/>
        private ParameterModel model = new ParameterModel();

        /// <exclude/>
        private ICommand mouseDoubleClickCommand;

        /// <exclude/>
        private ParamterGridModel selectedEmployee;

        /// <exclude/>
        public ParameterViewModel() : this(new ParameterContext())
        {
            this.SaveCommand = new CustomCommand(this.Save);
            this.CancelCommand = new CustomCommand(this.Cancel);
            this.ClearCommand = new CustomCommand(this.Clear);
            this.mouseDoubleClickCommand = new RelayCommand<object>(Edit);

            this.GetData();

            this.FilterViewModel.HasNewEntry = false;
        }

        /// <exclude/>
        public ParameterViewModel(IParameterContext context)
        {
            this.context = context;
        }

        /// <exclude/>
        public ICommand CancelCommand { get; private set; }

        /// <exclude/>
        public ICommand ClearCommand { get; private set; }

        /// <exclude/>
        public ShowHideButtonForCreateUpdate FilterViewModel
        {
            get
            {
                return this.filterViewModel;
            }

            set
            {
                this.Set(ref this.filterViewModel, value);
            }
        }

        /// <exclude/>
        public IList<ParamterGridModel> GirdData
        {
            get
            {
                if (this.girdData == null)
                {
                    this.GetData();
                }
                return this.girdData;
            }

            set
            {
                this.Set(ref this.girdData, value);
            }
        }

        /// <exclude/>
        public ParameterModel Model
        {
            get
            {
                return this.model;
            }

            set
            {
                this.Set(ref this.model, value);
            }
        }

        /// <exclude/>
        public ICommand MouseDoubleClickCommand
        {
            get
            {
                if (mouseDoubleClickCommand == null)
                {
                    mouseDoubleClickCommand = new RelayCommand<ParamterGridModel>(
                        item =>
                        {
                            var selectedItem = item;
                        });
                }

                return mouseDoubleClickCommand;
            }
        }

        /// <exclude/>
        public ICommand SaveCommand { get; private set; }

        /// <exclude/>
        public ParamterGridModel SelectedEmployee
        {
            get { return selectedEmployee; }
            set
            {
                selectedEmployee = value;
            }
        }

        /// <exclude/>
        internal static T GetService<T>()
        {
            return ConfiguredContainer.Current.GetInstance<T>();
        }

        /// <exclude/>
        private void Cancel()
        {
            var result = MaterialMessageBox.ShowWithCancel("Do you want to cancel this record?");
            if (result.ToString().ToUpper() == "OK")
            {
                this.Clear();
                this.GetData();
                this.FilterViewModel.HasNewEntry = false;
            }
        }

        /// <exclude/>
        private void Clear()
        {
            this.Model = new ParameterModel();
        }

        /// <exclude/>
        private void Edit(object obj)
        {
            if (obj != null)
            {
                SelectedEmployee = (ParamterGridModel)obj;
                Model.Id = SelectedEmployee.Id;
                Model.Name = SelectedEmployee.Name;
                Model.PermissableLimit = SelectedEmployee.PermissableLimit;
                Model.AcceptableLimit = SelectedEmployee.AcceptableLimit;
                Model.HasAnalyticalPurpose = SelectedEmployee.HasAnalyticalPurpose == 1 ? true : false;
                Model.HasConstructionPurpose = SelectedEmployee.HasConstructionPurpose == 1 ? true : false;
                Model.HasDrinkingPurpose = SelectedEmployee.HasDrinkingPurpose == 1 ? true : false;
                this.FilterViewModel.HasNewEntry = true;
                this.HasValid();
            }
        }

        /// <exclude/>
        private void GetData()
        {
            this.GirdData = GetService<IParameterContext>().Get<ParamterGridModel>(ConfiguredContainer.ConnectionString).ToList();
        }

        /// <exclude/>
        private bool HasValid()
        {
            bool hasValid = true;
            if (string.IsNullOrWhiteSpace((Model.Name ?? "").ToString()))
            {
                this.Model.errors.Add(nameof(Model.Name), "Parameter Name is mandatory");
                hasValid = false;
            }
            else
            {
                this.Model.errors.Clear(nameof(Model.Name));
            }
            return hasValid;
        }

        /// <exclude/>
        private void Save()
        {
            bool hasValid = HasValid();
            if (hasValid == true)
            {
                string output = Utility.ToString(GetService<IParameterContext>().Post(ConfiguredContainer.ConnectionString, Model));
                if (string.IsNullOrEmpty(output) || output.ToUpper() == "ERROR")
                {
                    MaterialMessageBox.ShowError(@"Parameter  Details not inserted succesfully.Contact Admin");
                }
                else
                {
                    MaterialMessageBox.Show(output.ToLowerInvariant());
                    this.Clear();
                    this.GetData();
                }
                this.FilterViewModel.HasNewEntry = false;
            }
        }
    }
}