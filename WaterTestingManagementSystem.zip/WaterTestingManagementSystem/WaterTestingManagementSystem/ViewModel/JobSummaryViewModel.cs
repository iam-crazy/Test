﻿// ------------------------------------------------------------------------------//
// <copyright file="JobSummaryViewModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.ViewModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Windows.Input;
    using BusinessLayer.Contract;
    using CommonLayer.ViewModel;
    using GalaSoft.MvvmLight.Command;
    using GalaSoft.MvvmLight.Messaging;
    using global::FrameWork;
    using LightInject;
    using MaterialDesignDemo.Domain;
    using Navigation;
    using View;

    /// <summary>
    /// Initialize JobSummaryViewModel class
    /// </summary>
    public class JobSummaryViewModel : BaseSummaryViewModel
    {
        /// <summary>
        /// The apply Filter.
        /// </summary>
        private string applyFilter;

        /// <summary>
        /// The filter
        /// </summary>
        private JobSummarySearchRequest filter = new JobSummarySearchRequest();

        /// <summary>
        /// The gird data
        /// </summary>
        private IList<JobDetailsModel> girdData;

        /// <summary>
        /// The mouse double click command
        /// </summary>
        private ICommand mouseDoubleClickCommand;

        /// <summary>
        /// The selected employee
        /// </summary>
        private JobDetailsModel selectedEmployee;

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugViewModel"/> class.
        /// </summary>
        public JobSummaryViewModel()
        {
            this.FilterViewModel.SetInitialState();
            this.SearchCommand = new CustomCommand(this.Search, this.CanSearch);
            this.ClearCommand = new CustomCommand(this.Clear);
            this.mouseDoubleClickCommand = new RelayCommand<object>(Edit);
            this.CreateData();
        }

        /// <summary>
        /// Occurs when [property changed1].
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        public ICommand ChangeToFirstViewCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    Messenger.Default.Send<SwitchViewMessage>(new SwitchViewMessage { ViewName = "Home" });
                });
            }
        }

        /// <summary>
        /// Gets the search command.
        /// </summary>
        /// <value>The search command.</value>
        public ICommand ClearCommand { get; private set; }

        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>The stock filter.</value>
        public JobSummarySearchRequest Filter
        {
            get
            {
                return this.filter;
            }

            set
            {
                this.Set(ref this.filter, value);
            }
        }

        /// <summary>
        /// Gets or sets the gird data.
        /// </summary>
        /// <value>The gird data.</value>
        public IList<JobDetailsModel> GirdData
        {
            get
            {
                if (this.girdData == null)
                {
                    this.CreateData();
                }

                return this.girdData;
            }

            set
            {
                this.Set(ref this.girdData, value);
                OnPropertyChanged("GirdData");
            }
        }

        /// <summary>
        /// Gets the mouse double click command.
        /// </summary>
        /// <value>The mouse double click command.</value>
        public ICommand MouseDoubleClickCommand
        {
            get
            {
                if (mouseDoubleClickCommand == null)
                {
                    mouseDoubleClickCommand = new RelayCommand<JobDetailsModel>(
                        item =>
                        {
                            var selectedItem = item;
                        });
                }

                return mouseDoubleClickCommand;
            }
        }

        /// <summary>
        /// Gets the drug pop up command.
        /// </summary>
        /// <value>The drug pop up command.</value>
        public ICommand PopUpCommand { get; private set; }

        /// <summary>
        /// Gets the search command.
        /// </summary>
        /// <value>The search command.</value>
        public ICommand SearchCommand { get; private set; }

        /// <summary>
        /// Gets or sets the selected employee.
        /// </summary>
        /// <value>The selected employee.</value>
        public JobDetailsModel SelectedEmployee
        {
            get { return selectedEmployee; }
            set
            {
                selectedEmployee = value;
            }
        }

        /// <summary>
        /// Searches the drug.
        /// </summary>
        public void Search()
        {
            this.FunForSetKeyValue();
            this.CreateData();
        }

        /// <summary>
        /// Gets the service.
        /// </summary>
        /// <typeparam name="T">The UI Service.</typeparam>
        /// <returns>Call the Service.</returns>
        internal static T GetService<T>()
        {
            return ConfiguredContainer.Current.GetInstance<T>();
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Determines whether this instance can search.
        /// </summary>
        /// <returns><c>true</c> if this instance can search; otherwise, <c>false</c>.</returns>
        private bool CanSearch()
        {
            if (this.Filter.FromDate == null && this.Filter.ToDate == null && this.Filter.ChallanNo == null)
            {
                return false;
            }
            else if (this.Filter.FromDate == null && this.Filter.ToDate != null && this.Filter.ChallanNo == null)
            {
                return false;
            }
            else if (this.Filter.FromDate != null && this.Filter.ToDate == null && this.Filter.ChallanNo == null)
            {
                return false;
            }
            else if (this.Filter.FromDate != null && this.Filter.ToDate == null && this.Filter.ChallanNo != null)
            {
                return false;
            }
            else if (this.Filter.FromDate == null && this.Filter.ToDate != null && this.Filter.ChallanNo != null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Clears the specified object.
        /// </summary>
        private void Clear()
        {
            this.Filter = new JobSummarySearchRequest();
            //this.GirdData = GetService<IDrugUIService>().Get(this.Filter).ToList();
            this.ApplyFilter = string.Empty;
        }

        /// <summary>
        /// Closes the specified object.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void Close(object obj)
        {
            //this.GirdData = GetService<IDrugUIService>().Get(this.Filter).ToList();
        }

        /// <summary>
        /// Creates the data.
        /// </summary>
        private void CreateData()
        {
            if (this.Filter.FromDate != null && this.Filter.ToDate != null && this.Filter.ChallanNo != null)
            {
                this.Filter.Key = "DATECHALLANNO";
            }
            else if (this.Filter.FromDate != null && this.Filter.ToDate != null && this.Filter.ChallanNo == null)
            {
                this.Filter.Key = "DATE";
            }
            else if (this.Filter.FromDate == null && this.Filter.ToDate == null && this.Filter.ChallanNo != null)
            {
                this.Filter.Key = "CHALLANNO";
            }
            else
            {
                this.Filter.Key = "ALL";
            }

            this.GirdData = GetService<IJobSummaryContext>().Get<JobDetailsModel>(ConfiguredContainer.ConnectionString, this.Filter).ToList();
        }

        /// <summary>
        /// Edits the drug.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void Edit(object obj)
        {
            if (obj != null)
            {
                SelectedEmployee = (JobDetailsModel)obj;
                MainViewModel.Current.Content = new AnalyticalReport(SelectedEmployee.Id);

                //DrugPopUpViewModel editDialogViewModel = new DrugPopUpViewModel("Drug Creation/Updation Master", this.Close, SelectedEmployee.DrugId);
                //var vw = new DrugPopUp();
                //editDialogViewModel.SetView(vw);
                //vw.Owner = Application.Current.MainWindow;
                //Application.Current.MainWindow.Opacity = 0.5;
                //vw.Closed += (sender, e) =>
                //{
                //    Application.Current.MainWindow.Opacity = 1;
                //};
                //vw.SourceInitialized += (sender, e) =>
                //{
                //    FreezeWindowBehavior.FreezeWindow(vw);
                //};
                //vw.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                //vw.WindowStyle = WindowStyle.ToolWindow;
                //vw.ResizeMode = ResizeMode.NoResize;
                //vw.Width = SystemParameters.VirtualScreenWidth - 150;
                //vw.Height = SystemParameters.VirtualScreenHeight - 150;
                //vw.ShowDialog();
            }
        }

        /// <summary>
        /// Funs for set key value.
        /// </summary>
        private void FunForSetKeyValue()
        {
            string filterDetails = string.Empty;
            if (this.Filter.FromDate != null)
            {
                filterDetails += "From Date:" + Filter.FromDate + ";";
            }
            if (this.Filter.ToDate != null)
            {
                filterDetails += "To Date:" + Filter.ToDate + ";";
            }
            if (this.Filter.ChallanNo != null)
            {
                filterDetails += "Challan No:" + Filter.ChallanNo + ";";
            }
            if (!string.IsNullOrEmpty(filterDetails))
            {
                this.ApplyFilter = "Apply Filter(" + filterDetails + ")";
            }
        }
    }
}