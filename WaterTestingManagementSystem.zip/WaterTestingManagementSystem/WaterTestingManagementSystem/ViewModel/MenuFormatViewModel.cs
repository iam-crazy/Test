﻿// ------------------------------------------------------------------------------//
// <copyright file="MenuFormatViewModel.cs" >
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Controls;
    using MaterialDesign.Domain;

    /// <summary>
    /// </summary>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged"/>
    public sealed class MenuFormatViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The content
        /// </summary>
        private object _content;

        /// <summary>
        /// The horizontal scroll bar visibility requirement
        /// </summary>
        private ScrollBarVisibility _horizontalScrollBarVisibilityRequirement;

        /// <summary>
        /// The margin requirement
        /// </summary>
        private Thickness _marginRequirement = new Thickness(16);

        /// <summary>
        /// The vertical scroll bar visibility requirement
        /// </summary>
        private ScrollBarVisibility _verticalScrollBarVisibilityRequirement;

        /// <summary>
        /// The has selected
        /// </summary>
        private bool hasSelected;

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuFormatViewModel"/> class.
        /// </summary>
        /// <param name="name">         The name.</param>
        /// <param name="content">      The content.</param>
        /// <param name="menuIcon">     The menu icon.</param>
        /// <param name="documentation">The documentation.</param>
        /// <param name="subMenuFormat">The sub menu format.</param>
        /// <param name="hasSelected">  if set to <c>true</c> [has selected].</param>
        public MenuFormatViewModel(string name, object content, string menuIcon, IEnumerable<DocumentationLink> documentation, IList<SubMenuFormatViewModel> subMenuFormat, bool hasSelected)
        {
            Name = name;
            Content = content;
            if (subMenuFormat != null)
            {
                SubMenuFormat = new ObservableCollection<SubMenuFormatViewModel>(subMenuFormat);
            }
            Documentation = documentation;
            HasSelected = hasSelected;
            Icon = menuIcon;
        }

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets or sets the content.
        /// </summary>
        /// <value>The content.</value>
        public object Content
        {
            get { return _content; }
            set { this.MutateVerbose(ref _content, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Gets or sets the documentation.
        /// </summary>
        /// <value>The documentation.</value>
        public IEnumerable<DocumentationLink> Documentation { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has selected.
        /// </summary>
        /// <value><c>true</c> if this instance has selected; otherwise, <c>false</c>.</value>
        public bool HasSelected
        {
            get
            {
                return hasSelected;
            }

            set
            {
                hasSelected = value;
            }
        }

        /// <summary>
        /// Gets or sets the horizontal scroll bar visibility requirement.
        /// </summary>
        /// <value>The horizontal scroll bar visibility requirement.</value>
        public ScrollBarVisibility HorizontalScrollBarVisibilityRequirement
        {
            get { return _horizontalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _horizontalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Gets or sets the icon.
        /// </summary>
        /// <value>The icon.</value>
        public string Icon { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the margin requirement.
        /// </summary>
        /// <value>The margin requirement.</value>
        public Thickness MarginRequirement
        {
            get { return _marginRequirement; }
            set { this.MutateVerbose(ref _marginRequirement, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the sub menu format.
        /// </summary>
        /// <value>The sub menu format.</value>
        public ObservableCollection<SubMenuFormatViewModel> SubMenuFormat { get; set; }

        /// <summary>
        /// Gets or sets the vertical scroll bar visibility requirement.
        /// </summary>
        /// <value>The vertical scroll bar visibility requirement.</value>
        public ScrollBarVisibility VerticalScrollBarVisibilityRequirement
        {
            get { return _verticalScrollBarVisibilityRequirement; }
            set { this.MutateVerbose(ref _verticalScrollBarVisibilityRequirement, value, RaisePropertyChanged()); }
        }

        /// <summary>
        /// Raises the property changed.
        /// </summary>
        /// <returns></returns>
        private Action<PropertyChangedEventArgs> RaisePropertyChanged()
        {
            return args => PropertyChanged?.Invoke(this, args);
        }
    }
}