﻿// ------------------------------------------------------------------------------//
// <copyright file="AnalyticalReportViewModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Windows.Input;
    using BusinessLayer.Contract;
    using CommonLayer;
    using CommonLayer.ViewModel;
    using GalaSoft.MvvmLight;
    using global::FrameWork;
    using LightInject;
    using MaterialDesign.Domain;

    /// <summary>
    /// Initialize AnalyticalReportViewModel class.
    /// </summary>
    /// <seealso cref="GalaSoft.MvvmLight.ViewModelBase"/>
    /// <seealso cref="System.ComponentModel.INotifyPropertyChanged"/>
    public class AnalyticalReportViewModel : ViewModelBase, INotifyPropertyChanged
    {
        /// <summary>
        /// The filter view model
        /// </summary>
        private ShowHideButtonForCreateUpdate filterViewModel = new ShowHideButtonForCreateUpdate();

        /// <summary>
        /// The gird data
        /// </summary>
        private ObservableCollection<JobResult> girdData = new ObservableCollection<JobResult>();

        /// <summary>
        /// The model
        /// </summary>
        private JobDetailsModel model = new JobDetailsModel();

        private ObservableCollection<string> resultList = new ObservableCollection<string> { "Fit For Drinking Purpose", "Not Fit For Drinking Purpose" };
        private ObservableCollection<string> statusList = new ObservableCollection<string> { "Approved", "Pending", "Cancel", "OnHold", "Process" };

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion INotifyPropertyChanged Members

        /// <summary>
        /// Initializes a new instance of the <see cref="AnalyticalReportViewModel"/> class.
        /// </summary>
        /// <param name="isValid">if set to <c>true</c> [is valid].</param>
        public AnalyticalReportViewModel(long id)
        {
            this.SaveCommand = new CustomCommand(this.Save);
            this.ClearCommand = new CustomCommand(this.Clear);

            this.GetData(id);
            this.FilterViewModel.HasNewEntry = false;
        }

        /// <summary>
        /// Gets the clear command.
        /// </summary>
        /// <value>The clear command.</value>
        public ICommand ClearCommand { get; private set; }

        /// <summary>
        /// Gets or sets the filter view model.
        /// </summary>
        /// <value>The filter view model.</value>
        public ShowHideButtonForCreateUpdate FilterViewModel
        {
            get
            {
                return this.filterViewModel;
            }

            set
            {
                this.Set(ref this.filterViewModel, value);
            }
        }

        /// <summary>
        /// Gets or sets the gird data.
        /// </summary>
        /// <value>The gird data.</value>
        public ObservableCollection<JobResult> GirdData
        {
            get
            {
                return this.girdData;
            }

            set
            {
                this.Set(ref this.girdData, value);
                RaisePropertyChanged("GirdData");
                NotifyPropertyChanged("GirdData");
            }
        }

        /// <summary>
        /// Gets or sets the model.
        /// </summary>
        /// <value>The model.</value>
        public JobDetailsModel Model
        {
            get
            {
                return this.model;
            }

            set
            {
                this.Set(ref this.model, value);
            }
        }

        public ObservableCollection<string> ResultList
        {
            get
            {
                return resultList;
            }
        }

        /// <summary>
        /// Gets the save command.
        /// </summary>
        /// <value>The save command.</value>
        public ICommand SaveCommand { get; private set; }

        public ObservableCollection<string> StatusList
        {
            get
            {
                return statusList;
            }
        }

        /// <summary>
        /// Gets the service.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        internal static T GetService<T>()
        {
            return ConfiguredContainer.Current.GetInstance<T>();
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        private void Clear()
        {
            this.Model = new JobDetailsModel();
            this.GirdData = new ObservableCollection<JobResult>();
            this.GetData(0);
        }

        /// <summary>
        /// Gets the data.
        /// </summary>
        private void GetData(long id)
        {
            IList<JobResult> mappedJobResult =
             GetService<IParameterContext>().Get<JobResult>(ConfiguredContainer.ConnectionString,
             id, "Analytical Purpose").ToList();

            IList<JobResult> defaultJobResult = GetService<IParameterContext>().Get<JobResult>(ConfiguredContainer.ConnectionString,
             id, "Default Analytical").ToList();
            IList<JobResult> jobResult = new List<JobResult>();

            if (!mappedJobResult.Any())
            {
                foreach (var item in defaultJobResult)
                {
                    JobResult kk = item;
                    jobResult.Add(kk);
                }
            }
            else
            {
                foreach (var item in defaultJobResult)
                {
                    if (mappedJobResult.Any(w => w.ParameterId == item.ParameterId))
                    {
                        JobResult kk = mappedJobResult.Where(w => w.ParameterId == item.ParameterId)?.FirstOrDefault();
                        jobResult.Add(kk);
                    }
                    else
                    {
                        JobResult kk1 = item;
                        jobResult.Add(kk1);
                    }
                }
            }
            this.GirdData = new ObservableCollection<JobResult>(jobResult);
        }

        /// <summary>
        /// Determines whether this instance has valid.
        /// </summary>
        /// <returns><c>true</c> if this instance has valid; otherwise, <c>false</c>.</returns>
        private bool HasValid()
        {
            bool hasValid = true;
            if (string.IsNullOrWhiteSpace((Model.ChallanNo ?? "").ToString()))
            {
                this.Model.errors.Add(nameof(Model.ChallanNo), "Challan No is mandatory");
                hasValid = false;
            }
            else
            {
                this.Model.errors.Clear(nameof(Model.ChallanNo));
            }

            if (string.IsNullOrWhiteSpace((Utility.ToString(Model.ChallanDate) ?? "").ToString()))
            {
                this.Model.errors.Add(nameof(Model.ChallanDate), "Challan Date is mandatory");
                hasValid = false;
            }
            else
            {
                this.Model.errors.Clear(nameof(Model.ChallanDate));
            }

            this.GirdData = girdData;
            return hasValid;
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        private void Save()
        {
            bool hasValid = HasValid();
            if (hasValid == true)
            {
                Model.JobTitle = "Analytical Purpose";
                string output = Utility.ToString(GetService<IJobDetailsContext>().Post(ConfiguredContainer.ConnectionString, Model));
                if (string.IsNullOrEmpty(output) || output.ToUpper() == "ERROR")
                {
                    MaterialMessageBox.ShowError(@"Parameter  Details not inserted succesfully.Contact Admin");
                }
                else
                {
                    Int64 id = Utility.ConvertInt64(output);
                    foreach (JobResult item in girdData)
                    {
                        item.JobTitle = "Analytical Purpose";
                        Utility.ToString(GetService<IJobDetailsContext>().Post(ConfiguredContainer.ConnectionString, item, id));
                    }

                    MaterialMessageBox.Show("Analytical Report Details Saved Successfully");

                    this.GetData(Utility.ConvertInt16(id));
                }
                this.FilterViewModel.HasNewEntry = false;
            }
        }
    }
}