﻿// ------------------------------------------------------------------------------//
// <copyright file="JobDetailsViewModel.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//

namespace WaterTestingManagementSystem.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows.Input;
    using BusinessLayer.Contract;
    using CommonLayer;
    using CommonLayer.ViewModel;
    using GalaSoft.MvvmLight.Command;
    using global::FrameWork;
    using LightInject;
    using MaterialDesign.Domain;

    /// <summary>
    /// Initialize JobDetailsViewModel class
    /// </summary>
    public partial class JobDetailsViewModel : BaseSummaryViewModel
    {
        /// <exclude/>
        private ShowHideButtonForCreateUpdate filterViewModel1 = new ShowHideButtonForCreateUpdate();

        /// <summary>
        /// The gird data
        /// </summary>
        private IList<JobResult> girdDataAnalyticalPurpose;

        /// <summary>
        /// The gird data
        /// </summary>
        private IList<JobDetailsModel> jobSummaryGrid;

        /// <summary>
        /// The filter
        /// </summary>
        private JobSummarySearchRequest jobSummarySearchRequest = new JobSummarySearchRequest();

        /// <summary>
        /// The model
        /// </summary>
        private JobDetailsModel modelAnalyticalPurpose = new JobDetailsModel();

        /// <summary>
        /// The mouse double click command
        /// </summary>
        private ICommand mouseDoubleClickJobSummaryCommand;

        /// <summary>
        /// The selected employee
        /// </summary>
        private JobDetailsModel selectedJobSummary;

        /// <exclude/>
        private ShowHideButtonForJobDetails showHideButtonForJobDetails = new ShowHideButtonForJobDetails();

        /// <summary>
        /// Initializes a new instance of the <see cref="DrugViewModel"/> class.
        /// </summary>
        public JobDetailsViewModel(bool isValid)
        {
            this.FilterViewModel.SetInitialState();
            this.SearchJobSummaryCommand = new CustomCommand(this.SearchJobSummary, this.CanSearchJobSummary);
            this.ClearJobSummaryCommand = new CustomCommand(this.ClearJobSummary);
            this.mouseDoubleClickJobSummaryCommand = new RelayCommand<object>(EditJobSummary);
            this.CreateJobSummaryData();
            this.SaveAnalyticalPurposeCommand = new CustomCommand(this.SaveAnalyticalPurpose);
            this.ClearAnalyticalPurposeCommand = new CustomCommand(this.ClearAnalyticalPurpose);
            if (isValid)
            {
                this.GetAnalyticalPurposeData();
            }

            this.FilterViewModel1.HasNewEntry = false;
            this.ShowHideButtonForJobDetails.HasAnalyticalPurpose = false;
            this.ShowHideButtonForJobDetails.HasJobSummary = false;
        }

        /// <summary>
        /// Gets the clear command.
        /// </summary>
        /// <value>The clear command.</value>
        public ICommand ClearAnalyticalPurposeCommand { get; private set; }

        /// <summary>
        /// Gets the search command.
        /// </summary>
        /// <value>The search command.</value>
        public ICommand ClearJobSummaryCommand { get; private set; }

        /// <exclude/>
        public ShowHideButtonForCreateUpdate FilterViewModel1
        {
            get
            {
                return this.filterViewModel1;
            }

            set
            {
                this.Set(ref this.filterViewModel1, value);
            }
        }

        /// <summary>
        /// Gets or sets the gird data.
        /// </summary>
        /// <value>The gird data.</value>
        public IList<JobResult> GirdDataAnalyticalPurpose
        {
            get
            {
                if (this.girdDataAnalyticalPurpose == null)
                {
                    this.GetAnalyticalPurposeData();
                }
                return this.girdDataAnalyticalPurpose;
            }

            set
            {
                this.Set(ref this.girdDataAnalyticalPurpose, value);
            }
        }

        /// <summary>
        /// Gets or sets the gird data.
        /// </summary>
        /// <value>The gird data.</value>
        public IList<JobDetailsModel> JobSummaryGrid
        {
            get
            {
                if (this.jobSummaryGrid == null)
                {
                    this.CreateJobSummaryData();
                }

                return this.jobSummaryGrid;
            }

            set
            {
                this.Set(ref this.jobSummaryGrid, value);
            }
        }

        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>The stock filter.</value>
        public JobSummarySearchRequest JobSummarySearchRequest
        {
            get
            {
                return this.jobSummarySearchRequest;
            }

            set
            {
                this.Set(ref this.jobSummarySearchRequest, value);
            }
        }

        /// <summary>
        /// Gets or sets the model.
        /// </summary>
        /// <value>The model.</value>
        public JobDetailsModel ModelAnalyticalPurpose
        {
            get
            {
                return this.modelAnalyticalPurpose;
            }

            set
            {
                this.Set(ref this.modelAnalyticalPurpose, value);
            }
        }

        /// <summary>
        /// Gets the mouse double click command.
        /// </summary>
        /// <value>The mouse double click command.</value>
        public ICommand MouseDoubleClickJobSummaryCommand
        {
            get
            {
                if (mouseDoubleClickJobSummaryCommand == null)
                {
                    mouseDoubleClickJobSummaryCommand = new RelayCommand<JobDetailsModel>(
                        item =>
                        {
                            var selectedItem = item;
                        });
                }

                return mouseDoubleClickJobSummaryCommand;
            }
        }

        /// <summary>
        /// Gets the drug pop up command.
        /// </summary>
        /// <value>The drug pop up command.</value>
        public ICommand PopUpJobSummaryCommand { get; private set; }

        /// <summary>
        /// Gets the save command.
        /// </summary>
        /// <value>The save command.</value>
        public ICommand SaveAnalyticalPurposeCommand { get; private set; }

        /// <summary>
        /// Gets the search command.
        /// </summary>
        /// <value>The search command.</value>
        public ICommand SearchJobSummaryCommand { get; private set; }

        /// <summary>
        /// Gets or sets the selected employee.
        /// </summary>
        /// <value>The selected employee.</value>
        public JobDetailsModel SelectedJobSummary
        {
            get { return selectedJobSummary; }
            set
            {
                selectedJobSummary = value;
            }
        }

        /// <exclude/>
        public ShowHideButtonForJobDetails ShowHideButtonForJobDetails
        {
            get
            {
                return this.showHideButtonForJobDetails;
            }

            set
            {
                this.Set(ref this.showHideButtonForJobDetails, value);
            }
        }

        /// <summary>
        /// Searches the drug.
        /// </summary>
        public void SearchJobSummary()
        {
            this.SetKeyValueJobSummary();
            this.CreateJobSummaryData();
        }

        /// <summary>
        /// Gets the service.
        /// </summary>
        /// <typeparam name="T">The UI Service.</typeparam>
        /// <returns>Call the Service.</returns>
        internal static T GetService<T>()
        {
            return ConfiguredContainer.Current.GetInstance<T>();
        }

        /// <summary>
        /// Determines whether this instance can search.
        /// </summary>
        /// <returns><c>true</c> if this instance can search; otherwise, <c>false</c>.</returns>
        private bool CanSearchJobSummary()
        {
            if (this.JobSummarySearchRequest.FromDate == null && this.JobSummarySearchRequest.ToDate == null && this.jobSummarySearchRequest.ChallanNo == null)
            {
                return false;
            }
            else if (this.JobSummarySearchRequest.FromDate == null && this.JobSummarySearchRequest.ToDate != null && this.JobSummarySearchRequest.ChallanNo == null)
            {
                return false;
            }
            else if (this.JobSummarySearchRequest.FromDate != null && this.JobSummarySearchRequest.ToDate == null && this.JobSummarySearchRequest.ChallanNo == null)
            {
                return false;
            }
            else if (this.JobSummarySearchRequest.FromDate != null && this.JobSummarySearchRequest.ToDate == null && this.JobSummarySearchRequest.ChallanNo != null)
            {
                return false;
            }
            else if (this.JobSummarySearchRequest.FromDate == null && this.JobSummarySearchRequest.ToDate != null && this.JobSummarySearchRequest.ChallanNo != null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        private void ClearAnalyticalPurpose()
        {
            this.ModelAnalyticalPurpose = new JobDetailsModel();
            this.GirdDataAnalyticalPurpose = new List<JobResult>();
            this.GetAnalyticalPurposeData();
        }

        /// <summary>
        /// Clears the specified object.
        /// </summary>
        private void ClearJobSummary()
        {
            this.JobSummarySearchRequest = new JobSummarySearchRequest();
            //this.GirdData = GetService<IDrugUIService>().Get(this.JobSummarySearchRequest).ToList();
            this.ApplyFilter = string.Empty;
        }

        /// <summary>
        /// Closes the specified object.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void CloseJobSummary(object obj)
        {
            //this.GirdData = GetService<IDrugUIService>().Get(this.JobSummarySearchRequest).ToList();
        }

        /// <summary>
        /// Creates the data.
        /// </summary>
        private void CreateJobSummaryData()
        {
            if (this.JobSummarySearchRequest.FromDate != null && this.JobSummarySearchRequest.ToDate != null && this.JobSummarySearchRequest.ChallanNo != null)
            {
                this.JobSummarySearchRequest.Key = "DATECHALLANNO";
            }
            else if (this.JobSummarySearchRequest.FromDate != null && this.JobSummarySearchRequest.ToDate != null && this.JobSummarySearchRequest.ChallanNo == null)
            {
                this.JobSummarySearchRequest.Key = "DATE";
            }
            else if (this.JobSummarySearchRequest.FromDate == null && this.JobSummarySearchRequest.ToDate == null && this.JobSummarySearchRequest.ChallanNo != null)
            {
                this.JobSummarySearchRequest.Key = "CHALLANNO";
            }
            else
            {
                this.JobSummarySearchRequest.Key = "ALL";
            }

            this.JobSummaryGrid = GetService<IJobSummaryContext>().Get<JobDetailsModel>(ConfiguredContainer.ConnectionString, this.JobSummarySearchRequest).ToList();
        }

        /// <summary>
        /// Edits the drug.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void EditJobSummary(object obj)
        {
            if (obj != null)
            {
                //SelectedEmployee = (JobDetailsModel)obj;
                //DrugPopUpViewModel editDialogViewModel = new DrugPopUpViewModel("Drug Creation/Updation Master", this.Close, SelectedEmployee.DrugId);
                //var vw = new DrugPopUp();
                //editDialogViewModel.SetView(vw);
                //vw.Owner = Application.Current.MainWindow;
                //Application.Current.MainWindow.Opacity = 0.5;
                //vw.Closed += (sender, e) =>
                //{
                //    Application.Current.MainWindow.Opacity = 1;
                //};
                //vw.SourceInitialized += (sender, e) =>
                //{
                //    FreezeWindowBehavior.FreezeWindow(vw);
                //};
                //vw.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                //vw.WindowStyle = WindowStyle.ToolWindow;
                //vw.ResizeMode = ResizeMode.NoResize;
                //vw.Width = SystemParameters.VirtualScreenWidth - 150;
                //vw.Height = SystemParameters.VirtualScreenHeight - 150;
                //vw.ShowDialog();
            }
        }

        /// <summary>
        /// Gets the data.
        /// </summary>
        private void GetAnalyticalPurposeData()
        {
            this.GirdDataAnalyticalPurpose = GetService<IParameterContext>().Get<JobResult>(ConfiguredContainer.ConnectionString).ToList();
        }

        /// <summary>
        /// Determines whether this instance has valid.
        /// </summary>
        /// <returns><c>true</c> if this instance has valid; otherwise, <c>false</c>.</returns>
        private bool HasValid()
        {
            bool hasValid = true;
            if (string.IsNullOrWhiteSpace((ModelAnalyticalPurpose.ChallanNo ?? "").ToString()))
            {
                this.ModelAnalyticalPurpose.errors.Add(nameof(ModelAnalyticalPurpose.ChallanNo), "Challan No is mandatory");
                hasValid = false;
            }
            else
            {
                this.ModelAnalyticalPurpose.errors.Clear(nameof(ModelAnalyticalPurpose.ChallanNo));
            }

            if (string.IsNullOrWhiteSpace((Utility.ToString(ModelAnalyticalPurpose.ChallanDate) ?? "").ToString()))
            {
                this.ModelAnalyticalPurpose.errors.Add(nameof(ModelAnalyticalPurpose.ChallanDate), "Challan Date is mandatory");
                hasValid = false;
            }
            else
            {
                this.ModelAnalyticalPurpose.errors.Clear(nameof(ModelAnalyticalPurpose.ChallanDate));
            }
            //foreach (AnalyticalPurposeGridModel item in girdData)
            //{
            //    if (string.IsNullOrWhiteSpace((Utility.ToString(item.Result) ?? "").ToString()))
            //    {
            //        item.errors.Add(nameof(item.Result), "n");
            //        hasValid = false;
            //    }
            //    else
            //    {
            //        item.errors.Clear(nameof(item.Result));
            //    }
            //}
            return hasValid;
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        private void SaveAnalyticalPurpose()
        {
            bool hasValid = HasValid();
            if (hasValid == true)
            {
                ModelAnalyticalPurpose.JobTitle = "DRINKING_PURPOSE";
                string output = Utility.ToString(GetService<IJobDetailsContext>().Post(ConfiguredContainer.ConnectionString, ModelAnalyticalPurpose));
                if (string.IsNullOrEmpty(output) || output.ToUpper() == "ERROR")
                {
                    MaterialMessageBox.ShowError(@"Parameter  Details not inserted succesfully.Contact Admin");
                }
                else
                {
                    Int64 id = Utility.ConvertInt64(output);
                    foreach (JobResult item in girdDataAnalyticalPurpose)
                    {
                        item.Id = 0;
                        Utility.ToString(GetService<IJobDetailsContext>().Post(ConfiguredContainer.ConnectionString, item, id));
                    }

                    MaterialMessageBox.Show("Drinking Purpose Report Details Saved Successfully");
                    this.ClearAnalyticalPurpose();
                    this.GetAnalyticalPurposeData();
                }
            }
        }

        /// <summary>
        /// Funs for set key value.
        /// </summary>
        private void SetKeyValueJobSummary()
        {
            string filterDetails = string.Empty;
            if (this.JobSummarySearchRequest.FromDate != null)
            {
                filterDetails += "From Date:" + JobSummarySearchRequest.FromDate + ";";
            }
            if (this.JobSummarySearchRequest.ToDate != null)
            {
                filterDetails += "To Date:" + JobSummarySearchRequest.ToDate + ";";
            }
            if (this.JobSummarySearchRequest.ChallanNo != null)
            {
                filterDetails += "Challan No:" + JobSummarySearchRequest.ChallanNo + ";";
            }
            if (!string.IsNullOrEmpty(filterDetails))
            {
                this.ApplyFilter = "Apply Filter(" + filterDetails + ")";
            }
        }
    }
}