﻿// ------------------------------------------------------------------------------//
// <copyright file="SwitchViewMessage.cs" company="anantH Enterprises">
//     Copyright (c) anantH Enterprises. All rights reserved.
// </copyright>
// <author>AnantH.g</author>
// ------------------------------------------------------------------------------//
namespace WaterTestingManagementSystem.Navigation
{
    /// <summary>
    /// Initialize SwitchViewMessage class
    /// </summary>
    public class SwitchViewMessage
    {
        public string ViewName { get; set; }
    }
}