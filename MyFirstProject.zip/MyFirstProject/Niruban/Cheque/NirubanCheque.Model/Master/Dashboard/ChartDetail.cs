﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NirubanCheque.Model.Master.Dashboard
{
    /// <summary>
    /// Defines the <see cref="ChartDetail" />
    /// </summary>
    public class ChartDetail
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Chart
        /// </summary>
        public IList<ChartContent> Chart { get; } = new List<ChartContent>();

        /// <summary>
        /// Gets or sets the Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the Total
        /// </summary>
        public decimal Total { get; set; }

        #endregion
    }

}
