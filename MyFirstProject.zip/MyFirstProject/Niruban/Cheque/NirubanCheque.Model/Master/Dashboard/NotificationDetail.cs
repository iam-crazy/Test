﻿using NirubanCheque.Model.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NirubanCheque.Model.Master.Dashboard
{
    /// <summary>
    /// Defines the <see cref="NotificationDetail" />
    /// </summary>
    public class NotificationDetail: ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Date
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Gets or sets the Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets a value indicating whether IsActive
        /// </summary>
        public bool IsExpried
        {
            get { return Date > DateTime.Now; }
        }

        /// <summary>
        /// Gets or sets the SerialNumber
        /// </summary>
        public int SerialNumber { get; set; }

        #endregion
    }
}
