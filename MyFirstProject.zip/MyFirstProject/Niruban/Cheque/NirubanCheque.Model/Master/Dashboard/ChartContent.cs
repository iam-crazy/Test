﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NirubanCheque.Model.Master.Dashboard
{

    /// <summary>
    /// Defines the <see cref="ChartContent" />
    /// </summary>
    public class ChartContent
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the Legend
        /// </summary>
        public string Legend { get; set; }

        #endregion
    }


}
