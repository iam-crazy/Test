﻿
namespace NirubanCheque.Model.Master
{
    using Common;

   public class City : ModelBase
    {
       
    }
}
