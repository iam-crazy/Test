﻿
namespace NirubanCheque.Model.Master
{
    using Common;

   public class Bank : ModelBase
    {
       
    }
}
