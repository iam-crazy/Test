﻿// <copyright file="Collection.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a Collection.cs</summary>

namespace NirubanCheque.Model.Transaction
{
    using Common;
    using Master;
    using System;

    /// <summary>
    /// Defines the <see cref="CollectionEntry" />
    /// </summary>
    public class CollectionEntry : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Cheque
        /// </summary>
        public Cheque Cheque { get; set; }

        /// <summary>
        /// Gets or sets the ReceiveDate
        /// </summary>
        public DateTime ReceivedDate { get; set; }

        /// <summary>
        /// Gets or sets the Remark
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// Gets or sets the Supplier
        /// </summary>
        public ConsumerBase Supplier { get; set; }

        #endregion
    }
}
