﻿// <copyright file="ChequeBase.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a Cheque.cs</summary>

namespace NirubanCheque.Model.Transaction
{
    using NirubanCheque.Model.Common;
    using System;

    /// <summary>
    /// Defines the <see cref="ChequeBase" />
    /// </summary>
    public class ChequeBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the ChequeNumber
        /// </summary>
        public string ChequeNumber { get; set; }
      
        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Bank
        /// </summary>
        public string BankName { get; set; }

        /// <summary>
        /// Gets or sets the ChequeNumber
        /// </summary>
        public char Status { get; set; }

        public string StatusDescription
        {
            get
            {
                return "Yet to Deposit";
            }
        }

        #endregion
    }
}
