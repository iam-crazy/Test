﻿namespace NirubanCheque.Model.Transaction
{
    public class Clearance : Common.ModelBase
    {
        public ChequeBase Cheque { get; set; }
        public string Remarks { get; set; }
        public bool IsCleared { get; set; }
        public decimal? Amount { get; set; }
    }
}
