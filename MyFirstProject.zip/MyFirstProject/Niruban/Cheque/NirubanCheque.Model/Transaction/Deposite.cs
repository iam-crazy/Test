﻿// <copyright file="Deposit.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a Deposit.cs</summary>

namespace NirubanCheque.Model.Transaction
{
    using Common;
    using Master;
    using System;

    /// <summary>
    /// Defines the <see cref="Deposite" />
    /// </summary>
    public class Deposite : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the AccountNumber
        /// </summary>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the Bank
        /// </summary>
        public GeneralCode Bank { get; set; }

        /// <summary>
        /// Gets or sets the Branch
        /// </summary>
        public GeneralCode Branch { get; set; }

        /// <summary>
        /// Gets or sets the Cheque
        /// </summary>
        public ChequeBase Cheque { get; set; }

        /// <summary>
        /// Gets or sets the DepositDate
        /// </summary>
        public DateTime DepositDate { get; set; }

        /// <summary>
        /// Gets or sets the Depositor
        /// </summary>
        public ConsumerBase Depositer { get; set; }

        /// <summary>
        /// Gets or sets the Remark
        /// </summary>
        public string Remark { get; set; }
        public string StatusDescription { get; set; }

        #endregion
    }
}
