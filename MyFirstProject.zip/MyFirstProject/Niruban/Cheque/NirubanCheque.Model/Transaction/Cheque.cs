﻿// <copyright file="Cheque.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a Cheque.cs</summary>

namespace NirubanCheque.Model.Transaction
{
    using NirubanCheque.Model.Common;
    using System;

    /// <summary>
    /// Defines the <see cref="ChequeBase" />
    /// </summary>
    public class Cheque:ChequeBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the Bank
        /// </summary>
        public GeneralCode Bank { get; set; }

        /// <summary>
        /// Gets or sets the Branch
        /// </summary>
        public GeneralCode Branch { get; set; }

        /// <summary>
        /// Gets or sets the ChequeDate
        /// </summary>
        public DateTime ChequeDate { get; set; }

        /// <summary>
        /// Gets or sets the Remark
        /// </summary>
        public string Remark { get; set; }

        #endregion
    }
}
