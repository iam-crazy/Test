﻿
using CrazyFramework.Model;

namespace NirubanCheque.Model.Common
{
    public class ModelBase
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public bool IsActive { get; set; }
        public int UserId { get; set; }
        public RecordStatus Status { get; set; }
    }
}
