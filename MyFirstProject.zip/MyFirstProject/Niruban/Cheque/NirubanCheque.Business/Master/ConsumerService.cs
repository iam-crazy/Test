﻿// <copyright file="ConsumerService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a ConsumerService.cs</summary>

namespace NirubanCheque.Business.Master
{
    using CrazyFramework.Model;
    using Dataaccess.Interface;
    using Interface;
    using Model.Common;
    using Model.Master;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="ConsumerService" />
    /// </summary>
    public class ConsumerService : BaseService<IConsumerRepository>, IConsumerService
    {

        public ConsumerService(IConsumerRepository context) : base(context)
        {
        }

        public async Task<OperationOutcome> Delete(int id, int userId)
        {
            Consumer consumer = new Consumer();
            consumer.Id = id;
            consumer.UserId = userId;
            consumer.Status = RecordStatus.Delete;
            return await iContext.Save(consumer);
        }

        #region Methods

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="consumer">The <see cref="Consumer"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        public async Task<OperationOutcome> Save(Consumer consumer)
        {
            OperationOutcome operation = new OperationOutcome();
            if (consumer != null)
            {
                consumer.Status = consumer.Id > 0 ? RecordStatus.Update : RecordStatus.Create;
                operation = await iContext.Save(consumer);
                if (operation.Status == OperationOutcomeStatus.Success)
                {
                    operation.Message = consumer.Id > 0 ? "Updated Successfully" : "Saved Successfully";
                }
            }
            return operation;
        }

        public async Task<IList<Consumer>> Get()
        {
            return await iContext.Get();
        }

        public async Task<IList<ConsumerBase>> Search()
        {
            return await iContext.Search();
        }

        #endregion
    }
}
