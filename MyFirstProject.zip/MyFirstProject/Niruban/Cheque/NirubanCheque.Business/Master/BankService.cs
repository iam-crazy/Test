﻿// <copyright file="BankService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a BankService.cs</summary>

namespace NirubanCheque.Business.Master
{
    using CrazyFramework.Model;
    using Dataaccess.Interface;
    using Interface;
    using Model.Master;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="BankService" />
    /// </summary>
    public class BankService : BaseService<IBankRepository>, IBankService
    {
        #region Methods
        public BankService(IBankRepository context) : base(context)
        {
        }

        public async Task<OperationOutcome> Delete(int id, int userId)
        {
            Bank bank = new Bank();
            bank.Id = id;
            bank.UserId = userId;
            bank.Status = RecordStatus.Delete;
            OperationOutcome operation = await iContext.Save(bank);
            operation.Message = "Deleted Successfully";
            return operation;
        }

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{Bank}"/></returns>
        public async Task<IList<Bank>> Get()
        {
            return await iContext.Get();
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="bank">The <see cref="Bank"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        public async Task<OperationOutcome> Save(Bank bank)
        {
            OperationOutcome operation = new OperationOutcome();
            if (bank != null)
            {
                bank.Status = bank.Id > 0 ? RecordStatus.Update : RecordStatus.Create;
                operation = await iContext.Save(bank);
                if (operation.Status == OperationOutcomeStatus.Success)
                {
                    operation.Message = bank.Id > 0 ? "Updated Successfully" : "Saved Successfully";
                }
            }
            return operation;
        }

        #endregion
    }
}
