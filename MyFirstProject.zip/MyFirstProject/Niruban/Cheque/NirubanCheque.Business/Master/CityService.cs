﻿// <copyright file="CityService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a CityService.cs</summary>

namespace NirubanCheque.Business.Master
{
    using CrazyFramework.Model;
    using Dataaccess.Interface;
    using Interface;
    using Model.Master;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="CityService" />
    /// </summary>
    public class CityService : BaseService<ICityRepository>, ICityService
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CityService"/> class.
        /// </summary>
        /// <param name="context">The <see cref="ICityRepository"/></param>
        public CityService(ICityRepository context) : base(context)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Delete
        /// </summary>
        /// <param name="id">The <see cref="int"/></param>
        /// <returns>The <see cref="Task{OperationOutcome}"/></returns>
        public async Task<OperationOutcome> Delete(int id, int userId)
        {
            City city = new City();
            city.Id = id;
            city.UserId = userId;
            city.Status = RecordStatus.Delete;
            OperationOutcome operation = await iContext.Save(city);
            operation.Message = "Deleted Successfully";
            return operation;
        }

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="Task{IList{City}}"/></returns>
        public async Task<IList<City>> Get()
        {
            return await iContext.Get();
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="city">The <see cref="City"/></param>
        /// <returns>The <see cref="Task{OperationOutcome}"/></returns>
        public async Task<OperationOutcome> Save(City city)
        {
            OperationOutcome operation = new OperationOutcome();
            if (city != null)
            {
                city.Status = city.Id > 0 ? RecordStatus.Update : RecordStatus.Create;
                operation = await iContext.Save(city);
                operation.Message = city.Id > 0 ? "Updated Successfully" : "Saved Successfully";
            }
            return operation;
        }

        #endregion
    }
}
