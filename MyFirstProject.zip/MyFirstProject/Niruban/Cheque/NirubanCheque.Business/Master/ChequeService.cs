﻿using NirubanCheque.Business.Interface;
using NirubanCheque.Dataaccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NirubanCheque.Model.Transaction;

namespace NirubanCheque.Business.Master
{
    public class ChequeService : BaseService<IChequeRepository>, IChequeService
    {
        public ChequeService(IChequeRepository context) : base(context)
        {
        }

        public async Task<IList<ChequeBase>> Search(string status)
        {
            return await iContext.Search(status);
        }
    }
}
