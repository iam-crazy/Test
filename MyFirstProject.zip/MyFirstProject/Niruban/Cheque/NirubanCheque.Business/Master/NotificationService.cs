﻿// <copyright file="NotificationService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a NotificationService.cs</summary>

namespace NirubanCheque.Business.Master
{
    using CrazyFramework.Model;
    using Dataaccess.Interface;
    using Interface;
    using Model.Master.Dashboard;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="NotificationService" />
    /// </summary>
    public class NotificationService : BaseService<INotificationRepository>, INotificationService
    {

        public NotificationService(INotificationRepository context) : base(context)
        {
        }

        public async Task<IList<NotificationDetail>> Get()
        {
            return await iContext.Get();
        }

        public async Task<OperationOutcome> Save(NotificationDetail notification)
        {
            OperationOutcome operation = new OperationOutcome();
            if (notification != null)
            {
                operation = await iContext.Save(notification);
                operation.Message = "Saved Successfully";
            }

            return operation; 
        }
    }
}
