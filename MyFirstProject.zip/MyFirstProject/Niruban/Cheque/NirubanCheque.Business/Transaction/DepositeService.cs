﻿using NirubanCheque.Business.Interface;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrazyFramework.Model;
using NirubanCheque.Model.Transaction;
using NirubanCheque.Dataaccess.Interface;
using System.Collections.Generic;

namespace NirubanCheque.Business.Transaction
{
    public class DepositeService : BaseService<IDepositeRepository>, IDepositeService
    {
        public DepositeService(IDepositeRepository context) : base(context)
        {
        }

        public async Task<OperationOutcome> Delete(int id, int userId)
        {
            return new OperationOutcome();
        }

        public async Task<IList<Deposite>> Get()
        {
            return await iContext.Get();
        }

        public async Task<OperationOutcome> Save(Deposite deposite)
        {
            OperationOutcome operation = new OperationOutcome();
            if (deposite != null)
            {
                deposite.Status = deposite.Id > 0 ? RecordStatus.Update : RecordStatus.Create;
                operation = await iContext.Save(deposite);
                if (operation.Status == OperationOutcomeStatus.Success)
                {
                    operation.Message = deposite.Id > 0 ? "Updated Successfully" : "Saved Successfully";
                }
            }

            return operation;
        }
    }
}
