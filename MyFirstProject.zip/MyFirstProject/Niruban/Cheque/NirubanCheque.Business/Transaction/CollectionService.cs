﻿using NirubanCheque.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrazyFramework.Model;
using NirubanCheque.Model.Transaction;
using NirubanCheque.Dataaccess.Interface;

namespace NirubanCheque.Business.Transaction
{
    public class CollectionService : BaseService<ICollectionRepository>, ICollectionService
    {
        public CollectionService(ICollectionRepository context) : base(context)
        {
        }

        public async Task<OperationOutcome> Delete(int id, int userId)
        {
            return new OperationOutcome();
        }

        public async Task<IList<CollectionEntry>> Get()
        {
            return await iContext.Get();
        }

        public async Task<OperationOutcome> Save(CollectionEntry collection)
        {
            OperationOutcome operation = new OperationOutcome();
            if (collection != null)
            {
                collection.Status = collection.Id > 0 ? RecordStatus.Update : RecordStatus.Create;
                operation = await iContext.Save(collection);
                if (operation.Status == OperationOutcomeStatus.Success)
                {
                    operation.Message = collection.Id > 0 ? "Updated Successfully" : "Saved Successfully";
                }
            }

            return operation;
        }
    }
}
