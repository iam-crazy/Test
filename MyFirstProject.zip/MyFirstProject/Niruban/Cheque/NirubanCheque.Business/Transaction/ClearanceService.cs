﻿using NirubanCheque.Business.Interface;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrazyFramework.Model;
using NirubanCheque.Model.Transaction;
using NirubanCheque.Dataaccess.Interface;

namespace NirubanCheque.Business.Transaction
{
    public class ClearanceService : BaseService<IClearanceRepository>, IClearanceService
    {
        public ClearanceService(IClearanceRepository context) : base(context)
        {
        }

        

        public async Task<OperationOutcome> Save(Clearance Clearance)
        {
            OperationOutcome operation = new OperationOutcome();
            if (Clearance != null)
            {
                Clearance.Status = Clearance.Id > 0 ? RecordStatus.Update : RecordStatus.Create;
                operation = await iContext.Save(Clearance);
                if (operation.Status == OperationOutcomeStatus.Success)
                {
                    operation.Message = "Updated Successfully";
                }
            }

            return operation;
        }
    }
}
