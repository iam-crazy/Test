﻿// <copyright file="IChequeService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IChequeService.cs</summary>

namespace NirubanCheque.Business.Interface
{
    using CrazyFramework.Model;
    using Model.Master;
    using Model.Transaction;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IChequeService" />
    /// </summary>
    public interface IChequeService
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{ChequeBase}"/></returns>
        Task<IList<ChequeBase>> Search(string status);

        #endregion
    }

    #endregion
}
