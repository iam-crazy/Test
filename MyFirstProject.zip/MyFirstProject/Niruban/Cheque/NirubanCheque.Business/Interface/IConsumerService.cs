﻿// <copyright file="IConsumerService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IConsumerService.cs</summary>

namespace NirubanCheque.Business.Interface
{
    using CrazyFramework.Model;
    using Model.Common;
    using Model.Master;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IConsumerService" />
    /// </summary>
    public interface IConsumerService
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{Consumer}"/></returns>
        Task<IList<Consumer>> Get();

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="bank">The <see cref="Consumer"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        Task<OperationOutcome> Save(Consumer bank);

        /// <summary>
        /// The Search
        /// </summary>
        /// <returns>The <see cref="IList{GeneralCode}"/></returns>
        Task<IList<ConsumerBase>> Search();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<OperationOutcome> Delete(int id, int userId);

        #endregion
    }

    #endregion
}
