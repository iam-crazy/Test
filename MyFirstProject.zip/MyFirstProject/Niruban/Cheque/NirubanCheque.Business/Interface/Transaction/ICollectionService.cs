﻿// <copyright file="ICollectionService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a ICollectionService.cs</summary>

namespace NirubanCheque.Business.Interface
{
    using CrazyFramework.Model;
    using Model.Master;
    using Model.Transaction;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="ICollectionService" />
    /// </summary>
    public interface ICollectionService
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{CollectionEntry}"/></returns>
        Task<IList<CollectionEntry>> Get();

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="collection">The <see cref="CollectionEntry"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        Task<OperationOutcome> Save(CollectionEntry collection);

        Task<OperationOutcome> Delete(int id, int userId);

        #endregion
    }

    #endregion
}
