﻿// <copyright file="IBankService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IBankService.cs</summary>

namespace NirubanCheque.Business.Interface
{
    using CrazyFramework.Model;
    using Model.Master;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IBankService" />
    /// </summary>
    public interface IBankService
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{Bank}"/></returns>
        Task<IList<Bank>> Get();

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="bank">The <see cref="Bank"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        Task<OperationOutcome> Save(Bank bank);

        Task<OperationOutcome> Delete(int id, int userId);

        #endregion
    }

    #endregion
}
