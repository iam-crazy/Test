﻿namespace NirubanCheque.Data
{


    partial class ChequeDataset
    {
    }
}
