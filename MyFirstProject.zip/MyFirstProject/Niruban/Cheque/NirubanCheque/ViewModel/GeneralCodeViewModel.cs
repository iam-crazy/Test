﻿// <copyright file="GeneralCodeViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a GeneralCodeViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using NirubanCheque.Model.Common;

    /// <summary>
    /// Defines the <see cref="GeneralCodeViewModel" />
    /// </summary>
    public class GeneralCodeViewModel
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name { get; set; }

        public bool IsActive { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The ToModel
        /// </summary>
        /// <returns>The <see cref="GeneralCode"/></returns>
        public GeneralCode ToModel()
        {
            return new GeneralCode()
            {
                Id = this.Id,
                Name = this.Name,
                IsActive=this.IsActive
            };
        }

        #endregion
    }
}
