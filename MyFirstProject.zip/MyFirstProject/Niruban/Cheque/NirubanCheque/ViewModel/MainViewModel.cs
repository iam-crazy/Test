﻿// <copyright file="MainViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a MainViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using CrazyFramework.WPF.Interface;
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Model;
    using NirubanCheque.Views;
    using Resources;
    using Resources.Supplier;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Windows.Input;
    using Views.Report;

    /// <summary>
    /// Defines the <see cref="MainViewModel" />
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// Defines the currentiew
        /// </summary>
        private IView currentiew;
        /// <summary>
        /// Defines the englishBorder
        /// </summary>
        private int englishBorder;

        /// <summary>
        /// Defines the isHome
        /// </summary>
        private bool isHome;
        /// <summary>
        /// Defines the tamilBorder
        /// </summary>
        private int tamilBorder;

        private string status;
        #endregion

        #region Constructors

        public static MainViewModel Current;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainViewModel"/> class.
        /// </summary>
        public MainViewModel()
        {
            Menus = new ObservableCollection<MenuHeader>();
            EnglishCommand = new Command(ToEnglish);
            TamilCommand = new Command(ToTamil);
            LoadMenu();
            LoadDashBoard(string.Empty);
            this.UserId = 1;
            this.Status = "Ready..";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the AdditionalGroup
        /// </summary>
        public MenuGroup AdditionalGroup { get; set; }

        /// <summary>
        /// Gets or sets the Currentiew
        /// </summary>
        public IView Currentiew
        {
            get
            {
                return this.currentiew;
            }
            set
            {
                this.Set(ref this.currentiew, value);
            }
        }

        /// <summary>
        /// Gets or sets the EnglishBorder
        /// </summary>
        public int EnglishBorder
        {
            get
            {
                return this.englishBorder;
            }
            set
            {
                this.Set(ref this.englishBorder, value);
            }
        }

       
        public string Status
        {
            get
            {
                return this.status;
            }
            set
            {
                this.Set(ref this.status, value);
            }
        }

        /// <summary>
        /// Gets or sets the EnglishCommand
        /// </summary>
        public ICommand EnglishCommand { get; set; }

        /// <summary>
        /// Gets or sets the Menus
        /// </summary>
        public ObservableCollection<MenuHeader> Menus { get; set; }

        public int UserId { get; }

        /// <summary>
        /// Gets or sets the TamilBorder
        /// </summary>
        public int TamilBorder
        {
            get
            {
                return this.tamilBorder;
            }
            set
            {
                this.Set(ref this.tamilBorder, value);
            }
        }

        /// <summary>
        /// Gets or sets the TamilCommand
        /// </summary>
        public ICommand TamilCommand { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The ChangeLanguage
        /// </summary>
        /// <param name="cluture">The <see cref="string"/></param>
        /// <param name="isTamil">The <see cref="bool"/></param>
        public void ChangeLanguage(string cluture, bool isTamil)
        {
            Supplier.Culture = new CultureInfo(cluture);
            this.EnglishBorder = isTamil ? 0 : 1;
            this.TamilBorder = isTamil ? 1 : 0;
            this.Currentiew = this.currentiew;
            this.RaisePropertyChanged(nameof(this.Currentiew));
        }

        /// <summary>
        /// The LoadMenu
        /// </summary>
        public void LoadMenu()
        {
            Menus.Clear();
            MenuHeader home = new MenuHeader("Home");
            MenuHeader report = new MenuHeader("Report");
            home.IsSelected = isHome;
            report.IsSelected = !isHome;
            MenuGroup masterGroup = new MenuGroup("Master");
            masterGroup.Items.Add(new MenuItem("Dashboard", "Images\\dashboard.png", new Command(this.LoadDashBoard)));
            masterGroup.Items.Add(new MenuItem("Supplier/Depositor Detail", "Images\\supplier.png", new Command(this.LoadSupplier)));
            if (AdditionalGroup != null)
            {
                home.Groups.Add(AdditionalGroup);

            }
            home.Groups.Add(masterGroup);

            MenuGroup transactionGroup = new MenuGroup("Transaction");
            transactionGroup.Items.Add(new MenuItem("Collection Detail", "Images\\collection.png", new Command(this.LoadCollection)));
            transactionGroup.Items.Add(new MenuItem("Deposit Detail", "Images\\deposit.png", new Command(this.LoadDepositer)));
            transactionGroup.Items.Add(new MenuItem("Clearance Detail", "Images\\verify.png", new Command(this.LoadClearance)));
            home.Groups.Add(transactionGroup);

            MenuGroup reportGroup = new MenuGroup("Supplier/Depositor");
            reportGroup.Items.Add(new MenuItem("Supplier", "Images\\supplierreport.png", new Command(this.LoadSupplierReport)));
            reportGroup.Items.Add(new MenuItem("Depositor", "Images\\clientreport.png", new Command(this.LoadDepositerReport)));
            MenuGroup chequeGroup = new MenuGroup("Cheque");
            chequeGroup.Items.Add(new MenuItem("Cheque Detail", "Images\\chequereport.png", new Command(this.LoadChequeReport)));
            chequeGroup.Items.Add(new MenuItem("Overall Detail", "Images\\overallreport.png", new Command(this.LoadOverallReport)));

            report.Groups.Add(reportGroup);
            report.Groups.Add(chequeGroup);

            Menus.Add(home);
            Menus.Add(report);
        }

        /// <summary>
        /// The LoadChequeReport
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadChequeReport(object obj)
        {
            Currentiew = new ChequeReport();
            DashboardViewModel model = new DashboardViewModel();
            Currentiew.DataContext = model;
            isHome = true;
            AdditionalGroup = null;
        }

        /// <summary>
        /// The LoadClearance
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadClearance(object obj)
        {
            Currentiew = new ClearingView();
            ClearingViewModel model = new ClearingViewModel();
            Currentiew.DataContext = model;
            AdditionalGroup = model.Initialize();
            isHome = true;
            LoadMenu();
        }

        /// <summary>
        /// The LoadCollection
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadCollection(object obj)
        {
            Currentiew = new CollectionView();
            CollectionViewModel model = new CollectionViewModel();
            Currentiew.DataContext = model;
            AdditionalGroup = model.Initialize();
            isHome = true;
            LoadMenu();
        }

        /// <summary>
        /// The LoadDashBoard
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadDashBoard(object obj)
        {
            Currentiew = new DashboardView();
            DashboardViewModel model = new DashboardViewModel();
            Currentiew.DataContext = model;
            AdditionalGroup = model.Initialize();
            isHome = true;
            LoadMenu();
        }

        /// <summary>
        /// The LoadDepositor
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadDepositer(object obj)
        {
            Currentiew = new DepositeView();
            DepositeViewModel model = new DepositeViewModel();
            Currentiew.DataContext = model;
            AdditionalGroup = model.Initialize();
            isHome = true;
            LoadMenu();
        }

        /// <summary>
        /// The LoadDepositorReport
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadDepositerReport(object obj)
        {
            Currentiew = new DepositerReport();
            DashboardViewModel model = new DashboardViewModel();
            Currentiew.DataContext = model;
            isHome = true;
            AdditionalGroup = null;
        }

        /// <summary>
        /// The LoadOverallReport
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadOverallReport(object obj)
        {
            Currentiew = new OverallReport();
            DashboardViewModel model = new DashboardViewModel();
            Currentiew.DataContext = model;
            isHome = true;
            AdditionalGroup = null;
        }

        /// <summary>
        /// The LoadSupplier
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadSupplier(object obj)
        {
            Currentiew = new SupplierView();
            SupplierViewModel model = new SupplierViewModel();
            Currentiew.DataContext = model;
            AdditionalGroup = model.Initialize();
            isHome = true;
            LoadMenu();
        }

        /// <summary>
        /// The LoadSupplierReport
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void LoadSupplierReport(object obj)
        {
            Currentiew = new SupplierReportView();
            DashboardViewModel model = new DashboardViewModel();
            Currentiew.DataContext = model;
            isHome = true;
            AdditionalGroup = null;
        }

        /// <summary>
        /// The ToEnglish
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void ToEnglish(object obj)
        {
            ChangeLanguage("", false);
        }

        /// <summary>
        /// The ToTamil
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void ToTamil(object obj)
        {
            ChangeLanguage("ta-IN", true);
        }

        public void ShowBusy(string statusDetail)
        {
            this.ShowBusy();
            this.Status = statusDetail;
        }
        public void HideBusy(string statusDetail)
        {
            this.HideBusy();
            this.Status = statusDetail;
        }

        
        #endregion
    }

}
