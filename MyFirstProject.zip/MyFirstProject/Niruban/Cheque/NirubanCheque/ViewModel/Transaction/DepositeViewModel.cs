﻿// <copyright file="depositeviewmodel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a depositeviewmodel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using Business.Interface;
    using Configuration;
    using CrazyFramework.Model;
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Model.Transaction;
    using NirubanCheque.Extensions;
    using NirubanCheque.Model.Common;
    using NirubanCheque.Model.Master;
    using NirubanCheque.Views.Transaction;
    using System;
    using System.Threading.Tasks;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref="DepositeViewModel" />
    /// </summary>
    public class DepositeViewModel : Selector<Deposite>
    {
        #region Fields

        /// <summary>
        /// Defines the accountNumber
        /// </summary>
        private string accountNumber;

        /// <summary>
        /// Defines the bank
        /// </summary>
        private Selection<GeneralCode> bank;

        /// <summary>
        /// Defines the branch
        /// </summary>
        private Selection<GeneralCode> branch;

        /// <summary>
        /// Defines the cheque
        /// </summary>
        private Selection<ChequeBase> cheque;

        /// <summary>
        /// Defines the depositeDate
        /// </summary>
        private DateTime? depositeDate;

        /// <summary>
        /// Defines the depositer
        /// </summary>
        private Selection<ConsumerBase> depositer;

        /// <summary>
        /// Defines the popup
        /// </summary>
        private BankPopup popup;

        /// <summary>
        /// Defines the remarks
        /// </summary>
        private string remarks;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the AccountNumber
        /// </summary>
        public string AccountNumber
        {
            get { return this.accountNumber; }
            set { this.Set(ref this.accountNumber, value); }
        }

        /// <summary>
        /// Gets or sets the City
        /// </summary>
        public Selection<GeneralCode> Bank
        {
            get
            {
                if (this.bank == null)
                {
                    this.bank = new Selection<GeneralCode>(this.LoadBank);
                }

                return bank;
            }
            set { this.Set(ref this.bank, value); }
        }

        /// <summary>
        /// Gets or sets the City
        /// </summary>
        public Selection<GeneralCode> Branch
        {
            get
            {
                if (this.branch == null)
                {
                    this.branch = new Selection<GeneralCode>(this.LoadBranch);
                }

                return branch;
            }
            set { this.Set(ref this.branch, value); }
        }

        /// <summary>
        /// Gets or sets the Cheque
        /// </summary>
        public Selection<ChequeBase> Cheque
        {
            get
            {
                if (this.cheque == null)
                {
                    this.cheque = new Selection<ChequeBase>(this.LoadCheque);
                }

                return cheque;
            }
            set { this.Set(ref this.cheque, value); }
        }

        /// <summary>
        /// Gets or sets the DepositeDate
        /// </summary>
        public DateTime? DepositeDate
        {
            get { return this.depositeDate; }
            set { this.Set(ref this.depositeDate, value); }
        }

        /// <summary>
        /// Gets or sets the Depositer
        /// </summary>
        public Selection<ConsumerBase> Depositer
        {
            get
            {
                if (this.depositer == null)
                {
                    this.depositer = new Selection<ConsumerBase>(this.LoadDepositer);
                }

                return depositer;
            }

            set
            {
                this.Set(ref this.depositer, value);
            }
        }

        /// <summary>
        /// Gets or sets the Remarks
        /// </summary>
        public string Remarks
        {
            get { return this.remarks; }
            set { this.Set(ref this.remarks, value); }
        }

        public int Id { get; private set; }

        #endregion

        #region Methods

        /// <summary>
        /// The Initialize
        /// </summary>
        /// <returns>The <see cref="MenuGroup"/></returns>
        public MenuGroup Initialize()
        {
            MenuGroup masterGroup = new MenuGroup("Action");
            masterGroup.Items.Add(new MenuItem("New", "Images\\new.png", new Command(New)));
            masterGroup.Items.Add(new MenuItem("Save", "Images\\save.png", new Command(this.Save)));
            masterGroup.Items.Add(new MenuItem("Delete", "Images\\delete.png", new Command(this.Delete)));
            masterGroup.Items.Add(new MenuItem("Add Bank", "Images\\bank.png", new Command(this.AddBank)));
            masterGroup.Items.Add(new MenuItem("Add Branch", "Images\\branch.png", new Command(this.AddBranch)));
            return masterGroup;
        }
        public ICommand DetailCommand { get; set; }

        public DepositeViewModel()
        {
            this.DetailCommand = new Command(this.DetailExecution, this.CanDetail);
            this.LoadDetail();
        }

        private bool CanDetail(object obj)
        {
            return this.Current != null;
        }

        /// <summary>
        /// The LoadSupplier
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async void LoadDetail()
        {
            var deposites = await InstanceConfig.GetInstance<IDepositeService>().Get();
            this.UpdateDataSource(deposites);
        }

        /// <summary>
        /// The AddBank
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void AddBank(object obj)
        {
            this.popup = NavigationManager.OpenBank(this.ClosePopup);
            this.popup.ShowDialog();
        }

        /// <summary>
        /// The AddBranch
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void AddBranch(object obj)
        {
            this.popup = NavigationManager.OpenBranch(this.ClosePopup);
            this.popup.ShowDialog();
        }

        /// <summary>
        /// The ClosePopup
        /// </summary>
        private void ClosePopup()
        {
            this.popup?.Close();
        }

        /// <summary>
        /// The Delete
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void Delete(object obj)
        {
        }

        private void Clear()
        {
            this.Cheque.Current = null;
            this.DepositeDate = null;
            this.Depositer.Current = null;
            this.Bank.Current = null;
            this.Branch.Current = null;
            this.AccountNumber = null;
            this.Remarks = string.Empty;
        }

        /// <summary>
        /// The LoadBank
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async Task LoadBank()
        {
            this.Bank.Items = await ObservableCollectionDetail.GetBanks();
        }
        private async Task LoadCheque()
        {
            this.Cheque.Items = await ObservableCollectionDetail.GetCollectedCheque();
        }
        /// <summary>
        /// The LoadBranch
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async Task LoadBranch()
        {
            this.Branch.Items = await ObservableCollectionDetail.GetCity();
        }

        /// <summary>
        /// The LoadDepositer
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async Task LoadDepositer()
        {
            this.Depositer.Items = await ObservableCollectionDetail.GetConsumer(false);
        }

        /// <summary>
        /// The New
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void New(object obj)
        {
            this.Clear();
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private async void Save(object obj)
        {
            this.Validate();
            if (!this.HasErrors)
            {
                MainViewModel.Current.ShowBusy("Saving...");
                OperationOutcome outCome = await InstanceConfig.GetInstance<IDepositeService>().Save(ToDepositeModel());
                if (outCome.ProcessOutCome())
                {
                    this.Clear();
                    this.LoadDetail();
                    MainViewModel.Current.HideBusy("Saved Successfully");
                }
            }
        }

        /// <summary>
        /// The ToCollectionModel
        /// </summary>
        /// <returns>The <see cref="CollectionEntry"/></returns>
        private Deposite ToDepositeModel()
        {
            var deposite = new Deposite();
            deposite.Cheque = this.Cheque.Current;
            deposite.Bank = this.Bank.Current;
            deposite.Branch = this.Branch.Current;
            deposite.DepositDate = this.DepositeDate.Value;
            deposite.Remark = this.Remarks;
            deposite.Id = this.Id;
            deposite.Depositer = this.Depositer.Current;
            deposite.AccountNumber = this.AccountNumber;
            deposite.UserId = MainViewModel.Current.UserId;
            return deposite;
        }

        /// <summary>
        /// The ValidateCheque
        /// </summary>
        public void Validate()
        {
            this.ClearAllErrors();
            if (this.Depositer.Validate("Depositer is mandatory."))
            {
                this.AddError(nameof(this.Depositer), "Depositer is mandatory.");
            }

            if (this.Cheque.Validate("Cheque is mandatory."))
            {
                this.AddError(nameof(this.Cheque), "Cheque is mandatory.");
            }

            if (this.Bank.Validate("Bank is mandatory."))
            {
                this.AddError(nameof(this.Bank), "Bank is mandatory.");
            }

            if (this.Branch.Validate("Branch is mandatory."))
            {
                this.AddError(nameof(this.Branch), "Branch is mandatory.");
            }

            if (string.IsNullOrEmpty(this.AccountNumber))
            {
                this.AddError(nameof(this.AccountNumber), "AccountNumber is mandatory.");
            }

            if (!this.DepositeDate.HasValue)
            {
                this.AddError(nameof(this.DepositeDate), "DepositeDate is mandatory.");
            }
        }

        private void DetailExecution(object obj)
        {
            this.Id = this.Current.Id;
            this.Cheque.Current = this.Current.Cheque;
            this.DepositeDate = this.Current.DepositDate;
            this.Depositer.Current = this.Current.Depositer;
            this.Bank.Current = this.Current.Bank;
            this.Branch.Current = this.Current.Branch;
            this.AccountNumber = this.Current.AccountNumber;
            this.Remarks = this.Current.Remark;
        }

        /// <summary>
        /// The Filter
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        /// <returns>The <see cref="bool"/></returns>
        protected override bool Filter(object obj)
        {
            var obj1 = obj as Deposite;
            if (!string.IsNullOrWhiteSpace(this.SearchText))
            {
                return obj1.Depositer.Name.Contains(this.SearchText) || obj1.Cheque.ChequeNumber.Contains(this.SearchText) || obj1.Bank.Name.Contains(this.SearchText);
            }

            return base.Filter(obj);
        }

        #endregion
    }
}
