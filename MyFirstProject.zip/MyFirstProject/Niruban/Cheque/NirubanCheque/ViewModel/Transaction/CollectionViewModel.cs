﻿// <copyright file="CollectionViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a CollectionViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using Business.Interface;
    using Configuration;
    using CrazyFramework.Model;
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Extensions;
    using Model.Master;
    using Model.Transaction;
    using System;
    using System.Threading.Tasks;
    using System.Windows.Input;
    using Views.Transaction;

    /// <summary>
    /// Defines the <see cref="CollectionViewModel" />
    /// </summary>
    public class CollectionViewModel : Selector<CollectionEntry>
    {
        #region Fields

        /// <summary>
        /// Defines the bank
        /// </summary>
        private BankPopup bankPopup;

        /// <summary>
        /// Defines the cheque
        /// </summary>
        private ChequeViewModel cheque;

        /// <summary>
        /// Defines the recievedDate
        /// </summary>
        private DateTime? recievedDate;

        /// <summary>
        /// Defines the remark
        /// </summary>
        private string remark;

        /// <summary>
        /// Defines the supplier
        /// </summary>
        private Selection<ConsumerBase> supplier;

        #endregion

        #region Constructors
        public ICommand DetailCommand { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CollectionViewModel"/> class.
        /// </summary>
        public CollectionViewModel()
        {
            this.DetailCommand = new Command(this.DetailExecution, this.CanDetail);
            this.SaveCommand = new Command(this.Save);
            this.NewCommand = new Command(this.New);
            this.DeleteCommand = new Command(this.Delete);
            this.LoadDetail();
        }

        private bool CanDetail(object obj)
        {
            return this.Current!=null;
        }

        private void DetailExecution(object obj)
        {
            this.Supplier.Current = this.Current.Supplier;
            this.Id = this.Current.Id;
            this.Remark = this.Current.Remark;
            this.RecievedDate = this.Current.ReceivedDate;
            this.Cheque.Amount = this.Current.Cheque.Amount;
            this.Cheque.Bank.Current = this.Current.Cheque.Bank;
            this.Cheque.Branch.Current = this.Current.Cheque.Branch;
            this.Cheque.ChequeDate = this.Current.Cheque.ChequeDate;
            this.Cheque.ChequeNumber = this.Current.Cheque.ChequeNumber;
            this.Cheque.Id = this.Current.Cheque.Id;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Cheque
        /// </summary>
        public ChequeViewModel Cheque
        {
            get
            {
                if (this.cheque == null)
                {
                    this.cheque = new ChequeViewModel();
                }

                return this.cheque;
            }

            set
            {
                this.Set(ref this.cheque, value);
            }
        }

        /// <summary>
        /// Gets or sets the DeleteCommand
        /// </summary>
        public ICommand DeleteCommand { get; set; }

        /// <summary>
        /// Gets or sets the NewCommand
        /// </summary>
        public ICommand NewCommand { get; set; }

        /// <summary>
        /// Gets or sets the RecievedDate
        /// </summary>
        public DateTime? RecievedDate
        {
            get { return this.recievedDate; }
            set { this.Set(ref this.recievedDate, value); }
        }

        /// <summary>
        /// Gets or sets the Remark
        /// </summary>
        public string Remark
        {
            get { return this.remark; }
            set { this.Set(ref this.remark, value); }
        }
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the SaveCommand
        /// </summary>
        public ICommand SaveCommand { get; set; }

        /// <summary>
        /// Gets or sets the City
        /// </summary>
        public Selection<ConsumerBase> Supplier
        {
            get
            {
                if (this.supplier == null)
                {
                    this.supplier = new Selection<ConsumerBase>(this.LoadSupplier);
                }

                return supplier;
            }

            set
            {
                this.Set(ref this.supplier, value);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Initialize
        /// </summary>
        /// <returns>The <see cref="MenuGroup"/></returns>
        public MenuGroup Initialize()
        {
            MenuGroup masterGroup = new MenuGroup("Action");
            masterGroup.Items.Add(new MenuItem("New", "Images\\new.png", NewCommand));
            masterGroup.Items.Add(new MenuItem("Save", "Images\\save.png", SaveCommand));
            masterGroup.Items.Add(new MenuItem("Delete", "Images\\delete.png", DeleteCommand));
            masterGroup.Items.Add(new MenuItem("Add Bank", "Images\\bank.png", new Command(this.AddBank)));
            masterGroup.Items.Add(new MenuItem("Add Branch", "Images\\branch.png", new Command(this.AddBranch)));
            return masterGroup;
        }

        /// <summary>
        /// The ValidateCheque
        /// </summary>
        public void Validate()
        {
            this.ClearAllErrors();
            this.Cheque.ValidateCheque();
            if(this.Supplier.Validate("Supplier is mandatory."))
            {
                this.AddError(nameof(this.Supplier), "Supplier is mandatory.");
            }

            if (!this.RecievedDate.HasValue)
            {
                this.AddError(nameof(this.RecievedDate), "RecievedDate is mandatory.");
            }
        }

        /// <summary>
        /// The AddBank
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void AddBank(object obj)
        {
            this.bankPopup = NavigationManager.OpenBank(this.CloseBank);
            this.bankPopup.ShowDialog();
        }

        /// <summary>
        /// The AddBranch
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void AddBranch(object obj)
        {
            this.bankPopup = NavigationManager.OpenBranch(this.CloseBank);
            this.bankPopup.ShowDialog();
        }

        /// <summary>
        /// The CloseBank
        /// </summary>
        private void CloseBank()
        {
            this.bankPopup.Close();
        }

        /// <summary>
        /// The Delete
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private void Delete(object commandParameter)
        {
        }

        /// <summary>
        /// The LoadSupplier
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async Task LoadSupplier()
        {
            this.Supplier.Items = await ObservableCollectionDetail.GetConsumer(true);
        }

        /// <summary>
        /// The LoadSupplier
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async void LoadDetail()
        {
            var banks = await InstanceConfig.GetInstance<ICollectionService>().Get();
            this.UpdateDataSource(banks);
        }

        /// <summary>
        /// The New
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private void New(object commandParameter)
        {
            this.Clear();
        }

        private void Clear()
        {
            this.Remark = string.Empty;
            this.Supplier = null;
            this.RecievedDate = null;
            this.RecievedDate = null;
            this.Cheque.ReInitalize();
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private async void Save(object commandParameter)
        {
            this.Validate();
            if (!this.HasErrors && !this.Cheque.HasErrors)
            {
                MainViewModel.Current.ShowBusy("Saving...");
                OperationOutcome outCome = await InstanceConfig.GetInstance<ICollectionService>().Save(ToCollectionModel());
                if (outCome.ProcessOutCome())
                {
                    this.Clear();
                    this.LoadDetail();
                    MainViewModel.Current.HideBusy("Saved Successfully");
                }
            }
            
        }

        /// <summary>
        /// The ToCollectionModel
        /// </summary>
        /// <returns>The <see cref="CollectionEntry"/></returns>
        private CollectionEntry ToCollectionModel()
        {
            var collection = new CollectionEntry();
            collection.Cheque = this.cheque.ToModel();
            collection.ReceivedDate = this.RecievedDate.Value;
            collection.Remark = this.Remark;
            collection.Id = this.Id;
            collection.Supplier= this.Supplier.Current;
            collection.UserId = MainViewModel.Current.UserId;
            return collection;
        }

        /// <summary>
        /// The Filter
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        /// <returns>The <see cref="bool"/></returns>
        protected override bool Filter(object obj)
        {
            var obj1 = obj as CollectionEntry;
            if (!string.IsNullOrWhiteSpace(this.SearchText))
            {
                return obj1.Supplier.Name.Contains(this.SearchText) || obj1.Cheque.Branch.Name.Contains(this.SearchText) || obj1.Cheque.Bank.Name.Contains(this.SearchText) || obj1.Cheque.StatusDescription.Contains(this.SearchText) || obj1.Cheque.Amount.ToString().Contains(this.SearchText);
            }

            return true;
        }

        #endregion
    }
}
