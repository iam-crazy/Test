﻿// <copyright file="ClearingViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a ClearingViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using CrazyFramework.Model;
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using NirubanCheque.Business.Interface;
    using NirubanCheque.Configuration;
    using NirubanCheque.Extensions;
    using NirubanCheque.Model.Transaction;
    using System.Collections.ObjectModel;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="ClearingViewModel" />
    /// </summary>
    internal class ClearingViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// Defines the charge
        /// </summary>
        private decimal? charge;

        /// <summary>
        /// Defines the cheque
        /// </summary>
        private Selection<ChequeBase> cheque;

        /// <summary>
        /// Defines the isCleared
        /// </summary>
        private bool isCleared = true;

        /// <summary>
        /// Defines the remarks
        /// </summary>
        private string remarks;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Charge
        /// </summary>
        public decimal? Charge
        {
            get { return this.charge; }
            set { this.Set(ref this.charge, value); }
        }

        /// <summary>
        /// Gets or sets the Cheque
        /// </summary>
        public Selection<ChequeBase> Cheque
        {
            get
            {
                if (this.cheque == null)
                {
                    this.cheque = new Selection<ChequeBase>(this.LoadCheque);
                }

                return cheque;
            }
            set { this.Set(ref this.cheque, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsCleared
        /// </summary>
        public bool IsCleared
        {
            get { return this.isCleared; }
            set { this.Set(ref this.isCleared, value); }
        }

        /// <summary>
        /// Gets or sets the Remarks
        /// </summary>
        public string Remarks
        {
            get { return this.remarks; }
            set { this.Set(ref this.remarks, value); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Initialize
        /// </summary>
        /// <returns>The <see cref="MenuGroup"/></returns>
        public MenuGroup Initialize()
        {
            MenuGroup masterGroup = new MenuGroup("Action");
            masterGroup.Items.Add(new MenuItem("Save", "Images\\save.png", new Command(this.Save)));
            return masterGroup;
        }

        /// <summary>
        /// The Validate
        /// </summary>
        public void Validate()
        {
            this.ClearAllErrors();
            if (this.Cheque.Validate("Cheque is mandatory."))
            {
                this.AddError(nameof(this.Cheque), "Cheque is mandatory.");
            }
        }

        /// <summary>
        /// The Clear
        /// </summary>
        private void Clear()
        {
            this.Cheque = null;
            this.Charge = null;
            this.IsCleared = true;
            this.Remarks = string.Empty;
            ObservableCollectionDetail.ClearCheque();
        }

        /// <summary>
        /// The LoadCheque
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async Task LoadCheque()
        {
            this.Cheque.Items = await ObservableCollectionDetail.GetDepositedCheque();
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private async void Save(object obj)
        {
            this.Validate();
            if (!this.HasErrors)
            {
                MainViewModel.Current.ShowBusy("Saving...");
                Clearance data = new Clearance();
                data.Cheque = this.Cheque.Current;
                data.Amount = this.Charge;
                data.IsCleared = this.IsCleared;
                data.Remarks = this.Remarks;
                data.UserId = MainViewModel.Current.UserId;
                OperationOutcome outCome = await InstanceConfig.GetInstance<IClearanceService>().Save(data);
                if (outCome.ProcessOutCome())
                {
                    this.Clear();
                    MainViewModel.Current.HideBusy("Saved Successfully");
                }
            }
        }

        #endregion
    }
}
