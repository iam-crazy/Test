﻿// <copyright file="ChequeViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a ChequeViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Extensions;
    using Model.Common;
    using Model.Transaction;
    using System;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="ChequeViewModel" />
    /// </summary>
    public class ChequeViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// Defines the amount
        /// </summary>
        private decimal? amount;

        /// <summary>
        /// Defines the chequeDate
        /// </summary>
        private DateTime? chequeDate;

        /// <summary>
        /// Defines the chequeNumber
        /// </summary>
        private string chequeNumber;

        /// <summary>
        /// Defines the remark
        /// </summary>
        private string remark;

        #endregion

        #region Properties

        private Selection<GeneralCode> bank;

        private Selection<GeneralCode> branch;

        /// <summary>
        /// Gets or sets the City
        /// </summary>
        public Selection<GeneralCode> Bank
        {
            get
            {
                if (this.bank == null)
                {
                    this.bank = new Selection<GeneralCode>(this.LoadBank);
                }

                return bank;
            }
            set { this.Set(ref this.bank, value); }
        }

        private async Task LoadBank()
        {
            this.Bank.Items = await ObservableCollectionDetail.GetBanks();
        }

        /// <summary>
        /// Gets or sets the City
        /// </summary>
        public Selection<GeneralCode> Branch
        {
            get
            {
                if (this.branch == null)
                {
                    this.branch = new Selection<GeneralCode>(this.LoadBranch);
                }

                return branch;
            }
            set { this.Set(ref this.branch, value); }
        }

        private async Task LoadBranch()
        {
            this.Branch.Items = await ObservableCollectionDetail.GetCity();
        }

        /// <summary>
        /// Gets or sets the Amount
        /// </summary>
        public decimal? Amount
        {
            get { return this.amount; }
            set { this.Set(ref this.amount, value); }
        }

        /// <summary>
        /// Gets or sets the ChequeDate
        /// </summary>
        public DateTime? ChequeDate
        {
            get { return this.chequeDate; }
            set { this.Set(ref this.chequeDate, value); }
        }

        /// <summary>
        /// Gets or sets the ChequeNumber
        /// </summary>
        public string ChequeNumber
        {
            get { return this.chequeNumber; }
            set { this.Set(ref this.chequeNumber, value); }
        }

        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Remark
        /// </summary>
        public string Remark
        {
            get { return this.remark; }
            set { this.Set(ref this.remark, value); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The ReInitalize
        /// </summary>
        public void ReInitalize()
        {
            this.ChequeNumber = null;
            this.Id = 0;
            this.ChequeDate = null;
            this.Bank = null;
            this.Branch = null;
            this.Amount = null;
            this.Remark = null;
        }

        /// <summary>
        /// Convert to Model, Please Validate this Model before converting.
        /// </summary>
        /// <returns></returns>
        public Cheque ToModel()
        {
            var cheque = new Cheque();
            cheque.Amount = this.Amount.Value;
            cheque.ChequeNumber = this.chequeNumber;
            cheque.Bank = this.bank.Current;
            cheque.Branch = this.branch.Current;
            cheque.Remark = this.remark;
            cheque.ChequeDate = this.chequeDate.Value;
            cheque.Id = this.Id;
            return cheque;
        }

        /// <summary>
        /// Convert to Model, Please Validate this Model before converting.
        /// </summary>
        /// <returns></returns>
        public void ToModel(Cheque cheque)
        {
            this.Amount = cheque.Amount;
            this.ChequeNumber = cheque.ChequeNumber;
            this.Bank.Current = cheque.Bank;
            this.Branch.Current = cheque.Branch;
            this.Remark = cheque.Remark;
            this.ChequeDate = cheque.ChequeDate;
            this.Id = cheque.Id;
        }

        /// <summary>
        /// The ValidateCheque
        /// </summary>
        public void ValidateCheque()
        {
            this.ClearAllErrors();
            if (!this.ChequeDate.HasValue)
            {
                this.AddError(nameof(this.ChequeDate), "Cheque Date is mandatory.");
            }
            
            if (string.IsNullOrEmpty(this.ChequeNumber))
            {
                this.AddError(nameof(this.ChequeNumber), "Cheque Number is mandatory.");
            }

            if (!this.Amount.HasValue)
            {
                this.AddError(nameof(this.Amount), "Amount is mandatory.");
            }

            if (this.Branch.Validate("Branch is mandatory."))
            {
                this.AddError(nameof(this.Branch), "Branch is mandatory.");
            }

            if (this.Bank.Validate("Bank is mandatory."))
            {
                this.AddError(nameof(this.Bank), "Bank is mandatory.");
            }
        }

        #endregion
    }
}
