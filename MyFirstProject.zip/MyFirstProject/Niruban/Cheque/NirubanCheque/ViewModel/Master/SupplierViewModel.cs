﻿// <copyright file="SupplierViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a SupplierViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using Business.Interface;
    using Configuration;
    using CrazyFramework.Model;
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Extensions;
    using Model.Common;
    using Model.Master;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Windows.Data;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref="SupplierViewModel" />
    /// </summary>
    public class SupplierViewModel : Selector<Consumer>
    {
        #region Fields

        /// <summary>
        /// Defines the address
        /// </summary>
        private string address;

        /// <summary>
        /// Defines the city
        /// </summary>
        private Selection<GeneralCode> city;

        /// <summary>
        /// Defines the isSupplier
        /// </summary>
        private bool isSupplier;

        /// <summary>
        /// Defines the name
        /// </summary>
        private string name;

        /// <summary>
        /// Defines the phoneNumber
        /// </summary>
        private string phoneNumber;

        /// <summary>
        /// Defines the remarks
        /// </summary>
        private string remarks;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SupplierViewModel"/> class.
        /// </summary>
        public SupplierViewModel()
        {
            this.SupplierDetailCommand = new Command(this.SupplierExecution, this.CanSupplier);
            this.LoadDetail();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Address
        /// </summary>
        public string Address
        {
            get { return address; }
            set { this.Set(ref this.address, value); }
        }

        /// <summary>
        /// Gets or sets the City
        /// </summary>
        public Selection<GeneralCode> City
        {
            get
            {
                if (this.city == null)
                {
                    this.city = new Selection<GeneralCode>(this.LoadCity);
                }

                return city;
            }
            set { this.Set(ref this.city, value); }
        }

        /// <summary>
        /// Gets or sets the Items
        /// </summary>

        /// <summary>
        /// Gets or sets the Current
        /// </summary>
        public Consumer Current { get; set; }

        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsSupplier
        /// </summary>
        public bool IsSupplier
        {
            get { return isSupplier; }
            set { this.Set(ref this.isSupplier, value); }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { this.Set(ref this.name, value); }
        }

        /// <summary>
        /// Gets or sets the PhoneNumber
        /// </summary>
        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { this.Set(ref this.phoneNumber, value); }
        }

        /// <summary>
        /// Gets or sets the Remarks
        /// </summary>
        public string Remarks
        {
            get { return remarks; }
            set { this.Set(ref this.remarks, value); }
        }

        /// <summary>
        /// Gets or sets the SupplierDetailCommand
        /// </summary>
        public ICommand SupplierDetailCommand { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The Initialize
        /// </summary>
        /// <returns>The <see cref="MenuGroup"/></returns>
        public MenuGroup Initialize()
        {
            MenuGroup masterGroup = new MenuGroup("Action");
            masterGroup.Items.Add(new MenuItem("New", "Images\\new.png", new Command(this.New)));
            masterGroup.Items.Add(new MenuItem("Save", "Images\\save.png", new Command(this.Save)));
            masterGroup.Items.Add(new MenuItem("Delete", "Images\\delete.png", new Command(this.Delete, this.CanDelete)));
            return masterGroup;
        }

        /// <summary>
        /// The Validate
        /// </summary>
        public void Validate()
        {
            this.ClearAllErrors();
            if (string.IsNullOrEmpty(this.Name))
            {
                this.AddError(nameof(this.Name), "Name is mandatory.");
            }

            if (string.IsNullOrEmpty(this.PhoneNumber))
            {
                this.AddError(nameof(this.PhoneNumber), "Phone Number is mandatory.");
            }
        }

        /// <summary>
        /// The CanDelete
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        /// <returns>The <see cref="bool"/></returns>
        private bool CanDelete(object obj)
        {
            return this.Current != null;
        }

        /// <summary>
        /// The CanSupplier
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        /// <returns>The <see cref="bool"/></returns>
        private bool CanSupplier(object obj)
        {
            return this.Current != null;
        }

        /// <summary>
        /// The Clear
        /// </summary>
        private void Clear()
        {
            this.Name = string.Empty;
            this.Address = string.Empty;
            this.PhoneNumber = string.Empty;
            this.Address = string.Empty;
            this.Remarks = string.Empty;
            this.City.Current = null;
            this.Id = 0;
            this.Current = null;
        }

        /// <summary>
        /// The Delete
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private async void Delete(object obj)
        {
            MainViewModel.Current.ShowBusy("Deleting...");
            var outCome = await InstanceConfig.GetInstance<IConsumerService>().Delete(this.Current.Id, MainViewModel.Current.UserId);
            if (outCome.ProcessOutCome())
            {
                this.Clear();
                this.LoadDetail();
                Extension.ShowSaveMessage("Supplier", "Saved Successfully");
                MainViewModel.Current.HideBusy("Saved Successfully");
            }
        }

        /// <summary>
        /// The Filter
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        /// <returns>The <see cref="bool"/></returns>
        protected override bool Filter(object obj)
        {
            var obj1 = obj as Consumer;
            if (!string.IsNullOrWhiteSpace(this.SearchText))
            {
                return obj1.Name.Contains(this.SearchText) || obj1.City.Name.Contains(this.SearchText) || obj1.PhoneNumber.Contains(this.SearchText) || obj1.Type.Contains(this.SearchText);
            }

            return true;
        }

        /// <summary>
        /// The LoadCity
        /// </summary>
        /// <returns>The <see cref="Task"/></returns>
        private async Task LoadCity()
        {
            this.City.Items = await ObservableCollectionDetail.GetCity();
        }

        /// <summary>
        /// The LoadDetail
        /// </summary>
        private async void LoadDetail()
        {
            var consumerDetails = await InstanceConfig.GetInstance<IConsumerService>().Get();
            this.UpdateDataSource(consumerDetails);
        }

        /// <summary>
        /// The New
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void New(object obj)
        {
            this.Clear();
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private async void Save(object obj)
        {
            this.Validate();
            if (!this.HasErrors)
            {
                MainViewModel.Current.ShowBusy("Saving...");
                var consumer = new Consumer
                {
                    Address = this.Address,
                    City = this.City.Current,
                    IsSupplier = this.IsSupplier,
                    Name = this.Name,
                    IsActive = true,
                    Id = this.Id,
                    PhoneNumber = this.PhoneNumber,
                    Remark = this.Remarks,
                    UserId = MainViewModel.Current.UserId
                };
                OperationOutcome outCome = await InstanceConfig.GetInstance<IConsumerService>().Save(consumer);
                if (outCome.ProcessOutCome())
                {
                    this.Clear();
                    this.LoadDetail();
                    MainViewModel.Current.HideBusy("Saved Successfully");
                }
            }
            else
            {
                MainViewModel.Current.Status = "Please fill all mandatory fields";
            }
        }

        /// <summary>
        /// The SupplierExecution
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private void SupplierExecution(object commandParameter)
        {
            this.City.Current = this.Current.City;
            this.Id = this.Current.Id;
            this.Name = this.Current.Name;
            this.Address = this.Current.Address;
            this.IsSupplier = this.Current.IsSupplier;
            this.PhoneNumber = this.Current.PhoneNumber;
            this.Remarks = this.Current.Remark;
        }

        #endregion
    }
}
