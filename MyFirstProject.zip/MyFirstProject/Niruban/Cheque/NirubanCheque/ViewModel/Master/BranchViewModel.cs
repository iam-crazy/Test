﻿// <copyright file="BranchViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a BranchViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using CrazyFramework.Model;
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Model.Master;
    using NirubanCheque.Business.Interface;
    using NirubanCheque.Configuration;
    using NirubanCheque.Extensions;
    using NirubanCheque.Model.Common;
    using System;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Windows.Data;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref="BranchViewModel" />
    /// </summary>
    public class BranchViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// Defines the OnClose
        /// </summary>
        public Action OnClose;

        /// <summary>
        /// Defines the name
        /// </summary>
        private string name;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="BranchViewModel"/> class.
        /// </summary>
        public BranchViewModel()
        {
            this.SaveCommand = new Command(this.SaveExecute);
            this.CloseCommand = new Command(this.CloseExecute);
            this.DeleteCommand = new Command(this.DeleteExecute);
            this.ClearCommand = new Command(this.ClearExecute);
            this.EditCommand = new Command(this.EditExecute);
            this.Branches = new ObservableCollection<GeneralCode>();
            this.Items = CollectionViewSource.GetDefaultView(this.Branches);
            this.Items.Filter += this.Filter;
            this.LoadDetail();
            this.TextLabel = "Branch Detail";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BranchViewModel"/> class.
        /// </summary>
        /// <param name="onClose">The <see cref="Action"/></param>
        public BranchViewModel(Action onClose) : this()
        {
            this.OnClose = onClose;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Current
        /// </summary>
        public static BranchViewModel Current { get; set; }

        /// <summary>
        /// Gets the Items
        /// </summary>
        public ObservableCollection<GeneralCode> Branches { get; }

        /// <summary>
        /// Gets or sets the ClearCommand
        /// </summary>
        public ICommand ClearCommand { get; set; }

        /// <summary>
        /// Gets or sets the CloseCommand
        /// </summary>
        public ICommand CloseCommand { get; set; }

        /// <summary>
        /// Gets or sets the DeleteCommand
        /// </summary>
        public ICommand DeleteCommand { get; set; }

        /// <summary>
        /// Gets or sets the EditCommand
        /// </summary>
        public ICommand EditCommand { get; set; }

        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return this.name; }
            set { this.Set(ref name, value); }
        }

        /// <summary>
        /// Gets or sets the SaveCommand
        /// </summary>
        public ICommand SaveCommand { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string TextLabel { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The LoadBranch
        /// </summary>
        public async void LoadDetail()
        {
            var branches = await ObservableCollectionDetail.GetAllCity();
            this.Branches.Clear();
            if (branches != null && branches.Any())
            {
                foreach (var data in branches)
                {
                    this.Branches.Add(data);
                }
            }
        }

        /// <summary>
        /// The Validate
        /// </summary>
        public void Validate()
        {
            this.ClearAllErrors();
            if (string.IsNullOrEmpty(this.Name))
            {
                this.AddError(nameof(this.Name), "Name is mandatory.");
            }
        }

        /// <summary>
        /// The Clear
        /// </summary>
        private void Clear()
        {
            this.ClearAllErrors();
            this.Name = string.Empty;
            this.Id = 0;
        }

        /// <summary>
        /// The ClearExecute
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void ClearExecute(object obj)
        {
            this.Clear();
        }

        /// <summary>
        /// The CloseExecute
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void CloseExecute(object obj)
        {
            this.OnClose?.Invoke();
        }

        /// <summary>
        /// The DeleteExecute
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private async void DeleteExecute(object commandParameter)
        {
            var bank = commandParameter as GeneralCode;
            if (bank != null && Extension.ConfirmationMessage("Branch", "Do you want to delete?"))
            {
                MainViewModel.Current.ShowBusy("Deleting...");
                var outCome = await InstanceConfig.GetInstance<ICityService>().Delete(bank.Id, MainViewModel.Current.UserId);
                if (outCome.ProcessOutCome())
                {
                    this.ReloadAllData();
                    MainViewModel.Current.HideBusy("Deleted Successfully");
                }
            }
        }

        /// <summary>
        /// The EditExecute
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private void EditExecute(object commandParameter)
        {
            var bank = commandParameter as GeneralCode;
            if (bank != null)
            {
                this.Id = bank.Id;
                this.Name = bank.Name;
            }
        }

        /// <summary>
        /// The Filter
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        /// <returns>The <see cref="bool"/></returns>
        private bool Filter(object obj)
        {
            var obj1 = obj as Consumer;
            if (!string.IsNullOrWhiteSpace(this.SearchText))
            {
                return obj1.Name.Contains(this.SearchText);
            }

            return true;
        }

        /// <summary>
        /// The ReloadAllData
        /// </summary>
        private void ReloadAllData()
        {
            this.Clear();
            ObservableCollectionDetail.ClearCities();
            this.LoadDetail();
        }

        /// <summary>
        /// The SaveExecute
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private async void SaveExecute(object obj)
        {
            this.Validate();
            if (!this.HasErrors)
            {
                MainViewModel.Current.ShowBusy("Saving...");
                var consumer = new City
                {
                    Name = this.Name,
                    IsActive = true,
                    Id = this.Id,
                    UserId = MainViewModel.Current.UserId
                };
                OperationOutcome outCome = await InstanceConfig.GetInstance<ICityService>().Save(consumer);
                if (outCome.ProcessOutCome())
                {
                    this.ReloadAllData();
                    MainViewModel.Current.HideBusy("Saved Successfully");
                }
            }
        }

        #endregion
    }
}
