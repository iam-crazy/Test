﻿// <copyright file="LoginViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a LoginViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref="LoginViewModel" />
    /// </summary>
    public class LoginViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// Defines the language
        /// </summary>
        private GeneralCodeViewModel language;

        /// <summary>
        /// Defines the password
        /// </summary>
        private string password;

        /// <summary>
        /// Defines the userName
        /// </summary>
        private string userName;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginViewModel"/> class.
        /// </summary>
        public LoginViewModel()
        {
            this.LoginCommand = new Command(this.Login);
            this.Language = this.Languages.First();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Language
        /// </summary>
        public GeneralCodeViewModel Language
        {
            get { return this.language; }
            set { this.Set(ref this.language, value); }
        }

        /// <summary>
        /// Gets the Languages
        /// </summary>
        public List<GeneralCodeViewModel> Languages
        {
            get
            {
                return new List<GeneralCodeViewModel>()
                {
                    new GeneralCodeViewModel()
                    {
                        Id=1,
                        Name="தமிழ்"
                    },
                    new GeneralCodeViewModel()
                    {
                        Id=2,
                        Name="English"
                    }
                };
            }
        }

        /// <summary>
        /// Gets or sets the LoginCommand
        /// </summary>
        public ICommand LoginCommand { get; set; }

        /// <summary>
        /// Gets or sets the Password
        /// </summary>
        public string Password
        {
            get { return this.password; }
            set { this.Set(ref this.password, value); }
        }

        /// <summary>
        /// Gets or sets the UserName
        /// </summary>
        public string UserName
        {
            get { return this.userName; }
            set { this.Set(ref this.userName, value); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Login
        /// </summary>
        /// <param name="commandParameter">The <see cref="object"/></param>
        private void Login(object commandParameter)
        {
            this.Validate();
            if (!this.HasErrors)
            {
                MainViewModel.Current = new MainViewModel();
                if (this.Language.Id == 1)
                {
                    MainViewModel.Current.ChangeLanguage("ta-IN", true);
                }
                else
                {
                    MainViewModel.Current.ChangeLanguage("", false);
                }

                MainWindow window = new MainWindow();
                window.DataContext = MainViewModel.Current;
                (this.View as Window).Close();
                window.Show();
            }
        }

        /// <summary>
        /// The Validate
        /// </summary>
        private void Validate()
        {
            this.ClearAllErrors();
            if (string.IsNullOrEmpty(this.UserName))
            {
                this.AddError(nameof(this.UserName), "User Name is mandatory.");
            }

            if (string.IsNullOrEmpty(this.Password))
            {
                this.AddError(nameof(this.Password), "Password is mandatory.");
            }

            if (this.Language == null)
            {
                this.AddError(nameof(this.Language), "Language is mandatory.");
            }
        }

        #endregion
    }
}
