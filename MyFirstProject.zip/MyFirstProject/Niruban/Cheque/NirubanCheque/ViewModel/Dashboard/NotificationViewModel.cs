﻿using CrazyFramework.WPF.Model;
using CrazyFramework.WPF.ViewModel;
using NirubanCheque.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace NirubanCheque.ViewModel
{
    public class NotificationViewModel : ViewModelBase
    {
        private string description;

        public string Description
        {
            get { return description; }
            set { this.Set(ref this.description, value); }
        }
        private DateTime? date;

        public DateTime? Date
        {
            get { return date; }
            set { this.Set(ref this.date, value); }
        }

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public Action<DateTime?, string> AfterSave { get; set; }
        public Action AfterClose { get; set; }
        public NotificationViewModel()
        {
            SaveCommand = new Command(this.Save);
            CancelCommand = new Command(this.Cancel);
        }

        public NotificationViewModel(Action<DateTime?, string> afterSave, Action close) : this()
        {
            this.AfterSave = afterSave;
            this.AfterClose = close;
        }
        private void Save(object obj)
        {
            this.AfterSave.Invoke(this.Date, this.Description);
        }

        private void Cancel(object obj)
        {
            this.AfterClose.Invoke();
        }
    }
}
