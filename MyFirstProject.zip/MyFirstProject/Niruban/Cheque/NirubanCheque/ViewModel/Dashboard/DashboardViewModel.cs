﻿// <copyright file="DashboardViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a DashboardViewModel.cs</summary>

namespace NirubanCheque.ViewModel
{
    using CrazyFramework.WPF.Model;
    using CrazyFramework.WPF.ViewModel;
    using Model.Master.Dashboard;
    using NirubanCheque.Views.DashBoard;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    /// <summary>
    /// Defines the <see cref="DashboardViewModel" />
    /// </summary>
    public class DashboardViewModel : ViewModelBase
    {
        #region Fields

        /// <summary>
        /// Defines the popup
        /// </summary>
        private NotificationPopup popup;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the ChartDetails
        /// </summary>
        public ObservableCollection<ChartContent> ChartDetails { get; set; } = new ObservableCollection<ChartContent>();

        /// <summary>
        /// Gets or sets the Notifications
        /// </summary>
        public ObservableCollection<NotificationDetail> Notifications { get; set; } = new ObservableCollection<NotificationDetail>();

        #endregion

        #region Methods

        /// <summary>
        /// The Initialize
        /// </summary>
        /// <returns>The <see cref="MenuGroup"/></returns>
        public MenuGroup Initialize()
        {
            this.ChartDetails.Clear();
            this.Notifications.Clear();
            this.Notifications.Add(new NotificationDetail() { SerialNumber = 1, Date = DateTime.Now, Description = "Request Cheque on 12/712/12" });
            this.Notifications.Add(new NotificationDetail() { SerialNumber = 1, Date = DateTime.Now.AddDays(-1), Description = "Request Cheque on 12/712/12" });
            this.Notifications.Add(new NotificationDetail() { SerialNumber = 1, Date = DateTime.Now.AddDays(1), Description = "Request Cheque on 12/712/12" });
            ChartDetails.Add(new ChartContent() { Legend = "Deposit", Amount = 784 });
            ChartDetails.Add(new ChartContent() { Legend = "Collection", Amount = 74 });
            ChartDetails.Add(new ChartContent() { Legend = "Cleared", Amount = 84 });
            ChartDetails.Add(new ChartContent() { Legend = "Bounced", Amount = 84 });
            ChartDetails.Add(new ChartContent() { Legend = "Additional Charge", Amount = 74 });
            MenuGroup masterGroup = new MenuGroup("Action");
            masterGroup.Items.Add(new MenuItem("Add Notification", "Images\\new.png", new Command(this.New)));
            return masterGroup;
        }

        /// <summary>
        /// The CloseNotificaiton
        /// </summary>
        private void CloseNotificaiton()
        {
            this.popup.Close();
        }

        /// <summary>
        /// The New
        /// </summary>
        /// <param name="obj">The <see cref="object"/></param>
        private void New(object obj)
        {
            this.popup = new NotificationPopup();
            NotificationViewModel model = new NotificationViewModel(SaveNotificaiton, CloseNotificaiton);
            this.popup.DataContext = model;
            popup.ShowDialog();
        }

        /// <summary>
        /// The SaveNotificaiton
        /// </summary>
        /// <param name="date">The <see cref="DateTime?"/></param>
        /// <param name="description">The <see cref="string"/></param>
        private void SaveNotificaiton(DateTime? date, string description)
        {
            this.Notifications.Add(new NotificationDetail() { Date = date, Description = description, SerialNumber = 2 });
            this.popup.Close();
        }

        #endregion
    }

}
