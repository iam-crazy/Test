﻿using NirubanCheque.Configuration;
using NirubanCheque.ViewModel;
using NirubanCheque.Views;
using System.Threading.Tasks;
using System.Windows;

namespace NirubanCheque
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            InstanceConfig.RegisterGlobalInstances();
            var data = new LoginViewModel();
            Login login = new Login();
            data.View = login;
            login.DataContext = data;
            login.Show();
            this.Dispatcher.UnhandledException += OnDispatcherUnhandledException;
        }

        void OnDispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            string errorMessage = string.Format("An unhandled exception occurred: {0}", e.Exception.Message);
            MessageBox.Show(errorMessage, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            MainViewModel.Current?.HideBusy("Some Thing went wrong");
            e.Handled = true;
        }
    }
}
