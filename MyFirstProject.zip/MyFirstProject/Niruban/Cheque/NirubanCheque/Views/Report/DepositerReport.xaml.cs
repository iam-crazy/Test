﻿using CrazyFramework.Conversion;
using CrazyFramework.WPF.Interface;
using Microsoft.Reporting.WinForms;
using NirubanCheque.Configuration;
using NirubanCheque.Dataaccess.Interface.Report;
using NirubanCheque.Extensions;
using NirubanCheque.Model.Master;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static NirubanCheque.Data.ChequeDataset;

namespace NirubanCheque.Views.Report
{
    /// <summary>
    /// Interaction logic for DepositerReport.xaml
    /// </summary>
    public partial class DepositerReport : UserControl, IView
    {
        public DepositerReport()
        {
            InitializeComponent();
            this.supplier.ItemsSource = data;
        }
        #region Properties

        /// <summary>
        /// Gets the data
        /// </summary>
        internal ObservableCollection<ConsumerBase> data { get; } = new ObservableCollection<ConsumerBase>();

        /// <summary>
        /// The EndInit
        /// </summary>
        public override void EndInit()
        {
            base.EndInit();
            ObservableCollectionDetail.GetConsumer(false).ContinueWith(async (s) =>
            {
                var dd = await s;
                foreach (var ss in dd)
                {
                    data.Add(ss);
                }
            });
        }

        /// <summary>
        /// The Clear_Click
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            this.fromDate.SelectedDate = null;
            this.toDate.SelectedDate = null;
            this.supplier.SelectedIndex = -1;
        }

        /// <summary>
        /// The GetChequeDataSet
        /// </summary>
        /// <returns>The <see cref="Task{ChequeDataset}"/></returns>
        private async Task<DepositerDataTable> GetChequeDataSet()
        {
            decimal balance = 0;
            var id = this.supplier.SelectedValue;
            var suppliers = await InstanceConfig.GetInstance<IReportRepository>().GetDepoisterReports(this.fromDate.SelectedDate, this.toDate.SelectedDate, id?.ToInt32());
            DepositerDataTable depositer = new DepositerDataTable();
            if (suppliers != null)
            {
                foreach (var s in suppliers)
                {
                    if (s.StatusCode == "D")
                    {
                        balance += s.Amount;
                        depositer.AddDepositerRow(s.ChequeDate, GetDescription(s), s.Amount, 0, balance, 0);
                        if (s.AdditionalAmount > 0)
                        {
                            balance -= s.AdditionalAmount.HasValue ? s.AdditionalAmount.Value : 0;
                            depositer.AddDepositerRow(s.ChequeDate, GetDescription(s) + " and clearance charge", 0, s.AdditionalAmount??0, balance, 0);
                        }
                    }
                    else if (s.StatusCode == "B")
                    {
                        balance -= s.AdditionalAmount.HasValue ? s.AdditionalAmount.Value : 0;
                        depositer.AddDepositerRow(s.ChequeDate, GetDescription(s), 0, s.AdditionalAmount ?? 0, balance, 0);
                    }
                    else if (s.StatusCode == "R" || s.StatusCode == "A")
                    {
                        depositer.AddDepositerRow(s.ChequeDate, GetDescription(s), 0, 0, balance, s.Amount);
                    }

                }
            }

            return depositer;
        }

        public string GetDescription(Model.Report.DepositerReport depositer)
        {
            var status = string.Empty;
            if (depositer.StatusCode == "R" || depositer.StatusCode == "A")
            {
                status = "depsoited and waiting for clearing.";
            }
            else if (depositer.StatusCode == "B")
            {
                status = "bounced.";
            }
            else if (depositer.StatusCode == "D")
            {
                status = "cleared.";
            }

            return string.Format("Cheque:{0} from {1},{2} has been {3}", depositer.ChequeNumber, depositer.BankName, depositer.CityName, status);
        }
        /// <summary>
        /// The Search_Click
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private async void Search_Click(object sender, RoutedEventArgs e)
        {
            ReportDataSource reportDataSource = new ReportDataSource();
            reportViewer.LocalReport.ReportPath = @"Report\DepositerReport.rdlc";
            reportViewer.LocalReport.DataSources.Add(reportDataSource);
            DepositerDataTable dataTable = await GetChequeDataSet();
            reportViewer.LocalReport.DataSources.Clear();
            List<ReportParameter> parameter = new List<ReportParameter>();
            parameter.Add(new ReportParameter("Title", "Test"));
            reportViewer.LocalReport.SetParameters(parameter);
            reportViewer.LocalReport.DataSources.Add(new ReportDataSource("DespositerDataset", dataTable as DataTable));
            reportViewer.RefreshReport();
        }

        #endregion

    }
}
