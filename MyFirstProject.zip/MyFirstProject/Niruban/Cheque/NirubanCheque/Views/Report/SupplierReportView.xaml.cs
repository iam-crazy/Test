﻿// <copyright file="SupplierReportView.xaml.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a SupplierReportView.xaml.cs</summary>

namespace NirubanCheque.Views.Report
{
    using CrazyFramework.Conversion;
    using CrazyFramework.WPF.Interface;
    using Microsoft.Reporting.WinForms;
    using Model.Master;
    using NirubanCheque.Configuration;
    using NirubanCheque.Dataaccess.Interface.Report;
    using NirubanCheque.Extensions;
    using System.Collections.ObjectModel;
    using System.Data;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using static NirubanCheque.Data.ChequeDataset;

    /// <summary>
    /// Interaction logic for SupplierReportView.xaml
    /// </summary>
    public partial class SupplierReportView : UserControl, IView
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SupplierReportView"/> class.
        /// </summary>
        public SupplierReportView()
        {
            InitializeComponent();
            this.supplier.ItemsSource = data;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the data
        /// </summary>
        internal ObservableCollection<ConsumerBase> data { get; } = new ObservableCollection<ConsumerBase>();

        #endregion

        #region Methods

        /// <summary>
        /// The EndInit
        /// </summary>
        public override void EndInit()
        {
            base.EndInit();
            ObservableCollectionDetail.GetConsumer(true).ContinueWith(async (s) =>
            {
                var dd = await s;
                foreach (var ss in dd)
                {
                    data.Add(ss);
                }
            });
        }

        /// <summary>
        /// The Clear_Click
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            this.fromDate.SelectedDate = null;
            this.toDate.SelectedDate = null;
            this.supplier.SelectedIndex = -1;
        }

        /// <summary>
        /// The GetChequeDataSet
        /// </summary>
        /// <returns>The <see cref="Task{ChequeDataset}"/></returns>
        private async Task<SupplierDataTable> GetChequeDataSet()
        {
            var id = this.supplier.SelectedValue;
            var suppliers = await InstanceConfig.GetInstance<IReportRepository>().GetSupplierReports(this.fromDate.SelectedDate, this.toDate.SelectedDate, id?.ToInt32());
            SupplierDataTable supplier = new SupplierDataTable();
            if (suppliers != null)
            {
                foreach (var s in suppliers)
                {
                    supplier.AddSupplierRow(s.ChequeNumber, s.ChequeDate, s.ReceivedDate, s.ConsumerName, s.BankName, s.CityName, s.StatusCode, s.Amount);
                }
            }

            return supplier;
        }

        /// <summary>
        /// The Search_Click
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private async void Search_Click(object sender, RoutedEventArgs e)
        {
            ReportDataSource reportDataSource = new ReportDataSource();
            reportViewer.LocalReport.ReportPath = @"Report\SupplierReport.rdlc";
            reportViewer.LocalReport.DataSources.Add(reportDataSource);
            SupplierDataTable dataTable = await GetChequeDataSet();
            reportViewer.LocalReport.DataSources.Clear();
            reportViewer.LocalReport.DataSources.Add(new ReportDataSource("SupplierDataSet", dataTable as DataTable));
            reportViewer.RefreshReport();
        }

        #endregion
    }
}
