﻿// <copyright file="ViewModelExtension.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a ViewModelExtension.cs</summary>

namespace NirubanCheque.Extensions
{
    using NirubanCheque.Model.Common;
    using NirubanCheque.ViewModel;

    /// <summary>
    /// Defines the <see cref="ViewModelExtension" />
    /// </summary>
    public static class ViewModelExtension
    {
        #region Methods

        /// <summary>
        /// The ToViewModel
        /// </summary>
        /// <param name="code">The <see cref="GeneralCode"/></param>
        /// <returns>The <see cref="GeneralCodeViewModel"/></returns>
        public static GeneralCodeViewModel ToViewModel(this GeneralCode code)
        {
            return new GeneralCodeViewModel()
            {
                Id = code.Id,
                Name = code.Name
            };
        }

        #endregion
    }
}
