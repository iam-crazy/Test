﻿using NirubanCheque.ViewModel;
using NirubanCheque.Views.Transaction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NirubanCheque.Extensions
{
    public static class NavigationManager
    {
        internal static BankPopup OpenBranch(Action close)
        {
            BankPopup bank = new BankPopup();
            if (BranchViewModel.Current == null)
            {
                BranchViewModel.Current = new BranchViewModel();
            }

            BranchViewModel.Current.OnClose = close;
            bank.DataContext = BranchViewModel.Current;
            return bank;
        }

        internal static BankPopup OpenBank(Action close)
        {
            BankPopup bank = new BankPopup();
            if (BankViewModel.Current == null)
            {
                BankViewModel.Current = new BankViewModel();
            }

            BankViewModel.Current.OnClose = close;
            bank.DataContext = BankViewModel.Current;
            return bank;
        }
    }
}
