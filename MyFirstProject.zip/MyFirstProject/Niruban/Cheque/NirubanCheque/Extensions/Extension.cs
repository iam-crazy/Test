﻿// <copyright file="Extension.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a Extension.cs</summary>

namespace NirubanCheque.Extensions
{
    using CrazyFramework.Model;
    using CrazyFramework.WPF.Control.Notification;
    using NirubanCheque.ViewModel;
    using System.Windows;
    using CViewModel = CrazyFramework.WPF.ViewModel;

    /// <summary>
    /// Defines the <see cref="Extension" />
    /// </summary>
    public static class Extension
    {
        #region Constants

        /// <summary>
        /// Defines the leftOffset
        /// </summary>
        private const double leftOffset = 350;

        /// <summary>
        /// Defines the topOffset
        /// </summary>
        private const double topOffset = 20;

        #endregion

        #region Fields

        /// <summary>
        /// Defines the notification
        /// </summary>
        internal static Notification notification = new Notification();

        #endregion

        #region Methods

        /// <summary>
        /// The ConfirmationMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        /// <returns>The <see cref="bool"/></returns>
        public static bool ConfirmationMessage(string title, string message)
        {
            return MessageBox.Show(message, title, MessageBoxButton.OKCancel) == MessageBoxResult.OK;
        }

        /// <summary>
        /// The ProcessOutCome
        /// </summary>
        /// <param name="outcome">The <see cref="OperationOutcome"/></param>
        /// <returns>The <see cref="bool"/></returns>
        public static bool ProcessOutCome(this OperationOutcome outcome)
        {
            bool isSuccess = outcome.Status == OperationOutcomeStatus.Success;
            if (!isSuccess)
            {
                ShowErrorMessage("Error", outcome.Message);
                MainViewModel.Current.HideBusy("Opps Something went wrong");
            }
            else
            {
                ShowSaveMessage("Success", outcome.Message);
            }

            return isSuccess;
        }

        /// <summary>
        /// The ShowDeleteMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public static void ShowDeleteMessage(string title, string message)
        {
            ShowMessage(title, message, "\uf1f8");
        }

        /// <summary>
        /// The ShowErrorMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public static void ShowErrorMessage(string title, string message)
        {
            MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error);
        }

        /// <summary>
        /// The ShowInformationMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public static void ShowInformationMessage(string title, string message)
        {
            ShowMessage(title, message, "\uf05a");
        }

        /// <summary>
        /// The ShowSaveMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public static void ShowSaveMessage(string title, string message)
        {
            ShowMessage(title, message, "\uf00c");
        }

        /// <summary>
        /// The ShowWarningMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public static void ShowWarningMessage(string title, string message)
        {
            ShowMessage(title, message, "\uf071");
        }

        /// <summary>
        /// The ShowMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        /// <param name="icon">The <see cref="string"/></param>
        private static void ShowMessage(string title, string message, string icon)
        {
            notification.Top = SystemParameters.WorkArea.Top  - topOffset;
            notification.Left = SystemParameters.WorkArea.Left + SystemParameters.WorkArea.Width - leftOffset;

            notification.AddNotification(new CViewModel.NotificationViewModel { IconCode = icon, Title = title, Message = message });
        }

        #endregion
    }
}
