﻿// <copyright file="ObservableCollectionDetail.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a ObservableCollectionDetail.cs</summary>

namespace NirubanCheque.Extensions
{
    using Business.Interface;
    using Configuration;
    using Model.Common;
    using Model.Master;
    using Model.Transaction;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="ObservableCollectionDetail" />
    /// </summary>
    public static class ObservableCollectionDetail
    {
        #region Fields

        /// <summary>
        /// Defines the allBanks
        /// </summary>
        private static ObservableCollection<GeneralCode> allBanks = new ObservableCollection<GeneralCode>();

        /// <summary>
        /// Defines the cities
        /// </summary>
        private static ObservableCollection<GeneralCode> allCities = new ObservableCollection<GeneralCode>();

        /// <summary>
        /// Defines the banks
        /// </summary>
        private static ObservableCollection<GeneralCode> banks = new ObservableCollection<GeneralCode>();

        /// <summary>
        /// Defines the cities
        /// </summary>
        private static ObservableCollection<GeneralCode> cities = new ObservableCollection<GeneralCode>();

        /// <summary>
        /// Defines the collectCheque
        /// </summary>
        private static ObservableCollection<ChequeBase> collectCheque = new ObservableCollection<ChequeBase>();

        /// <summary>
        /// Defines the depoistCheque
        /// </summary>
        private static ObservableCollection<ChequeBase> depoistCheque = new ObservableCollection<ChequeBase>();

        /// <summary>
        /// Defines the depositers
        /// </summary>
        private static ObservableCollection<ConsumerBase> depositers = new ObservableCollection<ConsumerBase>();

        /// <summary>
        /// 
        /// </summary>
        private static ObservableCollection<ConsumerBase> suppliers = new ObservableCollection<ConsumerBase>();

        #endregion

        #region Methods

        /// <summary>
        /// The ClearBanks
        /// </summary>
        public static void ClearBanks()
        {
            banks.Clear();
            allBanks.Clear();
        }

        /// <summary>
        /// The ClearCities
        /// </summary>
        public static void ClearCities()
        {
            cities.Clear();
            allCities.Clear();
        }

        public static void ClearCheque()
        {
            collectCheque.Clear();
            depoistCheque.Clear();
        }

        /// <summary>
        /// The ClearConsumers
        /// </summary>
        public static void ClearConsumers()
        {
            suppliers.Clear();
            depositers.Clear();
        }

        /// <summary>
        /// The GetAllBanks
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{GeneralCode}}"/></returns>
        public static async Task<ObservableCollection<GeneralCode>> GetAllBanks()
        {

            if (allBanks.Count == 0)
            {
                var bankDetails = await InstanceConfig.GetInstance<IBankService>().Get();
                bankDetails.ToList().ForEach(s => allBanks.Add(new GeneralCode
                {
                    Id = s.Id,
                    Name = s.Name,
                    IsActive = s.IsActive
                }));
            }

            return allBanks;
        }

        /// <summary>
        /// The GetAllCity
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{GeneralCode}}"/></returns>
        public static async Task<ObservableCollection<GeneralCode>> GetAllCity()
        {

            if (allCities.Count == 0)
            {
                var citys = await InstanceConfig.GetInstance<ICityService>().Get();
                citys.ToList().ForEach(s => allCities.Add(new GeneralCode
                {
                    Id = s.Id,
                    Name = s.Name,
                    IsActive = s.IsActive
                }));
            }

            return allCities;
        }

        /// <summary>
        /// The GetBanks
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{GeneralCode}}"/></returns>
        public static async Task<ObservableCollection<GeneralCode>> GetBanks()
        {

            if (banks.Count == 0)
            {
                if (allBanks.Count == 0)
                {
                    var bankDetails = await InstanceConfig.GetInstance<IBankService>().Get();
                    bankDetails.ToList().ForEach(s => allBanks.Add(new GeneralCode
                    {
                        Id = s.Id,
                        Name = s.Name,
                        IsActive = s.IsActive
                    }));
                }

                allBanks.Where(s => s.IsActive).ToList().ForEach(s => banks.Add(s));
            }

            return banks;
        }

        /// <summary>
        /// The GetCity
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{GeneralCode}}"/></returns>
        public static async Task<ObservableCollection<GeneralCode>> GetCity()
        {

            if (cities.Count == 0)
            {
                if (allCities.Count == 0)
                {
                    var citys = await InstanceConfig.GetInstance<ICityService>().Get();
                    citys.ToList().ForEach(s => allCities.Add(new GeneralCode
                    {
                        Id = s.Id,
                        Name = s.Name,
                        IsActive = s.IsActive
                    }));
                }

                allCities.Where(s => s.IsActive).ToList().ForEach(s => cities.Add(s));
            }

            return cities;
        }

        /// <summary>
        /// The GetAllCity
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{ChequeBase}}"/></returns>
        public static async Task<ObservableCollection<ChequeBase>> GetCollectedCheque()
        {

            if (collectCheque.Count == 0)
            {
                var cheques = await InstanceConfig.GetInstance<IChequeService>().Search("C");
                cheques.ToList().ForEach(s => collectCheque.Add(s));
            }

            return collectCheque;
        }

        /// <summary>
        /// The GetAllCity
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{ChequeBase}}"/></returns>
        public static async Task<ObservableCollection<ChequeBase>> GetDepositedCheque()
        {

            if (depoistCheque.Count == 0)
            {
                var cheques = await InstanceConfig.GetInstance<IChequeService>().Search("A");
                cheques.ToList().ForEach(s => depoistCheque.Add(s));
            }

            return depoistCheque;
        }

        /// <summary>
        /// The GetCity
        /// </summary>
        /// <returns>The <see cref="Task{ObservableCollection{GeneralCode}}"/></returns>
        public static async Task<ObservableCollection<ConsumerBase>> GetConsumer(bool isSupplier)
        {

            if (suppliers.Count == 0 && depositers.Count == 0)
            {

                var consumer = await InstanceConfig.GetInstance<IConsumerService>().Search();
                foreach (var con in consumer.Where(s => s.IsSupplier))
                {
                    suppliers.Add(con);
                }
                foreach (var con in consumer.Where(s => !s.IsSupplier))
                {
                    depositers.Add(con);
                }
            }

            return isSupplier ? suppliers : depositers;
        }

        #endregion
    }
}
