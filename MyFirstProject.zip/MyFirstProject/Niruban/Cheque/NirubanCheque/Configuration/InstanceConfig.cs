﻿// <copyright file="InstanceConfig.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a InstanceConfig.cs</summary>

namespace NirubanCheque.Configuration
{
    using Business.Interface;
    using Business.Master;
    using Business.Transaction;
    using CrazyFramework.Dataaccess;
    using Dataaccess.Interface;
    using Dataaccess.Interface.Report;
    using Dataaccess.Master;
    using Dataaccess.Report;
    using Dataaccess.Transaction;
    using LightInject;

    /// <summary>
    /// Defines the <see cref="InstanceConfig" />
    /// </summary>
    public static class InstanceConfig
    {
        #region Fields

        /// <summary>
        /// Defines the container
        /// </summary>
        public static ServiceContainer container = new ServiceContainer();

        #endregion

        #region Methods

        /// <summary>
        /// The GetInstance
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>The <see cref="T"/></returns>
        public static T GetInstance<T>()
        {
            return container.GetInstance<T>();
        }

        /// <summary>
        /// The RegisterGlobalInstances
        /// </summary>
        public static void RegisterGlobalInstances()
        {
            //------------------------- BUSINESS LAYER -------------------------
            container.Register<IBankService, BankService>();
            container.Register<ICityService, CityService>();
            container.Register<IConsumerService, ConsumerService>();
            container.Register<INotificationService, NotificationService>();
            container.Register<ICollectionService, CollectionService>();
            container.Register<IDepositeService, DepositeService>();
            container.Register<IChequeService, ChequeService>();
            container.Register<IClearanceService, ClearanceService>();

            //------------------------ DATAACCESS LAYER -------------------------
            container.Register<ISqlRepository, SqlRepository>();
            container.Register<IBankRepository, BankRepository>();
            container.Register<ICityRepository, CityRepository>();
            container.Register<IConsumerRepository, ConsumerRepository>();
            container.Register<INotificationRepository, NotificationRepository>();
            container.Register<ICollectionRepository, CollectionRepository>();
            container.Register<IDepositeRepository, DepositeRepository>();
            container.Register<IChequeRepository, ChequeRepository>();
            container.Register<IClearanceRepository, ClearanceRepository>();
            container.Register<IReportRepository, ReportRepository>();
        }

        #endregion
    }
}
