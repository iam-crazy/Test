﻿// <copyright file="INotificationService.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a INotificationService.cs</summary>

namespace NirubanCheque.Dataaccess.Interface
{
    using CrazyFramework.Model;
    using NirubanCheque.Model.Master.Dashboard;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="INotificationRepository" />
    /// </summary>
    public interface INotificationRepository
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{NotificationDetail}"/></returns>
        Task<IList<NotificationDetail>> Get();

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="bank">The <see cref="NotificationDetail"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        Task<OperationOutcome> Save(NotificationDetail bank);

        #endregion
    }

    #endregion
}
