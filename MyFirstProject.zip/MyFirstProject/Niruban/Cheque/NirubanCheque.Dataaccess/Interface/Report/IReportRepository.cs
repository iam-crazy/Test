﻿using NirubanCheque.Model.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NirubanCheque.Dataaccess.Interface.Report
{
    public interface IReportRepository
    {
        Task<IList<SupplierReport>> GetSupplierReports(DateTime? fromDate, DateTime? toDate, int? consumerId);
        Task<IList<DepositerReport>> GetDepoisterReports(DateTime? fromDate, DateTime? toDate, int? consumerId);
    }
}
