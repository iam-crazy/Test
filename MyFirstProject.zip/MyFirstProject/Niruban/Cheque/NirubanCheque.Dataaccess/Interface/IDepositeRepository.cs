﻿// <copyright file="IDepoit.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IDepoit.cs</summary>

namespace NirubanCheque.Dataaccess.Interface
{
    using CrazyFramework.Model;
    using Model.Master;
    using Model.Transaction;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IDepositeRepository" />
    /// </summary>
    public interface IDepositeRepository
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{Deposit}"/></returns>
        Task<IList<Deposite>> Get();

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="deposit">The <see cref="Deposite"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        Task<OperationOutcome> Save(Deposite deposit);



        #endregion
    }

    #endregion
}
