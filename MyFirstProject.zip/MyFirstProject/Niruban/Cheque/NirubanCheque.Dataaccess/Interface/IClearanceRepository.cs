﻿// <copyright file="IClearanceRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IClearanceRepository.cs</summary>

namespace NirubanCheque.Business.Interface
{
    using CrazyFramework.Model;
    using Model.Master;
    using Model.Transaction;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IClearanceRepository" />
    /// </summary>
    public interface IClearanceRepository
    {
        #region Methods

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="clearance">The <see cref="Clearance"/></param>
        /// <returns>The <see cref="OperationOutcome"/></returns>
        Task<OperationOutcome> Save(Clearance clearance);

        #endregion Methods
    }

    #endregion
}
