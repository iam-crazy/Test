﻿// <copyright file="IChequeRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IChequeRepository.cs</summary>

namespace NirubanCheque.Dataaccess.Interface
{
    using CrazyFramework.Model;
    using Model.Master;
    using Model.Transaction;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IChequeRepository" />
    /// </summary>
    public interface IChequeRepository
    {
        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="IList{ChequeBase}"/></returns>
        Task<IList<ChequeBase>> Search(string status);

        #endregion
    }

    #endregion
}
