﻿using NirubanCheque.Dataaccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrazyFramework.Model;
using NirubanCheque.Model.Transaction;
using CrazyFramework.Dataaccess;
using System.Data.SqlClient;
using CrazyFramework.Conversion;
using NirubanCheque.Model.Master;
using NirubanCheque.Model.Common;
using CrazyFramework.Dataaccess.Extensions;
using System.Data;
using NirubanCheque.Business.Interface;

namespace NirubanCheque.Dataaccess.Transaction
{
    public class ClearanceRepository : BaseRepository, IClearanceRepository
    {
        #region Constructors

        private const string SaveCheque = "TRA_UPDATE_CHEQUECLEARANCE";

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public ClearanceRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        public async Task<OperationOutcome> Save(Clearance clearance)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            var dd = SqlParameterExtension.GetParameter("@Status", clearance.IsCleared ? 'D' : 'B');
            dd.Size = 1;
            parameters.Add(SqlParameterExtension.GetParameter("@ChequeId", clearance.Cheque.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@AdditionalAmount", clearance.Amount.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@Remark", clearance.Remarks.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", clearance.UserId));
            parameters.Add(dd);
            parameters.Add(SqlParameterExtension.GetParameter("@Message", string.Empty, SqlDbType.VarChar, 5000, ParameterDirection.Output));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveCheque, parameters.ToArray());
            var message = outputDetail.FirstOrDefault(s => s.Item1 == "@Message").Item2.ConvertToString();
            if (!string.IsNullOrEmpty(message))
            {
                outCome.Message = message;
                outCome.Status = OperationOutcomeStatus.Rejection;
            }
            else
            {
                outCome.IdentityValue = outputDetail.FirstOrDefault(s => s.Item1 == "@Id")?.Item2.ToString();
            }

            return outCome;
        }
    }
}
/*
     C-Collection
     R-Deposit
     A-Automative Deposit
     D - Cleared
     B-Bounce
     */