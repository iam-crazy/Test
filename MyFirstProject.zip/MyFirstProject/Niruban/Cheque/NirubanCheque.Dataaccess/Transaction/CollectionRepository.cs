﻿using NirubanCheque.Dataaccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrazyFramework.Model;
using NirubanCheque.Model.Transaction;
using CrazyFramework.Dataaccess;
using System.Data.SqlClient;
using CrazyFramework.Conversion;
using NirubanCheque.Model.Master;
using NirubanCheque.Model.Common;
using CrazyFramework.Dataaccess.Extensions;
using System.Data;

namespace NirubanCheque.Dataaccess.Transaction
{
    public class CollectionRepository : BaseRepository, ICollectionRepository
    {
        #region Constructors

        private const string GetCollection = "TRA_GET_COLLECTION";
        private const string SaveCollection = "TRA_CUD_COLLECTION";

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public CollectionRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        public async Task<IList<CollectionEntry>> Get()
        {
            OperationOutcome outCome = new OperationOutcome();
            return await Repository.ExecuteDataQueryAsync(GetCollection, GetCollectionReader);
        }

        private IList<CollectionEntry> GetCollectionReader(SqlDataReader reader)
        {
            var banks = new List<CollectionEntry>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    banks.Add(new CollectionEntry
                    {
                        Id = reader["collectionId"].ToInt32(),
                        Supplier = new ConsumerBase()
                        {
                            Id = reader["consumerId"].ToInt32(),
                            Name = reader["consumerName"].ConvertToString(),
                        },
                        Cheque=new Cheque()
                        {
                            Amount= reader["amount"].ToDecimal(),
                            ChequeDate= reader["chequeDate"].ToDate(),
                            ChequeNumber= reader["chequeNumber"].ConvertToString(),
                            Status = reader["chequeStatus"].ToChar(),
                            Bank = new GeneralCode
                            {
                                Id = reader["bankId"].ToInt32(),
                                Name = reader["bankName"].ConvertToString(),
                            },
                            Branch=new GeneralCode
                            {

                                Id = reader["cityId"].ToInt32(),
                                Name = reader["cityName"].ConvertToString(),
                            },
                            Id = reader["chequeId"].ToInt32(),
                        },
                        ReceivedDate = reader["receivedDate"].ToDate(),
                        Remark = reader["remark"].ConvertToString(),
                        IsActive = !reader["isDeleted"].ToBoolean()
                    });
                }
            }

            return banks;
        }

        public async Task<OperationOutcome> Save(CollectionEntry collection)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Id", collection.Id, SqlDbType.Int, ParameterDirection.InputOutput));
            parameters.Add(SqlParameterExtension.GetParameter("@ConsumerId", collection.Supplier.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@ReceivedDate", collection.ReceivedDate));
            parameters.Add(SqlParameterExtension.GetParameter("@ChequeId", (object)collection.Cheque.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@ChequeDate", collection.Cheque.ChequeDate));
            parameters.Add(SqlParameterExtension.GetParameter("@ChequeNumber", collection.Cheque.ChequeNumber.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@BankId", (object)collection.Cheque.Bank.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@CityId", collection.Cheque.Branch.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@Amount", collection.Cheque.Amount));
            parameters.Add(SqlParameterExtension.GetParameter("@Remark", collection.Remark.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", collection.UserId));
            parameters.Add(SqlParameterExtension.GetParameter("@Status", collection.Status.GetDescription()));
            parameters.Add(SqlParameterExtension.GetParameter("@Message", string.Empty, SqlDbType.VarChar, 5000, ParameterDirection.Output));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveCollection, parameters.ToArray());
            var message = outputDetail.FirstOrDefault(s => s.Item1 == "@Message").Item2.ConvertToString();
            if (!string.IsNullOrEmpty(message))
            {
                outCome.Message = message;
                outCome.Status = OperationOutcomeStatus.Rejection;
            }
            else
            {
                outCome.IdentityValue = outputDetail.FirstOrDefault(s => s.Item1 == "@Id")?.Item2.ToString();
            }

            return outCome;
        }
    }
}
