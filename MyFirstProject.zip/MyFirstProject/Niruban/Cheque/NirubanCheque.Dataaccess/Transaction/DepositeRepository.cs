﻿using NirubanCheque.Dataaccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrazyFramework.Model;
using NirubanCheque.Model.Transaction;
using CrazyFramework.Dataaccess;
using System.Data.SqlClient;
using CrazyFramework.Conversion;
using NirubanCheque.Model.Master;
using NirubanCheque.Model.Common;
using CrazyFramework.Dataaccess.Extensions;
using System.Data;

namespace NirubanCheque.Dataaccess.Transaction
{
    public class DepositeRepository : BaseRepository, IDepositeRepository
    {
        #region Constructors

        private const string GetDeposite = "TRA_GET_DEPOSIT";
        private const string SaveDeposite = "TRA_CUD_DEPOSIT";

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public DepositeRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        public async Task<IList<Deposite>> Get()
        {
            return await Repository.ExecuteDataQueryAsync(GetDeposite, GetDepositeReader);
        }

        private IList<Deposite> GetDepositeReader(SqlDataReader reader)
        {
            var banks = new List<Deposite>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    banks.Add(new Deposite
                    {
                        Id = reader["depositId"].ToInt32(),
                        Depositer = new ConsumerBase()
                        {
                            Id = reader["consumerId"].ToInt32(),
                            Name = reader["consumerName"].ConvertToString(),
                        },
                       Cheque=new ChequeBase()
                       {
                           ChequeNumber = reader["chequeNumber"].ConvertToString(),
                           Id = reader["chequeId"].ToInt32(),
                       },
                        Bank = new GeneralCode
                        {
                            Id = reader["bankId"].ToInt32(),
                            Name = reader["bankName"].ConvertToString(),
                        },
                        Branch = new GeneralCode
                        {

                            Id = reader["cityId"].ToInt32(),
                            Name = reader["cityName"].ConvertToString(),
                        },
                        DepositDate = reader["depositDate"].ToDate(),
                        AccountNumber = reader["accountNumber"].ConvertToString(),
                        Remark = reader["remark"].ConvertToString(),
                        IsActive = !reader["isDeleted"].ToBoolean()
                    });
                }
            }

            return banks;
        }

        public async Task<OperationOutcome> Save(Deposite deposite)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Id", deposite.Id, SqlDbType.Int, ParameterDirection.InputOutput));
            parameters.Add(SqlParameterExtension.GetParameter("@ChequeId", deposite.Cheque.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@ConsumerId", deposite.Depositer.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@BankId", deposite.Bank.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@CityId", deposite.Branch.Id));
            parameters.Add(SqlParameterExtension.GetParameter("@DepositeDate", deposite.DepositDate));
            parameters.Add(SqlParameterExtension.GetParameter("@AccountNumber", deposite.AccountNumber));
            parameters.Add(SqlParameterExtension.GetParameter("@Remark", deposite.Remark.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", deposite.UserId));
            parameters.Add(SqlParameterExtension.GetParameter("@Status", deposite.Status.GetDescription()));
            parameters.Add(SqlParameterExtension.GetParameter("@Message", string.Empty, SqlDbType.VarChar, 5000, ParameterDirection.Output));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveDeposite, parameters.ToArray());
            var message = outputDetail.FirstOrDefault(s => s.Item1 == "@Message").Item2.ConvertToString();
            if (!string.IsNullOrEmpty(message))
            {
                outCome.Message = message;
                outCome.Status = OperationOutcomeStatus.Rejection;
            }
            else
            {
                outCome.IdentityValue = outputDetail.FirstOrDefault(s => s.Item1 == "@Id")?.Item2.ToString();
            }

            return outCome;
        }
    }
}
