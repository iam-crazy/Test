﻿// <copyright file="ConsumerRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a ConsumerRepository.cs</summary>

namespace NirubanCheque.Dataaccess.Master
{
    using CrazyFramework.Conversion;
    using CrazyFramework.Dataaccess;
    using CrazyFramework.Dataaccess.Extensions;
    using CrazyFramework.Model;
    using Interface;
    using NirubanCheque.Model.Master;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="BankRepository" />
    /// </summary>
    public class BankRepository : BaseRepository,IBankRepository
    {
        #region Constants

        /// <summary>
        /// Defines the GetBank
        /// </summary>
        private const string GetBank = "MAS_GET_BANK";

        /// <summary>
        /// Defines the SaveBank
        /// </summary>
        private const string SaveBank = "MAS_CUD_BANK";

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public BankRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="Task{IList{Bank}}"/></returns>
        public async Task<IList<Bank>> Get()
        {
            OperationOutcome outCome = new OperationOutcome();
            return await Repository.ExecuteDataQueryAsync(GetBank, GetBankReader);
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="bank">The <see cref="Consumer"/></param>
        /// <returns>The <see cref="Task{OperationOutcome}"/></returns>
        public async Task<OperationOutcome> Save(Bank bank)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Id", bank.Id, SqlDbType.Int, ParameterDirection.InputOutput));           
            parameters.Add(SqlParameterExtension.GetParameter("@Name", bank.Name.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", bank.UserId));
            parameters.Add(SqlParameterExtension.GetParameter("@Status", bank.Status.GetDescription()));
            parameters.Add(SqlParameterExtension.GetParameter("@Message", string.Empty, SqlDbType.VarChar,5000, ParameterDirection.Output));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveBank, parameters.ToArray());
            var message = outputDetail.FirstOrDefault(s => s.Item1 == "@Message").Item2.ConvertToString();
            if (!string.IsNullOrEmpty(message))
            {
                outCome.Message = message;
                outCome.Status = OperationOutcomeStatus.Rejection;
            }
            else
            {
                outCome.IdentityValue = outputDetail.FirstOrDefault(s => s.Item1 == "@Id")?.Item2.ToString();
            }
            return outCome;
        }

        /// <summary>
        /// The GetSearchReader
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="IList{GeneralCode}"/></returns>
        private IList<Bank> GetBankReader(SqlDataReader reader)
        {
            var banks = new List<Bank>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    banks.Add(new Bank
                    {
                        Id = reader["bankId"].ToInt32(),
                        Name = reader["name"].ConvertToString(),
                        IsActive = !reader["isDeleted"].ToBoolean()
                    });
                }
            }

            return banks;
        }

        #endregion
    }
}
