﻿// <copyright file="CityRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a CityRepository.cs</summary>

namespace NirubanCheque.Dataaccess.Master
{
    using CrazyFramework.Conversion;
    using CrazyFramework.Dataaccess;
    using CrazyFramework.Dataaccess.Extensions;
    using CrazyFramework.Model;
    using Interface;
    using NirubanCheque.Model.Master;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="CityRepository" />
    /// </summary>
    public class CityRepository : BaseRepository, ICityRepository
    {
        #region Constants

        /// <summary>
        /// Defines the GetBank
        /// </summary>
        private const string GetCity = "MAS_GET_CITY";

        /// <summary>
        /// Defines the SaveBank
        /// </summary>
        private const string SaveCity = "MAS_CUD_CITY";

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public CityRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="Task{IList{City}}"/></returns>
        public async Task<IList<City>> Get()
        {
            OperationOutcome outCome = new OperationOutcome();
            return await Task.Run(() => Repository.ExecuteDataQuery(GetCity, new SqlParameter[0], GetBankReader));
            //  return await Repository.ExecuteDataQueryAsync(GetCity, new SqlParameter[0], GetBankReader);
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="city">The <see cref="City"/></param>
        /// <returns>The <see cref="Task{OperationOutcome}"/></returns>
        public async Task<OperationOutcome> Save(City city)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Id", city.Id, SqlDbType.Int, ParameterDirection.InputOutput));
            parameters.Add(SqlParameterExtension.GetParameter("@Name", city.Name.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", city.UserId));
            parameters.Add(SqlParameterExtension.GetParameter("@Status", city.Status.GetDescription()));
            parameters.Add(SqlParameterExtension.GetParameter("@Message", string.Empty, SqlDbType.VarChar,5000, ParameterDirection.Output));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveCity, parameters.ToArray());
            var message = outputDetail.FirstOrDefault(s => s.Item1 == "@Message").Item2.ConvertToString();
            if (!string.IsNullOrEmpty(message))
            {
                outCome.Message = message;
                outCome.Status = OperationOutcomeStatus.Rejection;
            }
            else
            {
                outCome.IdentityValue = outputDetail.FirstOrDefault(s => s.Item1 == "@Id")?.Item2.ToString();
            }

            return outCome;
        }

        /// <summary>
        /// The GetSearchReader
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="IList{GeneralCode}"/></returns>
        private IList<City> GetBankReader(SqlDataReader reader)
        {
            var banks = new List<City>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    banks.Add(new City
                    {
                        Id = reader["cityId"].ToInt32(),
                        Name = reader["name"].ConvertToString(),
                        IsActive = !reader["isDeleted"].ToBoolean()
                    });
                }
            }

            return banks;
        }

        #endregion
    }
}
