﻿// <copyright file="CityRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a CityRepository.cs</summary>

namespace NirubanCheque.Dataaccess.Master
{
    using CrazyFramework.Conversion;
    using CrazyFramework.Dataaccess;
    using CrazyFramework.Dataaccess.Extensions;
    using CrazyFramework.Model;
    using Interface;
    using Model.Transaction;
    using NirubanCheque.Model.Master;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="CityRepository" />
    /// </summary>
    public class ChequeRepository : BaseRepository, IChequeRepository
    {
        #region Constants

        /// <summary>
        /// Defines the GetBank
        /// </summary>
        private const string SearchCheque = "TRA_SEARCH_CHEQUE";

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ChequeRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public ChequeRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="Task{IList{City}}"/></returns>
        public async Task<IList<ChequeBase>> Search(string status)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Status", status));
            return await Task.Run(() => Repository.ExecuteDataQuery(SearchCheque, parameters.ToArray(), GetChequeReader));
        }


        /// <summary>
        /// The GetSearchReader
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="IList{GeneralCode}"/></returns>
        private IList<ChequeBase> GetChequeReader(SqlDataReader reader)
        {
            var banks = new List<ChequeBase>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    banks.Add(new ChequeBase
                    {
                        Id = reader["chequeId"].ToInt32(),
                        BankName = reader["bankName"].ConvertToString(),
                        ChequeNumber = reader["Number"].ConvertToString()
                    });
                }
            }

            return banks;
        }

        #endregion
    }
}
