﻿// <copyright file="ConsumerRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a ConsumerRepository.cs</summary>

namespace NirubanCheque.Dataaccess.Master
{
    using CrazyFramework.Conversion;
    using CrazyFramework.Dataaccess;
    using CrazyFramework.Dataaccess.Extensions;
    using CrazyFramework.Model;
    using Interface;
    using Model.Common;
    using NirubanCheque.Model.Master;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="ConsumerRepository" />
    /// </summary>
    public class ConsumerRepository : BaseRepository, IConsumerRepository
    {
        #region Constants

        /// <summary>
        /// Defines the GetConsumer
        /// </summary>
        private const string GetConsumer = "MAS_GET_CONSUMER";

        /// <summary>
        /// Defines the SaveConsumer
        /// </summary>
        private const string SaveConsumer = "MAS_CUD_CONSUMER";

        /// <summary>
        /// Defines the SearchConsumer
        /// </summary>
        private const string SearchConsumer = "MAS_SEARCH_CONSUMER";

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public ConsumerRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="Task{IList{Consumer}}"/></returns>
        public async Task<IList<Consumer>> Get()
        {
            OperationOutcome outCome = new OperationOutcome();
            return await Repository.ExecuteDataQueryAsync(GetConsumer, GetConsumerReader);
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="consumer">The <see cref="Consumer"/></param>
        /// <returns>The <see cref="Task{OperationOutcome}"/></returns>
        public async Task<OperationOutcome> Save(Consumer consumer)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Id", consumer.Id, SqlDbType.Int, ParameterDirection.InputOutput));
            parameters.Add(SqlParameterExtension.GetParameter("@Name", consumer.Name.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@Phone", consumer.PhoneNumber.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@CityId", (consumer.City?.Id).ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@Address", consumer.Address.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@Remark", consumer.Remark.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@IsSupplier", consumer.IsSupplier));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", consumer.UserId));
            parameters.Add(SqlParameterExtension.GetParameter("@Status", consumer.Status.GetDescription()));
            parameters.Add(SqlParameterExtension.GetParameter("@Message", string.Empty, SqlDbType.VarChar,5000, ParameterDirection.Output));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveConsumer, parameters.ToArray());
            var message = outputDetail.FirstOrDefault(s => s.Item1 == "@Message").Item2.ConvertToString();
            if (!string.IsNullOrEmpty(message))
            {
                outCome.Message = message;
                outCome.Status = OperationOutcomeStatus.Rejection;
            }
            else
            {
                outCome.IdentityValue = outputDetail.FirstOrDefault(s => s.Item1 == "@Id")?.Item2.ToString();
            }

            return outCome;
        }

        /// <summary>
        /// The Search
        /// </summary>
        /// <returns>The <see cref="Task{IList{GeneralCode}}"/></returns>
        public async Task<IList<ConsumerBase>> Search()
        {
            OperationOutcome outCome = new OperationOutcome();
            return await Repository.ExecuteDataQueryAsync(SearchConsumer, GetSearchReader);
        }

        /// <summary>
        /// The GetConsumerReader
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="IList{Consumer}"/></returns>
        private IList<Consumer> GetConsumerReader(SqlDataReader reader)
        {
            var codes = new List<Consumer>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    codes.Add(new Consumer
                    {
                        Id = reader["consumerId"].ToInt32(),
                        Name = reader["name"].ConvertToString(),
                        PhoneNumber = reader["phone"].ConvertToString(),
                        City = new GeneralCode
                        {
                            Id = reader["cityId"].ToInt32(),
                            Name = reader["cityName"].ConvertToString(),
                        },
                        Address = reader["address"].ConvertToString(),
                        Remark = reader["remark"].ConvertToString(),
                        IsSupplier = reader["isSupplier"].ToBoolean(),
                        IsActive = !reader["isDeleted"].ToBoolean()
                    });
                }
            }
            return codes;
        }

        /// <summary>
        /// The GetSearchReader
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="IList{GeneralCode}"/></returns>
        private IList<ConsumerBase> GetSearchReader(SqlDataReader reader)
        {
            var codes = new List<ConsumerBase>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    codes.Add(new ConsumerBase
                    {
                        Id = reader["consumerId"].ToInt32(),
                        Name = reader["name"].ConvertToString(),
                        IsSupplier = reader["isSupplier"].ToBoolean(),
                    });
                }
            }
            return codes;
        }

        #endregion
    }
}