﻿// <copyright file="NotificationRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a NotificationRepository.cs</summary>

namespace NirubanCheque.Dataaccess.Master
{
    using CrazyFramework.Conversion;
    using CrazyFramework.Dataaccess;
    using CrazyFramework.Dataaccess.Extensions;
    using CrazyFramework.Model;
    using Interface;
    using Model.Master.Dashboard;
    using NirubanCheque.Model.Master;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="NotificationRepository" />
    /// </summary>
    public class NotificationRepository : BaseRepository, INotificationRepository
    {
        #region Constants

        /// <summary>
        /// Defines the GetBank
        /// </summary>
        private const string GetNotification = "MAS_GET_NOTIFICATION";

        /// <summary>
        /// Defines the SaveBank
        /// </summary>
        private const string SaveNotification = "MAS_INSERT_NOTIFICATION";

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public NotificationRepository(ISqlRepository repository) : base(repository)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Get
        /// </summary>
        /// <returns>The <see cref="Task{IList{Notification}}"/></returns>
        public async Task<IList<NotificationDetail>> Get()
        {
            OperationOutcome outCome = new OperationOutcome();
            return await Repository.ExecuteDataQueryAsync(GetNotification, GetNotificationReader);
        }

        /// <summary>
        /// The Save
        /// </summary>
        /// <param name="notification">The <see cref="City"/></param>
        /// <returns>The <see cref="Task{OperationOutcome}"/></returns>
        public async Task<OperationOutcome> Save(NotificationDetail notification)
        {
            OperationOutcome outCome = new OperationOutcome();
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@Description", notification.Description));
            parameters.Add(SqlParameterExtension.GetParameter("@Date", notification.Date));
            parameters.Add(SqlParameterExtension.GetParameter("@UserId", notification.UserId));
            var outputDetail = await Repository.ExecuteNonQueryWithOutputParameterAsync(SaveNotification, parameters.ToArray());
            return outCome;
        }

        /// <summary>
        /// The GetSearchReader
        /// </summary>
        /// <param name="reader">The <see cref="SqlDataReader"/></param>
        /// <returns>The <see cref="IList{GeneralCode}"/></returns>
        private IList<NotificationDetail> GetNotificationReader(SqlDataReader reader)
        {
            var notifications = new List<NotificationDetail>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    notifications.Add(new NotificationDetail
                    {
                        Id = reader["notificationId"].ToInt32(),
                        Name = reader["description"].ConvertToString(),
                        Date = reader["date"].ToDate()
                    });
                }
            }

            return notifications;
        }

        #endregion
    }
}
