﻿using CrazyFramework.Dataaccess;
using NirubanCheque.Dataaccess.Interface.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NirubanCheque.Model.Report;
using System.Data.SqlClient;
using CrazyFramework.Dataaccess.Extensions;
using CrazyFramework.Conversion;

namespace NirubanCheque.Dataaccess.Report
{
   public class ReportRepository : BaseRepository, IReportRepository
    {
        #region Constructors

        private const string GetSupplierReport = "RPT_GET_SUPPLIER";
        private const string GetDepositerReport = "RPT_GET_DEPOSITER";

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public ReportRepository(ISqlRepository repository) : base(repository)
        {
        }

        public async Task<IList<SupplierReport>> GetSupplierReports(DateTime? fromDate, DateTime? toDate, int? consumerId)
        {
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@fromDate", fromDate.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@toDate", toDate.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@consumerId", consumerId.ConvertToDBObject()));
            return await Repository.ExecuteDataQueryAsync(GetSupplierReport, parameters.ToArray(), GetSupplierReader);
        }

        public async Task<IList<DepositerReport>> GetDepoisterReports(DateTime? fromDate, DateTime? toDate, int? consumerId)
        {
            IList<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(SqlParameterExtension.GetParameter("@fromDate", fromDate.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@toDate", toDate.ConvertToDBObject()));
            parameters.Add(SqlParameterExtension.GetParameter("@consumerId", consumerId.ConvertToDBObject()));
            return await Repository.ExecuteDataQueryAsync(GetDepositerReport, parameters.ToArray(), GetDepositerReader);
        }

        private IList<SupplierReport> GetSupplierReader(SqlDataReader reader)
        {
            var suppliers = new List<SupplierReport>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    suppliers.Add(new SupplierReport
                    {
                        ChequeNumber = reader["number"].ToString(),
                        ChequeDate = reader["chequeDate"].ToDate(),
                        ConsumerName = reader["consumerName"].ToString(),
                        BankName = reader["bankName"].ToString(),
                        CityName = reader["cityName"].ToString(),
                        StatusCode = reader["status"].ToString(),
                        Amount = reader["amount"].ToDecimal(),
                        ReceivedDate = reader["receivedDate"].ToDate(),
                    });
                }
            }

            return suppliers;
        }

        private IList<DepositerReport> GetDepositerReader(SqlDataReader reader)
        {
            var suppliers = new List<DepositerReport>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    suppliers.Add(new DepositerReport
                    {
                        ChequeNumber = reader["number"].ToString(),
                        ChequeDate = reader["chequeDate"].ToDate(),
                        StatusCode = reader["status"].ToString(),
                        Amount = reader["amount"].ToDecimal(),
                        AdditionalAmount = reader["additionalAmount"].ToNullabelDecimal(),
                        DepositerName = reader["depositorName"].ToString(),
                        BankName = reader["depositorBankName"].ToString(),
                        CityName = reader["depositorCityName"].ToString(),
                    });
                }
            }

            return suppliers;
        }

        /*
         CHE.Number AS number,
		CHE.Date as chequeDate,
		CHE.Status as status,
		CHE.Amount as amount,
		CHE.AdditionalAmount as additionalAmount,
		DCON.Name AS depositorName,
		DBNK.Name as depositorBankName,
		DCTY.Name as depositorCityName
         
         */
        #endregion

    }
}
