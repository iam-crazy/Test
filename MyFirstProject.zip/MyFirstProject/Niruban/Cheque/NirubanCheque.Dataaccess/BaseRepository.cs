﻿// <copyright file="BaseRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a BaseRepository.cs</summary>

namespace NirubanCheque.Dataaccess
{
    using CrazyFramework.Dataaccess;
    using System.Configuration;

    /// <summary>
    /// Defines the <see cref="BaseRepository" />
    /// </summary>
    public class BaseRepository
    {
        #region Constants

        /// <summary>
        /// Defines the connectionName
        /// </summary>
        private const string connectionName = "DefaultContext";

        #endregion

        #region Fields

        /// <summary>
        /// Defines the connectionString
        /// </summary>
        protected string connectionString = ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;

        /// <summary>
        /// Defines the Repository
        /// </summary>
        protected ISqlRepository Repository;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="repository">The <see cref="ISqlRepository"/></param>
        public BaseRepository(ISqlRepository repository)
        {
            this.Repository = repository;
            (this.Repository as SqlRepository).ConnectionString = connectionString;
        }

        #endregion
    }
}
