﻿namespace CrazyFramework.Model
{
    using System.ComponentModel;

    public enum OperationOutcomeStatus
    {
        [Description("S")]
        Success,

        [Description("R")]
        Rejection,

        [Description("F")]
        Failure
    }
}