﻿namespace CrazyFramework.Model
{
    public enum OperationOutcomeSeverity
    {
        Debug,

        Information,

        Warning,

        Fatal,

        Error,

        Critical
    }
}