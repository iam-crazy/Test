﻿namespace CrazyFramework.Model
{
    public class OperationOutcomeMessage
    {
        #region Properties

        public OperationOutcomeSeverity Severity
        {
            get;
            set;
        }

        public string Message
        {
            get;
            set;
        }

        #endregion Properties
    }
}