﻿namespace CrazyFramework.Model
{
    using System.Collections.Generic;

    public class OperationOutcome
    {
        public OperationOutcome()
            : this(OperationOutcomeStatus.Success)
        { }

        public OperationOutcome(OperationOutcomeStatus status)
        {
            this.Status = status;
            this.Messages = new List<OperationOutcomeMessage>();
        }

        #region Properties

        public OperationOutcomeStatus Status
        {
            get;
            set;
        }

        public string IdentityValue
        {
            get;
            set;
        }

        public IList<OperationOutcomeMessage> Messages
        {
            get;
            set;
        }

        public string Message { get; set; }

        public object Output { get; set; }

        #endregion Properties

        public void AddResult(OperationOutcomeSeverity severity, string message)
        {
            Messages.Add(new OperationOutcomeMessage { Severity = severity, Message = message });
            this.Status = OperationOutcomeStatus.Failure;
        }

        public void SuccessMessage(string message)
        {
            this.Message = message;
        }
    }
}