﻿namespace CrazyFramework.Model
{
    using System.ComponentModel;

    public enum RecordStatus
    {
        [Description("U")]
        Unchanged,

        [Description("I")]
        Create,

        [Description("U")]
        Update,

        [Description("D")]
        Delete
    }
}
