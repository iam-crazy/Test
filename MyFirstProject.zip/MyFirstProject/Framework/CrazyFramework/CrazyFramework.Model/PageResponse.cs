﻿namespace CrazyFramework.Model
{
    using System.Collections.Generic;

    public class PageResponse<T> where T : class
    {
        private IList<T> items;

        public IList<T> Items
        {
            get
            {
                if (items == null)
                {
                    items = new List<T>();
                }

                return items;
            }
            set { items = value; }
        }


        public int Count { get; set; }
    }
}