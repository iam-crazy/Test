﻿// <copyright file="ComboBox.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a ComboBox.cs</summary>
namespace CrazyFramework.WPF.Control
{
    using System;
    using System.Collections;
    using System.Collections.Specialized;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using control = System.Windows.Controls;

    /// <summary>
    /// Defines the <see cref="ComboBox" />
    /// </summary>
    public class ComboBox : control.ComboBox
    {
        #region Fields

        /// <summary>
        /// The check all property.
        /// </summary>
        public static readonly DependencyProperty CheckAllProperty = DependencyProperty.RegisterAttached("CheckAll", typeof(bool?), typeof(ComboBox), new PropertyMetadata(null));

        /// <summary>
        /// The command parameter property.
        /// </summary>
        public static readonly DependencyProperty DefaultItemsProperty = DependencyProperty.RegisterAttached("DefaultItems", typeof(INotifyCollectionChanged), typeof(ComboBox), new PropertyMetadata(new PropertyChangedCallback(OnSelectedItemsPropertyChanged)));

        /// <summary>
        /// Defines the LoadedCommandProperty.
        /// </summary>
        public static readonly DependencyProperty LoadedCommandProperty = DependencyProperty.RegisterAttached("LoadedCommand", typeof(ICommand), typeof(ComboBox), new PropertyMetadata(null));

        /// <summary>
        /// The on load command property.
        /// </summary>
        public static readonly DependencyProperty OnLoadCommandProperty = DependencyProperty.RegisterAttached("OnLoadCommand", typeof(ICommand), typeof(ComboBox), new PropertyMetadata(null));

        /// <summary>
        /// The command parameter property.
        /// </summary>
        public static readonly DependencyProperty SelectionCommandProperty = DependencyProperty.RegisterAttached("SelectionCommand", typeof(ICommand), typeof(ComboBox), new PropertyMetadata(null));

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RadMultipleSelectComboBox"/> class.
        /// </summary>
        public ComboBox()
        {
            System.Collections.ObjectModel.Collection<ResourceDictionary> dictionaries = this.Resources.MergedDictionaries;
            dictionaries.Add(new ResourceDictionary { Source = new Uri(@"pack://application:,,,/Msc.Logistics.ESR.Presentation;Component/ViewResource/CustomStyleViewResource.xaml", UriKind.RelativeOrAbsolute) });
            this.SelectionChanged -= this.OnSelectionChanged;
            this.SelectionChanged += this.OnSelectionChanged;
            this.Loaded -= this.OnLoaded;
            this.Loaded += this.OnLoaded;
            this.GotFocus -= this.OnGotFocus;
            this.GotFocus += this.OnGotFocus;
            this.StaysOpenOnEdit = true;
            this.IsTextSearchEnabled = true;
            this.StaysOpenOnEdit = true;
            this.IsEditable = true;
            //  this.AllowMultipleSelection = true;
            //   this.TextSearchMode = TextSearchMode.Contains;
            //  this.MultipleSelectionSeparator = Constant.CharacterComma;
            this.ItemTemplate = this.FindResource("MultiSelectWithCheckBox") as DataTemplate;
            //   this.CanAutocompleteSelectItems = false;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the check all.
        /// </summary>
        /// <value>
        /// The check all.
        /// </value>
        public bool? CheckAll
        {
            get
            {
                return (bool)this.GetValue(CheckAllProperty);
            }

            set
            {
                this.SetValue(CheckAllProperty, value == true);
            }
        }

        /// <summary>
        /// Gets or sets the selection command.
        /// </summary>
        /// <value>
        /// The selection command.
        /// </value>
        public INotifyCollectionChanged DefaultItems { get; set; }

        /// <summary>
        /// Gets or sets the loaded command.
        /// </summary>
        /// <value>
        /// The loaded command.
        /// </value>
        public ICommand LoadedCommand { get; set; }

        /// <summary>
        /// Gets or sets the on load command.
        /// </summary>
        /// <value>
        /// The on load command.
        /// </value>
        public ICommand OnLoadCommand { get; set; }

        /// <summary>
        /// Gets or sets the selection command.
        /// </summary>
        /// <value>
        /// The selection command.
        /// </value>
        public ICommand SelectionCommand { get; set; }

        #endregion Properties

        #region Public Methods

        /// <summary>
        /// Gets Selected Items.
        /// </summary>
        /// <param name="dependencyObject">The DependencyObject.</param>
        /// <returns>Returns Notify Collection Changed Details.</returns>
        public static INotifyCollectionChanged GetSelectedItems(DependencyObject dependencyObject)
        {
            if (dependencyObject == null)
            {
                throw new ArgumentNullException(nameof(dependencyObject));
            }

            return (INotifyCollectionChanged)dependencyObject.GetValue(DefaultItemsProperty);
        }

        /// <summary>
        /// Gets Selected Items.
        /// </summary>
        /// <param name="dependencyObject">The DependencyObject.</param>
        /// <param name="selectedItems">The selected Items.</param>
        public static void SetSelectedItems(DependencyObject dependencyObject, INotifyCollectionChanged selectedItems)
        {
            dependencyObject?.SetValue(DefaultItemsProperty, selectedItems);
        }

        /// <summary>
        /// The Transfer source to target.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        public static void Transfer(IList source, IList target)
        {
            if (source != null && target != null)
            {
                target.Clear();
                foreach (object item in source)
                {
                    target.Add(item);
                }
            }
        }


        /// <summary>
        /// Called when [On Selected Items Property Changed].
        /// </summary>
        /// <param name="dependencyObject">The DependencyObject.</param>
        /// <param name="e">The Dependency Property Changed Event Args.</param>
        private static void OnSelectedItemsPropertyChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var comboBox = dependencyObject as ComboBox;
            var selectedItems = e.NewValue as INotifyCollectionChanged;
            if (comboBox != null && selectedItems != null)
            {
              //  Transfer(GetSelectedItems(comboBox) as IList, comboBox.SelectedItems);
            }
        }

        /// <summary>
        /// Called when [loaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void OnGotFocus(object sender, RoutedEventArgs e)
        {
            if (e != null)
            {
                var loaded = (ICommand)GetValue(OnLoadCommandProperty);
                if (loaded != null && loaded.CanExecute(e))
                {
                    loaded.Execute(e);
                }
            }
        }

        /// <summary>
        /// Called when [loaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (e != null)
            {
                var loaded = (ICommand)GetValue(LoadedCommandProperty);
                if (loaded != null && loaded.CanExecute(e))
                {
                    loaded.Execute(e);
                }
            }
        }

        /// <summary>
        /// Called when [mouse double click].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e != null)
            {
                var selection = (ICommand)GetValue(SelectionCommandProperty);
                if (selection != null && selection.CanExecute(e))
                {
                    selection.Execute(e);
                }
            }
        }

        #endregion Private Methods
    }
}
