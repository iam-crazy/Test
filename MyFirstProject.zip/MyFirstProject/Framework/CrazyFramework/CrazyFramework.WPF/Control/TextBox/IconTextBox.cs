﻿// <copyright file="IconTextBox.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a IconTextBox.cs</summary>

namespace CrazyFramework.WPF.Control
{
    using System.Windows;

    /// <summary>
    /// Defines the <see cref="IconTextBox" />
    /// </summary>
    public class IconTextBox : WaterMarkTextBox
    {
        #region Constants

        /// <summary>
        /// Defines the IconCode
        /// </summary>
        public const string IconCode = "IconText";

        #endregion

        #region Fields

        /// <summary>
        /// Defines the IconTextProperty
        /// </summary>
        public static readonly DependencyProperty IconTextProperty = DependencyProperty.RegisterAttached(IconCode, typeof(string), typeof(IconTextBox), new PropertyMetadata(null));

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the IconText
        /// </summary>
        public string IconText
        {
            get
            {
                return (string)GetValue(IconTextProperty);
            }

            set
            {
                this.SetValue(IconTextProperty, value);
            }
        }

        #endregion
    }
}
