﻿
namespace CrazyFramework.WPF.Control
{

   
    public class TextBox : System.Windows.Controls.TextBox
    {
        
    }
}
