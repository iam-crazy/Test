﻿

namespace CrazyFramework.WPF.Control
{
    using System.Windows;

    public class WaterMarkTextBox : TextBox
    {
        public const string WaterMark = "WaterMarkText";

        public static readonly DependencyProperty WaterMarkTextProperty = DependencyProperty.RegisterAttached(WaterMark, typeof(string), typeof(IconTextBox), new PropertyMetadata(null));


        public string WaterMarkText
        {
            get
            {
                return (string)GetValue(WaterMarkTextProperty);
            }

            set
            {
                this.SetValue(WaterMarkTextProperty, value);
            }
        }
    }
}
