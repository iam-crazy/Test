﻿// <copyright file="ObservableObject.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a ObservableObject.cs</summary>

namespace CrazyFramework.WPF.ViewModel
{
    using Model;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// Defines the <see cref="ObservableObject" />
    /// </summary>
    public class ObservableObject : INotifyPropertyChanged, INotifyPropertyChanging, INotifyDataErrorInfo
    {
        #region Fields

        /// <summary>
        /// Defines the _errors
        /// </summary>
        private readonly IList<DataError> _errors = new ObservableCollection<DataError>();

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ObservableObject"/> class.
        /// </summary>
        protected ObservableObject()
        {
        }

        #endregion

        #region Events

        /// <summary>
        /// Defines the ErrorsChanged
        /// </summary>
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        /// <summary>
        /// Occurs after a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Defines the PropertyChanging
        /// </summary>
        public event PropertyChangingEventHandler PropertyChanging;

        #endregion

        #region Properties

        /// <summary>
        /// Gets the Errors
        /// </summary>
        public IEnumerable Errors
        {
            get { return _errors; }
        }

        /// <summary>
        /// Gets a value indicating whether HasErrors
        /// </summary>
        public bool HasErrors
        {
            get { return _errors.Any(); }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The GetErrors
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        /// <returns>The <see cref="IEnumerable"/></returns>
        public IEnumerable GetErrors(string propertyName)
        {
            if (propertyName == null)
            {
                return null;
            }
            return _errors.Where(e => e.PropertyName == propertyName).ToList();
        }

        /// <summary>
        /// Verifies that a property name exists in this ViewModel. This method
        /// can be called before the property is used, for instance before
        /// calling RaisePropertyChanged. It avoids errors when a property name
        /// is changed but some places are missed.
        /// </summary>
        /// <remarks>This method is only active in DEBUG mode.</remarks>
        /// <param name="propertyName">The name of the property that will be
        /// checked.</param>
        [Conditional("DEBUG")]
        [DebuggerStepThrough]
        public void VerifyPropertyName(String propertyName)
        {
            var myType = this.GetType();
            if (!string.IsNullOrEmpty(propertyName) && myType.GetTypeInfo().GetDeclaredProperty(propertyName) == null)
            {
                throw new ArgumentException("Property not found", propertyName);
            }
        }

        /// <summary>
        /// The AddError
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        /// <param name="errorMessage">The <see cref="string"/></param>
        protected void AddError(string propertyName, string errorMessage)
        {
            if (_errors.Any(e => e.PropertyName == propertyName && e.Message == errorMessage))
            {
                return;
            }
            _errors.Add(new DataError(propertyName, errorMessage));
            RaiseErrorsChanged(propertyName);
        }

        /// <summary>
        /// The ClearAllErrors
        /// </summary>
        protected void ClearAllErrors()
        {
            if (_errors.Any())
            {
                var keys = _errors.Select(e => e.PropertyName).Distinct().ToList();
                _errors.Clear();
                keys.ForEach(p => RaiseErrorsChanged(p));
            }
        }

        /// <summary>
        /// The ClearError
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        protected void ClearError(string propertyName)
        {
            if (!_errors.Any(e => e.PropertyName == propertyName))
            {
                return;
            }
            var toDelete = _errors.Where(e => e.PropertyName == propertyName).ToList();
            toDelete.ForEach(e => _errors.Remove(e));
            RaiseErrorsChanged(propertyName);
        }

        /// <summary>
        /// The RaiseErrorsChanged
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        protected void RaiseErrorsChanged(string propertyName)
        {
            this.ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));
            RaisePropertyChanged("Errors");
            RaisePropertyChanged("HasErrors");
        }

        /// <summary>
        /// Raises the PropertyChanged event if needed.
        /// </summary>
        /// <remarks>If the propertyName parameter
        /// does not correspond to an existing property on the current class, an
        /// exception is thrown in DEBUG configuration only.</remarks>
        /// <param name="propertyName">(optional) The name of the property that
        /// changed.</param>
        protected virtual void RaisePropertyChanged([CallerMemberName] string propertyName = null)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// The RaisePropertyChanging
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="e">The <see cref="PropertyChangingEventArgs{T}"/></param>
        protected virtual void RaisePropertyChanging<T>(PropertyChangingEventArgs<T> e)
        {
            this.PropertyChanging?.Invoke(this, e);
        }

        /// <summary>
        /// The RemoveError
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        /// <param name="errorMessage">The <see cref="string"/></param>
        protected void RemoveError(string propertyName, string errorMessage)
        {
            if (!_errors.Any(e => e.PropertyName == propertyName && e.Message == errorMessage))
            {
                return;
            }
            var toDelete = _errors.Where(e => e.PropertyName == propertyName && e.Message == errorMessage).ToList();
            toDelete.ForEach(e => _errors.Remove(e));
            RaiseErrorsChanged(propertyName);
        }

        /// <summary>
        /// Assigns a new value to the property. Then, raises the
        /// PropertyChanged event if needed. 
        /// </summary>
        /// <typeparam name="T">The type of the property that
        /// changed.</typeparam>
        /// <param name="field">The field storing the property's value.</param>
        /// <param name="newValue">The property's value after the change
        /// occurred.</param>
        /// <param name="propertyName">(optional) The name of the property that
        /// changed.</param>
        /// <returns>True if the PropertyChanged event has been raised,
        /// false otherwise. The event is not raised if the old
        /// value is equal to the new value.</returns>
        protected virtual bool Set<T>(ref T field, T newValue, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, newValue))
            {
                return false;
            }
            var changing = new PropertyChangingEventArgs<T>(propertyName, field, newValue);
            this.RaisePropertyChanging<T>(changing);
            if (changing.Cancel)
            {
                return false;
            }
            field = newValue;
            this.RaisePropertyChanged(propertyName);
            return true;
        }

        #endregion
    }
}
