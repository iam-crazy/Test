﻿// <copyright file="PropertyChangingEventArgs.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a PropertyChangingEventArgs.cs</summary>

namespace CrazyFramework.WPF.ViewModel
{
    /// <summary>
    /// Defines the <see cref="PropertyChangingEventArgs{T}" />
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PropertyChangingEventArgs<T> : System.ComponentModel.PropertyChangingEventArgs
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyChangingEventArgs{T}"/> class.
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        /// <param name="old">The <see cref="T"/></param>
        /// <param name="future">The <see cref="T"/></param>
        public PropertyChangingEventArgs(string propertyName, T old, T future)
            : base(propertyName)
        {
            OldValue = old;
            NewValue = future;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether Cancel
        /// </summary>
        public bool Cancel { get; set; }

        /// <summary>
        /// Gets or sets the NewValue
        /// </summary>
        public T NewValue { get; private set; }

        /// <summary>
        /// Gets or sets the OldValue
        /// </summary>
        public T OldValue { get; private set; }

        #endregion
    }
}
