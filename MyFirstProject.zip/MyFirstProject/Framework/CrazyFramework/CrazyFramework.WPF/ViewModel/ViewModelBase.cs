﻿// <copyright file="ViewModelBase.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a ViewModelBase.cs</summary>

namespace CrazyFramework.WPF.ViewModel
{
    using CrazyFramework.WPF.Interface;

    /// <summary>
    /// Defines the <see cref="ViewModelBase" />
    /// </summary>
    public abstract class ViewModelBase : ObservableObject, IViewModel
    {
        #region Fields

        /// <summary>
        /// Defines the _isBusy
        /// </summary>
        private bool _isBusy;

        #endregion

        #region Properties

        /// <summary>
        /// Must return a RadRibbonTab
        /// </summary>
        public virtual System.Windows.Controls.Control ContextRibbonTab
        {
            get
            {
                return null;
            }
            set { }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsBusy
        /// </summary>
        public bool IsBusy
        {
            get { return _isBusy; }
            protected set { Set(ref _isBusy, value); }
        }

        /// <summary>
        /// Gets or sets the View
        /// </summary>
        public IView View { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The CultureChanged
        /// </summary>
        public virtual void CultureChanged()
        {
        }

        /// <summary>
        /// The Initialize
        /// </summary>
        /// <param name="args">The <see cref="object[]"/></param>
        public virtual void Initialize(object[] args)
        {
        }

        /// <summary>
        /// The LoadDataAsync
        /// </summary>
        public virtual void LoadDataAsync()
        {
        }

        /// <summary>
        /// The SetView
        /// </summary>
        /// <param name="view">The <see cref="IView"/></param>
        public void SetView(IView view)
        {
            View = view;
            if (View == null)
            {
                return;
            }

            View.DataContext = this;
        }

        #endregion
    }
}
