﻿// <copyright file="DataError.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a DataError.cs</summary>

namespace CrazyFramework.WPF.Model
{
    /// <summary>
    /// Defines the <see cref="DataError" />
    /// </summary>
    public class DataError
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="DataError"/> class.
        /// </summary>
        /// <param name="propertyName">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public DataError(string propertyName, string message)
        {
            PropertyName = propertyName;
            Message = message;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Message
        /// </summary>
        public string Message { get; private set; }

        /// <summary>
        /// Gets or sets the PropertyName
        /// </summary>
        public string PropertyName { get; private set; }

        #endregion

        #region Methods

        /// <summary>
        /// The ToString
        /// </summary>
        /// <returns>The <see cref="string"/></returns>
        public override string ToString()
        {
            return string.Format("{0}", Message);
        }

        #endregion
    }
}
