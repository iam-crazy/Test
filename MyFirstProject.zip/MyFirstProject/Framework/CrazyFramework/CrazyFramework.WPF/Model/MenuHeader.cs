﻿// <copyright file="MenuHeader.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a MenuHeader.cs</summary>

namespace CrazyFramework.WPF.Model
{
    using System.Collections.Generic;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref="MenuHeader" />
    /// </summary>
    public class MenuHeader
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuHeader"/> class.
        /// </summary>
        /// <param name="name">The <see cref="string"/></param>
        public MenuHeader(string name)
        {
            this.Name = name;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Command
        /// </summary>
        public ICommand Command { get; set; }

        /// <summary>
        /// Gets or sets the Groups
        /// </summary>
        public List<MenuGroup> Groups { get; set; } = new List<MenuGroup>();

        /// <summary>
        /// Gets or sets the IconPath
        /// </summary>
        public string IconPath { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsSelected
        /// </summary>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name { get; set; }

        #endregion
    }
}
