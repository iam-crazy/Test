﻿// <copyright file="MenuItem.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a MenuItem.cs</summary>

using System.Windows.Input;

namespace CrazyFramework.WPF.Model
{
    /// <summary>
    /// Defines the <see cref="MenuItem" />
    /// </summary>
    public class MenuItem
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem"/> class.
        /// </summary>
        /// <param name="name">The <see cref="string"/></param>
        /// <param name="iconPath">The <see cref="string"/></param>
        /// <param name="command">The <see cref="Command"/></param>
        public MenuItem(string name, string iconPath, ICommand command)
        {
            this.Name = name;
            this.IconPath = iconPath;
            this.Command = command;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Command
        /// </summary>
        public ICommand Command { get; set; }

        /// <summary>
        /// Gets or sets the IconPath
        /// </summary>
        public string IconPath { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name { get; set; }

        #endregion
    }
}
