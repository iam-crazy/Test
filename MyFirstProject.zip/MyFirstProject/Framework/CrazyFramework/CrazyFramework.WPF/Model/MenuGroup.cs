﻿// <copyright file="MenuGroup.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a MenuGroup.cs</summary>

namespace CrazyFramework.WPF.Model
{
    using System.Collections.Generic;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref="MenuGroup" />
    /// </summary>
    public class MenuGroup
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuGroup"/> class.
        /// </summary>
        /// <param name="name">The <see cref="string"/></param>
        public MenuGroup(string name)
        {
            this.Name = name;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Command
        /// </summary>
        public ICommand Command { get; set; }

        /// <summary>
        /// Gets or sets the IconPath
        /// </summary>
        public string IconPath { get; set; }

        /// <summary>
        /// Gets or sets the Items
        /// </summary>
        public List<MenuItem> Items { get; set; } = new List<MenuItem>();

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name { get; set; }

        #endregion
    }
}
