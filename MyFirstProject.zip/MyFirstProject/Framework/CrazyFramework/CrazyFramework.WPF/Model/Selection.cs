﻿
namespace CrazyFramework.WPF.Model
{

    using CrazyFramework.WPF.Control;
    using CrazyFramework.WPF.ViewModel;
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Windows;
    using WindowControl = System.Windows.Controls;
    using System.Windows.Input;
    using System.Reflection;
    using Conversion;

    public class Selection<T> : ViewModelBase where T : class
    {
        #region Fields

        /// <summary>
        /// Defines the onLoad.
        /// </summary>
        private readonly Func<Task> onload;

        /// <summary>
        /// The can handel selection change event.
        /// </summary>
        private bool canHandelSelectionChangeEvent = true;

        /// <summary>
        /// The can select all.
        /// </summary>
        private bool canSelectAll = true;

        /// <summary>
        /// Defines the comboBox.
        /// </summary>
        private ComboBox comboBox;

        /// <summary>
        /// The is changed.
        /// </summary>
        private bool hasChanged;

        /// <summary>
        /// The is checked.
        /// </summary>
        private bool? hasChecked = false;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is item source changed.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is item source changed; otherwise, <c>false</c>.
        /// </value>
        private bool hasItemSourceChanged;

        /// <summary>
        /// The items.
        /// </summary>
        private IList<T> items;

        /// <summary>
        /// The select all visibility.
        /// </summary>
        private bool selectAllVisibility = false;

        /// <summary>
        /// The selected items.
        /// </summary>
        private ObservableCollection<T> selectedItems;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        public Selection()
        {
            this.SelectionChangedCommand = new Command(this.SelectionChanged);
            this.items = new ObservableCollection<T>();
            this.OnLoadCommand = new Command(this.OnLoad);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="action">The on demand load action.</param>
        public Selection(Func<Task> action) : this()
        {
            this.onload = action;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="action">The on demand load action.</param>
        /// <param name="handler">The handler.</param>
        public Selection(Func<Task> action, Action handler) : this()
        {
            this.ChangeEvent = handler;
            this.onload = action;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="handler">The handler.</param>
        /// <param name="selectedItems">The selected items.</param>
        public Selection(Func<Task> action, Action handler, ObservableCollection<T> selectedItems) : this(action, handler)
        {
            this.selectedItems = selectedItems;
            this.OnLoadedCommand = new Command(this.OnLoaded);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <param name="selectedItems">The selected items.</param>
        public Selection(Func<Task> action, ObservableCollection<T> selectedItems) : this(action)
        {
            this.selectedItems = selectedItems;
            this.OnLoadedCommand = new Command(this.OnLoaded);
            this.OnLoad(string.Empty);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="items">The items.</param>
        public Selection(IList<T> items)
        {
            this.SelectionChangedCommand = new Command(this.SelectionChanged);
            if (items != null)
            {
                this.items = new ObservableCollection<T>(items);
            }

            this.selectAllVisibility = items != null && items.Any();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="items">The items.</param>
        /// <param name="handler">The handler.</param>
        public Selection(IList<T> items, Action handler) : this(items)
        {
            this.ChangeEvent = handler;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="items">The items.</param>
        /// <param name="handler">The handler.</param>
        /// <param name="selectedItems">The selected items.</param>
        public Selection(IList<T> items, Action handler, ObservableCollection<T> selectedItems) : this(items, handler)
        {
            this.selectedItems = selectedItems;
            this.OnLoadedCommand = new Command(this.OnLoaded);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Selection{T}"/> class.
        /// </summary>
        /// <param name="items">The items.</param>
        /// <param name="selectedItems">The selected items.</param>
        public Selection(IList<T> items, ObservableCollection<T> selectedItems) : this(items)
        {
            this.selectedItems = selectedItems;
            this.OnLoadedCommand = new Command(this.OnLoaded);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether [accept null].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [accept null]; otherwise, <c>false</c>.
        /// </value>
        public bool AcceptNull { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating whether this instance can select all.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance can select all; otherwise, <c>false</c>.
        /// </value>
        public bool CanSelectAll
        {
            get
            {
                return this.canSelectAll;
            }

            set
            {
                this.Set(ref this.canSelectAll, value);
            }
        }

        /// <summary>
        /// Gets  the change event.
        /// </summary>
        /// <value>
        /// The change event.
        /// </value>
        public Action ChangeEvent { get; }

        /// <summary>
        /// Gets or sets the is checked.
        /// </summary>
        /// <value>
        /// The is checked.
        /// </value>
        public bool? IsChecked
        {
            get
            {
                return this.hasChecked;
            }

            set
            {
                // Since when user click on checkbox, then it must be true or false.
                // But we uncheck any item in the list, then we want that checkbox as TriState.
                if (this.AcceptNull)
                {
                    this.Set(ref this.hasChecked, value);
                }
                else
                {
                    this.Set(ref this.hasChecked, value == true);
                }
            }
        }

        /// <summary>
        /// Gets or sets the items.
        /// </summary>
        /// <value>
        /// The items.
        /// </value>
        public IList<T> Items
        {
            get
            {
                if (this.items == null)
                {
                    this.items = new List<T>();
                }

                return this.items;
            }

            set
            {
                this.hasItemSourceChanged = true;
                this.Set(ref this.items, value);
                this.hasItemSourceChanged = false;
                this.SelectAllVisibility = this.items != null && this.items.Any();
            }
        }

        /// <summary>
        /// Gets or sets the on load command.
        /// </summary>
        /// <value>
        /// The on load command.
        /// </value>
        public ICommand OnLoadCommand { get; set; }

        /// <summary>
        /// Gets or sets the on loaded command.
        /// </summary>
        /// <value>
        /// The on loaded command.
        /// </value>
        public ICommand OnLoadedCommand { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [reload item source].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [reload item source]; otherwise, <c>false</c>.
        /// </value>
        public bool ReloadItemSource { get; set; } = true;

        /// <summary>
        /// Gets or sets a value indicating whether [select all visibility].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [select all visibility]; otherwise, <c>false</c>.
        /// </value>
        public bool SelectAllVisibility
        {
            get
            {
                return this.selectAllVisibility;
            }

            set
            {
                this.Set(ref this.selectAllVisibility, value);
            }
        }

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public ObservableCollection<T> SelectedItem { get; set; } = new ObservableCollection<T>();

        /// <summary>
        /// Gets or sets the selected items.
        /// </summary>
        /// <value>
        /// The selected items.
        /// </value>
        public ObservableCollection<T> SelectedItems
        {
            get
            {
                if (this.selectedItems == null)
                {
                    this.selectedItems = new ObservableCollection<T>();
                }

                return this.selectedItems;
            }

            set
            {
                this.Set(ref this.selectedItems, value);
            }
        }

        /// <summary>
        /// Gets or sets the selection changed command.
        /// </summary>
        /// <value>
        /// The selection changed command.
        /// </value>
        public ICommand SelectionChangedCommand { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Clears the items.
        /// </summary>
        public void ClearItems()
        {
            if (this.comboBox != null)
            {
                this.comboBox.Text = string.Empty;
               // this.comboBox.SelectedItems.Clear();
            }

            this.Items.Clear();
            this.ReloadItemSource = true;
        }

        /// <summary>
        /// Clears the selected items.
        /// </summary>
        public void ClearSelectedItems()
        {
            if (this.comboBox != null)
            {
                this.comboBox.Text = string.Empty;
              // this.comboBox.SelectedItems.Clear();
            }
        }

        /// <summary>
        /// Called when [load].
        /// </summary>
        /// <param name="sender">The sender.</param>
        public void OnLoad(object sender)
        {
            if (this.onload != null && this.ReloadItemSource)
            {
                this.ReloadItemSource = false;
                Task.Run(() => this.onload.Invoke());
            }
        }

        /// <summary>
        /// Called when [loaded].
        /// </summary>
        /// <param name="sender">The sender.</param>
        public void OnLoaded(object sender)
        {
            if (sender != null)
            {
                var radcomboBoxItems = sender as RoutedEventArgs;
                var radComboBox = radcomboBoxItems.OriginalSource as ComboBox;
                this.comboBox = radComboBox;
                radcomboBoxItems.Handled = true;
                this.ItemSourceChanged(radComboBox);
            }
        }

        /// <summary>
        /// Selections the changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        public void SelectionChanged(object sender)
        {
            if (sender != null && this.canHandelSelectionChangeEvent)
            {
                var radcomboBoxItems = sender as WindowControl.SelectionChangedEventArgs;
                var radComboBox = radcomboBoxItems.OriginalSource as ComboBox;
                this.comboBox = radComboBox;
                if (!this.hasItemSourceChanged)
                {
                    this.SelectionItemsChanged(radcomboBoxItems);
                }
                else
                {
                    radcomboBoxItems.Handled = true;
                    this.ItemSourceChanged(radComboBox);
                }

                this.SelectAllEnabled(radComboBox);

                if (this.hasChanged)
                {
                    this.hasChanged = false;
                    this.ChangeEvent?.Invoke();
                }
            }
            else
            {
                this.canHandelSelectionChangeEvent = true;
            }
        }

        /// <summary>
        /// Updates the items source.
        /// </summary>
        /// <param name="currentItems">The current items.</param>
        public void UpdateItemsSource(IEnumerable<T> currentItems)
        {
            this.Items = currentItems.ToList();
            this.CanSelectAll = this.Items.Count < 500;
            this.SelectAllVisibility = this.items != null && this.items.Any();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Gets the property value.
        /// </summary>
        /// <param name="item">The current item.</param>
        /// <param name="propertyName">Name of the property.</param>
        /// <returns>The Current Value.</returns>
        private static int GetPropertyValue(object item, string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentNullException(nameof(propertyName));
            }

            Type t = item.GetType();
            PropertyInfo prop = t.GetProperty(propertyName);
            return Conversion.ToInt32(prop.GetValue(item));
        }

        /// <summary>
        /// Items the source changed.
        /// </summary>
        /// <param name="radComboBox">The RAD ComboBox.</param>
        private void ItemSourceChanged(ComboBox radComboBox)
        {
            //foreach (var selectItem in this.SelectedItems.ToList())
            //{
            //    this.canHandelSelectionChangeEvent = false;
            //    int index = this.Items.ToList().FindIndex(s => GetPropertyValue(s, Constant.Id) == GetPropertyValue(selectItem, Constant.Id));
            //    T item = this.Items.FirstOrDefault(s => GetPropertyValue(s, Constant.Id) == GetPropertyValue(selectItem, Constant.Id));
            //    if (index > -1)
            //    {
            //        this.SelectedItems.Remove(selectItem);
            //        this.SelectedItems.Add(item);
            //       // radComboBox.SelectedItems.Add(item);
            //    }
            //    else
            //    {
            //        this.SelectedItems.Remove(selectItem as T);
            //        this.hasChanged = true;
            //    }

            //    this.canHandelSelectionChangeEvent = true;
            //}
        }

        /// <summary>
        /// Selects all enabled.
        /// </summary>
        /// <param name="radComboBox">The RAD ComboBox.</param>
        private void SelectAllEnabled(ComboBox radComboBox)
        {
            //if (this.SelectedItems != null)
            //{
            //    if (this.SelectedItems.Count == Constant.DefaultNumeric)
            //    {
            //        this.IsChecked = false;
            //    }
            //    else if (this.SelectedItems.Count == radComboBox.Items.Count)
            //    {
            //        this.IsChecked = true;
            //    }
            //    else
            //    {
            //        // Since we can't able to set Null to IsChecked Property, so first i made acceptNull True and then false.
            //        // Since when user click on checkbox, then it must be true or false.
            //        // But we uncheck any item in the list, then we want that checkbox as TriState.
            //        this.AcceptNull = true;
            //        this.IsChecked = null;
            //        this.AcceptNull = false;
            //    }
            //}
        }

        /// <summary>
        /// Selections the items changed.
        /// </summary>
        /// <param name="radcomboBoxItems">The <see cref="SelectionChangedEventArgs"/> instance containing the event data.</param>
        private void SelectionItemsChanged(WindowControl.SelectionChangedEventArgs radcomboBoxItems)
        {
            //if (radcomboBoxItems.AddedItems != null)
            //{
            //    foreach (var addedItem in radcomboBoxItems.AddedItems)
            //    {
            //        int index = this.SelectedItems.ToList().FindIndex(s => GetPropertyValue(s, Constant.Id) == GetPropertyValue(addedItem, Constant.Id));

            //        if (index == -Constant.One && addedItem != null)
            //        {
            //            this.SelectedItems.Add(addedItem as T);
            //            this.hasChanged = true;
            //        }
            //    }
            //}

            //if (radcomboBoxItems.RemovedItems != null && this.SelectedItems.Any())
            //{
            //    foreach (var removeItem in radcomboBoxItems.RemovedItems)
            //    {
            //        int index = this.SelectedItems.ToList().FindIndex(s => GetPropertyValue(s, Constant.Id) == GetPropertyValue(removeItem, Constant.Id));

            //        if (index > -Constant.One && removeItem != null)
            //        {
            //            this.SelectedItems.Remove(removeItem as T);
            //            this.hasChanged = true;
            //        }
            //    }
            //}
        }

        #endregion
    }
}
