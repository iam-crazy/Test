﻿// <copyright file="IView.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IView.cs</summary>

namespace CrazyFramework.WPF.Interface
{
    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IView" />
    /// </summary>
    public interface IView
    {
        #region Properties

        /// <summary>
        /// Gets or sets the DataContext
        /// </summary>
        object DataContext { get; set; }

        #endregion
    }

    #endregion
}
