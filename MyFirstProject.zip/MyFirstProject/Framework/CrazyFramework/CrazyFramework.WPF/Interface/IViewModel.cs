﻿// <copyright file="IViewModel.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>Crazy Guy</author>
// <summary>Class representing a IViewModel.cs</summary>

using CrazyFramework.WPF.Model;

namespace CrazyFramework.WPF.Interface
{
    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IViewModel" />
    /// </summary>
    public interface IViewModel
    {
        #region Properties

        /// <summary>
        /// Returns the reference interface in the viewmodle to the assosicated IView
        /// </summary>
        IView View { set; }

        #endregion

        #region Methods

        /// <summary>
        /// Invoked by the boot loader when culture has changed. All controls are updated automatically. Some manual localization can be updated for example setting the Tab text.
        /// </summary>
        void CultureChanged();

        /// <summary>
        /// Called by the framework to initialize the unit. Arguments are passed via calling the IViewFrame.Open()
        /// </summary>
        /// <param name="args">Arguments from caller</param>
        void Initialize(object[] args);

        #endregion
    }

    #endregion
}
