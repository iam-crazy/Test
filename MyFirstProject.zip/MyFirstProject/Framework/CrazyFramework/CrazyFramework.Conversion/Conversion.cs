﻿// <copyright file="Class1.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a Class1.cs</summary>

namespace CrazyFramework.Conversion
{
    using System;
    using System.ComponentModel;
    using System.Reflection;

    /// <summary>
    /// Defines the <see cref="Conversion" />
    /// </summary>
    public static class Conversion
    {
        #region Methods

        /// <summary>
        /// This is method is used for short Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Short value. 
        /// </param>
        /// <returns>
        /// Returns The Short Value. 
        /// </returns>
        public static short ToInt16<T>(this T value)
        {
            string input = Conversion.ToString(value);
            short resout;
            return short.TryParse(input, out resout) ? resout : default(short);
        }

        /// <summary>
        /// This is method is used for Integer Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="parameterName">
        /// Integer value. 
        /// </param>
        /// <returns>
        /// Returns The Integer Value. 
        /// </returns>
        public static int ToInt32<T>(this T parameterName)
        {
            string input = Conversion.ToString(parameterName);
            int resout;
            return int.TryParse(input, out resout) ? resout : default(int);
        }

        /// <summary>
        /// This method is used for Long conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Long value. 
        /// </param>
        /// <returns>
        /// Returns The Long Value. 
        /// </returns>
        public static long ToInt64<T>(this T value)
        {
            string input = Conversion.ToString(value);
            long resout;
            return long.TryParse(input, out resout) ? resout : default(long);
        }

        /// <summary>
        /// The ConvertString
        /// </summary>
        /// <param name="current">The <see cref="object"/></param>
        /// <returns>The <see cref="string"/></returns>
        public static string ConvertToString(this object current)
        {
            string output = string.Empty;
            if (current != null)
            {
                output = current.ToString();
            }

            return output;
        }

        /// <summary>
        /// This method is used for boolean conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Boolean value. 
        /// </param>
        /// <returns>
        /// Returns The Boolean Value. 
        /// </returns>
        public static bool ToBoolean<T>(this T value)
        {
            string input = Conversion.ToString(value);

            bool resout;

            return bool.TryParse(input, out resout) ? resout : default(bool);
        }

        /// <summary>
        /// This method is used for Character Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Character value. 
        /// </param>
        /// <returns>
        /// Returns The Character Value. 
        /// </returns>
        public static char ToChar<T>(this T value)
        {
            string input = Conversion.ToString(value);
            char resout;
            return char.TryParse(input, out resout) ? resout : default(char);
        }

        /// <summary>
        /// This method is used for Date Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Date value. 
        /// </param>
        /// <returns>
        /// Returns The DateTime Value. 
        /// </returns>
        public static DateTime ToDate<T>(this T value)
        {
            string input = Conversion.ToString(value);
            DateTime resout;
            return DateTime.TryParse(input, out resout) ? resout : default(DateTime);
        }

        public static string GetDescription(this Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        /// <summary>
        /// This method is used for DateTime Offset Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Date value. 
        /// </param>
        /// <returns>
        /// Returns The DateTime offset Value. 
        /// </returns>
        public static DateTimeOffset ToDateTimeOffset<T>(this T value)
        {
            string input = Conversion.ToString(value);
            DateTimeOffset resout;
            return DateTimeOffset.TryParse(input, out resout) ? resout : default(DateTimeOffset);
        }

        /// <summary>
        /// This method is used for Decimal Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Decimal value. 
        /// </param>
        /// <returns>
        /// Returns The Value. 
        /// </returns>
        public static decimal ToDecimal<T>(this T value)
        {
            string input = Conversion.ToString(value);
            decimal resout;
            return decimal.TryParse(input, out resout) ? resout : default(decimal);
        }

        /// <summary>
        /// This method is used for Double Conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// Double value. 
        /// </param>
        /// <returns>
        /// Returns The Value. 
        /// </returns>
        public static double ToDouble<T>(this T value)
        {
            string input = Conversion.ToString(value);
            double resout;
            return double.TryParse(input, out resout) ? resout : default(double);
        }

        /// <summary>
        /// This method is used for string conversion. 
        /// </summary>
        /// <typeparam name="T">
        /// Base type. 
        /// </typeparam>
        /// <param name="value">
        /// String value. 
        /// </param>
        /// <returns>
        /// Returns The String Value. 
        /// </returns>
        public static string ToString<T>(T value)
        {
            if (value == null)
            {
                return string.Empty;
            }
            else
            {
                return value.ToString();
            }
        }

        #endregion
    }
}
