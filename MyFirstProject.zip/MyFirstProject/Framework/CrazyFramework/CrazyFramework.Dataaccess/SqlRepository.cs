﻿// <copyright file="SqlRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a SqlRepository.cs</summary>

namespace CrazyFramework.Dataaccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="SqlRepository" />
    /// </summary>
    public sealed class SqlRepository : ISqlRepository
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SqlRepository"/> class.
        /// </summary>
        public SqlRepository()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SqlRepository"/> class.
        /// </summary>
        /// <param name="connectionString">The <see cref="string"/></param>
        public SqlRepository(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the ConnectionString
        /// </summary>
        public string ConnectionString { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The ExecuteDataQuery
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="T"/></returns>
        public T ExecuteDataQuery<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader)
        {
            T output = default(T);
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            output = sqlReader.Invoke(reader);
                        }
                    }
                }
            }

            return output;
        }

        /// <summary>
        /// The ExecuteDataQueryAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Task{T}"/></returns>
        public async Task<T> ExecuteDataQueryAsync<T>(string procName, Func<SqlDataReader, T> sqlReader)
        {
            T output = default(T);
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;                  
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            output = sqlReader.Invoke(reader);
                        }
                    }
                }
            }

            return output;
        }

        /// <summary>
        /// The ExecuteDataQueryAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Task{T}"/></returns>
        public async Task<T> ExecuteDataQueryAsync<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader)
        {
            T output = default(T);
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            output = sqlReader.Invoke(reader);
                        }
                    }
                }
            }

            return output;
        }

        /// <summary>
        /// The ExecuteDataQueryWithOutputParameter
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Tuple{T, IEnumerable{Tuple{string, object}}}"/></returns>
        public Tuple<T, IEnumerable<Tuple<string, object>>> ExecuteDataQueryWithOutputParameter<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader)
        {
            T output = default(T);
            IEnumerable<Tuple<string, object>> value = null;
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            output = sqlReader.Invoke(reader);
                        }
                    }

                    value = parameters?.Where(s => s.Direction == ParameterDirection.Output).Select(s => new Tuple<string, object>(s.ParameterName, s.Value));
                }
            }

            return new Tuple<T, IEnumerable<Tuple<string, object>>>(output, value);
        }

        /// <summary>
        /// The ExecuteDataQueryWithOutputParameterAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Task{Tuple{T, IEnumerable{Tuple{string, object}}}}"/></returns>
        public async Task<Tuple<T, IEnumerable<Tuple<string, object>>>> ExecuteDataQueryWithOutputParameterAsync<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader)
        {
            T output = default(T);
            IEnumerable<Tuple<string, object>> value = null;
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            output = sqlReader.Invoke(reader);
                        }
                    }

                    value = parameters?.Where(s => s.Direction == ParameterDirection.Output).Select(s => new Tuple<string, object>(s.ParameterName, s.Value));
                }
            }

            return new Tuple<T, IEnumerable<Tuple<string, object>>>(output, value);
        }

        /// <summary>
        /// The ExecuteNonQuery
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        public void ExecuteNonQuery(string procName, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }

        /// <summary>
        /// The ExecuteNonQueryAsync
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task"/></returns>
        public async Task ExecuteNonQueryAsync(string procName, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    await command.ExecuteNonQueryAsync();
                    connection.Close();
                }
            }
        }

        /// <summary>
        /// The ExecuteNonQueryWithOutputParameter
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="IEnumerable{Tuple{string, object}}"/></returns>
        public IEnumerable<Tuple<string, object>> ExecuteNonQueryWithOutputParameter(string procName, SqlParameter[] parameters)
        {
            IEnumerable<Tuple<string, object>> value = null;
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    command.ExecuteNonQuery();
                    value = parameters?.Where(s => s.Direction == ParameterDirection.Output).Select(s => new Tuple<string, object>(s.ParameterName, s.Value));
                    connection.Close();
                }
            }
            return value;
        }

        /// <summary>
        /// The ExecuteNonQueryWithOutputParameterAsync
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task{IEnumerable{Tuple{string, object}}}"/></returns>
        public async Task<IEnumerable<Tuple<string, object>>> ExecuteNonQueryWithOutputParameterAsync(string procName, SqlParameter[] parameters)
        {
            IEnumerable<Tuple<string, object>> value = null;
            using (SqlConnection connection = new SqlConnection(this.ConnectionString))
            {
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    await command.ExecuteNonQueryAsync();
                    value = parameters?.Where(s => s.Direction == ParameterDirection.Output).Select(s => new Tuple<string, object>(s.ParameterName, s.Value));
                    connection.Close();
                }
            }
            return value;
        }

        #endregion
    }
}
