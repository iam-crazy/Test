﻿// <copyright file="ISqlRepository.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a ISqlRepository.cs</summary>

namespace CrazyFramework.Dataaccess
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Threading.Tasks;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="ISqlRepository" />
    /// </summary>
    public interface ISqlRepository
    {
        #region Methods

        /// <summary>
        /// The ExecuteDataQuery
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="T"/></returns>
        T ExecuteDataQuery<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader);

        /// <summary>
        /// The ExecuteDataQueryAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Task{T}"/></returns>
        Task<T> ExecuteDataQueryAsync<T>(string procName, Func<SqlDataReader, T> sqlReader);

        /// <summary>
        /// The ExecuteDataQueryAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Task{T}"/></returns>
        Task<T> ExecuteDataQueryAsync<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader);

        /// <summary>
        /// The ExecuteDataQueryWithOutputParameter
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Tuple{T, IEnumerable{Tuple{string, object}}}"/></returns>
        Tuple<T, IEnumerable<Tuple<string, object>>> ExecuteDataQueryWithOutputParameter<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader);

        /// <summary>
        /// The ExecuteDataQueryWithOutputParameterAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <param name="sqlReader">The <see cref="Func{SqlDataReader, T}"/></param>
        /// <returns>The <see cref="Task{Tuple{T, IEnumerable{Tuple{string, object}}}}"/></returns>
        Task<Tuple<T, IEnumerable<Tuple<string, object>>>> ExecuteDataQueryWithOutputParameterAsync<T>(string procName, SqlParameter[] parameters, Func<SqlDataReader, T> sqlReader);

        /// <summary>
        /// The ExecuteNonQuery
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        void ExecuteNonQuery(string procName, SqlParameter[] parameters);

        /// <summary>
        /// The ExecuteNonQueryAsync
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task"/></returns>
        Task ExecuteNonQueryAsync(string procName, SqlParameter[] parameters);

        /// <summary>
        /// The ExecuteNonQueryWithOutputParameter
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="IEnumerable{Tuple{string, object}}"/></returns>
        IEnumerable<Tuple<string, object>> ExecuteNonQueryWithOutputParameter(string procName, SqlParameter[] parameters);

        /// <summary>
        /// The ExecuteNonQueryWithOutputParameterAsync
        /// </summary>
        /// <param name="procName">The <see cref="string"/></param>
        /// <param name="parameters">The <see cref="SqlParameter[]"/></param>
        /// <returns>The <see cref="Task{IEnumerable{Tuple{string, object}}}"/></returns>
        Task<IEnumerable<Tuple<string, object>>> ExecuteNonQueryWithOutputParameterAsync(string procName, SqlParameter[] parameters);

        #endregion
    }

    #endregion
}
