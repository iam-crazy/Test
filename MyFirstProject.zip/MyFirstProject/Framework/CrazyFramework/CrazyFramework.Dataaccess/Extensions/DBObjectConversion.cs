﻿// <copyright file="DBObjectConversion.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a DBObjectConversion.cs</summary>

namespace CrazyFramework.Dataaccess
{
    using System;

    /// <summary>
    /// Defines the <see cref="DBObjectConversion" />
    /// </summary>
    public static class DBObjectConversion
    {
        #region Methods

        /// <summary>
        /// The ConvertToDBObject
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data">The <see cref="Nullable{T}"/></param>
        /// <returns>The <see cref="object"/></returns>
        public static object ConvertToDBObject<T>(this Nullable<T> data) where T : struct
        {
            object value = DBNull.Value;
            if (data.HasValue)
            {
                value = data.Value;
            }

            return value;
        }

        /// <summary>
        /// The ConvertToDBObject
        /// </summary>
        /// <param name="data">The <see cref="object"/></param>
        /// <param name="replacevalue">The <see cref="object"/></param>
        /// <returns>The <see cref="object"/></returns>
        public static object ConvertToDBObject(this object data, object replacevalue)
        {
            object value = DBNull.Value;
            if (data != null)
            {
                value = replacevalue;
            }

            return value;
        }

        /// <summary>
        /// The ConvertToDBObject
        /// </summary>
        /// <param name="data">The <see cref="string"/></param>
        /// <returns>The <see cref="object"/></returns>
        public static object ConvertToDBObject(this string data)
        {
            object value = DBNull.Value;
            if (!string.IsNullOrEmpty(data))
            {
                value = data.TrimStart().TrimEnd();
            }

            return value;
        }

        #endregion
    }
}
