﻿// <copyright file="SqlParameterExtension.cs" company="Crazy Technologies">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>$Crazy Guy$</author>
// <summary>Class representing a SqlParameterExtension.cs</summary>

namespace CrazyFramework.Dataaccess.Extensions
{
    using System.Data;
    using System.Data.SqlClient;

    /// <summary>
    /// Defines the <see cref="SqlParameterExtension" />
    /// </summary>
    public static class SqlParameterExtension
    {
        #region Methods

        /// <summary>
        /// The GetParameter
        /// </summary>
        /// <param name="parameterName">The <see cref="string"/></param>
        /// <param name="value">The <see cref="object"/></param>
        /// <returns>The <see cref="SqlParameter"/></returns>
        public static SqlParameter GetParameter(string parameterName, object value)
        {
            return new SqlParameter(parameterName, value);
        }

        /// <summary>
        /// The GetParameter
        /// </summary>
        /// <param name="parameterName">The <see cref="string"/></param>
        /// <param name="value">The <see cref="object"/></param>
        /// <param name="type">The <see cref="SqlDbType"/></param>
        /// <returns>The <see cref="SqlParameter"/></returns>
        public static SqlParameter GetParameter(string parameterName, object value, SqlDbType type)
        {
            var sqlParameter = new SqlParameter(parameterName, value);
            sqlParameter.SqlDbType = type;
            return sqlParameter;
        }

        /// <summary>
        /// The GetParameter
        /// </summary>
        /// <param name="parameterName">The <see cref="string"/></param>
        /// <param name="value">The <see cref="object"/></param>
        /// <param name="type">The <see cref="SqlDbType"/></param>
        /// <param name="direction">The <see cref="ParameterDirection"/></param>
        /// <returns>The <see cref="SqlParameter"/></returns>
        public static SqlParameter GetParameter(string parameterName, object value, SqlDbType type, ParameterDirection direction)
        {
            var sqlParameter = new SqlParameter(parameterName, value);
            sqlParameter.SqlDbType = type;
            sqlParameter.Direction = direction;
            return sqlParameter;
        }

        #endregion
    }
}
