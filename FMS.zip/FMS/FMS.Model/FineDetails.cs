﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMS.Model
{
    public class FineDetails
    {
        public long Id { get; set; }
        public DateTime FineDate { get; set; }
        public string Name { get; set; }
        public string FineAmount { get; set; }
        public string Query { get; set; }

        public string Status { get; set; }
    }
}
