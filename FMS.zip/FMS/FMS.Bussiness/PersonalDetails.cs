﻿using FMS.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace FMS.Bussiness
{
    public static class PersonalDetails
    {
        public static List<PersonalDetailsModel> FunForPlGridSummery()
        {
            List<PersonalDetailsModel> objLstPdSummery = new List<PersonalDetailsModel>();
            DataTable objDsPdSummery = ListOfXmlFilName.objPdXmlPath.FunForReadXMl();
            if (objDsPdSummery != null && objDsPdSummery.Rows.Count > 0)
            {
                objLstPdSummery = objDsPdSummery.FunForDataTableToList<PersonalDetailsModel>().ToList();
            }
            return objLstPdSummery;
        }
        public static List<PersonalDetailsModel> FunForPdActiveUser()
        {
            List<PersonalDetailsModel> objLstPdSummery = new List<PersonalDetailsModel>();
            DataTable objDsPdSummery = ListOfXmlFilName.objPdXmlPath.FunForReadXMl();
            if (objDsPdSummery != null && objDsPdSummery.Rows.Count > 0)
            {
                objLstPdSummery = objDsPdSummery.FunForDataTableToList<PersonalDetailsModel>().ToList().Where(w => w.Status == true).ToList();
            }
            return objLstPdSummery;
        }
        public static string convertXmlChar(string xmlString)
        {
            string encodedXml = xmlString.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;").Replace("'", "&apos;");
            return encodedXml;
        }
        public static List<PersonalDetailsModel> FunForPdUserDetails(string name)
        {
            List<PersonalDetailsModel> objLstPdSummery = new List<PersonalDetailsModel>();
            DataTable objDsPdSummery = ListOfXmlFilName.objPdXmlPath.FunForReadXMl();
            if (objDsPdSummery != null && objDsPdSummery.Rows.Count > 0)
            {
                objLstPdSummery = objDsPdSummery.FunForDataTableToList<PersonalDetailsModel>().ToList().Where(w => w.Name == name).ToList();
            }
            return objLstPdSummery;
        }
        public static void FunForPersonalDetailsInsert(PersonalDetailsModel objPdModel)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            long objId = 1;
            if (objLstPdSummery.Count > 0)
            {
                objId = objLstPdSummery.Max(m => m.Id) + 1;
            }
            objPdModel.Id = objId;
            objLstPdSummery.Add(objPdModel);
            ListOfXmlFilName.objPdXmlPath.FunForWriteXML(objLstPdSummery);
        }

        public static bool FunForValidateName(string text)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            if (objLstPdSummery.Where(w => w.Name == text).ToList().Count > 0)
            {
                return false;
            }
            return true;
        }

        public static bool FunForValidateContactNo(string text)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            if (objLstPdSummery.Where(w => w.PhoneNumber == text).ToList().Count > 0)
            {
                return false;
            }
            return true;
        }

        public static bool FunForValidateEmailId(string text)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            if (objLstPdSummery.Where(w => w.EmailID == text).ToList().Count > 0)
            {
                return false;
            }
            return true;
        }

        public static bool FunForValidateContactNo(string phoneNumber, string Name)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            if (objLstPdSummery.Where(w => w.Name != Name && w.PhoneNumber == phoneNumber).ToList().Count > 0)
            {
                return false;
            }
            return true;
        }
        public static bool FunForValidateEmailId(string emailID, string Name)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            if (objLstPdSummery.Where(w => w.Name != Name && w.EmailID == emailID).ToList().Count > 0)
            {
                return false;
            }
            return true;
        }
        public static bool FunForValidateReportSendingDate(string date)
        {
            List<ReportMailSending> LstPdSummery = FunForReportMailSending();
            if (LstPdSummery.Where(w => w.Date == Convert.ToDateTime(date)).ToList().Count > 0)
            {
                return false;
            }
            return true;
        }
        public static List<ReportMailSending> FunForReportMailSending()
        {
            List<ReportMailSending> objLstPdSummery = new List<ReportMailSending>();
            DataTable objDsPdSummery = ListOfXmlFilName.objRsXmlPath.FunForReadXMl();
            if (objDsPdSummery != null && objDsPdSummery.Rows.Count > 0)
            {
                objLstPdSummery = objDsPdSummery.FunForDataTableToList<ReportMailSending>().ToList();
            }
            return objLstPdSummery;
        }
        public static string ConvertDataTableToHTML(DataTable dt)
        {
            string html = "";
            if (dt.Rows.Count > 0)
            {
                html = "<table style='font - size: 12px; width: 480px; text - align: left; border - collapse: collapse; margin: 20px; ' summary='Meeting Results'>";
                //add header row
                html += "<tr style='display: table - row; '>";
                for (int i = 0; i < dt.Columns.Count; i++)
                    html += "<td style='color: #669; border: 1px solid #ddd; padding: 5px;font-weight: bold;'>" + dt.Columns[i].ColumnName + "</td>";
                html += "</tr>";
                //add rows
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    html += "<tr style='display: table - row; '>";
                    for (int j = 0; j < dt.Columns.Count; j++)
                        html += "<td style='color: #669; border: 1px solid #ddd; padding: 5px;font-weight: bold;'>" + dt.Columns[i].ColumnName + "</td>" + dt.Rows[i][j].ToString() + "</td>";
                    html += "</tr>";
                }
                html += "</table>";
            }
            return html;
        }
        public static void FunForPersonalDetailsUpdate(PersonalDetailsModel objPdModel, string name)
        {
            List<PersonalDetailsModel> objLstPdSummery = FunForPlGridSummery();
            List<PersonalDetailsModel> objLstPdNotUpdatedData = FunForPlGridSummery();
            List<PersonalDetailsModel> objLstPdUpdatedData = FunForPlGridSummery();
            objLstPdNotUpdatedData = objLstPdSummery.Where(l => l.Name != name).ToList();
            objLstPdUpdatedData = objLstPdSummery.Where(l => l.Name == name).Select(l => new PersonalDetailsModel
            {
                Id = objPdModel.Id,
                Name = objPdModel.Name,
                Address = objPdModel.Address,
                FatherName = objPdModel.FatherName,
                EmailID = objPdModel.EmailID,
                PhoneNumber = objPdModel.PhoneNumber,
                Status = objPdModel.Status
            }).ToList();
            objLstPdSummery = objLstPdNotUpdatedData.Concat(objLstPdUpdatedData).ToList();
            ListOfXmlFilName.objPdXmlPath.FunForWriteXML(objLstPdSummery);
        }

        public static List<FineDetails> FunForFdFineDetails(string name, string fineDate)
        {
            List<FineDetails> objLstFdSummery = new List<FineDetails>();
            DataTable objDsFdSummery = ListOfXmlFilName.objFdXmlPath.FunForReadXMl();
            if (objDsFdSummery != null && objDsFdSummery.Rows.Count > 0)
            {
                objLstFdSummery = objDsFdSummery.FunForDataTableToList<FineDetails>().ToList().Where(w => w.Name == name && Convert.ToDateTime(w.FineDate) == Convert.ToDateTime(fineDate)).ToList();
            }
            return objLstFdSummery;
        }
        public static List<FineDetails> FunForFdFineDetails()
        {
            List<FineDetails> objLstFdSummery = new List<FineDetails>();
            DataTable objDsFdSummery = ListOfXmlFilName.objFdXmlPath.FunForReadXMl();
            if (objDsFdSummery != null && objDsFdSummery.Rows.Count > 0)
            {
                objLstFdSummery = objDsFdSummery.FunForDataTableToList<FineDetails>().ToList().ToList();
            }
            return objLstFdSummery;
        }
        public static DataTable FunForDtFdFineDetails(string fineDate)
        {
            List<FineDetails> obj = new List<FineDetails>();
            obj = FunForFdFineDetails(fineDate);
            DataTable objDt = CommonMethod.ToDataTable(obj);
            return objDt;
        }
        public static List<FineDetails> FunForFdFineDetails(string fineDate)
        {
            List<PersonalDetailsModel> objPdActiveUser = FunForPdActiveUser();
            List<FineDetails> objLstFdSummery = new List<FineDetails>();
            List<FineDetails> objLstFd = new List<FineDetails>();
            DataTable objDsFdSummery = ListOfXmlFilName.objFdXmlPath.FunForReadXMl();
            if (objDsFdSummery != null && objDsFdSummery.Rows.Count > 0)
            {
                objLstFd = objDsFdSummery.FunForDataTableToList<FineDetails>().ToList().Where(w => Convert.ToDateTime(w.FineDate) == Convert.ToDateTime(fineDate)).ToList();
            }
            int id = 1;
            foreach (var item in objPdActiveUser)
            {

                List<FineDetails> objLstFdFilter = objLstFd.Where(w => w.Name == Convert.ToString(item.Name)).ToList();
                if (objLstFdFilter.Count == 1)
                {
                    objLstFdSummery.Add(new FineDetails()
                    {
                        Id = id,
                        FineAmount = objLstFdFilter.FirstOrDefault().FineAmount,
                        FineDate = Convert.ToDateTime(objLstFdFilter.FirstOrDefault().FineDate.ToString("dd/MMM/yyyy")),
                        Name = objLstFdFilter.FirstOrDefault().Name,
                        Query = objLstFdFilter.FirstOrDefault().Query,
                    });
                }
                else
                {
                    objLstFdSummery.Add(new FineDetails()
                    {
                        Id = id,
                        FineAmount = "0",
                        FineDate = Convert.ToDateTime(DateTime.Now.ToString("dd/MMM/yyyy")),
                        Name = item.Name,
                        Query = "",
                    });
                }
                id++;
            }

            return objLstFdSummery;
        }
        public static void FunForFineDetailsUpdate(FineDetails objPdModel)
        {
            List<FineDetails> objLstFdSummery = FunForFdFineDetails();
            List<FineDetails> objLstFdNotUpdatedData = objLstFdSummery.Where(w => w.Name == objPdModel.Name && Convert.ToDateTime(w.FineDate) == Convert.ToDateTime(objPdModel.FineDate)).ToList();
            if (objLstFdNotUpdatedData.Count > 0)
            {
                List<FineDetails> objLstFdUpdatedData = objLstFdSummery.Where(w => w.Id != objLstFdNotUpdatedData.FirstOrDefault().Id).ToList();
                objLstFdNotUpdatedData = objLstFdNotUpdatedData.Select(l => new FineDetails
                {
                    Id = objPdModel.Id,
                    Name = objPdModel.Name,
                    FineDate = objPdModel.FineDate,
                    FineAmount = objPdModel.FineAmount,
                    Query = objPdModel.Query
                }).ToList();
                objLstFdSummery = objLstFdNotUpdatedData.Concat(objLstFdUpdatedData).ToList();
            }
            else
            {
                long objId = 1;
                if (objLstFdSummery.Count > 0)
                {
                    objId = objLstFdSummery.Max(m => m.Id) + 1;
                }
                objPdModel.Id = objId;
                objLstFdSummery.Add(objPdModel);
            }
            ListOfXmlFilName.objFdXmlPath.FunForWriteXML(objLstFdSummery);
        }

        public static List<FineDetails> FunForReportSummery(string objFromDate, string objToDate, string objUserName)
        {
            List<FineDetails> objLstFdSummery = new List<FineDetails>();
            DataTable objDsFdSummery = ListOfXmlFilName.objFdXmlPath.FunForReadXMl();
            if (objDsFdSummery != null && objDsFdSummery.Rows.Count > 0)
            {
                if (objUserName != "")
                {
                    objLstFdSummery = objDsFdSummery.FunForDataTableToList<FineDetails>().ToList().Where(w => (w.FineDate >= Convert.ToDateTime(objFromDate) && w.FineDate <= Convert.ToDateTime(objToDate)) && w.Name == objUserName).ToList();
                }
                else
                {
                    objLstFdSummery = objDsFdSummery.FunForDataTableToList<FineDetails>().ToList().Where(w => (w.FineDate >= Convert.ToDateTime(objFromDate) && w.FineDate <= Convert.ToDateTime(objToDate))).ToList();
                }

            }
            return objLstFdSummery;
        }
        public static DataTable FunForDtReportCalCulation(string objFromDate, string objToDate)
        {
            List<ReportViewModel> obj = new List<ReportViewModel>();
            obj = FunForReportCalCulation(objFromDate, objToDate);
            return CommonMethod.ToDataTable(obj);
        }
        public static void FunForMailSending( string objSubject, string objBodyHtmlContent)
        {
            try
            {
                DataTable objDtToMailID = new DataTable();
                MailMessage objMailMsg;
                objMailMsg = new MailMessage();
                objMailMsg.From = new MailAddress("automail@tvscs.co.in");
                objMailMsg.Bcc.Add("ananth.g@kaspontech.com");
                objMailMsg.Bcc.Add("chandrasekar.s@tvscs.co.in");
                objMailMsg.To.Add("sridhar.sv@tvscs.co.in");

                objMailMsg.Subject = objSubject;
                objMailMsg.Body = objBodyHtmlContent;
                objMailMsg.IsBodyHtml = true;
                SmtpClient objSmtpClient = new SmtpClient();
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = new
System.Net.NetworkCredential("ananth.g1992@gmail.com", "ana");
                
               // objSmtpClient.Host = objAutomailURL;
                //objSmtpClient.Port = Convert.ToInt32(objAutomailPort);
                objSmtpClient.UseDefaultCredentials = false;
                objSmtpClient.Send(objMailMsg);
                objMailMsg.Dispose();
            }
            catch (Exception ex)
            {
            }
        }

        public static List<ReportViewModel> FunForReportCalCulation(string objFromDate, string objToDate)
        {
            List<PersonalDetailsModel> objPdActiveUser = FunForPdActiveUser();
            List<ReportViewModel> objLstFdSummery = new List<ReportViewModel>();
            List<FineDetails> objLstFd = new List<FineDetails>();
            DataTable objDsFdSummery = ListOfXmlFilName.objFdXmlPath.FunForReadXMl();
            if (objDsFdSummery != null && objDsFdSummery.Rows.Count > 0)
            {
                objLstFd = objDsFdSummery.FunForDataTableToList<FineDetails>().ToList().Where(w => (w.FineDate >= Convert.ToDateTime(objFromDate) && w.FineDate <= Convert.ToDateTime(objToDate))).ToList();
            }
            int id = 1;
            foreach (var item in objPdActiveUser)
            {

                List<FineDetails> objLstFdFilter = objLstFd.Where(w => w.Name == Convert.ToString(item.Name)).ToList();
                if (objLstFdFilter.Count > 0)
                {
                    objLstFdSummery.Add(new ReportViewModel()
                    {
                        Id = id,
                        FineAmount = objLstFdFilter.Sum(s => Convert.ToInt64(s.FineAmount)).ToString(),
                        Name = objLstFdFilter.FirstOrDefault().Name,
                        FineDate = objFromDate + " - " + objToDate
                    });
                }
                else
                {
                    objLstFdSummery.Add(new ReportViewModel()
                    {
                        Id = id,
                        FineAmount = "0",
                        Name = item.Name,
                        FineDate = objFromDate + " - " + objToDate
                    });
                }
                id++;
            }

            return objLstFdSummery;

        }
    }
}
