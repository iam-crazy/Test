﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMS.Bussiness
{
    public static class ListOfXmlFilName
    {
        public static string objBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        public static string objPdXmlPath = objBaseDirectory + "\\Data\\PersonalDetails.Xml";
        public static string objFdXmlPath = objBaseDirectory + "\\Data\\FineDetails.Xml";
        public static string objRsXmlPath = objBaseDirectory + "\\Data\\MailSendingDetails.Xml";
    }
}
