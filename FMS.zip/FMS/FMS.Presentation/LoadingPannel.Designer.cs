﻿namespace FMS.Presentation
{
    partial class LoadingPannel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbLoading = new System.Windows.Forms.PictureBox();
            this.lblPlsWait = new MetroFramework.Controls.MetroLabel();
            this.metroProgressSpinner3 = new MetroFramework.Controls.MetroProgressSpinner();
            ((System.ComponentModel.ISupportInitialize)(this.pbLoading)).BeginInit();
            this.SuspendLayout();
            // 
            // pbLoading
            // 
            this.pbLoading.BackColor = System.Drawing.Color.Transparent;
            this.pbLoading.Image = global::FMS.Presentation.Properties.Resources._301;
            this.pbLoading.Location = new System.Drawing.Point(1, -1);
            this.pbLoading.Name = "pbLoading";
            this.pbLoading.Size = new System.Drawing.Size(170, 166);
            this.pbLoading.TabIndex = 0;
            this.pbLoading.TabStop = false;
            // 
            // lblPlsWait
            // 
            this.lblPlsWait.AutoSize = true;
            this.lblPlsWait.BackColor = System.Drawing.Color.Transparent;
            this.lblPlsWait.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblPlsWait.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(174)))), ((int)(((byte)(220)))));
            this.lblPlsWait.Location = new System.Drawing.Point(29, 67);
            this.lblPlsWait.Name = "lblPlsWait";
            this.lblPlsWait.Size = new System.Drawing.Size(94, 19);
            this.lblPlsWait.TabIndex = 2;
            this.lblPlsWait.Text = "Please Wait..";
            this.lblPlsWait.UseCustomBackColor = true;
            this.lblPlsWait.UseCustomForeColor = true;
            // 
            // metroProgressSpinner3
            // 
            this.metroProgressSpinner3.Location = new System.Drawing.Point(1, -1);
            this.metroProgressSpinner3.Maximum = 100;
            this.metroProgressSpinner3.Name = "metroProgressSpinner3";
            this.metroProgressSpinner3.Size = new System.Drawing.Size(170, 166);
            this.metroProgressSpinner3.TabIndex = 12;
            this.metroProgressSpinner3.UseSelectable = true;
            this.metroProgressSpinner3.Value = 50;
            // 
            // LoadingPannel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(173, 167);
            this.Controls.Add(this.metroProgressSpinner3);
            this.Controls.Add(this.lblPlsWait);
            this.Controls.Add(this.pbLoading);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoadingPannel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LoadingPannel";
            ((System.ComponentModel.ISupportInitialize)(this.pbLoading)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbLoading;
        private MetroFramework.Controls.MetroLabel lblPlsWait;
        private MetroFramework.Controls.MetroProgressSpinner metroProgressSpinner3;
    }
}