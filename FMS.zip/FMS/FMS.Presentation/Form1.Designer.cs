﻿namespace FMS.Presentation
{

    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.mtc = new MetroFramework.Controls.MetroTabControl();
            this.mtpPersonalDetails = new MetroFramework.Controls.MetroTabPage();
            this.mtc2 = new MetroFramework.Controls.MetroTabControl();
            this.mtpSummery = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.grdPdSummery = new MetroFramework.Controls.MetroGrid();
            this.mtpAddPr = new MetroFramework.Controls.MetroTabPage();
            this.cbAddActive = new MetroFramework.Controls.MetroCheckBox();
            this.lblAddCno = new System.Windows.Forms.Label();
            this.txtAddName = new System.Windows.Forms.TextBox();
            this.lblAddAddress = new System.Windows.Forms.Label();
            this.lblAddName = new System.Windows.Forms.Label();
            this.lblAddFName = new System.Windows.Forms.Label();
            this.btnAddPr = new MetroFramework.Controls.MetroTile();
            this.txtAddEmail = new System.Windows.Forms.TextBox();
            this.txtAddAddress = new System.Windows.Forms.TextBox();
            this.txtAddFName = new System.Windows.Forms.TextBox();
            this.txtAddCNo = new System.Windows.Forms.MaskedTextBox();
            this.lblAddEmailID = new System.Windows.Forms.Label();
            this.mtpEditpr = new MetroFramework.Controls.MetroTabPage();
            this.cbEditName = new MetroFramework.Controls.MetroComboBox();
            this.pnlplEdit = new MetroFramework.Controls.MetroPanel();
            this.lblPdEditId = new System.Windows.Forms.Label();
            this.cbEditActive = new MetroFramework.Controls.MetroCheckBox();
            this.lblEditCno = new System.Windows.Forms.Label();
            this.lblEditAddress = new System.Windows.Forms.Label();
            this.lblEditFName = new System.Windows.Forms.Label();
            this.txtEditEmail = new System.Windows.Forms.TextBox();
            this.txtEditAddress = new System.Windows.Forms.TextBox();
            this.txtEditFName = new System.Windows.Forms.TextBox();
            this.txtEditCNo = new System.Windows.Forms.MaskedTextBox();
            this.lblEditEmailID = new System.Windows.Forms.Label();
            this.btnUpdate = new MetroFramework.Controls.MetroTile();
            this.lblEditName = new System.Windows.Forms.Label();
            this.mtpFineDetails = new MetroFramework.Controls.MetroTabPage();
            this.mtcPe = new MetroFramework.Controls.MetroTabControl();
            this.mtpItemDetails = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.grdFineSummary = new MetroFramework.Controls.MetroGrid();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.lblFdId = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFdTotalAmt = new System.Windows.Forms.TextBox();
            this.txtFdPerviousAmt = new System.Windows.Forms.TextBox();
            this.cbFdName = new MetroFramework.Controls.MetroComboBox();
            this.txtfdDate = new System.Windows.Forms.DateTimePicker();
            this.btnAddPurchasedDetails = new MetroFramework.Controls.MetroTile();
            this.lblFdName = new System.Windows.Forms.Label();
            this.lblFdDate = new System.Windows.Forms.Label();
            this.txtFdQuery = new System.Windows.Forms.TextBox();
            this.lblFdAmt = new System.Windows.Forms.Label();
            this.txtFdAmt = new System.Windows.Forms.TextBox();
            this.lblFdQuery = new System.Windows.Forms.Label();
            this.lblKey = new System.Windows.Forms.Label();
            this.mtpReport = new MetroFramework.Controls.MetroTabPage();
            this.mtcReport = new MetroFramework.Controls.MetroTabControl();
            this.mtpReportSummery = new MetroFramework.Controls.MetroTabPage();
            this.cbRUserName = new MetroFramework.Controls.MetroComboBox();
            this.btnReportSmry = new MetroFramework.Controls.MetroTile();
            this.lblToDate = new System.Windows.Forms.Label();
            this.lblFromDate = new System.Windows.Forms.Label();
            this.dtToDateRSmry = new System.Windows.Forms.DateTimePicker();
            this.dtFromDateRSmry = new System.Windows.Forms.DateTimePicker();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.grdRSummery = new MetroFramework.Controls.MetroGrid();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.cmbRmth = new MetroFramework.Controls.MetroComboBox();
            this.cmbRYear = new MetroFramework.Controls.MetroComboBox();
            this.pnlRcal = new MetroFramework.Controls.MetroPanel();
            this.grdRCal = new MetroFramework.Controls.MetroGrid();
            this.btnRCal = new MetroFramework.Controls.MetroTile();
            this.lblMonth = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.txtRsSubject = new System.Windows.Forms.TextBox();
            this.txtRsQuery = new System.Windows.Forms.TextBox();
            this.dtRsDate = new System.Windows.Forms.DateTimePicker();
            this.lblRsDescription = new System.Windows.Forms.Label();
            this.lblRsSubject = new System.Windows.Forms.Label();
            this.lblRsDate = new System.Windows.Forms.Label();
            this.lblTitle = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mtc.SuspendLayout();
            this.mtpPersonalDetails.SuspendLayout();
            this.mtc2.SuspendLayout();
            this.mtpSummery.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdPdSummery)).BeginInit();
            this.mtpAddPr.SuspendLayout();
            this.mtpEditpr.SuspendLayout();
            this.pnlplEdit.SuspendLayout();
            this.mtpFineDetails.SuspendLayout();
            this.mtcPe.SuspendLayout();
            this.mtpItemDetails.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdFineSummary)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            this.mtpReport.SuspendLayout();
            this.mtcReport.SuspendLayout();
            this.mtpReportSummery.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdRSummery)).BeginInit();
            this.metroTabPage1.SuspendLayout();
            this.pnlRcal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdRCal)).BeginInit();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mtc
            // 
            this.mtc.Controls.Add(this.mtpPersonalDetails);
            this.mtc.Controls.Add(this.mtpFineDetails);
            this.mtc.Controls.Add(this.mtpReport);
            this.mtc.FontWeight = MetroFramework.MetroTabControlWeight.Bold;
            this.mtc.HotTrack = true;
            this.mtc.Location = new System.Drawing.Point(4, 37);
            this.mtc.Name = "mtc";
            this.mtc.SelectedIndex = 2;
            this.mtc.Size = new System.Drawing.Size(772, 381);
            this.mtc.Style = MetroFramework.MetroColorStyle.Blue;
            this.mtc.TabIndex = 0;
            this.mtc.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtc.UseSelectable = true;
            // 
            // mtpPersonalDetails
            // 
            this.mtpPersonalDetails.BackColor = System.Drawing.Color.Transparent;
            this.mtpPersonalDetails.Controls.Add(this.mtc2);
            this.mtpPersonalDetails.HorizontalScrollbarBarColor = true;
            this.mtpPersonalDetails.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpPersonalDetails.HorizontalScrollbarSize = 10;
            this.mtpPersonalDetails.Location = new System.Drawing.Point(4, 38);
            this.mtpPersonalDetails.Name = "mtpPersonalDetails";
            this.mtpPersonalDetails.Size = new System.Drawing.Size(764, 339);
            this.mtpPersonalDetails.TabIndex = 0;
            this.mtpPersonalDetails.Text = "Personal Details";
            this.mtpPersonalDetails.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpPersonalDetails.UseCustomBackColor = true;
            this.mtpPersonalDetails.VerticalScrollbarBarColor = true;
            this.mtpPersonalDetails.VerticalScrollbarHighlightOnWheel = false;
            this.mtpPersonalDetails.VerticalScrollbarSize = 10;
            // 
            // mtc2
            // 
            this.mtc2.Controls.Add(this.mtpSummery);
            this.mtc2.Controls.Add(this.mtpAddPr);
            this.mtc2.Controls.Add(this.mtpEditpr);
            this.mtc2.FontWeight = MetroFramework.MetroTabControlWeight.Bold;
            this.mtc2.HotTrack = true;
            this.mtc2.Location = new System.Drawing.Point(3, 2);
            this.mtc2.Name = "mtc2";
            this.mtc2.SelectedIndex = 1;
            this.mtc2.Size = new System.Drawing.Size(755, 336);
            this.mtc2.TabIndex = 3;
            this.mtc2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtc2.UseSelectable = true;
            // 
            // mtpSummery
            // 
            this.mtpSummery.Controls.Add(this.metroPanel2);
            this.mtpSummery.HorizontalScrollbarBarColor = true;
            this.mtpSummery.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpSummery.HorizontalScrollbarSize = 10;
            this.mtpSummery.Location = new System.Drawing.Point(4, 38);
            this.mtpSummery.Name = "mtpSummery";
            this.mtpSummery.Size = new System.Drawing.Size(747, 294);
            this.mtpSummery.TabIndex = 0;
            this.mtpSummery.Text = "Summery";
            this.mtpSummery.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpSummery.VerticalScrollbarBarColor = true;
            this.mtpSummery.VerticalScrollbarHighlightOnWheel = false;
            this.mtpSummery.VerticalScrollbarSize = 10;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.grdPdSummery);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(8, 3);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(731, 288);
            this.metroPanel2.TabIndex = 4;
            this.metroPanel2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // grdPdSummery
            // 
            this.grdPdSummery.AllowUserToAddRows = false;
            this.grdPdSummery.AllowUserToDeleteRows = false;
            this.grdPdSummery.AllowUserToResizeRows = false;
            this.grdPdSummery.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grdPdSummery.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdPdSummery.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grdPdSummery.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grdPdSummery.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdPdSummery.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdPdSummery.ColumnHeadersHeight = 30;
            this.grdPdSummery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdPdSummery.DefaultCellStyle = dataGridViewCellStyle2;
            this.grdPdSummery.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdPdSummery.EnableHeadersVisualStyles = false;
            this.grdPdSummery.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grdPdSummery.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdPdSummery.Location = new System.Drawing.Point(0, 0);
            this.grdPdSummery.Name = "grdPdSummery";
            this.grdPdSummery.ReadOnly = true;
            this.grdPdSummery.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdPdSummery.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grdPdSummery.RowHeadersVisible = false;
            this.grdPdSummery.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.grdPdSummery.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.grdPdSummery.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdPdSummery.Size = new System.Drawing.Size(731, 288);
            this.grdPdSummery.TabIndex = 2;
            this.grdPdSummery.Theme = MetroFramework.MetroThemeStyle.Light;
            this.grdPdSummery.UseCustomBackColor = true;
            this.grdPdSummery.UseCustomForeColor = true;
            this.grdPdSummery.UseStyleColors = true;
            // 
            // mtpAddPr
            // 
            this.mtpAddPr.Controls.Add(this.cbAddActive);
            this.mtpAddPr.Controls.Add(this.lblAddCno);
            this.mtpAddPr.Controls.Add(this.txtAddName);
            this.mtpAddPr.Controls.Add(this.lblAddAddress);
            this.mtpAddPr.Controls.Add(this.lblAddName);
            this.mtpAddPr.Controls.Add(this.lblAddFName);
            this.mtpAddPr.Controls.Add(this.btnAddPr);
            this.mtpAddPr.Controls.Add(this.txtAddEmail);
            this.mtpAddPr.Controls.Add(this.txtAddAddress);
            this.mtpAddPr.Controls.Add(this.txtAddFName);
            this.mtpAddPr.Controls.Add(this.txtAddCNo);
            this.mtpAddPr.Controls.Add(this.lblAddEmailID);
            this.mtpAddPr.HorizontalScrollbarBarColor = true;
            this.mtpAddPr.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpAddPr.HorizontalScrollbarSize = 10;
            this.mtpAddPr.Location = new System.Drawing.Point(4, 38);
            this.mtpAddPr.Name = "mtpAddPr";
            this.mtpAddPr.Size = new System.Drawing.Size(747, 294);
            this.mtpAddPr.TabIndex = 1;
            this.mtpAddPr.Text = "Add Personal Details";
            this.mtpAddPr.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpAddPr.VerticalScrollbarBarColor = true;
            this.mtpAddPr.VerticalScrollbarHighlightOnWheel = false;
            this.mtpAddPr.VerticalScrollbarSize = 10;
            // 
            // cbAddActive
            // 
            this.cbAddActive.AutoSize = true;
            this.cbAddActive.Checked = true;
            this.cbAddActive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAddActive.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.cbAddActive.FontWeight = MetroFramework.MetroCheckBoxWeight.Bold;
            this.cbAddActive.Location = new System.Drawing.Point(331, 263);
            this.cbAddActive.Name = "cbAddActive";
            this.cbAddActive.Size = new System.Drawing.Size(67, 19);
            this.cbAddActive.TabIndex = 11;
            this.cbAddActive.Text = "Active";
            this.cbAddActive.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbAddActive.UseCustomForeColor = true;
            this.cbAddActive.UseSelectable = true;
            this.cbAddActive.CheckedChanged += new System.EventHandler(this.cbAddActive_CheckedChanged);
            // 
            // lblAddCno
            // 
            this.lblAddCno.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAddCno.AutoSize = true;
            this.lblAddCno.BackColor = System.Drawing.Color.Transparent;
            this.lblAddCno.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCno.ForeColor = System.Drawing.Color.Black;
            this.lblAddCno.Location = new System.Drawing.Point(180, 176);
            this.lblAddCno.Name = "lblAddCno";
            this.lblAddCno.Size = new System.Drawing.Size(80, 18);
            this.lblAddCno.TabIndex = 139;
            this.lblAddCno.Text = "Contact No.";
            // 
            // txtAddName
            // 
            this.txtAddName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAddName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtAddName.Location = new System.Drawing.Point(331, 13);
            this.txtAddName.Name = "txtAddName";
            this.txtAddName.Size = new System.Drawing.Size(240, 25);
            this.txtAddName.TabIndex = 4;
            this.txtAddName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidateAlphabet_KeyPress);
            // 
            // lblAddAddress
            // 
            this.lblAddAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAddAddress.AutoSize = true;
            this.lblAddAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddAddress.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddAddress.ForeColor = System.Drawing.Color.Black;
            this.lblAddAddress.Location = new System.Drawing.Point(180, 112);
            this.lblAddAddress.Name = "lblAddAddress";
            this.lblAddAddress.Size = new System.Drawing.Size(58, 18);
            this.lblAddAddress.TabIndex = 133;
            this.lblAddAddress.Text = "Address";
            // 
            // lblAddName
            // 
            this.lblAddName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAddName.AutoSize = true;
            this.lblAddName.BackColor = System.Drawing.Color.Transparent;
            this.lblAddName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddName.ForeColor = System.Drawing.Color.Black;
            this.lblAddName.Location = new System.Drawing.Point(180, 20);
            this.lblAddName.Name = "lblAddName";
            this.lblAddName.Size = new System.Drawing.Size(45, 18);
            this.lblAddName.TabIndex = 130;
            this.lblAddName.Text = "Name";
            // 
            // lblAddFName
            // 
            this.lblAddFName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAddFName.AutoSize = true;
            this.lblAddFName.BackColor = System.Drawing.Color.Transparent;
            this.lblAddFName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddFName.ForeColor = System.Drawing.Color.Black;
            this.lblAddFName.Location = new System.Drawing.Point(178, 57);
            this.lblAddFName.Name = "lblAddFName";
            this.lblAddFName.Size = new System.Drawing.Size(96, 18);
            this.lblAddFName.TabIndex = 127;
            this.lblAddFName.Text = "Father\'s Name";
            // 
            // btnAddPr
            // 
            this.btnAddPr.ActiveControl = null;
            this.btnAddPr.Location = new System.Drawing.Point(444, 254);
            this.btnAddPr.Name = "btnAddPr";
            this.btnAddPr.Size = new System.Drawing.Size(127, 37);
            this.btnAddPr.TabIndex = 12;
            this.btnAddPr.Text = "Add";
            this.btnAddPr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddPr.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnAddPr.UseSelectable = true;
            this.btnAddPr.Click += new System.EventHandler(this.btnAddPr_Click);
            // 
            // txtAddEmail
            // 
            this.txtAddEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAddEmail.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtAddEmail.Location = new System.Drawing.Point(331, 209);
            this.txtAddEmail.Multiline = true;
            this.txtAddEmail.Name = "txtAddEmail";
            this.txtAddEmail.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAddEmail.Size = new System.Drawing.Size(240, 25);
            this.txtAddEmail.TabIndex = 10;
            // 
            // txtAddAddress
            // 
            this.txtAddAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAddAddress.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtAddAddress.Location = new System.Drawing.Point(331, 88);
            this.txtAddAddress.Multiline = true;
            this.txtAddAddress.Name = "txtAddAddress";
            this.txtAddAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAddAddress.Size = new System.Drawing.Size(240, 68);
            this.txtAddAddress.TabIndex = 8;
            this.txtAddAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBlockSplChar_KeyPress);
            // 
            // txtAddFName
            // 
            this.txtAddFName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAddFName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtAddFName.Location = new System.Drawing.Point(331, 50);
            this.txtAddFName.Name = "txtAddFName";
            this.txtAddFName.Size = new System.Drawing.Size(240, 25);
            this.txtAddFName.TabIndex = 6;
            this.txtAddFName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidateAlphabet_KeyPress);
            // 
            // txtAddCNo
            // 
            this.txtAddCNo.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtAddCNo.Location = new System.Drawing.Point(331, 169);
            this.txtAddCNo.Name = "txtAddCNo";
            this.txtAddCNo.Size = new System.Drawing.Size(240, 25);
            this.txtAddCNo.TabIndex = 9;
            this.txtAddCNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidateNum_KeyPress);
            // 
            // lblAddEmailID
            // 
            this.lblAddEmailID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAddEmailID.AutoSize = true;
            this.lblAddEmailID.BackColor = System.Drawing.Color.Transparent;
            this.lblAddEmailID.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEmailID.Location = new System.Drawing.Point(180, 216);
            this.lblAddEmailID.Name = "lblAddEmailID";
            this.lblAddEmailID.Size = new System.Drawing.Size(43, 18);
            this.lblAddEmailID.TabIndex = 136;
            this.lblAddEmailID.Text = "Email";
            // 
            // mtpEditpr
            // 
            this.mtpEditpr.Controls.Add(this.cbEditName);
            this.mtpEditpr.Controls.Add(this.pnlplEdit);
            this.mtpEditpr.Controls.Add(this.lblEditName);
            this.mtpEditpr.HorizontalScrollbarBarColor = true;
            this.mtpEditpr.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpEditpr.HorizontalScrollbarSize = 10;
            this.mtpEditpr.Location = new System.Drawing.Point(4, 38);
            this.mtpEditpr.Name = "mtpEditpr";
            this.mtpEditpr.Size = new System.Drawing.Size(747, 294);
            this.mtpEditpr.TabIndex = 2;
            this.mtpEditpr.Text = "Edit Personal Details";
            this.mtpEditpr.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpEditpr.VerticalScrollbarBarColor = true;
            this.mtpEditpr.VerticalScrollbarHighlightOnWheel = false;
            this.mtpEditpr.VerticalScrollbarSize = 10;
            // 
            // cbEditName
            // 
            this.cbEditName.AllowDrop = true;
            this.cbEditName.FormattingEnabled = true;
            this.cbEditName.ItemHeight = 23;
            this.cbEditName.Location = new System.Drawing.Point(331, 13);
            this.cbEditName.Name = "cbEditName";
            this.cbEditName.PromptText = "Select User Name";
            this.cbEditName.Size = new System.Drawing.Size(240, 29);
            this.cbEditName.TabIndex = 13;
            this.cbEditName.UseSelectable = true;
            this.cbEditName.SelectedIndexChanged += new System.EventHandler(this.cbEditName_SelectedIndexChanged);
            // 
            // pnlplEdit
            // 
            this.pnlplEdit.Controls.Add(this.lblPdEditId);
            this.pnlplEdit.Controls.Add(this.cbEditActive);
            this.pnlplEdit.Controls.Add(this.lblEditCno);
            this.pnlplEdit.Controls.Add(this.lblEditAddress);
            this.pnlplEdit.Controls.Add(this.lblEditFName);
            this.pnlplEdit.Controls.Add(this.txtEditEmail);
            this.pnlplEdit.Controls.Add(this.txtEditAddress);
            this.pnlplEdit.Controls.Add(this.txtEditFName);
            this.pnlplEdit.Controls.Add(this.txtEditCNo);
            this.pnlplEdit.Controls.Add(this.lblEditEmailID);
            this.pnlplEdit.Controls.Add(this.btnUpdate);
            this.pnlplEdit.HorizontalScrollbarBarColor = true;
            this.pnlplEdit.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlplEdit.HorizontalScrollbarSize = 10;
            this.pnlplEdit.Location = new System.Drawing.Point(75, 43);
            this.pnlplEdit.Name = "pnlplEdit";
            this.pnlplEdit.Size = new System.Drawing.Size(595, 254);
            this.pnlplEdit.TabIndex = 155;
            this.pnlplEdit.Theme = MetroFramework.MetroThemeStyle.Light;
            this.pnlplEdit.VerticalScrollbarBarColor = true;
            this.pnlplEdit.VerticalScrollbarHighlightOnWheel = false;
            this.pnlplEdit.VerticalScrollbarSize = 10;
            // 
            // lblPdEditId
            // 
            this.lblPdEditId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPdEditId.AutoSize = true;
            this.lblPdEditId.BackColor = System.Drawing.Color.Transparent;
            this.lblPdEditId.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdEditId.ForeColor = System.Drawing.Color.Black;
            this.lblPdEditId.Location = new System.Drawing.Point(512, 10);
            this.lblPdEditId.Name = "lblPdEditId";
            this.lblPdEditId.Size = new System.Drawing.Size(0, 18);
            this.lblPdEditId.TabIndex = 177;
            this.lblPdEditId.Visible = false;
            // 
            // cbEditActive
            // 
            this.cbEditActive.AutoSize = true;
            this.cbEditActive.Checked = true;
            this.cbEditActive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbEditActive.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.cbEditActive.FontWeight = MetroFramework.MetroCheckBoxWeight.Bold;
            this.cbEditActive.Location = new System.Drawing.Point(256, 220);
            this.cbEditActive.Name = "cbEditActive";
            this.cbEditActive.Size = new System.Drawing.Size(67, 19);
            this.cbEditActive.TabIndex = 20;
            this.cbEditActive.Text = "Active";
            this.cbEditActive.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbEditActive.UseCustomForeColor = true;
            this.cbEditActive.UseSelectable = true;
            this.cbEditActive.CheckedChanged += new System.EventHandler(this.cbEditActive_CheckedChanged);
            // 
            // lblEditCno
            // 
            this.lblEditCno.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEditCno.AutoSize = true;
            this.lblEditCno.BackColor = System.Drawing.Color.Transparent;
            this.lblEditCno.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCno.ForeColor = System.Drawing.Color.Black;
            this.lblEditCno.Location = new System.Drawing.Point(105, 133);
            this.lblEditCno.Name = "lblEditCno";
            this.lblEditCno.Size = new System.Drawing.Size(80, 18);
            this.lblEditCno.TabIndex = 176;
            this.lblEditCno.Text = "Contact No.";
            // 
            // lblEditAddress
            // 
            this.lblEditAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEditAddress.AutoSize = true;
            this.lblEditAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblEditAddress.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditAddress.ForeColor = System.Drawing.Color.Black;
            this.lblEditAddress.Location = new System.Drawing.Point(105, 69);
            this.lblEditAddress.Name = "lblEditAddress";
            this.lblEditAddress.Size = new System.Drawing.Size(58, 18);
            this.lblEditAddress.TabIndex = 171;
            this.lblEditAddress.Text = "Address";
            // 
            // lblEditFName
            // 
            this.lblEditFName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEditFName.AutoSize = true;
            this.lblEditFName.BackColor = System.Drawing.Color.Transparent;
            this.lblEditFName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditFName.ForeColor = System.Drawing.Color.Black;
            this.lblEditFName.Location = new System.Drawing.Point(103, 14);
            this.lblEditFName.Name = "lblEditFName";
            this.lblEditFName.Size = new System.Drawing.Size(96, 18);
            this.lblEditFName.TabIndex = 167;
            this.lblEditFName.Text = "Father\'s Name";
            // 
            // txtEditEmail
            // 
            this.txtEditEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEditEmail.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtEditEmail.Location = new System.Drawing.Point(256, 166);
            this.txtEditEmail.Multiline = true;
            this.txtEditEmail.Name = "txtEditEmail";
            this.txtEditEmail.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEditEmail.Size = new System.Drawing.Size(240, 25);
            this.txtEditEmail.TabIndex = 19;
            // 
            // txtEditAddress
            // 
            this.txtEditAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEditAddress.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtEditAddress.Location = new System.Drawing.Point(256, 45);
            this.txtEditAddress.Multiline = true;
            this.txtEditAddress.Name = "txtEditAddress";
            this.txtEditAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEditAddress.Size = new System.Drawing.Size(240, 68);
            this.txtEditAddress.TabIndex = 17;
            this.txtEditAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBlockSplChar_KeyPress);
            // 
            // txtEditFName
            // 
            this.txtEditFName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEditFName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtEditFName.Location = new System.Drawing.Point(256, 7);
            this.txtEditFName.Name = "txtEditFName";
            this.txtEditFName.Size = new System.Drawing.Size(240, 25);
            this.txtEditFName.TabIndex = 15;
            this.txtEditFName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidateAlphabet_KeyPress);
            // 
            // txtEditCNo
            // 
            this.txtEditCNo.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtEditCNo.Location = new System.Drawing.Point(256, 126);
            this.txtEditCNo.Mask = "0000000000";
            this.txtEditCNo.Name = "txtEditCNo";
            this.txtEditCNo.Size = new System.Drawing.Size(240, 25);
            this.txtEditCNo.TabIndex = 18;
            this.txtEditCNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidateNum_KeyPress);
            // 
            // lblEditEmailID
            // 
            this.lblEditEmailID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEditEmailID.AutoSize = true;
            this.lblEditEmailID.BackColor = System.Drawing.Color.Transparent;
            this.lblEditEmailID.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditEmailID.Location = new System.Drawing.Point(105, 173);
            this.lblEditEmailID.Name = "lblEditEmailID";
            this.lblEditEmailID.Size = new System.Drawing.Size(43, 18);
            this.lblEditEmailID.TabIndex = 174;
            this.lblEditEmailID.Text = "Email";
            // 
            // btnUpdate
            // 
            this.btnUpdate.ActiveControl = null;
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            this.btnUpdate.Location = new System.Drawing.Point(369, 211);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(127, 37);
            this.btnUpdate.TabIndex = 21;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdate.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnUpdate.UseSelectable = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblEditName
            // 
            this.lblEditName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEditName.AutoSize = true;
            this.lblEditName.BackColor = System.Drawing.Color.Transparent;
            this.lblEditName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditName.ForeColor = System.Drawing.Color.Black;
            this.lblEditName.Location = new System.Drawing.Point(180, 20);
            this.lblEditName.Name = "lblEditName";
            this.lblEditName.Size = new System.Drawing.Size(45, 18);
            this.lblEditName.TabIndex = 144;
            this.lblEditName.Text = "Name";
            // 
            // mtpFineDetails
            // 
            this.mtpFineDetails.BackColor = System.Drawing.Color.Transparent;
            this.mtpFineDetails.Controls.Add(this.mtcPe);
            this.mtpFineDetails.HorizontalScrollbarBarColor = true;
            this.mtpFineDetails.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpFineDetails.HorizontalScrollbarSize = 10;
            this.mtpFineDetails.Location = new System.Drawing.Point(4, 38);
            this.mtpFineDetails.Name = "mtpFineDetails";
            this.mtpFineDetails.Size = new System.Drawing.Size(764, 339);
            this.mtpFineDetails.TabIndex = 1;
            this.mtpFineDetails.Text = "Fine Details";
            this.mtpFineDetails.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpFineDetails.UseCustomBackColor = true;
            this.mtpFineDetails.VerticalScrollbarBarColor = true;
            this.mtpFineDetails.VerticalScrollbarHighlightOnWheel = false;
            this.mtpFineDetails.VerticalScrollbarSize = 10;
            // 
            // mtcPe
            // 
            this.mtcPe.Controls.Add(this.mtpItemDetails);
            this.mtcPe.Controls.Add(this.metroTabPage3);
            this.mtcPe.FontWeight = MetroFramework.MetroTabControlWeight.Bold;
            this.mtcPe.HotTrack = true;
            this.mtcPe.Location = new System.Drawing.Point(3, 1);
            this.mtcPe.Name = "mtcPe";
            this.mtcPe.SelectedIndex = 1;
            this.mtcPe.Size = new System.Drawing.Size(763, 342);
            this.mtcPe.TabIndex = 22;
            this.mtcPe.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtcPe.UseSelectable = true;
            // 
            // mtpItemDetails
            // 
            this.mtpItemDetails.Controls.Add(this.metroPanel3);
            this.mtpItemDetails.HorizontalScrollbarBarColor = true;
            this.mtpItemDetails.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpItemDetails.HorizontalScrollbarSize = 10;
            this.mtpItemDetails.Location = new System.Drawing.Point(4, 38);
            this.mtpItemDetails.Name = "mtpItemDetails";
            this.mtpItemDetails.Size = new System.Drawing.Size(755, 300);
            this.mtpItemDetails.TabIndex = 1;
            this.mtpItemDetails.Text = "Today Fine Details";
            this.mtpItemDetails.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpItemDetails.VerticalScrollbarBarColor = true;
            this.mtpItemDetails.VerticalScrollbarHighlightOnWheel = false;
            this.mtpItemDetails.VerticalScrollbarSize = 10;
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.grdFineSummary);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(12, 6);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(731, 288);
            this.metroPanel3.TabIndex = 5;
            this.metroPanel3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // grdFineSummary
            // 
            this.grdFineSummary.AllowUserToAddRows = false;
            this.grdFineSummary.AllowUserToDeleteRows = false;
            this.grdFineSummary.AllowUserToResizeRows = false;
            this.grdFineSummary.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grdFineSummary.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdFineSummary.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdFineSummary.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grdFineSummary.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grdFineSummary.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdFineSummary.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.grdFineSummary.ColumnHeadersHeight = 30;
            this.grdFineSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdFineSummary.DefaultCellStyle = dataGridViewCellStyle6;
            this.grdFineSummary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdFineSummary.EnableHeadersVisualStyles = false;
            this.grdFineSummary.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grdFineSummary.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdFineSummary.Location = new System.Drawing.Point(0, 0);
            this.grdFineSummary.Name = "grdFineSummary";
            this.grdFineSummary.ReadOnly = true;
            this.grdFineSummary.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdFineSummary.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.grdFineSummary.RowHeadersVisible = false;
            this.grdFineSummary.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.grdFineSummary.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.grdFineSummary.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdFineSummary.Size = new System.Drawing.Size(731, 288);
            this.grdFineSummary.TabIndex = 2;
            this.grdFineSummary.Theme = MetroFramework.MetroThemeStyle.Light;
            this.grdFineSummary.UseCustomBackColor = true;
            this.grdFineSummary.UseCustomForeColor = true;
            this.grdFineSummary.UseStyleColors = true;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.lblFdId);
            this.metroTabPage3.Controls.Add(this.label2);
            this.metroTabPage3.Controls.Add(this.label1);
            this.metroTabPage3.Controls.Add(this.txtFdTotalAmt);
            this.metroTabPage3.Controls.Add(this.txtFdPerviousAmt);
            this.metroTabPage3.Controls.Add(this.cbFdName);
            this.metroTabPage3.Controls.Add(this.txtfdDate);
            this.metroTabPage3.Controls.Add(this.btnAddPurchasedDetails);
            this.metroTabPage3.Controls.Add(this.lblFdName);
            this.metroTabPage3.Controls.Add(this.lblFdDate);
            this.metroTabPage3.Controls.Add(this.txtFdQuery);
            this.metroTabPage3.Controls.Add(this.lblFdAmt);
            this.metroTabPage3.Controls.Add(this.txtFdAmt);
            this.metroTabPage3.Controls.Add(this.lblFdQuery);
            this.metroTabPage3.Controls.Add(this.lblKey);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(755, 300);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Add Fine Details";
            this.metroTabPage3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // lblFdId
            // 
            this.lblFdId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFdId.AutoSize = true;
            this.lblFdId.BackColor = System.Drawing.Color.Transparent;
            this.lblFdId.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFdId.ForeColor = System.Drawing.Color.Black;
            this.lblFdId.Location = new System.Drawing.Point(609, 31);
            this.lblFdId.Name = "lblFdId";
            this.lblFdId.Size = new System.Drawing.Size(0, 18);
            this.lblFdId.TabIndex = 195;
            this.lblFdId.Visible = false;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(495, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 18);
            this.label2.TabIndex = 194;
            this.label2.Text = "=";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(411, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 18);
            this.label1.TabIndex = 193;
            this.label1.Text = "+";
            // 
            // txtFdTotalAmt
            // 
            this.txtFdTotalAmt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFdTotalAmt.Enabled = false;
            this.txtFdTotalAmt.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtFdTotalAmt.Location = new System.Drawing.Point(512, 124);
            this.txtFdTotalAmt.Name = "txtFdTotalAmt";
            this.txtFdTotalAmt.Size = new System.Drawing.Size(69, 25);
            this.txtFdTotalAmt.TabIndex = 192;
            // 
            // txtFdPerviousAmt
            // 
            this.txtFdPerviousAmt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFdPerviousAmt.Enabled = false;
            this.txtFdPerviousAmt.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtFdPerviousAmt.Location = new System.Drawing.Point(426, 125);
            this.txtFdPerviousAmt.Name = "txtFdPerviousAmt";
            this.txtFdPerviousAmt.Size = new System.Drawing.Size(69, 25);
            this.txtFdPerviousAmt.TabIndex = 191;
            // 
            // cbFdName
            // 
            this.cbFdName.AllowDrop = true;
            this.cbFdName.FormattingEnabled = true;
            this.cbFdName.ItemHeight = 23;
            this.cbFdName.Location = new System.Drawing.Point(341, 31);
            this.cbFdName.Name = "cbFdName";
            this.cbFdName.PromptText = "Select User Name";
            this.cbFdName.Size = new System.Drawing.Size(240, 29);
            this.cbFdName.TabIndex = 190;
            this.cbFdName.UseSelectable = true;
            this.cbFdName.SelectedIndexChanged += new System.EventHandler(this.cbFdName_SelectedIndexChanged);
            // 
            // txtfdDate
            // 
            this.txtfdDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfdDate.Checked = false;
            this.txtfdDate.CustomFormat = "dd/MMM/yyyy";
            this.txtfdDate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtfdDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtfdDate.Location = new System.Drawing.Point(341, 82);
            this.txtfdDate.Name = "txtfdDate";
            this.txtfdDate.Size = new System.Drawing.Size(240, 25);
            this.txtfdDate.TabIndex = 182;
            this.txtfdDate.ValueChanged += new System.EventHandler(this.txtfdDate_ValueChanged);
            // 
            // btnAddPurchasedDetails
            // 
            this.btnAddPurchasedDetails.ActiveControl = null;
            this.btnAddPurchasedDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            this.btnAddPurchasedDetails.ForeColor = System.Drawing.Color.Black;
            this.btnAddPurchasedDetails.Location = new System.Drawing.Point(341, 232);
            this.btnAddPurchasedDetails.Name = "btnAddPurchasedDetails";
            this.btnAddPurchasedDetails.Size = new System.Drawing.Size(240, 37);
            this.btnAddPurchasedDetails.TabIndex = 185;
            this.btnAddPurchasedDetails.Text = "Add";
            this.btnAddPurchasedDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddPurchasedDetails.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnAddPurchasedDetails.UseCustomBackColor = true;
            this.btnAddPurchasedDetails.UseSelectable = true;
            this.btnAddPurchasedDetails.Click += new System.EventHandler(this.btnAddPurchasedDetails_Click);
            // 
            // lblFdName
            // 
            this.lblFdName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFdName.AutoSize = true;
            this.lblFdName.BackColor = System.Drawing.Color.Transparent;
            this.lblFdName.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFdName.ForeColor = System.Drawing.Color.Black;
            this.lblFdName.Location = new System.Drawing.Point(174, 42);
            this.lblFdName.Name = "lblFdName";
            this.lblFdName.Size = new System.Drawing.Size(48, 18);
            this.lblFdName.TabIndex = 186;
            this.lblFdName.Text = "Name ";
            // 
            // lblFdDate
            // 
            this.lblFdDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFdDate.AutoSize = true;
            this.lblFdDate.BackColor = System.Drawing.Color.Transparent;
            this.lblFdDate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFdDate.ForeColor = System.Drawing.Color.Black;
            this.lblFdDate.Location = new System.Drawing.Point(174, 86);
            this.lblFdDate.Name = "lblFdDate";
            this.lblFdDate.Size = new System.Drawing.Size(70, 18);
            this.lblFdDate.TabIndex = 187;
            this.lblFdDate.Text = "Fine Date ";
            // 
            // txtFdQuery
            // 
            this.txtFdQuery.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFdQuery.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtFdQuery.Location = new System.Drawing.Point(341, 171);
            this.txtFdQuery.Multiline = true;
            this.txtFdQuery.Name = "txtFdQuery";
            this.txtFdQuery.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFdQuery.Size = new System.Drawing.Size(240, 36);
            this.txtFdQuery.TabIndex = 184;
            this.txtFdQuery.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBlockSplChar_KeyPress);
            // 
            // lblFdAmt
            // 
            this.lblFdAmt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFdAmt.AutoSize = true;
            this.lblFdAmt.BackColor = System.Drawing.Color.Transparent;
            this.lblFdAmt.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFdAmt.ForeColor = System.Drawing.Color.Black;
            this.lblFdAmt.Location = new System.Drawing.Point(174, 131);
            this.lblFdAmt.Name = "lblFdAmt";
            this.lblFdAmt.Size = new System.Drawing.Size(88, 18);
            this.lblFdAmt.TabIndex = 188;
            this.lblFdAmt.Text = "Fine Amount";
            // 
            // txtFdAmt
            // 
            this.txtFdAmt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFdAmt.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtFdAmt.Location = new System.Drawing.Point(341, 125);
            this.txtFdAmt.Name = "txtFdAmt";
            this.txtFdAmt.Size = new System.Drawing.Size(69, 25);
            this.txtFdAmt.TabIndex = 183;
            this.txtFdAmt.TextChanged += new System.EventHandler(this.txtFdAmt_TextChanged);
            this.txtFdAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidateNum_KeyPress);
            // 
            // lblFdQuery
            // 
            this.lblFdQuery.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFdQuery.AutoSize = true;
            this.lblFdQuery.BackColor = System.Drawing.Color.Transparent;
            this.lblFdQuery.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFdQuery.ForeColor = System.Drawing.Color.Black;
            this.lblFdQuery.Location = new System.Drawing.Point(176, 190);
            this.lblFdQuery.Name = "lblFdQuery";
            this.lblFdQuery.Size = new System.Drawing.Size(46, 18);
            this.lblFdQuery.TabIndex = 189;
            this.lblFdQuery.Text = "Query";
            // 
            // lblKey
            // 
            this.lblKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblKey.AutoSize = true;
            this.lblKey.BackColor = System.Drawing.Color.Transparent;
            this.lblKey.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey.ForeColor = System.Drawing.Color.Black;
            this.lblKey.Location = new System.Drawing.Point(590, 64);
            this.lblKey.Name = "lblKey";
            this.lblKey.Size = new System.Drawing.Size(0, 18);
            this.lblKey.TabIndex = 180;
            this.lblKey.Visible = false;
            // 
            // mtpReport
            // 
            this.mtpReport.BackColor = System.Drawing.Color.Transparent;
            this.mtpReport.Controls.Add(this.mtcReport);
            this.mtpReport.HorizontalScrollbarBarColor = true;
            this.mtpReport.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpReport.HorizontalScrollbarSize = 10;
            this.mtpReport.Location = new System.Drawing.Point(4, 38);
            this.mtpReport.Name = "mtpReport";
            this.mtpReport.Size = new System.Drawing.Size(764, 339);
            this.mtpReport.TabIndex = 2;
            this.mtpReport.Text = "Report";
            this.mtpReport.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpReport.UseCustomBackColor = true;
            this.mtpReport.VerticalScrollbarBarColor = true;
            this.mtpReport.VerticalScrollbarHighlightOnWheel = false;
            this.mtpReport.VerticalScrollbarSize = 10;
            // 
            // mtcReport
            // 
            this.mtcReport.Controls.Add(this.mtpReportSummery);
            this.mtcReport.Controls.Add(this.metroTabPage1);
            this.mtcReport.Controls.Add(this.metroTabPage2);
            this.mtcReport.FontWeight = MetroFramework.MetroTabControlWeight.Bold;
            this.mtcReport.HotTrack = true;
            this.mtcReport.Location = new System.Drawing.Point(3, 1);
            this.mtcReport.Name = "mtcReport";
            this.mtcReport.SelectedIndex = 1;
            this.mtcReport.Size = new System.Drawing.Size(755, 336);
            this.mtcReport.TabIndex = 33;
            this.mtcReport.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtcReport.UseSelectable = true;
            // 
            // mtpReportSummery
            // 
            this.mtpReportSummery.Controls.Add(this.cbRUserName);
            this.mtpReportSummery.Controls.Add(this.btnReportSmry);
            this.mtpReportSummery.Controls.Add(this.lblToDate);
            this.mtpReportSummery.Controls.Add(this.lblFromDate);
            this.mtpReportSummery.Controls.Add(this.dtToDateRSmry);
            this.mtpReportSummery.Controls.Add(this.dtFromDateRSmry);
            this.mtpReportSummery.Controls.Add(this.metroPanel1);
            this.mtpReportSummery.HorizontalScrollbarBarColor = true;
            this.mtpReportSummery.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpReportSummery.HorizontalScrollbarSize = 10;
            this.mtpReportSummery.Location = new System.Drawing.Point(4, 38);
            this.mtpReportSummery.Name = "mtpReportSummery";
            this.mtpReportSummery.Size = new System.Drawing.Size(747, 294);
            this.mtpReportSummery.TabIndex = 0;
            this.mtpReportSummery.Text = "Report Summery";
            this.mtpReportSummery.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mtpReportSummery.VerticalScrollbarBarColor = true;
            this.mtpReportSummery.VerticalScrollbarHighlightOnWheel = false;
            this.mtpReportSummery.VerticalScrollbarSize = 10;
            // 
            // cbRUserName
            // 
            this.cbRUserName.AllowDrop = true;
            this.cbRUserName.FormattingEnabled = true;
            this.cbRUserName.ItemHeight = 23;
            this.cbRUserName.Location = new System.Drawing.Point(486, 18);
            this.cbRUserName.Name = "cbRUserName";
            this.cbRUserName.PromptText = "Select User Name";
            this.cbRUserName.Size = new System.Drawing.Size(138, 29);
            this.cbRUserName.TabIndex = 36;
            this.cbRUserName.UseSelectable = true;
            this.cbRUserName.SelectedIndexChanged += new System.EventHandler(this.cbRUserName_SelectedIndexChanged);
            // 
            // btnReportSmry
            // 
            this.btnReportSmry.ActiveControl = null;
            this.btnReportSmry.Location = new System.Drawing.Point(646, 18);
            this.btnReportSmry.Name = "btnReportSmry";
            this.btnReportSmry.Size = new System.Drawing.Size(98, 37);
            this.btnReportSmry.TabIndex = 37;
            this.btnReportSmry.Text = "Search";
            this.btnReportSmry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReportSmry.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnReportSmry.UseSelectable = true;
            this.btnReportSmry.Click += new System.EventHandler(this.btnReportSmry_Click);
            // 
            // lblToDate
            // 
            this.lblToDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblToDate.AutoSize = true;
            this.lblToDate.BackColor = System.Drawing.Color.Transparent;
            this.lblToDate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToDate.ForeColor = System.Drawing.Color.Black;
            this.lblToDate.Location = new System.Drawing.Point(249, 23);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(57, 18);
            this.lblToDate.TabIndex = 132;
            this.lblToDate.Text = "To Date";
            // 
            // lblFromDate
            // 
            this.lblFromDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.BackColor = System.Drawing.Color.Transparent;
            this.lblFromDate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFromDate.ForeColor = System.Drawing.Color.Black;
            this.lblFromDate.Location = new System.Drawing.Point(0, 23);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Size = new System.Drawing.Size(73, 18);
            this.lblFromDate.TabIndex = 131;
            this.lblFromDate.Text = "From Date";
            // 
            // dtToDateRSmry
            // 
            this.dtToDateRSmry.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtToDateRSmry.CustomFormat = "dd/MMM/yyyy";
            this.dtToDateRSmry.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.dtToDateRSmry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtToDateRSmry.Location = new System.Drawing.Point(338, 18);
            this.dtToDateRSmry.Name = "dtToDateRSmry";
            this.dtToDateRSmry.Size = new System.Drawing.Size(118, 25);
            this.dtToDateRSmry.TabIndex = 35;
            this.dtToDateRSmry.Value = new System.DateTime(2015, 12, 16, 0, 0, 0, 0);
            // 
            // dtFromDateRSmry
            // 
            this.dtFromDateRSmry.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFromDateRSmry.CustomFormat = "dd/MMM/yyyy";
            this.dtFromDateRSmry.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.dtFromDateRSmry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtFromDateRSmry.Location = new System.Drawing.Point(99, 18);
            this.dtFromDateRSmry.Name = "dtFromDateRSmry";
            this.dtFromDateRSmry.Size = new System.Drawing.Size(119, 25);
            this.dtFromDateRSmry.TabIndex = 34;
            this.dtFromDateRSmry.Value = new System.DateTime(2015, 12, 16, 0, 0, 0, 0);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.grdRSummery);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(8, 65);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(731, 226);
            this.metroPanel1.TabIndex = 4;
            this.metroPanel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // grdRSummery
            // 
            this.grdRSummery.AllowUserToAddRows = false;
            this.grdRSummery.AllowUserToDeleteRows = false;
            this.grdRSummery.AllowUserToResizeRows = false;
            this.grdRSummery.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grdRSummery.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdRSummery.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdRSummery.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grdRSummery.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grdRSummery.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.grdRSummery.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdRSummery.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.grdRSummery.ColumnHeadersHeight = 30;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdRSummery.DefaultCellStyle = dataGridViewCellStyle10;
            this.grdRSummery.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdRSummery.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdRSummery.EnableHeadersVisualStyles = false;
            this.grdRSummery.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grdRSummery.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdRSummery.Location = new System.Drawing.Point(0, 0);
            this.grdRSummery.MultiSelect = false;
            this.grdRSummery.Name = "grdRSummery";
            this.grdRSummery.ReadOnly = true;
            this.grdRSummery.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdRSummery.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.grdRSummery.RowHeadersVisible = false;
            this.grdRSummery.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            this.grdRSummery.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.grdRSummery.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdRSummery.Size = new System.Drawing.Size(731, 226);
            this.grdRSummery.StandardTab = true;
            this.grdRSummery.TabIndex = 3;
            this.grdRSummery.TabStop = false;
            this.grdRSummery.Theme = MetroFramework.MetroThemeStyle.Light;
            this.grdRSummery.UseCustomBackColor = true;
            this.grdRSummery.UseCustomForeColor = true;
            this.grdRSummery.UseStyleColors = true;
            this.grdRSummery.VirtualMode = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.cmbRmth);
            this.metroTabPage1.Controls.Add(this.cmbRYear);
            this.metroTabPage1.Controls.Add(this.pnlRcal);
            this.metroTabPage1.Controls.Add(this.btnRCal);
            this.metroTabPage1.Controls.Add(this.lblMonth);
            this.metroTabPage1.Controls.Add(this.lblYear);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(747, 294);
            this.metroTabPage1.TabIndex = 1;
            this.metroTabPage1.Text = "Report Calculation";
            this.metroTabPage1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // cmbRmth
            // 
            this.cmbRmth.FormattingEnabled = true;
            this.cmbRmth.ItemHeight = 23;
            this.cmbRmth.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbRmth.Location = new System.Drawing.Point(397, 11);
            this.cmbRmth.Name = "cmbRmth";
            this.cmbRmth.Size = new System.Drawing.Size(150, 29);
            this.cmbRmth.TabIndex = 39;
            this.cmbRmth.UseSelectable = true;
            // 
            // cmbRYear
            // 
            this.cmbRYear.FormattingEnabled = true;
            this.cmbRYear.ItemHeight = 23;
            this.cmbRYear.Items.AddRange(new object[] {
            "2017",
            "2018",
            "2019"});
            this.cmbRYear.Location = new System.Drawing.Point(140, 11);
            this.cmbRYear.Name = "cmbRYear";
            this.cmbRYear.Size = new System.Drawing.Size(150, 29);
            this.cmbRYear.TabIndex = 38;
            this.cmbRYear.UseSelectable = true;
            // 
            // pnlRcal
            // 
            this.pnlRcal.Controls.Add(this.grdRCal);
            this.pnlRcal.HorizontalScrollbarBarColor = true;
            this.pnlRcal.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlRcal.HorizontalScrollbarSize = 10;
            this.pnlRcal.Location = new System.Drawing.Point(59, 49);
            this.pnlRcal.Name = "pnlRcal";
            this.pnlRcal.Size = new System.Drawing.Size(638, 245);
            this.pnlRcal.TabIndex = 147;
            this.pnlRcal.Theme = MetroFramework.MetroThemeStyle.Light;
            this.pnlRcal.VerticalScrollbarBarColor = true;
            this.pnlRcal.VerticalScrollbarHighlightOnWheel = false;
            this.pnlRcal.VerticalScrollbarSize = 10;
            // 
            // grdRCal
            // 
            this.grdRCal.AllowUserToAddRows = false;
            this.grdRCal.AllowUserToDeleteRows = false;
            this.grdRCal.AllowUserToResizeRows = false;
            this.grdRCal.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grdRCal.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdRCal.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdRCal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grdRCal.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grdRCal.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.grdRCal.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdRCal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.grdRCal.ColumnHeadersHeight = 30;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdRCal.DefaultCellStyle = dataGridViewCellStyle14;
            this.grdRCal.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grdRCal.EnableHeadersVisualStyles = false;
            this.grdRCal.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grdRCal.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grdRCal.Location = new System.Drawing.Point(0, 0);
            this.grdRCal.MultiSelect = false;
            this.grdRCal.Name = "grdRCal";
            this.grdRCal.ReadOnly = true;
            this.grdRCal.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdRCal.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.grdRCal.RowHeadersVisible = false;
            this.grdRCal.RowHeadersWidth = 50;
            this.grdRCal.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            this.grdRCal.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.grdRCal.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.grdRCal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdRCal.Size = new System.Drawing.Size(638, 245);
            this.grdRCal.TabIndex = 159;
            this.grdRCal.Theme = MetroFramework.MetroThemeStyle.Light;
            this.grdRCal.UseCustomBackColor = true;
            this.grdRCal.UseCustomForeColor = true;
            this.grdRCal.UseStyleColors = true;
            // 
            // btnRCal
            // 
            this.btnRCal.ActiveControl = null;
            this.btnRCal.Location = new System.Drawing.Point(584, 4);
            this.btnRCal.Name = "btnRCal";
            this.btnRCal.Size = new System.Drawing.Size(127, 40);
            this.btnRCal.TabIndex = 40;
            this.btnRCal.Text = "Search";
            this.btnRCal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRCal.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnRCal.UseSelectable = true;
            this.btnRCal.Click += new System.EventHandler(this.btnRCal_Click);
            // 
            // lblMonth
            // 
            this.lblMonth.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMonth.AutoSize = true;
            this.lblMonth.BackColor = System.Drawing.Color.Transparent;
            this.lblMonth.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonth.ForeColor = System.Drawing.Color.Black;
            this.lblMonth.Location = new System.Drawing.Point(318, 21);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(49, 18);
            this.lblMonth.TabIndex = 143;
            this.lblMonth.Text = "Month";
            // 
            // lblYear
            // 
            this.lblYear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblYear.AutoSize = true;
            this.lblYear.BackColor = System.Drawing.Color.Transparent;
            this.lblYear.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.ForeColor = System.Drawing.Color.Black;
            this.lblYear.Location = new System.Drawing.Point(79, 18);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(35, 18);
            this.lblYear.TabIndex = 142;
            this.lblYear.Text = "Year";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroTile1);
            this.metroTabPage2.Controls.Add(this.txtRsSubject);
            this.metroTabPage2.Controls.Add(this.txtRsQuery);
            this.metroTabPage2.Controls.Add(this.dtRsDate);
            this.metroTabPage2.Controls.Add(this.lblRsDescription);
            this.metroTabPage2.Controls.Add(this.lblRsSubject);
            this.metroTabPage2.Controls.Add(this.lblRsDate);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(747, 294);
            this.metroTabPage2.TabIndex = 2;
            this.metroTabPage2.Text = "Report Sharing";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            this.metroTile1.Location = new System.Drawing.Point(326, 173);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(240, 30);
            this.metroTile1.TabIndex = 187;
            this.metroTile1.Text = "Send";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile1.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.Visible = false;
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click);
            // 
            // txtRsSubject
            // 
            this.txtRsSubject.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtRsSubject.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtRsSubject.Location = new System.Drawing.Point(326, 83);
            this.txtRsSubject.Name = "txtRsSubject";
            this.txtRsSubject.Size = new System.Drawing.Size(240, 25);
            this.txtRsSubject.TabIndex = 186;
            this.txtRsSubject.Visible = false;
            // 
            // txtRsQuery
            // 
            this.txtRsQuery.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtRsQuery.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtRsQuery.Location = new System.Drawing.Point(326, 122);
            this.txtRsQuery.Multiline = true;
            this.txtRsQuery.Name = "txtRsQuery";
            this.txtRsQuery.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtRsQuery.Size = new System.Drawing.Size(240, 36);
            this.txtRsQuery.TabIndex = 185;
            this.txtRsQuery.Visible = false;
            // 
            // dtRsDate
            // 
            this.dtRsDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtRsDate.Checked = false;
            this.dtRsDate.CustomFormat = "dd/MMM/yyyy";
            this.dtRsDate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold);
            this.dtRsDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtRsDate.Location = new System.Drawing.Point(326, 46);
            this.dtRsDate.Name = "dtRsDate";
            this.dtRsDate.Size = new System.Drawing.Size(240, 25);
            this.dtRsDate.TabIndex = 183;
            this.dtRsDate.Visible = false;
            // 
            // lblRsDescription
            // 
            this.lblRsDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRsDescription.AutoSize = true;
            this.lblRsDescription.BackColor = System.Drawing.Color.Transparent;
            this.lblRsDescription.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRsDescription.ForeColor = System.Drawing.Color.Black;
            this.lblRsDescription.Location = new System.Drawing.Point(189, 140);
            this.lblRsDescription.Name = "lblRsDescription";
            this.lblRsDescription.Size = new System.Drawing.Size(79, 18);
            this.lblRsDescription.TabIndex = 170;
            this.lblRsDescription.Text = "Description";
            this.lblRsDescription.Visible = false;
            // 
            // lblRsSubject
            // 
            this.lblRsSubject.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRsSubject.AutoSize = true;
            this.lblRsSubject.BackColor = System.Drawing.Color.Transparent;
            this.lblRsSubject.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRsSubject.ForeColor = System.Drawing.Color.Black;
            this.lblRsSubject.Location = new System.Drawing.Point(189, 90);
            this.lblRsSubject.Name = "lblRsSubject";
            this.lblRsSubject.Size = new System.Drawing.Size(53, 18);
            this.lblRsSubject.TabIndex = 169;
            this.lblRsSubject.Text = "Subject";
            this.lblRsSubject.Visible = false;
            // 
            // lblRsDate
            // 
            this.lblRsDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRsDate.AutoSize = true;
            this.lblRsDate.BackColor = System.Drawing.Color.Transparent;
            this.lblRsDate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRsDate.ForeColor = System.Drawing.Color.Black;
            this.lblRsDate.Location = new System.Drawing.Point(189, 51);
            this.lblRsDate.Name = "lblRsDate";
            this.lblRsDate.Size = new System.Drawing.Size(37, 18);
            this.lblRsDate.TabIndex = 168;
            this.lblRsDate.Text = "Date";
            this.lblRsDate.Visible = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(286, 14);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(180, 19);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Fine Management System";
            this.lblTitle.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblTitle.UseCustomBackColor = true;
            this.lblTitle.UseCustomForeColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::FMS.Presentation.Properties.Resources._1489955466_User;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(256, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 28);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.ApplyImageInvert = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BackImagePadding = new System.Windows.Forms.Padding(210, 10, 0, 0);
            this.BackMaxSize = 50;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(777, 422);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.mtc);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.None;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.mtc.ResumeLayout(false);
            this.mtpPersonalDetails.ResumeLayout(false);
            this.mtc2.ResumeLayout(false);
            this.mtpSummery.ResumeLayout(false);
            this.metroPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdPdSummery)).EndInit();
            this.mtpAddPr.ResumeLayout(false);
            this.mtpAddPr.PerformLayout();
            this.mtpEditpr.ResumeLayout(false);
            this.mtpEditpr.PerformLayout();
            this.pnlplEdit.ResumeLayout(false);
            this.pnlplEdit.PerformLayout();
            this.mtpFineDetails.ResumeLayout(false);
            this.mtcPe.ResumeLayout(false);
            this.mtpItemDetails.ResumeLayout(false);
            this.metroPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdFineSummary)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.mtpReport.ResumeLayout(false);
            this.mtcReport.ResumeLayout(false);
            this.mtpReportSummery.ResumeLayout(false);
            this.mtpReportSummery.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdRSummery)).EndInit();
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.pnlRcal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdRCal)).EndInit();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl mtc;
        private MetroFramework.Controls.MetroTabPage mtpPersonalDetails;
        private MetroFramework.Controls.MetroTabPage mtpFineDetails;
        private MetroFramework.Controls.MetroTabPage mtpReport;
        private MetroFramework.Controls.MetroLabel lblTitle;
        private MetroFramework.Controls.MetroTabControl mtc2;
        private MetroFramework.Controls.MetroTabPage mtpSummery;
        private MetroFramework.Controls.MetroTabPage mtpAddPr;
        private System.Windows.Forms.Label lblAddCno;
        public System.Windows.Forms.TextBox txtAddName;
        private System.Windows.Forms.Label lblAddAddress;
        private System.Windows.Forms.Label lblAddName;
        private System.Windows.Forms.Label lblAddFName;
        private MetroFramework.Controls.MetroTile btnAddPr;
        public System.Windows.Forms.TextBox txtAddEmail;
        public System.Windows.Forms.TextBox txtAddFName;
        public System.Windows.Forms.MaskedTextBox txtAddCNo;
        private System.Windows.Forms.Label lblAddEmailID;
        private MetroFramework.Controls.MetroTabPage mtpEditpr;
        private System.Windows.Forms.Label lblEditName;
        private MetroFramework.Controls.MetroGrid grdPdSummery;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroPanel pnlplEdit;
        private MetroFramework.Controls.MetroTile btnUpdate;
        private MetroFramework.Controls.MetroCheckBox cbEditActive;
        private System.Windows.Forms.Label lblEditCno;
        private System.Windows.Forms.Label lblEditAddress;
        private System.Windows.Forms.Label lblEditFName;
        public System.Windows.Forms.TextBox txtEditEmail;
        public System.Windows.Forms.TextBox txtEditAddress;
        public System.Windows.Forms.TextBox txtEditFName;
        public System.Windows.Forms.MaskedTextBox txtEditCNo;
        private System.Windows.Forms.Label lblEditEmailID;
        private MetroFramework.Controls.MetroComboBox cbEditName;
        private MetroFramework.Controls.MetroTabControl mtcReport;
        private MetroFramework.Controls.MetroTabPage mtpReportSummery;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroGrid grdRSummery;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.Label lblFromDate;
        public System.Windows.Forms.DateTimePicker dtToDateRSmry;
        public System.Windows.Forms.DateTimePicker dtFromDateRSmry;
        private MetroFramework.Controls.MetroTile btnReportSmry;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTile btnRCal;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Label lblYear;
        private MetroFramework.Controls.MetroPanel pnlRcal;
        private MetroFramework.Controls.MetroTabControl mtcPe;
        private MetroFramework.Controls.MetroTabPage mtpItemDetails;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroGrid grdRCal;
        private MetroFramework.Controls.MetroComboBox cmbRYear;
        private MetroFramework.Controls.MetroComboBox cmbRmth;
        private MetroFramework.Controls.MetroComboBox cbRUserName;
        private System.Windows.Forms.Label lblKey;
        private MetroFramework.Controls.MetroCheckBox cbAddActive;
        public System.Windows.Forms.TextBox txtAddAddress;
        private System.Windows.Forms.Label lblPdEditId;
        public System.Windows.Forms.DateTimePicker txtfdDate;
        private MetroFramework.Controls.MetroTile btnAddPurchasedDetails;
        private System.Windows.Forms.Label lblFdName;
        private System.Windows.Forms.Label lblFdDate;
        public System.Windows.Forms.TextBox txtFdQuery;
        private System.Windows.Forms.Label lblFdAmt;
        public System.Windows.Forms.TextBox txtFdAmt;
        private System.Windows.Forms.Label lblFdQuery;
        private MetroFramework.Controls.MetroComboBox cbFdName;
        public System.Windows.Forms.TextBox txtFdTotalAmt;
        public System.Windows.Forms.TextBox txtFdPerviousAmt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblFdId;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroGrid grdFineSummary;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTile metroTile1;
        public System.Windows.Forms.TextBox txtRsSubject;
        public System.Windows.Forms.TextBox txtRsQuery;
        public System.Windows.Forms.DateTimePicker dtRsDate;
        private System.Windows.Forms.Label lblRsDescription;
        private System.Windows.Forms.Label lblRsSubject;
        private System.Windows.Forms.Label lblRsDate;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}