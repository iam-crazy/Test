﻿using FMS.Bussiness;
using FMS.Model;
using MetroFramework;
using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FMS.Presentation
{
    public partial class Form1 : MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            grdPdSummery.DataSource = PersonalDetails.FunForPlGridSummery();
            FunForPlCmbEditName();
            cbEditActive_CheckedChanged(null, null);
            cbAddActive_CheckedChanged(null, null);
            grdFineSummary.DataSource = PersonalDetails.FunForFdFineDetails(DateTime.Now.ToString("dd/MMM/yyyy"));
            cbRUserName.SelectedIndex = 0;
            cmbRYear.SelectedIndex = cmbRmth.SelectedIndex = 0;
            dtFromDateRSmry.Text = dtToDateRSmry.Text = DateTime.Now.ToString("dd/MMM/yyyy");
        }
        public void FunForPlCmbEditName()
        {
            List<PersonalDetailsModel> objLstPdUser = new List<PersonalDetailsModel>();
            objLstPdUser = PersonalDetails.FunForPlGridSummery();

            List<PersonalDetailsModel> objLstPdUserTemp = new List<PersonalDetailsModel>();
            objLstPdUserTemp.Add(new PersonalDetailsModel
            {
                Name = "Select User Name"
            });
            if (objLstPdUser.Count > 0)
            {
                objLstPdUserTemp = objLstPdUserTemp.Concat(objLstPdUser).ToList();
            }

            List<PersonalDetailsModel> objLstPdActiveUser = new List<PersonalDetailsModel>();
            objLstPdActiveUser = PersonalDetails.FunForPdActiveUser();
            List<PersonalDetailsModel> objLstPdActiveUserTemp = new List<PersonalDetailsModel>();
            objLstPdActiveUserTemp.Add(new PersonalDetailsModel
            {
                Name = "Select User Name"
            });
            if (objLstPdActiveUser.Count > 0)
            {
                objLstPdActiveUserTemp = objLstPdActiveUserTemp.Concat(objLstPdActiveUser).ToList();
            }

            cbEditName.DataSource = objLstPdUserTemp;
            cbEditName.DisplayMember = "Name";
            cbEditName.ValueMember = "Name";

            cbFdName.DataSource = objLstPdActiveUserTemp;
            cbFdName.DisplayMember = "Name";
            cbFdName.ValueMember = "Name";
            pnlplEdit.Visible = false;

            cbRUserName.DataSource = objLstPdActiveUserTemp;
            cbRUserName.DisplayMember = "Name";
            cbRUserName.ValueMember = "Name";
        }
        private void btnAddPr_Click(object sender, EventArgs e)
        {

            if (txtAddName.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Name ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddName.Focus();
                return;
            }
            if (!PersonalDetails.FunForValidateName(txtAddName.Text))
            {
                MetroMessageBox.Show(this, " Name is already exist ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddName.Text = "";
                txtAddName.Focus();
                return;
            }
            if (txtAddFName.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Father's Name ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddFName.Focus();
                return;
            }
            if (txtAddAddress.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Address ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddAddress.Focus();
                return;
            }
            if (txtAddCNo.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Contact No ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddCNo.Focus();
                return;
            }
            if (!PersonalDetails.FunForValidateContactNo(txtAddCNo.Text))
            {
                MetroMessageBox.Show(this, " Contact No is already exist ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddCNo.Text = "";
                txtAddCNo.Focus();
                return;
            }
            if (txtAddEmail.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Email Id ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddEmail.Focus();
                return;
            }
            if (!IsValidEmailAddress(txtAddEmail.Text))
            {
                MetroMessageBox.Show(this, " Please Enter valid Email Id ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddEmail.Focus();
                return;
            }
            if (!PersonalDetails.FunForValidateEmailId(txtAddEmail.Text))
            {
                MetroMessageBox.Show(this, " Email Id is already exist ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddEmail.Text = "";
                txtAddEmail.Focus();
                return;
            }

            try
            {
                PersonalDetailsModel objPdModel = new PersonalDetailsModel()
                {
                    Address = txtAddAddress.Text,
                    EmailID = txtAddEmail.Text,
                    FatherName = txtAddFName.Text,
                    Name = txtAddName.Text,
                    PhoneNumber = txtAddCNo.Text,
                    Status = cbAddActive.Checked
                };
                PersonalDetails.FunForPersonalDetailsInsert(objPdModel);
                FunForRefreshPlAdd();
                MetroMessageBox.Show(this, " Personal Details Inserted Sucessfully ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, " Personal Details Not Inserted Sucessfully " + ex.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public bool IsValidEmailAddress(string email)
        {
            try
            {
                MailAddress ma = new MailAddress(email);

                return true;
            }
            catch
            {
                return false;
            }
        }
        public void FunForRefreshPlAdd()
        {
            txtAddName.Text = txtAddFName.Text = txtAddAddress.Text = txtAddCNo.Text = txtAddEmail.Text = string.Empty;
            cbAddActive.Checked = true;
            Form1_Load(null, null);
        }
        private void cbEditName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbEditName.SelectedIndex != 0)
            {
                pnlplEdit.Visible = true;
                List<PersonalDetailsModel> objLstPdUser = PersonalDetails.FunForPdUserDetails(cbEditName.SelectedValue.ToString());

                foreach (var item in objLstPdUser)
                {
                    lblPdEditId.Text = Convert.ToString(item.Id);
                    txtEditFName.Text = item.FatherName;
                    txtEditAddress.Text = item.Address;
                    txtEditCNo.Text = item.PhoneNumber;
                    txtEditEmail.Text = item.EmailID;
                    cbEditActive.Checked = item.Status;
                    cbEditActive.Text = item.Status == true ? "Active" : "InActive";
                    cbEditActive.ForeColor = item.Status == true ? Color.Green : Color.Red;
                }
            }
            else
            {
                FunForRefreshPlEdit();
            }
        }
        public void FunForRefreshPlEdit()
        {
            cbEditName.SelectedIndex = 0;
            pnlplEdit.Visible = false;
            cbAddActive.Checked = true;
            txtEditFName.Text = txtEditAddress.Text = txtEditCNo.Text = txtEditEmail.Text = string.Empty;
            Form1_Load(null, null);
        }

        private void cbEditActive_CheckedChanged(object sender, EventArgs e)
        {
            cbEditActive.Text = cbEditActive.Checked ? "Active" : "InActive";
            cbEditActive.ForeColor = cbEditActive.Checked ? Color.Green : Color.Red;
        }

        private void cbAddActive_CheckedChanged(object sender, EventArgs e)
        {
            cbAddActive.Text = cbAddActive.Checked ? "Active" : "InActive";
            cbAddActive.ForeColor = cbAddActive.Checked ? Color.Green : Color.Red;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (cbEditName.SelectedIndex == 0)
            {
                MetroMessageBox.Show(this, " Please Select Name ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cbEditName.Focus();
                return;
            }
            if (txtEditFName.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Father's Name ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEditFName.Focus();
                return;
            }
            if (txtEditAddress.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Address ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEditAddress.Focus();
                return;
            }
            if (txtEditCNo.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Contact No ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEditCNo.Focus();
                return;
            }
            if (!PersonalDetails.FunForValidateContactNo(txtEditCNo.Text, cbEditName.Text))
            {
                MetroMessageBox.Show(this, " Contact No is already exist ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEditCNo.Text = "";
                txtEditCNo.Focus();
                return;
            }
            if (txtEditEmail.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Email id ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEditEmail.Focus();
                return;
            }
            if (!IsValidEmailAddress(txtEditEmail.Text))
            {
                MetroMessageBox.Show(this, " Please Enter valid Email Id ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddEmail.Focus();
                return;
            }
            if (!PersonalDetails.FunForValidateEmailId(txtEditEmail.Text, cbEditName.Text))
            {
                MetroMessageBox.Show(this, " Email Id is already exist ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEditEmail.Text = "";
                txtEditEmail.Focus();
                return;
            }
            try
            {
                PersonalDetailsModel objPdModel = new PersonalDetailsModel()
                {
                    Id = Convert.ToInt64(lblPdEditId.Text),
                    Address = txtEditAddress.Text,
                    EmailID = txtEditEmail.Text,
                    FatherName = txtEditFName.Text,
                    Name = cbEditName.Text,
                    PhoneNumber = txtEditCNo.Text,
                    Status = cbEditActive.Checked
                };
                PersonalDetails.FunForPersonalDetailsUpdate(objPdModel, cbEditName.Text);
                FunForRefreshPlEdit();
                MetroMessageBox.Show(this, " Personal Details Updated Sucessfully ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                FunForRefreshPlEdit();
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, ex.Message.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbFdName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFdName.SelectedIndex != 0 && txtfdDate.Text != "")
            {
                List<FineDetails> objLstPdUser = PersonalDetails.FunForFdFineDetails(cbFdName.SelectedValue.ToString(), txtfdDate.Text);

                if (objLstPdUser.Count > 0)
                {
                    foreach (var item in objLstPdUser)
                    {
                        lblFdId.Text = Convert.ToString(item.Id);
                        txtFdTotalAmt.Text = txtFdPerviousAmt.Text = item.FineAmount;
                        txtFdAmt.Text = "0";
                        txtfdDate.Text = (item.FineDate == null ? DateTime.Now.ToString("dd/MMM/yyyy") : item.FineDate.ToString("dd/MMM/yyyy"));
                        txtFdQuery.Text = item.Query;
                    }
                }
                else
                {
                    txtFdAmt.Text = txtFdTotalAmt.Text = txtFdPerviousAmt.Text = "0";
                    lblFdId.Text = txtFdQuery.Text = "";
                    txtfdDate.Text = (txtfdDate.Text == "" ? DateTime.Now.ToString("dd/MMM/yyyy") : txtfdDate.Text.ToString());
                }
            }
            else
            {
                txtFdAmt.Text = txtFdTotalAmt.Text = txtFdPerviousAmt.Text = "0";
                lblFdId.Text = txtFdQuery.Text = "";
                txtfdDate.Text = (txtfdDate.Text == "" ? DateTime.Now.ToString("dd/MMM/yyyy") : txtfdDate.Text.ToString());
            }
        }

        private void txtfdDate_ValueChanged(object sender, EventArgs e)
        {
            if (cbFdName.SelectedIndex != 0 && txtfdDate.Text != "")
            {
                List<FineDetails> objLstPdUser = PersonalDetails.FunForFdFineDetails(cbFdName.SelectedValue.ToString(), txtfdDate.Text);

                if (objLstPdUser.Count > 0)
                {
                    foreach (var item in objLstPdUser)
                    {
                        lblFdId.Text = Convert.ToString(item.Id);
                        txtFdAmt.Text = "0";
                        txtFdTotalAmt.Text = txtFdPerviousAmt.Text = item.FineAmount;
                        txtfdDate.Text = (item.FineDate == null ? DateTime.Now.ToString("dd/MMM/yyyy") : item.FineDate.ToString("dd/MMM/yyyy"));
                        txtFdQuery.Text = item.Query;
                    }
                }
                else
                {
                    FunForRefreshFdEdit();
                }
            }
            else
            {
                FunForRefreshFdEdit();
            }
        }

        private void txtFdAmt_TextChanged(object sender, EventArgs e)
        {
            txtFdTotalAmt.Text = ((Convert.ToInt64((txtFdPerviousAmt.Text == "" ? "0" : txtFdPerviousAmt.Text))) + ((Convert.ToInt64((txtFdAmt.Text == "" ? "0" : (txtFdAmt.Text == "-" ? "0" : txtFdAmt.Text)))))).ToString();
        }

        private void btnAddPurchasedDetails_Click(object sender, EventArgs e)
        {
            if (cbFdName.SelectedIndex == 0)
            {
                MetroMessageBox.Show(this, " Please Select Name ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cbFdName.Focus();
                return;
            }
            if (txtfdDate.Text == "")
            {
                MetroMessageBox.Show(this, " Please Select Fine Date ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtfdDate.Focus();
                return;
            }
            if (txtFdTotalAmt.Text == "" || txtFdAmt.Text == "0" || txtFdAmt.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter Fine Amount ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFdAmt.Focus();
                return;
            }
            if (txtFdQuery.Text == "")
            {
                MetroMessageBox.Show(this, " Please Enter query ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFdQuery.Focus();
                return;
            }
            try
            {
                FineDetails objPdModel = new FineDetails()
                {
                    Id = Convert.ToInt64(lblFdId.Text == "" ? "0" : lblFdId.Text),
                    FineAmount = txtFdTotalAmt.Text,
                    FineDate = Convert.ToDateTime(txtfdDate.Text),
                    Query = txtFdQuery.Text,
                    Name = cbFdName.Text
                };
                PersonalDetails.FunForFineDetailsUpdate(objPdModel);
                FunForRefreshFdEdit();
                cbFdName.SelectedIndex = 0;
                MetroMessageBox.Show(this, " Fine Details Updated Sucessfully ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, ex.Message.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FunForRefreshFdEdit()
        {
            txtFdAmt.Text = txtFdTotalAmt.Text = txtFdPerviousAmt.Text = "0";
            lblFdId.Text = txtFdQuery.Text = "";
            txtfdDate.Text = (txtfdDate.Text == "" ? DateTime.Now.ToString("dd/MMM/yyyy") : txtfdDate.Text.ToString());
            grdFineSummary.DataSource = PersonalDetails.FunForFdFineDetails(DateTime.Now.ToString("dd/MMM/yyyy"));
        }

        private void txtValidateNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            FunForValidateNumber(e);
        }
        private void txtValidateAlphabet_KeyPress(object sender, KeyPressEventArgs e)
        {
            FunForValidateAlphabet(e);
        }
        private void txtBlockSplChar_KeyPress(object sender, KeyPressEventArgs e)
        {
            FunForValidateSplChar(e);
        }
        private void txtValidateDecimal_KeyPress(object sender, KeyPressEventArgs e)
        {
            FunForValidateDecimal(e);
        }
        private void FunForValidateAlphabet(KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z\s]");
            if (regex.IsMatch(e.KeyChar.ToString()) & (Keys)e.KeyChar != Keys.Back & (Keys)e.KeyChar != Keys.Delete & e.KeyChar != '.')
            {
                e.Handled = true;
            }
            base.OnKeyPress(e);
        }
        private void FunForValidateSplChar(KeyPressEventArgs e)
        {
            var regex = new Regex(@"[^a-zA-Z0-9\s]");
            if (regex.IsMatch(e.KeyChar.ToString()) & (Keys)e.KeyChar != Keys.Back & (Keys)e.KeyChar != Keys.Delete & e.KeyChar != '.' & e.KeyChar != ',' & e.KeyChar != ')' & e.KeyChar != '(')
            {
                e.Handled = true;
            }
            base.OnKeyPress(e);
        }
        private void FunForValidateDecimal(KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back
                                 & e.KeyChar != '.')
            {
                e.Handled = true;
            }
            base.OnKeyPress(e);
        }
        private void FunForValidateNumber(KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
            base.OnKeyPress(e);
        }

        private void btnReportSmry_Click(object sender, EventArgs e)
        {
            if (dtFromDateRSmry.Text == "")
            {
                MetroMessageBox.Show(this, " Please Select From Date ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtFromDateRSmry.Focus();
                return;
            }
            if (dtToDateRSmry.Text == "")
            {
                MetroMessageBox.Show(this, " Please Select From Date ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtToDateRSmry.Focus();
                return;
            }
            string objUserName = "";
            if (cbRUserName.SelectedIndex != 0)
            {
                objUserName = cbRUserName.Text;
            }
            grdRSummery.DataSource = PersonalDetails.FunForReportSummery(dtFromDateRSmry.Text, dtToDateRSmry.Text, objUserName);
        }

        private void cbRUserName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnRCal_Click(object sender, EventArgs e)
        {
            string objFromDate = "1/" + cmbRmth.Text + "/" + cmbRYear.Text;
            string objToDate = DateTime.DaysInMonth(Convert.ToInt16(cmbRYear.Text), Convert.ToInt16(cmbRmth.Text)).ToString() + "/" + cmbRmth.Text + "/" + cmbRYear.Text;
            grdRCal.DataSource = PersonalDetails.FunForReportCalCulation(objFromDate, objToDate);
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            if (dtRsDate.Text == "")
            {
                MetroMessageBox.Show(this, " Please select Date ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtRsDate.Focus();
                return;
            }
            if (PersonalDetails.FunForValidateReportSendingDate(dtRsDate.Text))
            {
                MetroMessageBox.Show(this, "Mail had been sent Already", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtRsDate.Focus();
                return;
            }
            if (txtRsSubject.Text == "")
            {
                MetroMessageBox.Show(this, " Please enter subject ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRsSubject.Focus();
                return;
            }
            if (txtRsQuery.Text == "")
            {
                MetroMessageBox.Show(this, " Please enter Query ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRsQuery.Focus();
                return;
            }
            DataTable objDtToday = new DataTable();
            objDtToday = PersonalDetails.FunForDtFdFineDetails(DateTime.Now.ToString("dd/MMM/yyyy"));
            DataTable objDtThisMonth = new DataTable();
            string objFromDate = "1/" + DateTime.Now.Month + "/" + DateTime.Now.Year;
            string objToDate = DateTime.DaysInMonth(Convert.ToInt16(DateTime.Now.Month), Convert.ToInt16(DateTime.Now.Year)).ToString() + "/" + DateTime.Now.Month + "/" + DateTime.Now.Year;
            objDtThisMonth = PersonalDetails.FunForDtReportCalCulation(objFromDate, objToDate);
            string objhtml = "<!DOCTYPE html>< html lang = 'en' >< head >< meta charset = 'utf-8' />< title ></ title ></ head >< body >< div style = 'font-family: Calibri; font-size: 14px;  min-height: 100%; line-height: 1.6em; background-color: #f6f6f6; margin: 0;' >< table style = 'font-family: Calibri; font-size: 14px; width: 100%; background-color: #f6f6f6; margin: 0;' >< tbody >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0;' ></ td >< td style = 'width: 600px; font-family: Calibri; font-size: 14px; vertical-align: top;    margin: 0 auto;' >< div style = 'font-family: Calibri; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;' >< table style = 'width: 100%; font-family: Calibri; font-size: 14px; border-radius: 3px; background-color: #fff; margin: 0; border: 1px solid #e9e9e9;' >< tbody >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 16px; vertical-align: top; color: #fff; font-weight: 500; text-align: left; border-radius: 3px 3px 0 0; background-color: #125A72; margin: 0; padding: 20px;' >< label style = 'font-size: 36px;font-family: Impact;color: #fff;' > ESR - Fine Management System</ label ></ td ></ tr >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0; padding: 20px;' >< table style = 'width: 100%; font-family: Calibri; font-size: 14px; margin: 0;' >< tbody >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 18px; vertical-align: top; margin: 0; padding: 0 0 20px;' > Dear All,</ td ></ tr >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' > " + txtRsQuery.Text + "</ td ></ tr >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' > Fine Details on " + DateTime.Now.ToString("dd/MMM/yyyy") + " " + PersonalDetails.ConvertDataTableToHTML(objDtToday) + "  </ td ></ tr >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' > Overall Fine Details for this month " + PersonalDetails.ConvertDataTableToHTML(objDtThisMonth) + "       </ td ></ tr >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' > Thanking You,< br >< i >< span > ESR </ span > Team </ i >< br >< br > Please do not reply to this mail - id, It is an automated mail.</ td ></ tr >< tr style = 'font-family: Calibri; font-size: 14px; margin: 0;' >< td style = 'font-family: Calibri; font-size: 12px; line-height: 16px; color: #aaa; vertical-align: top; margin: 0; padding: 20px 0 20px; border-top: 1px #ccc solid; text-align: center;color: #125A72;' > All rights reserved © Esr team. </ td ></ tr ></ tbody ></ table ></ td ></ tr ></ tbody ></ table ></ div ></ td >< td style = 'font-family: Calibri; font-size: 14px; vertical-align: top; margin: 0;' ></ td ></ tr ></ tbody ></ table ></ div ></ body ></ html > ";

        }
    }
}
