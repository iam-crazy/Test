﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FMS.Presentation
{
    public partial class LoadingPannel : Form
    {
        public LoadingPannel()
        {
            InitializeComponent();
        }

        //private static LoadingPannel ms_frmSplash = null;
        //private static Thread ms_oThread = null;
        //private const int TIMER_INTERVAL = 50;

        //static public void ShowSplashScreen()
        //{
        //    try
        //    {
        //        // Make sure it's only launched once.
        //        if (ms_frmSplash != null)
        //            return;
        //        ms_oThread = new Thread(new ThreadStart(LoadingPannel.ShowForm));
        //        ms_oThread.IsBackground = true;
        //        ms_oThread.SetApartmentState(ApartmentState.STA);
        //        ms_oThread.Start();
        //        while (ms_frmSplash == null || ms_frmSplash.IsHandleCreated == false)
        //        {
        //            System.Threading.Thread.Sleep(TIMER_INTERVAL);
        //        }
        //    }
        //    catch (ThreadAbortException)
        //    {
        //    }
        //}

        //static public void ShowForm()
        //{
        //    try
        //    {
        //        ms_frmSplash = new LoadingPannel();
        //        if (ms_oThread.Name != null)
        //        {
        //            Application.Run(ms_frmSplash);
        //        }
                
        //    }
        //    catch (ThreadAbortException ex)
        //    {
        //    }
        //    catch (Exception)
        //    { }
        //}

        //static public void CloseForm()
        //{
        //    try
        //    {
        //        ms_oThread.Abort(); ms_oThread.Join();
        //        ms_oThread = null;
        //        ms_frmSplash = null;
        //    }
        //    catch (ThreadAbortException)
        //    {

        //        throw;
        //    }

        //}
        //        #region Member Variables
        //        private static LoadingPannel ms_frmSplash = null;
        //        private static Thread ms_oThread = null;

        //        private const int TIMER_INTERVAL = 50;

        //        #endregion Member Variables

        //        static private void ShowForm()
        //        {
        //            try
        //            {
        //                ms_frmSplash = new LoadingPannel();
        //                Application.Run(new LoadingPannel());

        //            }
        //            catch (ThreadAbortException ex)
        //            {

        //            }
        //            catch (Exception ex)
        //            { 
        //            }
        //        }
        //        static public void ShowScreen()
        //        { try
        //            {
        //            if (ms_frmSplash != null)
        //                ms_frmSplash = null;
        //            ms_oThread = new Thread(new ThreadStart(LoadingPannel.ShowForm));
        //            ms_oThread.IsBackground = true;
        //            ms_oThread.SetApartmentState(ApartmentState.STA);
        //            ms_oThread.Start();
        //            while (ms_frmSplash == null ||
        //ms_frmSplash.IsHandleCreated == false)
        //            {
        //                System.Threading.Thread.Sleep(TIMER_INTERVAL);
        //            }
        //            }
        //        catch (ThreadAbortException ex)
        //        {

        //        }
        //        }

        //        static public void CloseForm()
        //        {
        //            try
        //            {
        //            ms_oThread.Abort(); }
        //            catch (ThreadAbortException ex)
        //            {

        //            }
        //        }
    }
}
